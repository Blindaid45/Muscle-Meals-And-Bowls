# Affiliate System Documentation

## Overview

The affiliate system allows users to become affiliates and earn commissions by referring customers to the meal subscription service. The system includes coupon code generation, validation, discount application, and automatic commission processing.

## Features

### 🎯 Core Features

- **Affiliate Registration**: Users can create affiliate accounts with custom promo codes
- **Coupon Code System**: Automatic generation of unique coupon codes with MMB suffix
- **Discount Application**: Automatic discount calculation (10% for monthly, 5% for weekly)
- **Commission Processing**: Automatic commission calculation and wallet credit
- **Real-time Tracking**: Dashboard for affiliates to track earnings and referrals
- **Robust Validation**: Prevents self-referrals and duplicate coupon codes

### 💰 Commission Structure

- **Monthly Subscriptions**: 10% commission to affiliate, 10% discount to customer
- **Weekly Subscriptions**: 5% commission to affiliate, 5% discount to customer
- **Payment Processing**: Automatic wallet credit within 24-48 hours

## Architecture

### Frontend Components

#### 1. AffiliateRegistrationForm

- **Location**: `src/components/affiliate/AffiliateRegistrationForm.tsx`
- **Purpose**: Allows users to create affiliate accounts
- **Features**:
  - Custom promo code input with MMB suffix
  - UPI ID validation
  - Real-time form validation
  - Error handling and loading states

#### 2. AffiliateDashboard

- **Location**: `src/components/affiliate/AffiliateDashboard.tsx`
- **Purpose**: Main dashboard for affiliates
- **Features**:
  - Earnings overview and statistics
  - Referral history tracking
  - Coupon code sharing
  - Monthly performance metrics

#### 3. CouponValidationForm

- **Location**: `src/components/affiliate/CouponValidationForm.tsx`
- **Purpose**: Validates and applies coupon codes during subscription
- **Features**:
  - Real-time coupon validation
  - Discount calculation display
  - Integration with subscription flow
  - Error handling for invalid codes

### Backend Functions

#### 1. processCouponUsage

- **Purpose**: Records coupon usage and creates commission records
- **Trigger**: Called after successful subscription creation
- **Process**:
  1. Validates coupon usage data
  2. Calculates commission amount
  3. Creates coupon usage record
  4. Updates affiliate referral count

#### 2. processAffiliateCommission

- **Purpose**: Processes commission payments to affiliate wallets
- **Trigger**: Manual admin call or automatic processing
- **Process**:
  1. Validates commission eligibility
  2. Updates affiliate earnings
  3. Credits affiliate wallet
  4. Creates transaction record

#### 3. batchProcessCommissions

- **Purpose**: Automated batch processing of pending commissions
- **Trigger**: Scheduled function (every 24 hours)
- **Process**:
  1. Finds pending commissions older than 24 hours
  2. Processes commissions in batches
  3. Updates affiliate wallets
  4. Creates transaction records

#### 4. handleSubscriptionPaymentSuccess

- **Purpose**: Webhook handler for subscription payment success
- **Trigger**: Razorpay webhook on successful payment
- **Process**:
  1. Verifies webhook signature
  2. Checks for associated coupon usage
  3. Triggers commission processing

### Data Models

#### Affiliate

```typescript
interface Affiliate {
  affiliateId: string;
  userId: string;
  couponCode: string;
  upiId: string;
  isActive: boolean;
  totalEarnings: number;
  totalReferrals: number;
  createdAt: string;
  updatedAt: string;
}
```

#### CouponUsage

```typescript
interface CouponUsage {
  usageId: string;
  couponCode: string;
  affiliateId: string;
  userId: string;
  orderId: string;
  subscriptionId: string;
  discountAmount: number;
  commissionAmount: number;
  subscriptionType: "weekly" | "monthly";
  originalAmount: number;
  finalAmount: number;
  status: "pending" | "processed" | "failed";
  createdAt: string;
  processedAt?: string;
}
```

## Database Collections

### Firestore Collections

1. **affiliates**

   - Stores affiliate account information
   - Indexed by userId and couponCode

2. **couponUsages**

   - Records all coupon usage instances
   - Indexed by affiliateId, status, and createdAt

3. **wallets**

   - User wallet balances (existing collection)
   - Updated with affiliate commissions

4. **walletTransactions**
   - Transaction history (existing collection)
   - Includes affiliate commission transactions

## Integration Points

### Subscription Flow Integration

1. **Coupon Validation**: Integrate `CouponValidationForm` in subscription pages
2. **Discount Application**: Apply validated discounts to subscription amounts
3. **Usage Recording**: Call `processCouponUsage` after successful subscription creation

### Example Integration:

```typescript
// In subscription component
const [couponValidation, setCouponValidation] = useState(null);

const handleCouponValidation = (result) => {
  setCouponValidation(result);
  // Update subscription amount with discount
};

// After successful subscription creation
if (couponValidation?.isValid) {
  await processCouponUsage({
    couponCode: couponValidation.couponCode,
    subscriptionId: subscription.id,
    originalAmount: originalAmount,
    discountAmount: couponValidation.discountAmount,
    finalAmount: couponValidation.finalAmount,
    subscriptionType: subscriptionType,
    affiliateId: couponValidation.affiliateId,
  });
}
```

## Security Features

### Validation & Prevention

- **Self-referral Prevention**: Users cannot use their own coupon codes
- **Unique Coupon Codes**: Automatic validation prevents duplicate codes
- **UPI Validation**: Regex validation for UPI ID format
- **Authentication Required**: All operations require user authentication
- **Webhook Verification**: Razorpay webhook signature verification

### Error Handling

- Comprehensive error messages for all failure scenarios
- Graceful degradation when services are unavailable
- Transaction rollback on partial failures
- Logging for debugging and monitoring

## Usage Instructions

### For Users (Becoming an Affiliate)

1. **Navigate to Affiliate Page**: Go to `/user/affiliate`
2. **Register**: Fill out the affiliate registration form
   - Choose a unique promo code (MMB will be added automatically)
   - Provide a valid UPI ID for commission payments
3. **Share Code**: Use the dashboard to copy and share your coupon code
4. **Track Earnings**: Monitor your referrals and earnings in real-time

### For Customers (Using Coupon Codes)

1. **During Subscription**: Look for "Have a Promo Code?" section
2. **Enter Code**: Input the affiliate's coupon code
3. **Apply Discount**: See the discount applied automatically
4. **Complete Purchase**: Proceed with discounted amount

### For Developers

#### Adding Coupon Validation to New Pages:

```typescript
import { CouponValidationForm } from "@/components/affiliate";

// In your subscription component
<CouponValidationForm
  subscriptionAmount={subscriptionAmount}
  subscriptionType={subscriptionType}
  onValidationResult={handleCouponValidation}
/>;
```

#### Processing Coupon Usage:

```typescript
import { processCouponUsage } from "@/services/affiliateService";

// After successful subscription creation
await processCouponUsage({
  couponCode: validatedCoupon.code,
  subscriptionId: subscription.id,
  originalAmount: originalAmount,
  discountAmount: validatedCoupon.discountAmount,
  finalAmount: validatedCoupon.finalAmount,
  subscriptionType: subscriptionType,
  affiliateId: validatedCoupon.affiliateId,
});
```

## Monitoring & Analytics

### Key Metrics to Track

- Total affiliate registrations
- Active affiliates (with at least one referral)
- Total commissions paid
- Average commission per affiliate
- Conversion rate of referred customers
- Most successful affiliates

### Logging

- All affiliate operations are logged for debugging
- Commission processing includes detailed transaction logs
- Error tracking for failed operations

## Future Enhancements

### Potential Features

1. **Tiered Commission Structure**: Different rates based on performance
2. **Bonus Programs**: Special rewards for top performers
3. **Marketing Materials**: Branded content for affiliates to share
4. **Advanced Analytics**: Detailed performance insights
5. **Payout Scheduling**: Flexible commission payment schedules
6. **Referral Limits**: Optional caps on referrals per affiliate

### Technical Improvements

1. **Caching**: Redis caching for frequently accessed affiliate data
2. **Rate Limiting**: Prevent abuse of coupon validation endpoints
3. **A/B Testing**: Test different commission structures
4. **Mobile App**: Dedicated affiliate mobile application

## Troubleshooting

### Common Issues

1. **Coupon Code Already Exists**

   - Solution: Choose a different promo code
   - Prevention: Real-time availability checking

2. **Commission Not Processed**

   - Check: Subscription payment status
   - Verify: Coupon usage record exists
   - Action: Manual commission processing if needed

3. **Invalid UPI ID**

   - Solution: Verify UPI ID format (username@provider)
   - Check: UPI ID is active and valid

4. **Self-referral Attempt**
   - Expected: System prevents users from using own codes
   - Message: Clear error message displayed

### Support Contacts

- Technical Issues: Contact development team
- Commission Disputes: Contact finance team
- General Questions: Contact customer support

## Conclusion

The affiliate system provides a robust, scalable solution for referral marketing with automatic commission processing and comprehensive tracking. The system is designed to be secure, user-friendly, and easily maintainable while providing real value to both affiliates and customers.
