# 🧪 Complete Coupon Flow Test Guide

## 📋 Test Checklist

### **Pre-requisites**

- [ ] Cloud functions deployed
- [ ] Affiliate account created with coupon code
- [ ] Test user account available

### **Flow to Test**

1. **Affiliate Setup** ✅

   - Go to `/user/affiliate`
   - Register as affiliate (if not already)
   - Get coupon code (format: `YOURNAMEMMB`)
   - Verify coupon shows in affiliate dashboard

2. **User Subscription with Coupon**

   - [ ] Go to meal plan page
   - [ ] Click subscribe
   - [ ] Select subscription period (e.g., 30 days)
   - [ ] Apply affiliate coupon in the form
   - [ ] Verify discount shows correctly
   - [ ] Complete payment via Razorpay

3. **Immediate Verification**

   - [ ] Payment success notification appears
   - [ ] Wallet credit notification appears (₹X credited to your wallet)
   - [ ] Check user wallet balance increased
   - [ ] Check affiliate wallet balance increased
   - [ ] **Check meal plan shows as subscribed** ⭐

4. **Backend Verification**
   - [ ] Check cloud function logs for coupon processing
   - [ ] Verify `walletTransactions` collection has records
   - [ ] Verify `couponUsages` collection has record
   - [ ] Verify affiliate stats updated (totalEarnings, totalReferrals)
   - [ ] **Verify meal plan document has `isSubscribed: true`** ⭐

---

## 🔍 Where to Check Results

### **User Wallet**

- **Path**: Firestore → `wallets` → `{userId}`
- **Expected**: Balance increased by discount amount
- **Transaction**: `walletTransactions` → type: "credit", source: "coupon-discount"

### **Affiliate Wallet**

- **Path**: Firestore → `wallets` → `{affiliateUserId}`
- **Expected**: Balance increased by commission amount
- **Transaction**: `walletTransactions` → type: "credit", source: "affiliate-commission"

### **Affiliate Stats**

- **Path**: Firestore → `affiliates` → `{affiliateId}`
- **Expected**:
  - `totalEarnings` increased by commission amount
  - `totalReferrals` increased by 1

### **Meal Plan Subscription Status** ⭐

- **Path**: Firestore → `mealPlans` → `{mealPlanId}`
- **Expected**: `isSubscribed: true`
- **Active Subscription**: `users` → `{userId}` → `activeSubscriptions` → `{orderId}`

### **Coupon Usage Record**

- **Path**: Firestore → `couponUsages` → `{usageId}`
- **Expected**: Complete record with all amounts and IDs

---

## 🚨 Common Issues & Solutions

### **Issue 1: No wallet credits after payment**

**Cause**: Webhook not triggering or data missing
**Solutions**:

- Check cloud function logs for errors
- Verify coupon data in subscription document
- Ensure webhook URL configured in Razorpay

### **Issue 2: Affiliate stats not updating**

**Cause**: Transaction failed or affiliate not found
**Solutions**:

- Check affiliate exists and is active
- Verify coupon code matches exactly
- Check transaction logs for errors

### **Issue 3: Wrong commission amount**

**Cause**: Using wrong base amount for calculation
**Solutions**:

- Verify `retailAmount` field is set correctly
- Check commission rate (10% monthly, 5% weekly)
- Ensure calculation uses retail price, not discounted price

### **Issue 4: Meal plan not showing as subscribed** ⭐

**Cause**: Missing subscription status update in payment verification
**Solutions**:

- Check subscription document has correct `type: "mealPlan"` and `itemId`
- Verify `verifyRazorpayPayment` function updates meal plan status
- Check cloud function logs for meal plan update messages
- Ensure meal plan ID is correctly passed from frontend

**Debug Steps**:

1. Check subscription document in `subscriptions/{orderId}`:
   ```json
   {
     "type": "mealPlan",
     "itemId": "mealPlanId123",
     "status": "paid"
   }
   ```
2. Look for log: "Updated meal plan {mealPlanId} subscription status to true"
3. Verify meal plan document updated: `mealPlans/{mealPlanId}` → `isSubscribed: true`

---

## 📊 Expected Results Example

### **Test Scenario**: 30-day subscription with JOHNDOEMMB coupon

```
Original Price: ₹1,500
Bulk Discount (20%): -₹300 = ₹1,200
Affiliate Discount (10%): -₹120 = ₹1,080
Commission (10% of ₹1,500): ₹150

User Wallet Credit: ₹120
Affiliate Wallet Credit: ₹150
Affiliate Stats: +₹150 earnings, +1 referral
Meal Plan Status: isSubscribed = true ⭐
```

---

## 🔧 Debugging Commands

### **Check Cloud Function Logs**

```bash
firebase functions:log --only razorpayWebhook,verifyRazorpayPayment
```

### **Look for Specific Log Messages**

- `"Creating order with data:"` - Check subscription data structure
- `"Processing coupon wallet credits immediately for:"` - Coupon processing
- `"Updated meal plan {mealPlanId} subscription status to true"` - Meal plan update ⭐

### **Check Firestore Collections**

- `wallets/{userId}` - User wallet balance
- `wallets/{affiliateUserId}` - Affiliate wallet balance
- `walletTransactions` - All wallet transactions
- `couponUsages` - Coupon usage records
- `affiliates/{affiliateId}` - Affiliate stats
- `mealPlans/{mealPlanId}` - **Meal plan subscription status** ⭐
- `subscriptions/{orderId}` - **Subscription details** ⭐

### **Manual Processing (if needed)**

```javascript
// Call this cloud function manually if webhook fails
processCouponWalletCredits({
  userId: "user123",
  couponCode: "JOHNDOEMMB",
  discountAmount: 120,
  commissionAmount: 150,
  subscriptionId: "order_xyz",
  // ... other fields
});
```

---

## ✅ Success Criteria

- [ ] **User Experience**: Smooth coupon application and payment
- [ ] **Immediate Feedback**: Wallet credit notifications appear
- [ ] **Data Consistency**: All amounts calculated correctly
- [ ] **Audit Trail**: Complete transaction records
- [ ] **Affiliate Benefits**: Stats and earnings updated properly
- [ ] **Subscription Status**: Meal plan marked as subscribed ⭐

---

## 🔄 **Key Fix Applied**

✅ **Added meal plan subscription status update to `verifyRazorpayPayment` function**

The payment verification now includes:

```typescript
// UPDATE THE MEAL PLAN'S SUBSCRIPTION STATUS
if (subscription && subscription.type === "mealPlan" && subscription.itemId) {
  await admin
    .firestore()
    .collection("mealPlans")
    .doc(subscription.itemId)
    .update({
      isSubscribed: true,
      updatedAt: admin.firestore.FieldValue.serverTimestamp(),
    });
}
```

**Note**: The system now uses **one-time orders** instead of subscriptions for better coupon handling and immediate wallet credit processing!
