/**
 * Calculates the price based on quantity with quantity-based discounts
 * 
 * @param basePrice - The base price of the product
 * @param baseQuantity - The base quantity set by admin
 * @param selectedQuantity - The quantity selected by user
 * @returns The calculated price with applicable discount
 */
export const calculatePriceWithDiscount = (
  basePrice: number,
  baseQuantity: number,
  selectedQuantity: number
): { price: number; discountPercentage: number; discountAmount: number } => {
  // Calculate raw price proportional to quantity
  const rawPrice = (basePrice / baseQuantity) * selectedQuantity;
  
  // Determine discount percentage based on quantity multiplier
  const quantityMultiplier = selectedQuantity / baseQuantity;
  let discountPercentage = 0;
  
  if (quantityMultiplier >= 4) {
    discountPercentage = 15; // 15% discount for 4x or more
  } else if (quantityMultiplier >= 3) {
    discountPercentage = 10; // 10% discount for 3x
  } else if (quantityMultiplier >= 2) {
    discountPercentage = 5; // 5% discount for 2x
  }
  
  // Calculate discount amount
  const discountAmount = (rawPrice * discountPercentage) / 100;
  
  // Calculate final price after discount
  const finalPrice = rawPrice - discountAmount;
  
  return {
    price: finalPrice,
    discountPercentage,
    discountAmount
  };
};

/**
 * Calculates the first-time user discount of ₹50 for orders above ₹300
 * 
 * @param amount - The amount after other discounts
 * @param isFirstTimeUser - Whether the user is a first-time user
 * @returns Object with discount details
 */
export const calculateFirstTimeUserDiscount = (
  amount: number,
  isFirstTimeUser: boolean
): { isEligible: boolean; discountAmount: number; finalAmount: number } => {
  const MINIMUM_ORDER_AMOUNT = 300;
  const FIRST_TIME_DISCOUNT_AMOUNT = 50;
  
  const isEligible = isFirstTimeUser && amount > MINIMUM_ORDER_AMOUNT;
  
  if (!isEligible) {
    return {
      isEligible: false,
      discountAmount: 0,
      finalAmount: amount
    };
  }
  
  const finalAmount = amount - FIRST_TIME_DISCOUNT_AMOUNT;
  
  return {
    isEligible: true,
    discountAmount: FIRST_TIME_DISCOUNT_AMOUNT,
    finalAmount
  };
}; 