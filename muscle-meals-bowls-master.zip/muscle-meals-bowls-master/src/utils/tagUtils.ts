/**
 * Formats a tag name for storage:
 * - Converts to lowercase
 * - Replaces spaces with underscores
 *
 * Example: "Low Carb" -> "low_carb"
 */
export const formatTagForStorage = (tagName: string): string => {
  return tagName.trim().toLowerCase().replace(/\s+/g, "_");
};

/**
 * Formats a tag name for display:
 * - Replaces underscores with spaces
 * - Capitalizes the first letter of each word
 *
 * Example: "low_carb" -> "Low Carb"
 */
export const formatTagForDisplay = (tagName: string): string => {
  if (!tagName) return "";

  return tagName
    .split("_")
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ");
};
