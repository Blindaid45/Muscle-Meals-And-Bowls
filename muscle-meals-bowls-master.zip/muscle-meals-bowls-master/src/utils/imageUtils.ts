/**
 * Helper function to get image URLs from a meal object
 * Handles both the new format (images array with url and path) and legacy format (single image URL)
 * Includes robust error handling for all edge cases
 */
export const getMealImages = (meal: any): string[] => {
  // Handle null or undefined meal
  if (!meal) return [];

  try {
    // Handle new format with images array
    if (meal.images && Array.isArray(meal.images) && meal.images.length > 0) {
      return meal.images
        .filter((img) => img && typeof img === "object" && img.url)
        .map((img) => String(img.url))
        .filter((url) => url && url.trim() !== "");
    }

    // Handle legacy format with single image string
    if (
      meal.image &&
      typeof meal.image === "string" &&
      meal.image.trim() !== ""
    ) {
      return [meal.image];
    }

    // Fallback to empty array if no valid images found
    return [];
  } catch (error) {
    console.error("Error parsing meal images:", error);
    return [];
  }
};
