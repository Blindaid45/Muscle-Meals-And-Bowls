import { Toaster } from "@/components/ui/Toaster";
import router from "./router";

export default function App() {
  return (
    <>
      <Toaster />
    </>
  );
}
