import { configureStore } from "@reduxjs/toolkit";
import { onAuthStateChanged } from "firebase/auth";
import authReducer, {
  setUser,
  setLoading,
  extractSerializableUser,
} from "./slices/authSlice";
import userReducer, {
  clearUserProfile,
  fetchUserProfile,
} from "./slices/userSlice";
import addressReducer from "./slices/addressSlice";
import adminReducer, {
  checkAdminStatus,
  clearAdminState,
} from "./slices/admin/adminSlice";
import adminDashboardReducer from "./slices/admin/adminDashboardSlice";
import adminUsersReducer from "./slices/admin/adminUsersSlice";
import adminProfileReducer, {
  clearAdminProfile,
  fetchAdminProfile,
} from "./slices/admin/adminProfileSlice";
import { auth } from "../lib/firebase";
import mealReducer from "./slices/mealSlice";
import tagReducer from "./slices/tagSlice";
import mealPlanReducer from "./slices/mealPlanSlice";
import adminMealPlanReducer from "./slices/adminMealPlanSlice";
import publicMealPlanReducer from "./slices/publicMealPlanSlice";
import subscriptionReducer from "./slices/subscriptionSlice";
import walletReducer, { clearWallet } from "./slices/walletSlice";
import transactionsReducer, {
  clearTransactions,
} from "./slices/transactionSlice";
import affiliateReducer, { clearAffiliate } from "./slices/affiliateSlice";

export const store = configureStore({
  reducer: {
    auth: authReducer,
    user: userReducer,
    address: addressReducer,
    admin: adminReducer,
    adminDashboard: adminDashboardReducer,
    adminUsers: adminUsersReducer,
    adminProfile: adminProfileReducer,
    meals: mealReducer,
    tags: tagReducer,
    mealPlans: mealPlanReducer,
    adminMealPlans: adminMealPlanReducer,
    publicMealPlans: publicMealPlanReducer,
    subscriptions: subscriptionReducer,
    wallet: walletReducer,
    transactions: transactionsReducer,
    affiliate: affiliateReducer,
  },
});

// Initialize auth state listener
onAuthStateChanged(auth, (user) => {
  if (user) {
    const serializableUser = extractSerializableUser(user);
    store.dispatch(setUser(serializableUser));
    store.dispatch(fetchUserProfile());
    store.dispatch(checkAdminStatus(user));

    // Check if user is an admin and fetch admin profile if they are
    store.dispatch(checkAdminStatus(user)).then((result) => {
      if (result.payload === true) {
        store.dispatch(fetchAdminProfile());
      }
    });
  } else {
    store.dispatch(setUser(null));
    store.dispatch(clearUserProfile());
    store.dispatch(clearAdminState());
    store.dispatch(clearAdminProfile());
    store.dispatch(clearWallet());
    store.dispatch(clearTransactions());
    store.dispatch(clearAffiliate());
  }
  store.dispatch(setLoading(false));
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
