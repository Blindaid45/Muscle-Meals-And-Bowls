import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import {
  doc,
  setDoc,
  getDoc,
  serverTimestamp,
  Timestamp,
} from "firebase/firestore";
import { updateProfile } from "firebase/auth";
import { db, auth } from "@/lib/firebase";

interface UserProfile {
  displayName: string;
  phoneNumber: string;
  weight: number | null;
  height: number | null;
  fitnessGoal: string;
  addressIds: string[];
  paymentMethods: PaymentMethod[];
  photoURL?: string | null;
  createdAt?: string;
  updatedAt?: string;
  lastLogin?: string;
  lastAccessTime?: string;
  isFirstTimeUser?: boolean;
}

interface PaymentMethod {
  id: string;
  type: "card";
  last4: string;
  expiryMonth: string;
  expiryYear: string;
  isDefault: boolean;
}

interface UserState {
  profile: UserProfile | null;
  loading: boolean;
  error: string | null;
}

const initialState: UserState = {
  profile: null,
  loading: false,
  error: null,
};

// Helper function to convert Firestore data to serializable format
const convertTimestamps = (data: any) => {
  const converted = { ...data };

  // Convert all potential timestamp fields
  const timestampFields = [
    "createdAt",
    "updatedAt",
    "lastLogin",
    "lastAccessTime",
  ];

  timestampFields.forEach((field) => {
    if (converted[field] instanceof Timestamp) {
      converted[field] = converted[field].toDate().toISOString();
    }
  });

  return converted;
};

export const updateUserProfile = createAsyncThunk(
  "user/updateProfile",
  async (profileData: Partial<UserProfile>, { rejectWithValue }) => {
    try {
      const user = auth.currentUser;
      if (!user) throw new Error("No authenticated user");

      // Update Firebase Auth user profile if displayName or photoURL is provided
      if (profileData.displayName || profileData.photoURL) {
        console.log("Updating user profile");
        await updateProfile(user, {
          displayName: profileData.displayName || user.displayName,
          photoURL: profileData.photoURL || user.photoURL,
        });
      }

      // Update profile in Firestore
      const userRef = doc(db, "users", user.uid);
      const userDoc = await getDoc(userRef);

      const timestamp = serverTimestamp();
      const updatedProfile = {
        ...(userDoc.exists() ? userDoc.data() : {}),
        ...profileData,
        updatedAt: timestamp,
      };

      await setDoc(userRef, updatedProfile, { merge: true });

      // Convert timestamps to ISO strings before returning
      const serializedProfile = convertTimestamps(
        await getDoc(userRef).then((doc) => doc.data())
      );
      return serializedProfile as UserProfile;
    } catch (error: any) {
      return rejectWithValue(error.message);
    }
  }
);

export const addAddressToUser = createAsyncThunk(
  "user/addAddress",
  async (addressId: string, { getState, rejectWithValue }) => {
    try {
      const user = auth.currentUser;
      if (!user) throw new Error("No authenticated user");

      const userRef = doc(db, "users", user.uid);
      const userDoc = await getDoc(userRef);

      if (!userDoc.exists()) {
        throw new Error("User document not found");
      }

      const currentAddressIds = userDoc.data().addressIds || [];
      const updatedAddressIds = [...currentAddressIds, addressId];

      await setDoc(
        userRef,
        {
          addressIds: updatedAddressIds,
          updatedAt: serverTimestamp(),
        },
        { merge: true }
      );

      return updatedAddressIds;
    } catch (error: any) {
      return rejectWithValue(error.message);
    }
  }
);

export const removeAddressFromUser = createAsyncThunk(
  "user/removeAddress",
  async (addressId: string, { getState, rejectWithValue }) => {
    try {
      const user = auth.currentUser;
      if (!user) throw new Error("No authenticated user");

      const userRef = doc(db, "users", user.uid);
      const userDoc = await getDoc(userRef);

      if (!userDoc.exists()) {
        throw new Error("User document not found");
      }

      const currentAddressIds = userDoc.data().addressIds || [];
      const updatedAddressIds = currentAddressIds.filter(
        (id: string) => id !== addressId
      );

      await setDoc(
        userRef,
        {
          addressIds: updatedAddressIds,
          updatedAt: serverTimestamp(),
        },
        { merge: true }
      );

      return updatedAddressIds;
    } catch (error: any) {
      return rejectWithValue(error.message);
    }
  }
);

export const fetchUserProfile = createAsyncThunk(
  "user/fetchProfile",
  async (_, { rejectWithValue }) => {
    try {
      const user = auth.currentUser;
      if (!user) throw new Error("No authenticated user");

      const userRef = doc(db, "users", user.uid);
      const userDoc = await getDoc(userRef);

      if (!userDoc.exists()) {
        return null;
      }

      // Convert timestamps to ISO strings before returning
      return convertTimestamps(userDoc.data()) as UserProfile;
    } catch (error: any) {
      return rejectWithValue(error.message);
    }
  }
);

const userSlice = createSlice({
  name: "user",
  initialState,
  reducers: {
    clearUserProfile: (state) => {
      state.profile = null;
      state.loading = false;
      state.error = null;
    },
  },
  extraReducers: (builder) => {
    builder
      // Update Profile
      .addCase(updateUserProfile.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updateUserProfile.fulfilled, (state, action) => {
        state.loading = false;
        state.profile = action.payload;
      })
      .addCase(updateUserProfile.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })
      // Fetch Profile
      .addCase(fetchUserProfile.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchUserProfile.fulfilled, (state, action) => {
        state.loading = false;
        state.profile = action.payload;
      })
      .addCase(fetchUserProfile.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })
      // Add Address
      .addCase(addAddressToUser.fulfilled, (state, action) => {
        if (state.profile) {
          state.profile.addressIds = action.payload;
        }
      })
      // Remove Address
      .addCase(removeAddressFromUser.fulfilled, (state, action) => {
        if (state.profile) {
          state.profile.addressIds = action.payload;
        }
      });
  },
});

export const { clearUserProfile } = userSlice.actions;
export default userSlice.reducer;
