import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import {
  collection,
  addDoc,
  getDocs,
  doc,
  getDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  serverTimestamp,
  Timestamp,
} from "firebase/firestore";
import { db, auth } from "@/lib/firebase";
import { deleteFileByUrl } from "@/lib/storageService";
import { toast } from "sonner";
import { Meal } from "./mealSlice";

// Define the admin meal plan item interface (same as MealPlanItem)
export interface AdminMealPlanItem {
  id?: string;
  mealId: string;
  quantity: number;
  dayNumbers: number[];
  mealTimes: string[];
  notes?: string;
  customizations?: string[];
}

// Define the admin meal plan interface
export interface AdminMealPlan {
  id?: string;
  name: string;
  description: string;
  adminId: string;
  duration: number;
  isActive: boolean;
  tags: string[];
  category?: string;
  featuredImage?: string;

  // Nutrition totals (calculated)
  totalCalories: number;
  totalProtein: number;
  totalCarbs: number;
  totalFat: number;
  totalFiber: number;
  totalPrice: number;

  // Items in the plan
  items: AdminMealPlanItem[];

  subscribedUsers: string[];

  // Timestamps
  createdAt?: Date;
  updatedAt?: Date;
}

// State interface
interface AdminMealPlanState {
  adminMealPlans: AdminMealPlan[];
  currentAdminMealPlan: AdminMealPlan | null;
  activeMealPlans: AdminMealPlan[];
  loading: boolean;
  error: string | null;
}

// Initial state
const initialState: AdminMealPlanState = {
  adminMealPlans: [],
  currentAdminMealPlan: null,
  activeMealPlans: [],
  loading: false,
  error: null,
};

// Helper functions
const convertTimestamps = (data: any) => {
  const converted = { ...data };
  if (converted.createdAt instanceof Timestamp) {
    converted.createdAt = converted.createdAt.toDate();
  }
  if (converted.updatedAt instanceof Timestamp) {
    converted.updatedAt = converted.updatedAt.toDate();
  }
  return converted;
};

// Verify admin status
const verifyAdmin = async (userId: string) => {
  try {
    const userRef = doc(db, "admins", userId);
    const userSnap = await getDoc(userRef);

    if (!userSnap.exists()) {
      throw new Error("User not found");
    }

    const userData = userSnap.data();
    if (!userData.isAdmin) {
      throw new Error("User does not have admin privileges");
    }

    return true;
  } catch (error) {
    throw error;
  }
};

// Calculate nutrition totals from a list of meals and quantities
export const calculateAdminMealPlanTotals = createAsyncThunk(
  "adminMealPlans/calculateTotals",
  async (items: AdminMealPlanItem[], { rejectWithValue }) => {
    try {
      let totalCalories = 0;
      let totalProtein = 0;
      let totalCarbs = 0;
      let totalFat = 0;
      let totalFiber = 0;
      let totalPrice = 0;

      // Fetch all meals that are part of the plan
      for (const item of items) {
        const mealRef = doc(db, "meals", item.mealId);
        const mealSnap = await getDoc(mealRef);

        if (!mealSnap.exists()) {
          throw new Error(`Meal with ID ${item.mealId} not found`);
        }

        const mealData = mealSnap.data() as Meal;
        const quantityRatio = item.quantity / mealData.baseQuantity;

        // Calculate the number of occurrences based on combinations of mealTimes and dayNumbers
        const occurrences = item.mealTimes.length * item.dayNumbers.length;

        totalCalories +=
          (Math.round(mealData.calories * quantityRatio * 10) / 10) *
          occurrences;
        totalProtein +=
          (Math.round(mealData.protein * quantityRatio * 10) / 10) *
          occurrences;
        totalCarbs +=
          (Math.round(mealData.carbs * quantityRatio * 10) / 10) * occurrences;
        totalFat +=
          (Math.round(mealData.fat * quantityRatio * 10) / 10) * occurrences;
        totalFiber +=
          (Math.round(mealData.fiber * quantityRatio * 10) / 10) * occurrences;
        totalPrice += mealData.price * quantityRatio * occurrences;
      }

      return {
        totalCalories,
        totalProtein,
        totalCarbs,
        totalFat,
        totalFiber,
        totalPrice,
      };
    } catch (error: any) {
      return rejectWithValue(error.message);
    }
  }
);

// Create a new admin meal plan
export const createAdminMealPlan = createAsyncThunk(
  "adminMealPlans/create",
  async (
    mealPlanData: Omit<
      AdminMealPlan,
      "id" | "adminId" | "createdAt" | "updatedAt"
    >,
    { dispatch, rejectWithValue }
  ) => {
    try {
      const user = auth.currentUser;
      if (!user) throw new Error("No authenticated user");

      // Verify admin status
      await verifyAdmin(user.uid);

      // Calculate nutrition totals
      const totals = await dispatch(
        calculateAdminMealPlanTotals(mealPlanData.items)
      ).unwrap();

      // Prepare data for Firestore
      const newMealPlan = {
        ...mealPlanData,
        ...totals,
        adminId: user.uid,
        subscribedUsers: [],
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      };

      const docRef = await addDoc(
        collection(db, "adminMealPlans"),
        newMealPlan
      );

      toast.success("Admin meal plan created successfully!");

      // Convert timestamps for Redux
      return {
        id: docRef.id,
        ...newMealPlan,
        createdAt: new Date(),
        updatedAt: new Date(),
      };
    } catch (error: any) {
      toast.error("Failed to create admin meal plan");
      return rejectWithValue(error.message);
    }
  }
);

// Fetch all admin meal plans
export const fetchAllAdminMealPlans = createAsyncThunk(
  "adminMealPlans/fetchAll",
  async (_, { rejectWithValue }) => {
    try {
      const user = auth.currentUser;
      if (!user) throw new Error("No authenticated user");

      // Verify admin status
      await verifyAdmin(user.uid);

      const mealPlansRef = collection(db, "adminMealPlans");
      const querySnapshot = await getDocs(mealPlansRef);

      const mealPlans = querySnapshot.docs.map((doc) => ({
        id: doc.id,
        ...convertTimestamps(doc.data()),
      })) as AdminMealPlan[];

      return mealPlans;
    } catch (error: any) {
      toast.error("Failed to fetch admin meal plans");
      return rejectWithValue(error.message);
    }
  }
);

// Fetch active admin meal plans (for non-admin users)
export const fetchActiveMealPlans = createAsyncThunk(
  "adminMealPlans/fetchActive",
  async (_, { rejectWithValue }) => {
    try {
      const mealPlansRef = collection(db, "adminMealPlans");
      const q = query(mealPlansRef, where("isActive", "==", true));
      const querySnapshot = await getDocs(q);

      const mealPlans = querySnapshot.docs.map((doc) => ({
        id: doc.id,
        ...convertTimestamps(doc.data()),
      })) as AdminMealPlan[];

      return mealPlans;
    } catch (error: any) {
      toast.error("Failed to fetch active meal plans");
      return rejectWithValue(error.message);
    }
  }
);

// Get a single admin meal plan by ID
export const fetchAdminMealPlanById = createAsyncThunk(
  "adminMealPlans/fetchById",
  async (id: string, { rejectWithValue }) => {
    try {
      const docRef = doc(db, "adminMealPlans", id);
      const docSnapshot = await getDoc(docRef);

      if (!docSnapshot.exists()) {
        throw new Error("Admin meal plan not found");
      }

      return {
        id: docSnapshot.id,
        ...convertTimestamps(docSnapshot.data()),
      } as AdminMealPlan;
    } catch (error: any) {
      toast.error("Failed to fetch admin meal plan");
      return rejectWithValue(error.message);
    }
  }
);

// Update an admin meal plan
export const updateAdminMealPlan = createAsyncThunk(
  "adminMealPlans/update",
  async (
    { id, ...mealPlanData }: Partial<AdminMealPlan> & { id: string },
    { dispatch, rejectWithValue }
  ) => {
    try {
      const user = auth.currentUser;
      if (!user) throw new Error("No authenticated user");

      // Verify admin status
      await verifyAdmin(user.uid);

      const docRef = doc(db, "adminMealPlans", id);
      const docSnapshot = await getDoc(docRef);

      if (!docSnapshot.exists()) {
        throw new Error("Admin meal plan not found");
      }

      // If items are being updated, recalculate totals
      let updateData: any = {
        ...mealPlanData,
        updatedAt: serverTimestamp(),
      };

      if (mealPlanData.items) {
        const totals = await dispatch(
          calculateAdminMealPlanTotals(mealPlanData.items)
        ).unwrap();
        updateData = { ...updateData, ...totals };
      }

      await updateDoc(docRef, updateData);

      toast.success("Admin meal plan updated successfully!");

      // Get the updated document for return
      const updatedSnapshot = await getDoc(docRef);
      return {
        id,
        ...convertTimestamps(updatedSnapshot.data()),
      } as AdminMealPlan;
    } catch (error: any) {
      toast.error("Failed to update admin meal plan");
      return rejectWithValue(error.message);
    }
  }
);

// Add a meal to an existing admin meal plan
export const addMealToAdminMealPlan = createAsyncThunk(
  "adminMealPlans/addMeal",
  async (
    { planId, mealItem }: { planId: string; mealItem: AdminMealPlanItem },
    { dispatch, rejectWithValue }
  ) => {
    try {
      const user = auth.currentUser;
      if (!user) throw new Error("No authenticated user");

      // Verify admin status
      await verifyAdmin(user.uid);

      const docRef = doc(db, "adminMealPlans", planId);
      const docSnapshot = await getDoc(docRef);

      if (!docSnapshot.exists()) {
        throw new Error("Admin meal plan not found");
      }

      // Ensure dayNumbers and mealTimes are arrays
      const newMealItem = {
        ...mealItem,
        id: crypto.randomUUID(),
        dayNumbers: Array.isArray(mealItem.dayNumbers)
          ? mealItem.dayNumbers
          : [mealItem.dayNumbers],
        mealTimes: Array.isArray(mealItem.mealTimes)
          ? mealItem.mealTimes
          : [mealItem.mealTimes],
      };

      const planData = docSnapshot.data() as AdminMealPlan;
      const currentItems = planData.items || [];
      const updatedItems = [...currentItems, newMealItem];

      // Recalculate totals with the new item
      const totals = await dispatch(
        calculateAdminMealPlanTotals(updatedItems)
      ).unwrap();

      // Update the plan
      await updateDoc(docRef, {
        items: updatedItems,
        ...totals,
        updatedAt: serverTimestamp(),
      });

      toast.success("Meal added to admin plan successfully!");

      // Get the updated document
      const updatedSnapshot = await getDoc(docRef);
      return {
        id: planId,
        ...convertTimestamps(updatedSnapshot.data()),
      } as AdminMealPlan;
    } catch (error: any) {
      toast.error("Failed to add meal to admin plan");
      return rejectWithValue(error.message);
    }
  }
);

// Remove a meal from an admin meal plan
export const removeMealFromAdminMealPlan = createAsyncThunk(
  "adminMealPlans/removeMeal",
  async (
    { planId, itemId }: { planId: string; itemId: string },
    { dispatch, rejectWithValue }
  ) => {
    try {
      const user = auth.currentUser;
      if (!user) throw new Error("No authenticated user");

      // Verify admin status
      await verifyAdmin(user.uid);

      const docRef = doc(db, "adminMealPlans", planId);
      const docSnapshot = await getDoc(docRef);

      if (!docSnapshot.exists()) {
        throw new Error("Admin meal plan not found");
      }

      // Remove the meal item
      const planData = docSnapshot.data() as AdminMealPlan;
      const updatedItems = planData.items.filter((item) => item.id !== itemId);

      // Recalculate totals without the removed meal
      const totals = await dispatch(
        calculateAdminMealPlanTotals(updatedItems)
      ).unwrap();

      // Update the plan
      await updateDoc(docRef, {
        items: updatedItems,
        ...totals,
        updatedAt: serverTimestamp(),
      });

      toast.success("Meal removed from admin plan successfully!");

      // Get the updated document
      const updatedSnapshot = await getDoc(docRef);
      return {
        id: planId,
        ...convertTimestamps(updatedSnapshot.data()),
      } as AdminMealPlan;
    } catch (error: any) {
      toast.error("Failed to remove meal from admin plan");
      return rejectWithValue(error.message);
    }
  }
);

// Update a single meal item in an admin meal plan
export const updateAdminMealPlanItem = createAsyncThunk(
  "adminMealPlans/updateMealItem",
  async (
    {
      planId,
      itemId,
      updatedItem,
    }: {
      planId: string;
      itemId: string;
      updatedItem: Partial<AdminMealPlanItem>;
    },
    { dispatch, rejectWithValue }
  ) => {
    try {
      const user = auth.currentUser;
      if (!user) throw new Error("No authenticated user");

      // Verify admin status
      await verifyAdmin(user.uid);

      const docRef = doc(db, "adminMealPlans", planId);
      const docSnapshot = await getDoc(docRef);

      if (!docSnapshot.exists()) {
        throw new Error("Admin meal plan not found");
      }

      // Ensure dayNumbers and mealTimes are arrays if provided
      const sanitizedUpdate: Partial<AdminMealPlanItem> = { ...updatedItem };
      if (updatedItem.dayNumbers) {
        sanitizedUpdate.dayNumbers = Array.isArray(updatedItem.dayNumbers)
          ? updatedItem.dayNumbers
          : [updatedItem.dayNumbers];
      }

      if (updatedItem.mealTimes) {
        sanitizedUpdate.mealTimes = Array.isArray(updatedItem.mealTimes)
          ? updatedItem.mealTimes
          : [updatedItem.mealTimes];
      }

      // Find and update the specific meal item
      const planData = docSnapshot.data() as AdminMealPlan;
      const updatedItems = planData.items.map((item) =>
        item.id === itemId ? { ...item, ...sanitizedUpdate } : item
      );

      // Recalculate totals with the updated meal
      const totals = await dispatch(
        calculateAdminMealPlanTotals(updatedItems)
      ).unwrap();

      // Update the plan
      await updateDoc(docRef, {
        items: updatedItems,
        ...totals,
        updatedAt: serverTimestamp(),
      });

      toast.success("Admin meal item updated successfully!");

      // Get the updated document
      const updatedSnapshot = await getDoc(docRef);
      return {
        id: planId,
        ...convertTimestamps(updatedSnapshot.data()),
      } as AdminMealPlan;
    } catch (error: any) {
      toast.error("Failed to update admin meal item");
      return rejectWithValue(error.message);
    }
  }
);

// Delete an admin meal plan
export const deleteAdminMealPlan = createAsyncThunk(
  "adminMealPlans/delete",
  async (id: string, { rejectWithValue }) => {
    try {
      const user = auth.currentUser;
      if (!user) throw new Error("No authenticated user");

      // Verify admin status
      await verifyAdmin(user.uid);

      const docRef = doc(db, "adminMealPlans", id);

      // Get the document data before deleting to access featuredImage
      const docSnapshot = await getDoc(docRef);
      const mealPlanData = docSnapshot.data();

      // Delete the document
      await deleteDoc(docRef);

      // Clean up featured image from Firebase Storage if it exists
      if (
        mealPlanData?.featuredImage &&
        mealPlanData.featuredImage.includes("firebase")
      ) {
        try {
          await deleteFileByUrl(mealPlanData.featuredImage);
        } catch (deleteError) {
          console.warn(
            "Could not delete featured image from storage:",
            deleteError
          );
          // Continue even if image deletion fails
        }
      }

      toast.success("Admin meal plan deleted successfully!");
      return id;
    } catch (error: any) {
      toast.error("Failed to delete admin meal plan");
      return rejectWithValue(error.message);
    }
  }
);

// Create the slice
const adminMealPlanSlice = createSlice({
  name: "adminMealPlans",
  initialState,
  reducers: {
    clearCurrentAdminMealPlan: (state) => {
      state.currentAdminMealPlan = null;
    },
    clearAdminMealPlanErrors: (state) => {
      state.error = null;
    },
  },
  extraReducers: (builder) => {
    builder
      // Create admin meal plan
      .addCase(createAdminMealPlan.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(createAdminMealPlan.fulfilled, (state, action) => {
        state.loading = false;
        state.adminMealPlans.push(action.payload);
        state.currentAdminMealPlan = action.payload;
      })
      .addCase(createAdminMealPlan.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })

      // Fetch all admin meal plans
      .addCase(fetchAllAdminMealPlans.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchAllAdminMealPlans.fulfilled, (state, action) => {
        state.loading = false;
        state.adminMealPlans = action.payload;
      })
      .addCase(fetchAllAdminMealPlans.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })

      // Fetch active meal plans
      .addCase(fetchActiveMealPlans.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchActiveMealPlans.fulfilled, (state, action) => {
        state.loading = false;
        state.activeMealPlans = action.payload;
      })
      .addCase(fetchActiveMealPlans.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })

      // Fetch admin meal plan by ID
      .addCase(fetchAdminMealPlanById.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchAdminMealPlanById.fulfilled, (state, action) => {
        state.loading = false;
        state.currentAdminMealPlan = action.payload;
      })
      .addCase(fetchAdminMealPlanById.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })

      // Update admin meal plan
      .addCase(updateAdminMealPlan.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updateAdminMealPlan.fulfilled, (state, action) => {
        state.loading = false;
        state.currentAdminMealPlan = action.payload;
        state.adminMealPlans = state.adminMealPlans.map((plan) =>
          plan.id === action.payload.id ? action.payload : plan
        );
      })
      .addCase(updateAdminMealPlan.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })

      // Add meal to admin plan
      .addCase(addMealToAdminMealPlan.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(addMealToAdminMealPlan.fulfilled, (state, action) => {
        state.loading = false;
        state.currentAdminMealPlan = action.payload;
        state.adminMealPlans = state.adminMealPlans.map((plan) =>
          plan.id === action.payload.id ? action.payload : plan
        );
      })
      .addCase(addMealToAdminMealPlan.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })

      // Remove meal from admin plan
      .addCase(removeMealFromAdminMealPlan.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(removeMealFromAdminMealPlan.fulfilled, (state, action) => {
        state.loading = false;
        state.currentAdminMealPlan = action.payload;
        state.adminMealPlans = state.adminMealPlans.map((plan) =>
          plan.id === action.payload.id ? action.payload : plan
        );
      })
      .addCase(removeMealFromAdminMealPlan.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })

      // Update admin meal item
      .addCase(updateAdminMealPlanItem.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updateAdminMealPlanItem.fulfilled, (state, action) => {
        state.loading = false;
        state.currentAdminMealPlan = action.payload;
        state.adminMealPlans = state.adminMealPlans.map((plan) =>
          plan.id === action.payload.id ? action.payload : plan
        );
      })
      .addCase(updateAdminMealPlanItem.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })

      // Delete admin meal plan
      .addCase(deleteAdminMealPlan.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(deleteAdminMealPlan.fulfilled, (state, action) => {
        state.loading = false;
        state.adminMealPlans = state.adminMealPlans.filter(
          (plan) => plan.id !== action.payload
        );
        if (state.currentAdminMealPlan?.id === action.payload) {
          state.currentAdminMealPlan = null;
        }
      })
      .addCase(deleteAdminMealPlan.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });

    // Subscribe to admin meal plan
  },
});

export const { clearCurrentAdminMealPlan, clearAdminMealPlanErrors } =
  adminMealPlanSlice.actions;
export default adminMealPlanSlice.reducer;
