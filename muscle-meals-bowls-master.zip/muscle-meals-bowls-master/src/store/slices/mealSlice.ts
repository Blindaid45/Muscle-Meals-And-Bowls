import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import {
  collection,
  addDoc,
  getDocs,
  doc,
  getDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
} from "firebase/firestore";
import { db } from "@/lib/firebase";
import { toast } from "sonner";

export interface Meal {
  id?: string;
  name: string;
  description: string;
  price: number;
  baseQuantity: number;
  unit: string; // Unit of measurement (g, pieces, bowls, etc.)
  protein: number;
  carbs: number;
  fat: number;
  fiber: number;
  calories: number;
  tags: string[];
  tagsString: string; // Lowercase tags joined by underscores for filtering
  image: string; // Main image URL (for backward compatibility)
  images?: Array<{ url: string; path: string }>; // Array of image objects with URL and storage path
  createdAt?: Date;
  updatedAt?: Date;
}

interface MealState {
  meals: Meal[];
  currentMeal: Meal | null;
  loading: boolean;
  error: string | null;
}

const initialState: MealState = {
  meals: [],
  currentMeal: null,
  loading: false,
  error: null,
};

// Helper function to process tags
const processTags = (tags: string[]): string => {
  return tags.map((tag) => tag.toLowerCase().replace(/\s+/g, "_")).join("_");
};

// Create a new meal
export const createMeal = createAsyncThunk(
  "meals/create",
  async (
    mealData: Omit<Meal, "id" | "tagsString" | "createdAt" | "updatedAt">,
    { rejectWithValue }
  ) => {
    try {
      // Process tags to create tagsString
      const tagsString = processTags(mealData.tags);

      // Add timestamp
      const timestamp = new Date();

      const newMeal = {
        ...mealData,
        tagsString,
        createdAt: timestamp,
        updatedAt: timestamp,
      };

      const docRef = await addDoc(collection(db, "meals"), newMeal);

      toast.success("Meal added successfully!");
      return { id: docRef.id, ...newMeal };
    } catch (error: any) {
      toast.error("Failed to add meal");
      return rejectWithValue(error.message);
    }
  }
);

// Get all meals
export const fetchMeals = createAsyncThunk(
  "meals/fetchAll",
  async (_, { rejectWithValue }) => {
    try {
      const querySnapshot = await getDocs(collection(db, "meals"));
      const meals = querySnapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      })) as Meal[];
      console.log(meals);
      return meals;
    } catch (error: any) {
      toast.error("Failed to fetch meals");
      return rejectWithValue(error.message);
    }
  }
);

// Get a single meal by ID
export const fetchMealById = createAsyncThunk(
  "meals/fetchById",
  async (id: string, { rejectWithValue }) => {
    try {
      const docRef = doc(db, "meals", id);
      const docSnapshot = await getDoc(docRef);

      if (!docSnapshot.exists()) {
        throw new Error("Meal not found");
      }

      return { id: docSnapshot.id, ...docSnapshot.data() } as Meal;
    } catch (error: any) {
      toast.error("Failed to fetch meal");
      return rejectWithValue(error.message);
    }
  }
);

// Update a meal
export const updateMeal = createAsyncThunk(
  "meals/update",
  async (
    { id, ...mealData }: Partial<Meal> & { id: string },
    { rejectWithValue }
  ) => {
    try {
      const docRef = doc(db, "meals", id);

      // Process tags if provided
      let updateData: Partial<Meal> = { ...mealData, updatedAt: new Date() };

      if (mealData.tags) {
        updateData.tagsString = processTags(mealData.tags);
      }

      await updateDoc(docRef, updateData);

      toast.success("Meal updated successfully!");
      return { id, ...updateData };
    } catch (error: any) {
      toast.error("Failed to update meal");
      return rejectWithValue(error.message);
    }
  }
);

// Delete a meal
export const deleteMeal = createAsyncThunk(
  "meals/delete",
  async (id: string, { rejectWithValue }) => {
    try {
      const docRef = doc(db, "meals", id);
      await deleteDoc(docRef);

      toast.success("Meal deleted successfully!");
      return id;
    } catch (error: any) {
      toast.error("Failed to delete meal");
      return rejectWithValue(error.message);
    }
  }
);

// Filter meals by tag
export const filterMealsByTag = createAsyncThunk(
  "meals/filterByTag",
  async (tag: string, { rejectWithValue }) => {
    try {
      const processedTag = tag.toLowerCase().replace(/\s+/g, "_");

      // Query meals where tagsString contains the processed tag
      const mealsRef = collection(db, "meals");
      const q = query(
        mealsRef,
        where("tagsString", "array-contains", processedTag)
      );
      const querySnapshot = await getDocs(q);

      const meals = querySnapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      })) as Meal[];

      return meals;
    } catch (error: any) {
      toast.error("Failed to filter meals");
      return rejectWithValue(error.message);
    }
  }
);

const mealSlice = createSlice({
  name: "meals",
  initialState,
  reducers: {
    clearCurrentMeal: (state) => {
      state.currentMeal = null;
    },
    clearMealErrors: (state) => {
      state.error = null;
    },
  },
  extraReducers: (builder) => {
    builder
      // Create meal cases
      .addCase(createMeal.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(createMeal.fulfilled, (state, action) => {
        state.loading = false;
        state.meals.push(action.payload);
      })
      .addCase(createMeal.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })

      // Fetch all meals cases
      .addCase(fetchMeals.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchMeals.fulfilled, (state, action) => {
        state.loading = false;
        state.meals = action.payload;
      })
      .addCase(fetchMeals.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })

      // Fetch meal by ID cases
      .addCase(fetchMealById.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchMealById.fulfilled, (state, action) => {
        state.loading = false;
        state.currentMeal = action.payload;
      })
      .addCase(fetchMealById.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })

      // Update meal cases
      .addCase(updateMeal.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updateMeal.fulfilled, (state, action) => {
        state.loading = false;
        const index = state.meals.findIndex(
          (meal) => meal.id === action.payload.id
        );
        if (index !== -1) {
          state.meals[index] = { ...state.meals[index], ...action.payload };
        }
        if (state.currentMeal?.id === action.payload.id) {
          state.currentMeal = { ...state.currentMeal, ...action.payload };
        }
      })
      .addCase(updateMeal.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })

      // Delete meal cases
      .addCase(deleteMeal.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(deleteMeal.fulfilled, (state, action) => {
        state.loading = false;
        state.meals = state.meals.filter((meal) => meal.id !== action.payload);
        if (state.currentMeal?.id === action.payload) {
          state.currentMeal = null;
        }
      })
      .addCase(deleteMeal.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })

      // Filter meals by tag cases
      .addCase(filterMealsByTag.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(filterMealsByTag.fulfilled, (state, action) => {
        state.loading = false;
        state.meals = action.payload;
      })
      .addCase(filterMealsByTag.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export const { clearCurrentMeal, clearMealErrors } = mealSlice.actions;
export default mealSlice.reducer;
