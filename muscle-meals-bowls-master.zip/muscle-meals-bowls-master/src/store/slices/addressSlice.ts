import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import { 
  collection, 
  doc, 
  getDocs, 
  addDoc, 
  updateDoc, 
  deleteDoc,
  query,
  where,
  serverTimestamp,
  Timestamp 
} from 'firebase/firestore';
import { db, auth } from '@/lib/firebase';
import { Address } from '@/types/address';
import { toast } from 'sonner';
import { addAddressToUser, removeAddressFromUser } from '@/store/slices/userSlice';
import { AppDispatch } from '@/store/store';

interface AddressState {
  addresses: Address[];
  loading: boolean;
  error: string | null;
}

const initialState: AddressState = {
  addresses: [],
  loading: false,
  error: null,
};

// Helper function to convert Firestore data
const convertTimestamps = (data: any) => {
  const converted = { ...data };
  if (converted.createdAt instanceof Timestamp) {
    converted.createdAt = converted.createdAt.toDate().toISOString();
  }
  if (converted.updatedAt instanceof Timestamp) {
    converted.updatedAt = converted.updatedAt.toDate().toISOString();
  }
  return converted;
};

// Fetch addresses
export const fetchAddresses = createAsyncThunk(
  'address/fetchAddresses',
  async (_, { rejectWithValue }) => {
    try {
      const user = auth.currentUser;
      if (!user) throw new Error('No authenticated user');

      const addressesRef = collection(db, 'addresses');
      const q = query(addressesRef, where('userId', '==', user.uid));
      const querySnapshot = await getDocs(q);
      
      const addresses = querySnapshot.docs.map(doc => ({
        id: doc.id,
        ...convertTimestamps(doc.data())
      })) as Address[];

      return addresses;
    } catch (error: any) {
      toast.error('Failed to fetch addresses');
      return rejectWithValue(error.message);
    }
  }
);

// Add new address
export const addAddress = createAsyncThunk(
  'address/addAddress',
  async (addressData: Omit<Address, 'id' | 'createdAt' | 'updatedAt'>, { dispatch, rejectWithValue }) => {
    try {
      const user = auth.currentUser;
      if (!user) throw new Error('No authenticated user');

      const addressesRef = collection(db, 'addresses');
      const timestamp = serverTimestamp();
      
      const newAddress = {
        ...addressData,
        userId: user.uid,
        createdAt: timestamp,
        updatedAt: timestamp
      };

      const docRef = await addDoc(addressesRef, newAddress);
      
      // Add address ID to user document
      await dispatch(addAddressToUser(docRef.id));

      const address = {
        id: docRef.id,
        ...addressData,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      toast.success('Address added successfully');
      return address;
    } catch (error: any) {
      toast.error('Failed to add address');
      return rejectWithValue(error.message);
    }
  }
);

// Update address
export const updateAddress = createAsyncThunk(
  'address/updateAddress',
  async ({ id, ...addressData }: Partial<Address> & { id: string }, { rejectWithValue }) => {
    try {
      const addressRef = doc(db, 'addresses', id);
      const timestamp = serverTimestamp();
      
      await updateDoc(addressRef, {
        ...addressData,
        updatedAt: timestamp
      });

      const updatedAddress = {
        id,
        ...addressData,
        updatedAt: new Date().toISOString()
      };

      toast.success('Address updated successfully');
      return updatedAddress;
    } catch (error: any) {
      toast.error('Failed to update address');
      return rejectWithValue(error.message);
    }
  }
);

// Delete address
export const deleteAddress = createAsyncThunk(
  'address/deleteAddress',
  async (id: string, { dispatch, rejectWithValue }) => {
    try {
      await deleteDoc(doc(db, 'addresses', id));
      
      // Remove address ID from user document
      await dispatch(removeAddressFromUser(id));

      toast.success('Address deleted successfully');
      return id;
    } catch (error: any) {
      toast.error('Failed to delete address');
      return rejectWithValue(error.message);
    }
  }
);

const addressSlice = createSlice({
  name: 'address',
  initialState,
  reducers: {},
  extraReducers: (builder) => {
    builder
      // Fetch addresses
      .addCase(fetchAddresses.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchAddresses.fulfilled, (state, action) => {
        state.loading = false;
        state.addresses = action.payload;
      })
      .addCase(fetchAddresses.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })
      // Add address
      .addCase(addAddress.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(addAddress.fulfilled, (state, action) => {
        state.loading = false;
        state.addresses.push(action.payload);
      })
      .addCase(addAddress.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })
      // Update address
      .addCase(updateAddress.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updateAddress.fulfilled, (state, action) => {
        state.loading = false;
        const index = state.addresses.findIndex(addr => addr.id === action.payload.id);
        if (index !== -1) {
          state.addresses[index] = { ...state.addresses[index], ...action.payload };
        }
      })
      .addCase(updateAddress.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })
      // Delete address
      .addCase(deleteAddress.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(deleteAddress.fulfilled, (state, action) => {
        state.loading = false;
        state.addresses = state.addresses.filter(addr => addr.id !== action.payload);
      })
      .addCase(deleteAddress.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export default addressSlice.reducer;