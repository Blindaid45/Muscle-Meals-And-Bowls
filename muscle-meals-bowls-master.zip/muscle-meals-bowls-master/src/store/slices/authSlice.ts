import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut as firebaseSignOut,
  updateProfile,
  User,
  onAuthStateChanged,
  GoogleAuthProvider,
  signInWithPopup,
  fetchSignInMethodsForEmail,
  sendPasswordResetEmail,
} from "firebase/auth";
import { doc, setDoc, serverTimestamp, getDoc } from "firebase/firestore";
import { auth, db } from "@/lib/firebase";
import { toast } from "sonner";

interface SerializableUser {
  uid: string;
  email: string | null;
  displayName: string | null;
  photoURL: string | null;
  emailVerified: boolean;
}

interface AuthState {
  user: SerializableUser | null;
  loading: boolean;
  error: string | null;
}

const initialState: AuthState = {
  user: null,
  loading: false,
  error: null,
};

export const extractSerializableUser = (user: User): SerializableUser => ({
  uid: user.uid,
  email: user.email,
  displayName: user.displayName,
  photoURL: user.photoURL,
  emailVerified: user.emailVerified,
});

export const registerUser = createAsyncThunk(
  "auth/register",
  async (
    {
      email,
      password,
      displayName,
    }: { email: string; password: string; displayName: string },
    { rejectWithValue }
  ) => {
    try {
      // Create the user in Firebase Auth
      const userCredential = await createUserWithEmailAndPassword(
        auth,
        email,
        password
      );
      const user = userCredential.user;

      // Update the user's display name
      await updateProfile(user, { displayName });

      // Create initial user document in Firestore
      const userDoc = {
        uid: user.uid,
        email: user.email,
        displayName,
        photoURL: null,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
        phoneNumber: "",
        fitnessGoal: "",
        isFirstTimeUser: true,
        weight: null,
        height: null,
        addresses: [],
        paymentMethods: [],
      };

      // Add the user to the users collection
      await setDoc(doc(db, "users", user.uid), userDoc);

      toast.success("Account created successfully!");
      return extractSerializableUser(user);
    } catch (error: any) {
      // Provide user-friendly error messages
      let errorMessage = "Failed to create account. Please try again.";

      if (error.code === "auth/email-already-in-use") {
        errorMessage =
          "This email is already in use. Please use a different email or sign in.";
      } else if (error.code === "auth/weak-password") {
        errorMessage =
          "Password is too weak. Please use a stronger password with at least 6 characters.";
      } else if (error.code === "auth/invalid-email") {
        errorMessage =
          "The email address is not valid. Please enter a valid email.";
      } else if (error.code === "auth/operation-not-allowed") {
        errorMessage =
          "Account creation is currently disabled. Please try again later.";
      } else if (error.code === "auth/network-request-failed") {
        errorMessage =
          "Network error. Please check your internet connection and try again.";
      }

      toast.error(errorMessage);
      return rejectWithValue(errorMessage);
    }
  }
);

export const loginWithGoogle = createAsyncThunk(
  "auth/loginWithGoogle",
  async (_, { rejectWithValue }) => {
    try {
      const provider = new GoogleAuthProvider();
      // Add scopes for additional profile info
      provider.addScope("profile");
      provider.addScope("email");

      const userCredential = await signInWithPopup(auth, provider);
      const user = userCredential.user;

      // Check if user document exists in Firestore
      const userDocRef = doc(db, "users", user.uid);
      const userDocSnap = await getDoc(userDocRef);

      // If user document doesn't exist, create it
      if (!userDocSnap.exists()) {
        const userDoc = {
          uid: user.uid,
          email: user.email,
          displayName: user.displayName,
          photoURL: user.photoURL,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
          role: "user",
          phoneNumber: "",
          fitnessGoal: "",
          weight: null,
          height: null,
          addresses: [],
          paymentMethods: [],
          authProvider: "google",
        };

        await setDoc(userDocRef, userDoc);
        toast.success("Account created successfully!");
      } else {
        // Update the last login time
        await setDoc(
          userDocRef,
          {
            lastLogin: serverTimestamp(),
            updatedAt: serverTimestamp(),
            authProvider: "google",
          },
          { merge: true }
        );
        toast.success("Welcome back!");
      }

      return extractSerializableUser(user);
    } catch (error: any) {
      // Provide user-friendly error messages for Google auth
      let errorMessage = "Google sign-in failed. Please try again.";

      if (error.code === "auth/popup-closed-by-user") {
        errorMessage =
          "Sign-in window was closed. Please try again to complete sign-in.";
      } else if (error.code === "auth/cancelled-popup-request") {
        errorMessage = "Sign-in was interrupted. Please try again.";
      } else if (error.code === "auth/popup-blocked") {
        errorMessage =
          "Sign-in window was blocked by your browser. Please allow popups for this site.";
      } else if (
        error.code === "auth/account-exists-with-different-credential"
      ) {
        errorMessage =
          "An account already exists with the same email but different sign-in method. Please use that method.";
      } else if (error.code === "auth/network-request-failed") {
        errorMessage =
          "Network error. Please check your internet connection and try again.";
      } else if (error.code === "auth/user-disabled") {
        errorMessage =
          "This account has been disabled. Please contact support.";
      }

      toast.error(errorMessage);
      return rejectWithValue(errorMessage);
    }
  }
);

export const loginUser = createAsyncThunk(
  "auth/login",
  async (
    { email, password }: { email: string; password: string },
    { rejectWithValue }
  ) => {
    try {
      // Check if the email has been used for Google sign-in
      const signInMethods = await fetchSignInMethodsForEmail(auth, email);

      // If the email is associated with Google sign-in but not with email/password
      if (
        signInMethods.includes("google.com") &&
        !signInMethods.includes("password")
      ) {
        const errorMsg =
          "Please sign in with Google instead. This email is linked to a Google account.";
        toast.error(errorMsg);
        return rejectWithValue(errorMsg);
      }

      const userCredential = await signInWithEmailAndPassword(
        auth,
        email,
        password
      );

      // Update user document with last login and auth provider
      const userDocRef = doc(db, "users", userCredential.user.uid);
      await setDoc(
        userDocRef,
        {
          lastLogin: serverTimestamp(),
          updatedAt: serverTimestamp(),
          authProvider: "password",
        },
        { merge: true }
      );

      toast.success("Welcome back!");
      return extractSerializableUser(userCredential.user);
    } catch (error: any) {
      // Provide user-friendly error messages for login
      let errorMessage =
        "Sign-in failed. Please check your credentials and try again.";

      if (error.code === "auth/account-exists-with-different-credential") {
        errorMessage =
          "This email is linked to a different sign-in method. Please use that method instead.";
      } else if (
        error.code === "auth/user-not-found" ||
        error.code === "auth/wrong-password"
      ) {
        errorMessage =
          "Invalid email or password. Please check your information and try again.";
      } else if (error.code === "auth/too-many-requests") {
        errorMessage =
          "Too many unsuccessful attempts. Please try again later or reset your password.";
      } else if (error.code === "auth/user-disabled") {
        errorMessage =
          "This account has been disabled. Please contact support.";
      } else if (error.code === "auth/invalid-email") {
        errorMessage = "Please enter a valid email address.";
      } else if (error.code === "auth/network-request-failed") {
        errorMessage =
          "Network error. Please check your internet connection and try again.";
      }

      toast.error(errorMessage);
      return rejectWithValue(errorMessage);
    }
  }
);

// Helper function to create user document
const createUserDocumentHelper = async (
  uid: string,
  userData: { name: string | null; email: string | null; role: string }
) => {
  try {
    const userDoc = {
      uid,
      email: userData.email,
      displayName: userData.name,
      photoURL: null,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
      role: userData.role,
      phoneNumber: "",
      fitnessGoal: "",
      weight: null,
      height: null,
      addresses: [],
      paymentMethods: [],
      isResumeUploaded: false,
      isWorkPreferencesSet: false,
    };

    await setDoc(doc(db, "users", uid), userDoc);
    return userDoc;
  } catch (error: any) {
    // Log the error but don't expose it to the user
    console.error("Error creating user document:", error);
    // Return a generic error message
    toast.error(
      "There was a problem setting up your account. Please try again."
    );
    throw new Error("Failed to create user profile");
  }
};

export const checkAuthState = createAsyncThunk(
  "auth/checkState",
  async (_, { rejectWithValue }) => {
    try {
      return new Promise<SerializableUser | null>((resolve, reject) => {
        const unsubscribe = onAuthStateChanged(auth, async (user) => {
          unsubscribe();

          if (!user) {
            resolve(null);
            return;
          }

          try {
            // Fetch user data from Firestore
            const userDoc = await getDoc(doc(db, "users", user.uid));

            // If user document doesn't exist, create it
            if (!userDoc.exists()) {
              await createUserDocumentHelper(user.uid, {
                name: user.displayName,
                email: user.email,
                role: "user",
              });
            }

            // Return serialized user data
            resolve(extractSerializableUser(user));
          } catch (error: any) {
            // Provide a user-friendly error message
            const errorMessage =
              "Failed to load user profile. Please refresh and try again.";
            toast.error(errorMessage);
            reject(errorMessage);
          }
        });
      });
    } catch (error: any) {
      // Provide a user-friendly error message
      const errorMessage =
        "Authentication check failed. Please try signing in again.";
      toast.error(errorMessage);
      return rejectWithValue(errorMessage);
    }
  }
);

export const signOut = createAsyncThunk(
  "auth/signOut",
  async (_, { rejectWithValue }) => {
    try {
      await firebaseSignOut(auth);

      return null;
    } catch (error: any) {
      // Provide a user-friendly error message
      const errorMessage = "Failed to log out. Please try again.";
      toast.error(errorMessage);
      return rejectWithValue(errorMessage);
    }
  }
);

export const resetPassword = createAsyncThunk(
  "auth/resetPassword",
  async (email: string, { rejectWithValue }) => {
    try {
      // Check if the email exists and what providers it uses
      const signInMethods = await fetchSignInMethodsForEmail(auth, email);

      // If no account exists with this email
      if (signInMethods.length === 0) {
        const errorMsg = "No account found with this email address.";
        toast.error(errorMsg);
        return rejectWithValue(errorMsg);
      }

      // If the email is associated with Google only (not with email/password)
      if (
        signInMethods.includes("google.com") &&
        !signInMethods.includes("password")
      ) {
        const errorMsg =
          "This email is linked to a Google account. Please sign in with Google instead.";
        toast.error(errorMsg);
        return rejectWithValue(errorMsg);
      }

      // Configure password reset email settings
      const actionCodeSettings = {
        // URL you want to redirect back to after password reset
        url: `${window.location.origin}/auth/login?reset=success`,
        handleCodeInApp: false,
      };

      // Send password reset email
      await sendPasswordResetEmail(auth, email, actionCodeSettings);

      toast.success("Password reset email sent. Please check your inbox.");
      return { email, success: true };
    } catch (error: any) {
      // Provide user-friendly error messages for password reset
      let errorMessage =
        "Failed to send password reset email. Please try again.";

      if (error.code === "auth/invalid-email") {
        errorMessage = "Please enter a valid email address.";
      } else if (error.code === "auth/missing-email") {
        errorMessage = "Please enter your email address.";
      } else if (error.code === "auth/network-request-failed") {
        errorMessage =
          "Network error. Please check your internet connection and try again.";
      } else if (error.code === "auth/too-many-requests") {
        errorMessage = "Too many attempts. Please try again later.";
      }

      toast.error(errorMessage);
      return rejectWithValue(errorMessage);
    }
  }
);

export const authSlice = createSlice({
  name: "auth",
  initialState,
  reducers: {
    setUser: (state, action) => {
      state.user = action.payload;
    },
    setLoading: (state, action) => {
      state.loading = action.payload;
    },
    clearError: (state) => {
      state.error = null;
    },
  },
  extraReducers: (builder) => {
    builder
      // Register
      .addCase(registerUser.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(registerUser.fulfilled, (state, action) => {
        state.loading = false;
        state.user = action.payload;
        state.error = null;
      })
      .addCase(registerUser.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })
      // Login
      .addCase(loginUser.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(loginUser.fulfilled, (state, action) => {
        state.loading = false;
        state.user = action.payload;
        state.error = null;
      })
      .addCase(loginUser.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })
      // Login with Google
      .addCase(loginWithGoogle.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(loginWithGoogle.fulfilled, (state, action) => {
        state.loading = false;
        state.user = action.payload;
        state.error = null;
      })
      .addCase(loginWithGoogle.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })
      // Reset Password
      .addCase(resetPassword.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(resetPassword.fulfilled, (state) => {
        state.loading = false;
        state.error = null;
      })
      .addCase(resetPassword.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })
      // Check Auth State
      .addCase(checkAuthState.pending, (state) => {
        state.loading = true;
      })
      .addCase(checkAuthState.fulfilled, (state, action) => {
        state.loading = false;
        state.user = action.payload;
      })
      .addCase(checkAuthState.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })
      // Sign Out
      .addCase(signOut.pending, (state) => {
        state.loading = true;
      })
      .addCase(signOut.fulfilled, (state) => {
        state.loading = false;
        state.user = null;
        state.error = null;
      })
      .addCase(signOut.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export const { setUser, setLoading, clearError } = authSlice.actions;
export default authSlice.reducer;
