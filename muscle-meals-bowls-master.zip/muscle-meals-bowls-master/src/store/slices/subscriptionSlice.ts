import { createSlice, createAsyncThunk, PayloadAction } from "@reduxjs/toolkit";
import {
  collection,
  getDocs,
  doc,
  getDoc,
  query,
  where,
} from "firebase/firestore";
import { db } from "../../lib/firebase";

// Define Subscription type based on the shared screenshots
interface Subscription {
  amount: number;
  createdAt: string;
  currency: string;
  endDate: string;
  frequency: string;
  itemId: string;
  paymentId: string;
  planId: string;
  quantity: number;
  startDate: string;
  status: string;
  subscriptionId: string;
  totalCount: number;
  type?: string;
  updatedAt?: string;
  userId?: string;
}

// Extend subscription with meal plan details
interface SubscriptionWithMealPlan extends Subscription {
  mealPlan?: {
    name: string;
    description: string;
    totalCalories: number;
    totalCarbs: number;
    totalProtein: number;
    totalFat: number;
    totalFiber: number;
    totalPrice: number;
    tags: string[];
    duration: number;
  };
}

interface SubscriptionState {
  subscriptions: SubscriptionWithMealPlan[];
  loading: boolean;
  error: string | null;
  selectedSubscription: SubscriptionWithMealPlan | null;
}

const initialState: SubscriptionState = {
  subscriptions: [],
  loading: false,
  error: null,
  selectedSubscription: null,
};

// Fetch all subscriptions
export const fetchAllSubscriptions = createAsyncThunk(
  "subscriptions/fetchAll",
  async (_, { rejectWithValue }) => {
    try {
      const subscriptionsRef = collection(db, "subscriptions");
      const snapshot = await getDocs(subscriptionsRef);

      const subscriptions = await Promise.all(
        snapshot.docs.map(async (docSnapshot) => {
          const subscription = {
            ...docSnapshot.data(),
            subscriptionId: docSnapshot.id,
          } as Subscription;

          // Fetch related meal plan
          if (subscription.planId) {
            try {
              const mealPlanDoc = await getDoc(
                doc(db, "mealPlans", subscription.planId)
              );
              if (mealPlanDoc.exists()) {
                return {
                  ...subscription,
                  mealPlan: mealPlanDoc.data(),
                } as SubscriptionWithMealPlan;
              }
            } catch (error) {
              console.error("Error fetching meal plan:", error);
            }
          }

          return subscription as SubscriptionWithMealPlan;
        })
      );

      return subscriptions;
    } catch (error: any) {
      return rejectWithValue(error.message);
    }
  }
);

// Fetch subscriptions by user ID
export const fetchUserSubscriptions = createAsyncThunk(
  "subscriptions/fetchByUser",
  async (userId: string, { rejectWithValue }) => {
    try {
      const q = query(
        collection(db, "subscriptions"),
        where("userId", "==", userId)
      );

      const snapshot = await getDocs(q);

      const subscriptions = await Promise.all(
        snapshot.docs.map(async (docSnapshot) => {
          const subscription = {
            ...docSnapshot.data(),
            subscriptionId: docSnapshot.id,
          } as Subscription;

          // Fetch related meal plan
          if (subscription.planId) {
            try {
              const mealPlanDoc = await getDoc(
                doc(db, "mealPlans", subscription.planId)
              );
              if (mealPlanDoc.exists()) {
                return {
                  ...subscription,
                  mealPlan: mealPlanDoc.data(),
                } as SubscriptionWithMealPlan;
              }
            } catch (error) {
              console.error("Error fetching meal plan:", error);
            }
          }

          return subscription as SubscriptionWithMealPlan;
        })
      );

      return subscriptions;
    } catch (error: any) {
      return rejectWithValue(error.message);
    }
  }
);

const subscriptionSlice = createSlice({
  name: "subscriptions",
  initialState,
  reducers: {
    setSelectedSubscription: (
      state,
      action: PayloadAction<SubscriptionWithMealPlan | null>
    ) => {
      state.selectedSubscription = action.payload;
    },
    clearSubscriptions: (state) => {
      state.subscriptions = [];
      state.selectedSubscription = null;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchAllSubscriptions.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchAllSubscriptions.fulfilled, (state, action) => {
        state.loading = false;
        state.subscriptions = action.payload;
      })
      .addCase(fetchAllSubscriptions.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })
      .addCase(fetchUserSubscriptions.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchUserSubscriptions.fulfilled, (state, action) => {
        state.loading = false;
        state.subscriptions = action.payload;
      })
      .addCase(fetchUserSubscriptions.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export const { setSelectedSubscription, clearSubscriptions } =
  subscriptionSlice.actions;
export default subscriptionSlice.reducer;
