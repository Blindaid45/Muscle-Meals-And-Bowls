import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import {
  collection,
  addDoc,
  getDocs,
  doc,
  getDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  serverTimestamp,
  Timestamp,
  arrayUnion,
} from "firebase/firestore";
import { db, auth } from "@/lib/firebase";
import { toast } from "sonner";
import { Meal } from "./mealSlice";
import { AdminMealPlan } from "./adminMealPlanSlice";

// Define the meal plan item interface
export interface MealPlanItem {
  id?: string; // Generated on creation
  mealId: string; // Reference to the meal
  quantity: number; // Quantity in grams
  dayNumbers: number[]; // Days of the plan (1, 2, 3, etc.) as an array
  mealTimes: string[]; // When to eat (breakfast, lunch, dinner, snack) as an array
  notes?: string; // Optional notes for this meal
  customizations?: string[]; // Any customization requests
}

// Define the meal plan interface
export interface MealPlan {
  id?: string;
  name: string;
  description: string;
  userId: string;
  duration: number; // Duration in days
  isPublic: boolean;
  tags: string[];
  isSubscribed?: boolean;
  adminPlanId?: string; // Reference to the admin plan if this is a copy

  // Nutrition totals (calculated)
  totalCalories: number;
  totalProtein: number;
  totalCarbs: number;
  totalFat: number;
  totalFiber: number;
  totalPrice: number;

  // Items in the plan
  items: MealPlanItem[];

  // Timestamps
  createdAt?: Date;
  updatedAt?: Date;
}

// State interface
interface MealPlanState {
  mealPlans: MealPlan[];
  currentMealPlan: MealPlan | null;
  publicMealPlans: MealPlan[];
  loading: boolean;
  error: string | null;
}

// Initial state
const initialState: MealPlanState = {
  mealPlans: [],
  currentMealPlan: null,
  publicMealPlans: [],
  loading: false,
  error: null,
};

// Helper functions
const convertTimestamps = (data: any) => {
  const converted = { ...data };
  if (converted.createdAt instanceof Timestamp) {
    converted.createdAt = converted.createdAt.toDate();
  }
  if (converted.updatedAt instanceof Timestamp) {
    converted.updatedAt = converted.updatedAt.toDate();
  }
  return converted;
};

// Copy an admin meal plan to user's personal plans and update the subscribedUsers count
export const createFromAdminMealPlan = createAsyncThunk(
  "mealPlans/createFromAdmin",
  async (adminPlanId: string, { rejectWithValue }) => {
    try {
      const user = auth.currentUser;
      if (!user) throw new Error("No authenticated user");

      // Get the admin plan
      const adminPlanRef = doc(db, "adminMealPlans", adminPlanId);
      const adminPlanSnap = await getDoc(adminPlanRef);

      if (!adminPlanSnap.exists()) {
        throw new Error("Admin meal plan not found");
      }

      const adminPlan = adminPlanSnap.data() as AdminMealPlan;

      // Create a user meal plan version
      const newPlan: Omit<MealPlan, "id"> = {
        name: adminPlan.name,
        description: adminPlan.description,
        userId: user.uid,
        duration: adminPlan.duration,
        isPublic: false,
        tags: adminPlan.tags || [],
        totalCalories: adminPlan.totalCalories,
        totalProtein: adminPlan.totalProtein,
        totalCarbs: adminPlan.totalCarbs,
        totalFat: adminPlan.totalFat,
        totalFiber: adminPlan.totalFiber,
        totalPrice: adminPlan.totalPrice,
        items: adminPlan.items,
        isSubscribed: false,
        adminPlanId: adminPlanId,
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      // Add to user's meal plans collection
      const docRef = await addDoc(collection(db, "mealPlans"), {
        ...newPlan,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });

      // Update the admin plan's subscribedUsers array
      await updateDoc(adminPlanRef, {
        subscribedUsers: arrayUnion(user.uid),
      });

      toast.success("Meal plan added to your collection!");

      return {
        id: docRef.id,
        ...newPlan,
      } as MealPlan;
    } catch (error: any) {
      toast.error("Failed to subscribe to meal plan");
      return rejectWithValue(error.message);
    }
  }
);

// Calculate nutrition totals from a list of meals and quantities
export const calculateMealPlanTotals = createAsyncThunk(
  "mealPlans/calculateTotals",
  async (items: MealPlanItem[], { rejectWithValue }) => {
    try {
      let totalCalories = 0;
      let totalProtein = 0;
      let totalCarbs = 0;
      let totalFat = 0;
      let totalFiber = 0;
      let totalPrice = 0;

      // Fetch all meals that are part of the plan
      for (const item of items) {
        const mealRef = doc(db, "meals", item.mealId);
        const mealSnap = await getDoc(mealRef);

        if (!mealSnap.exists()) {
          throw new Error(`Meal with ID ${item.mealId} not found`);
        }

        const mealData = mealSnap.data() as Meal;
        const quantityRatio = item.quantity / mealData.baseQuantity;

        // Calculate the number of occurrences based on combinations of mealTimes and dayNumbers
        const occurrences = item.mealTimes.length * item.dayNumbers.length;

        totalCalories +=
          (Math.round(mealData.calories * quantityRatio * 10) / 10) *
          occurrences;
        totalProtein +=
          (Math.round(mealData.protein * quantityRatio * 10) / 10) *
          occurrences;
        totalCarbs +=
          (Math.round(mealData.carbs * quantityRatio * 10) / 10) * occurrences;
        totalFat +=
          (Math.round(mealData.fat * quantityRatio * 10) / 10) * occurrences;
        totalFiber +=
          (Math.round(mealData.fiber * quantityRatio * 10) / 10) * occurrences;
        totalPrice += mealData.price * quantityRatio * occurrences;
      }

      return {
        totalCalories,
        totalProtein,
        totalCarbs,
        totalFat,
        totalFiber,
        totalPrice,
      };
    } catch (error: any) {
      return rejectWithValue(error.message);
    }
  }
);

// Create a new meal plan
export const createMealPlan = createAsyncThunk(
  "mealPlans/create",
  async (
    mealPlanData: Omit<MealPlan, "id" | "userId" | "createdAt" | "updatedAt">,
    { dispatch, rejectWithValue }
  ) => {
    try {
      const user = auth.currentUser;
      if (!user) throw new Error("No authenticated user");

      // Calculate nutrition totals
      const totals = await dispatch(
        calculateMealPlanTotals(mealPlanData.items)
      ).unwrap();

      // Prepare data for Firestore
      const newMealPlan = {
        ...mealPlanData,
        ...totals,
        userId: user.uid,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
        isSubscribed: false,
      };

      const docRef = await addDoc(collection(db, "mealPlans"), newMealPlan);

      toast.success("Meal plan created successfully!");

      // Convert timestamps for Redux
      return {
        id: docRef.id,
        ...newMealPlan,
        createdAt: new Date(),
        updatedAt: new Date(),
      };
    } catch (error: any) {
      toast.error("Failed to create meal plan");
      return rejectWithValue(error.message);
    }
  }
);

// Fetch all meal plans for the current user
export const fetchUserMealPlans = createAsyncThunk(
  "mealPlans/fetchUserPlans",
  async (_, { rejectWithValue }) => {
    try {
      const user = auth.currentUser;
      if (!user) throw new Error("No authenticated user");

      const mealPlansRef = collection(db, "mealPlans");
      const q = query(mealPlansRef, where("userId", "==", user.uid));
      const querySnapshot = await getDocs(q);

      const mealPlans = querySnapshot.docs.map((doc) => ({
        id: doc.id,
        ...convertTimestamps(doc.data()),
      })) as MealPlan[];

      return mealPlans;
    } catch (error: any) {
      toast.error("Failed to fetch meal plans");
      return rejectWithValue(error.message);
    }
  }
);

// Get a single meal plan by ID
export const fetchMealPlanById = createAsyncThunk(
  "mealPlans/fetchById",
  async (id: string, { rejectWithValue }) => {
    try {
      const docRef = doc(db, "mealPlans", id);
      const docSnapshot = await getDoc(docRef);

      if (!docSnapshot.exists()) {
        throw new Error("Meal plan not found");
      }

      return {
        id: docSnapshot.id,
        ...convertTimestamps(docSnapshot.data()),
      } as MealPlan;
    } catch (error: any) {
      toast.error("Failed to fetch meal plan");
      return rejectWithValue(error.message);
    }
  }
);

// Update a meal plan
export const updateMealPlan = createAsyncThunk(
  "mealPlans/update",
  async (
    { id, ...mealPlanData }: Partial<MealPlan> & { id: string },
    { dispatch, rejectWithValue }
  ) => {
    try {
      const user = auth.currentUser;
      if (!user) throw new Error("No authenticated user");

      const docRef = doc(db, "mealPlans", id);
      const docSnapshot = await getDoc(docRef);

      if (!docSnapshot.exists()) {
        throw new Error("Meal plan not found");
      }

      // Verify ownership
      const planData = docSnapshot.data();
      if (planData.userId !== user.uid) {
        throw new Error("You don't have permission to update this meal plan");
      }

      // If items are being updated, recalculate totals
      let updateData: any = {
        ...mealPlanData,
        updatedAt: serverTimestamp(),
      };

      if (mealPlanData.items) {
        const totals = await dispatch(
          calculateMealPlanTotals(mealPlanData.items)
        ).unwrap();
        updateData = { ...updateData, ...totals };
      }

      await updateDoc(docRef, updateData);

      toast.success("Meal plan updated successfully!");

      // Get the updated document for return
      const updatedSnapshot = await getDoc(docRef);
      return {
        id,
        ...convertTimestamps(updatedSnapshot.data()),
      } as MealPlan;
    } catch (error: any) {
      toast.error("Failed to update meal plan");
      return rejectWithValue(error.message);
    }
  }
);

// Add a meal to an existing meal plan
export const addMealToMealPlan = createAsyncThunk(
  "mealPlans/addMeal",
  async (
    { planId, mealItem }: { planId: string; mealItem: MealPlanItem },
    { dispatch, rejectWithValue }
  ) => {
    try {
      const user = auth.currentUser;
      if (!user) throw new Error("No authenticated user");

      const docRef = doc(db, "mealPlans", planId);
      const docSnapshot = await getDoc(docRef);

      if (!docSnapshot.exists()) {
        throw new Error("Meal plan not found");
      }

      // Verify ownership
      const planData = docSnapshot.data() as MealPlan;
      if (planData.userId !== user.uid) {
        throw new Error("You don't have permission to update this meal plan");
      }

      // Ensure dayNumbers and mealTimes are arrays
      const newMealItem = {
        ...mealItem,
        id: crypto.randomUUID(),
        dayNumbers: Array.isArray(mealItem.dayNumbers)
          ? mealItem.dayNumbers
          : [mealItem.dayNumbers],
        mealTimes: Array.isArray(mealItem.mealTimes)
          ? mealItem.mealTimes
          : [mealItem.mealTimes],
      };

      const currentItems = planData.items || [];
      const updatedItems = [...currentItems, newMealItem];

      // Recalculate totals with the new item
      const totals = await dispatch(
        calculateMealPlanTotals(updatedItems)
      ).unwrap();

      // Update the plan
      await updateDoc(docRef, {
        items: updatedItems,
        ...totals,
        updatedAt: serverTimestamp(),
      });

      // Get the updated document
      const updatedSnapshot = await getDoc(docRef);
      return {
        id: planId,
        ...convertTimestamps(updatedSnapshot.data()),
      } as MealPlan;
    } catch (error: any) {
      toast.error("Failed to add meal to plan");
      return rejectWithValue(error.message);
    }
  }
);

// Remove a meal from a meal plan
export const removeMealFromMealPlan = createAsyncThunk(
  "mealPlans/removeMeal",
  async (
    { planId, itemId }: { planId: string; itemId: string },
    { dispatch, rejectWithValue }
  ) => {
    try {
      const user = auth.currentUser;
      if (!user) throw new Error("No authenticated user");

      const docRef = doc(db, "mealPlans", planId);
      const docSnapshot = await getDoc(docRef);

      if (!docSnapshot.exists()) {
        throw new Error("Meal plan not found");
      }

      // Verify ownership
      const planData = docSnapshot.data() as MealPlan;
      if (planData.userId !== user.uid) {
        throw new Error("You don't have permission to update this meal plan");
      }

      // Remove the meal item
      const updatedItems = planData.items.filter((item) => item.id !== itemId);

      // Recalculate totals without the removed meal
      const totals = await dispatch(
        calculateMealPlanTotals(updatedItems)
      ).unwrap();

      // Update the plan
      await updateDoc(docRef, {
        items: updatedItems,
        ...totals,
        updatedAt: serverTimestamp(),
      });

      toast.success("Meal removed from plan successfully!");

      // Get the updated document
      const updatedSnapshot = await getDoc(docRef);
      return {
        id: planId,
        ...convertTimestamps(updatedSnapshot.data()),
      } as MealPlan;
    } catch (error: any) {
      toast.error("Failed to remove meal from plan");
      return rejectWithValue(error.message);
    }
  }
);

// Update a single meal item in a meal plan
export const updateMealPlanItem = createAsyncThunk(
  "mealPlans/updateMealItem",
  async (
    {
      planId,
      itemId,
      updatedItem,
    }: {
      planId: string;
      itemId: string;
      updatedItem: Partial<MealPlanItem>;
    },
    { dispatch, rejectWithValue }
  ) => {
    try {
      const user = auth.currentUser;
      if (!user) throw new Error("No authenticated user");

      const docRef = doc(db, "mealPlans", planId);
      const docSnapshot = await getDoc(docRef);

      if (!docSnapshot.exists()) {
        throw new Error("Meal plan not found");
      }

      // Verify ownership
      const planData = docSnapshot.data() as MealPlan;
      if (planData.userId !== user.uid) {
        throw new Error("You don't have permission to update this meal plan");
      }

      // Ensure dayNumbers and mealTimes are arrays if provided
      const sanitizedUpdate: Partial<MealPlanItem> = { ...updatedItem };
      if (updatedItem.dayNumbers) {
        sanitizedUpdate.dayNumbers = Array.isArray(updatedItem.dayNumbers)
          ? updatedItem.dayNumbers
          : [updatedItem.dayNumbers];
      }

      if (updatedItem.mealTimes) {
        sanitizedUpdate.mealTimes = Array.isArray(updatedItem.mealTimes)
          ? updatedItem.mealTimes
          : [updatedItem.mealTimes];
      }

      // Find and update the specific meal item
      const updatedItems = planData.items.map((item) =>
        item.id === itemId ? { ...item, ...sanitizedUpdate } : item
      );

      // Recalculate totals with the updated meal
      const totals = await dispatch(
        calculateMealPlanTotals(updatedItems)
      ).unwrap();

      // Update the plan
      await updateDoc(docRef, {
        items: updatedItems,
        ...totals,
        updatedAt: serverTimestamp(),
      });

      toast.success("Meal item updated successfully!");

      // Get the updated document
      const updatedSnapshot = await getDoc(docRef);
      return {
        id: planId,
        ...convertTimestamps(updatedSnapshot.data()),
      } as MealPlan;
    } catch (error: any) {
      toast.error("Failed to update meal item");
      return rejectWithValue(error.message);
    }
  }
);

// Delete a meal plan
export const deleteMealPlan = createAsyncThunk(
  "mealPlans/delete",
  async (id: string, { rejectWithValue }) => {
    try {
      const user = auth.currentUser;
      if (!user) throw new Error("No authenticated user");

      const docRef = doc(db, "mealPlans", id);
      const docSnapshot = await getDoc(docRef);

      if (!docSnapshot.exists()) {
        throw new Error("Meal plan not found");
      }

      // Verify ownership
      const planData = docSnapshot.data();
      if (planData.userId !== user.uid) {
        throw new Error("You don't have permission to delete this meal plan");
      }

      await deleteDoc(docRef);

      toast.success("Meal plan deleted successfully!");
      return id;
    } catch (error: any) {
      toast.error("Failed to delete meal plan");
      return rejectWithValue(error.message);
    }
  }
);

// Fetch public meal plans
export const fetchPublicMealPlans = createAsyncThunk(
  "mealPlans/fetchPublic",
  async (_, { rejectWithValue }) => {
    try {
      const mealPlansRef = collection(db, "mealPlans");
      const q = query(mealPlansRef, where("isPublic", "==", true));
      const querySnapshot = await getDocs(q);

      const mealPlans = querySnapshot.docs.map((doc) => ({
        id: doc.id,
        ...convertTimestamps(doc.data()),
      })) as MealPlan[];

      return mealPlans;
    } catch (error: any) {
      toast.error("Failed to fetch public meal plans");
      return rejectWithValue(error.message);
    }
  }
);

// Copy a public meal plan to user's own plans
export const copyPublicMealPlan = createAsyncThunk(
  "mealPlans/copyPublic",
  async (planId: string, { rejectWithValue }) => {
    try {
      const user = auth.currentUser;
      if (!user) throw new Error("No authenticated user");

      // Get the source plan
      const sourceRef = doc(db, "mealPlans", planId);
      const sourceSnap = await getDoc(sourceRef);

      if (!sourceSnap.exists()) {
        throw new Error("Meal plan not found");
      }

      const sourcePlan = sourceSnap.data() as MealPlan;

      // Only allow copying public plans
      if (!sourcePlan.isPublic) {
        throw new Error("This meal plan is not public and cannot be copied");
      }

      // Create a new plan based on the source plan
      const newPlan = {
        ...sourcePlan,
        name: `Copy of ${sourcePlan.name}`,
        userId: user.uid,
        isPublic: false, // Make the copy private by default
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      };

      // Delete the id from the source plan
      delete newPlan.id;

      // Add to Firestore
      const docRef = await addDoc(collection(db, "mealPlans"), newPlan);

      toast.success("Meal plan copied successfully!");

      return {
        id: docRef.id,
        ...newPlan,
        createdAt: new Date(),
        updatedAt: new Date(),
      } as MealPlan;
    } catch (error: any) {
      toast.error("Failed to copy meal plan");
      return rejectWithValue(error.message);
    }
  }
);

// Create the slice
const mealPlanSlice = createSlice({
  name: "mealPlans",
  initialState,
  reducers: {
    clearCurrentMealPlan: (state) => {
      state.currentMealPlan = null;
    },
    clearMealPlanErrors: (state) => {
      state.error = null;
    },
  },
  extraReducers: (builder) => {
    builder
      // Create meal plan
      .addCase(createMealPlan.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(createMealPlan.fulfilled, (state, action) => {
        state.loading = false;
        state.mealPlans.push(action.payload);
        state.currentMealPlan = action.payload;
      })
      .addCase(createMealPlan.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })

      // Fetch user's meal plans
      .addCase(fetchUserMealPlans.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchUserMealPlans.fulfilled, (state, action) => {
        state.loading = false;
        state.mealPlans = action.payload;
      })
      .addCase(fetchUserMealPlans.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })

      // Fetch meal plan by ID
      .addCase(fetchMealPlanById.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchMealPlanById.fulfilled, (state, action) => {
        state.loading = false;
        state.currentMealPlan = action.payload;
      })
      .addCase(fetchMealPlanById.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })

      // Update meal plan
      .addCase(updateMealPlan.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updateMealPlan.fulfilled, (state, action) => {
        state.loading = false;
        state.currentMealPlan = action.payload;
        state.mealPlans = state.mealPlans.map((plan) =>
          plan.id === action.payload.id ? action.payload : plan
        );
      })
      .addCase(updateMealPlan.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })

      // Add meal to plan
      .addCase(addMealToMealPlan.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(addMealToMealPlan.fulfilled, (state, action) => {
        state.loading = false;
        state.currentMealPlan = action.payload;
        state.mealPlans = state.mealPlans.map((plan) =>
          plan.id === action.payload.id ? action.payload : plan
        );
      })
      .addCase(addMealToMealPlan.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })

      // Remove meal from plan
      .addCase(removeMealFromMealPlan.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(removeMealFromMealPlan.fulfilled, (state, action) => {
        state.loading = false;
        state.currentMealPlan = action.payload;
        state.mealPlans = state.mealPlans.map((plan) =>
          plan.id === action.payload.id ? action.payload : plan
        );
      })
      .addCase(removeMealFromMealPlan.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })

      // Update meal item
      .addCase(updateMealPlanItem.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updateMealPlanItem.fulfilled, (state, action) => {
        state.loading = false;
        state.currentMealPlan = action.payload;
        state.mealPlans = state.mealPlans.map((plan) =>
          plan.id === action.payload.id ? action.payload : plan
        );
      })
      .addCase(updateMealPlanItem.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })

      // Delete meal plan
      .addCase(deleteMealPlan.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(deleteMealPlan.fulfilled, (state, action) => {
        state.loading = false;
        state.mealPlans = state.mealPlans.filter(
          (plan) => plan.id !== action.payload
        );
        if (state.currentMealPlan?.id === action.payload) {
          state.currentMealPlan = null;
        }
      })
      .addCase(deleteMealPlan.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })

      // Fetch public meal plans
      .addCase(fetchPublicMealPlans.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchPublicMealPlans.fulfilled, (state, action) => {
        state.loading = false;
        state.publicMealPlans = action.payload;
      })
      .addCase(fetchPublicMealPlans.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })

      // Copy public meal plan
      .addCase(copyPublicMealPlan.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(copyPublicMealPlan.fulfilled, (state, action) => {
        state.loading = false;
        state.mealPlans.push(action.payload);
        state.currentMealPlan = action.payload;
      })
      .addCase(copyPublicMealPlan.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })

      // Create from admin meal plan
      .addCase(createFromAdminMealPlan.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(createFromAdminMealPlan.fulfilled, (state, action) => {
        state.loading = false;
        state.mealPlans.push(action.payload);
        state.currentMealPlan = action.payload;
      })
      .addCase(createFromAdminMealPlan.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export const { clearCurrentMealPlan, clearMealPlanErrors } =
  mealPlanSlice.actions;
export default mealPlanSlice.reducer;
