import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import {
  collection,
  getDocs,
  query,
  where,
  Timestamp,
  limit,
} from "firebase/firestore";
import { db, auth } from "@/lib/firebase";

// Interface for the wallet data
interface Wallet {
  userId: string;
  createdAt?: string;
  updatedAt?: string;
  balance: number;
  currency?: string;
  paymentId?: string;
  orderId?: string;
  status?: string;
}

// Interface for wallet state
interface WalletState {
  wallet: Wallet | null;
  loading: boolean;
  error: string | null;
}

const initialState: WalletState = {
  wallet: null,
  loading: false,
  error: null,
};

// Helper function to convert Firestore data to serializable format
const convertTimestamps = (data: any) => {
  const converted = { ...data };
  if (converted.createdAt instanceof Timestamp) {
    converted.createdAt = converted.createdAt.toDate().toISOString();
  }
  if (converted.updatedAt instanceof Timestamp) {
    converted.updatedAt = converted.updatedAt.toDate().toISOString();
  }
  return converted;
};

// Fetch wallet details for the current user
export const fetchWalletDetails = createAsyncThunk(
  "wallet/fetchDetails",
  async (_, { rejectWithValue }) => {
    try {
      const user = auth.currentUser;
      if (!user) throw new Error("No authenticated user");

      // Query wallets collection for the current user's wallet
      const walletsRef = collection(db, "wallets");
      const walletQuery = query(
        walletsRef,
        where("userId", "==", user.uid),
        limit(1)
      );

      const walletSnapshot = await getDocs(walletQuery);

      // If no wallet found, return default wallet with zero balance
      if (walletSnapshot.empty) {
        return {
          wallet: {
            balance: 0,
            userId: user.uid,
          },
        };
      }

      // Get the first wallet document
      const walletDoc = walletSnapshot.docs[0];
      const walletData = walletDoc.data();

      // Process wallet data
      const processedWalletData = convertTimestamps(walletData);
      processedWalletData.balance = processedWalletData.balance;

      return {
        wallet: processedWalletData as Wallet,
      };
    } catch (error: any) {
      return rejectWithValue(error.message);
    }
  }
);

const walletSlice = createSlice({
  name: "wallet",
  initialState,
  reducers: {
    clearWallet: (state) => {
      state.wallet = null;
      state.loading = false;
      state.error = null;
    },
  },
  extraReducers: (builder) => {
    builder
      // Fetch Wallet
      .addCase(fetchWalletDetails.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchWalletDetails.fulfilled, (state, action) => {
        state.loading = false;
        state.wallet = action.payload.wallet;
      })
      .addCase(fetchWalletDetails.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export const { clearWallet } = walletSlice.actions;
export default walletSlice.reducer;
