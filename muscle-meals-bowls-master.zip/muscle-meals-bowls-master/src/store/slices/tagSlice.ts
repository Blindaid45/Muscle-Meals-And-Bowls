import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import {
  collection,
  addDoc,
  getDocs,
  doc,
  getDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
} from "firebase/firestore";
import { db } from "@/lib/firebase";
import { toast } from "sonner";
import { formatTagForStorage } from "@/utils/tagUtils";

export interface Tag {
  id?: string;
  name: string;
  description?: string;
  color?: string;
  createdAt?: Date;
  updatedAt?: Date;
}

interface TagState {
  tags: Tag[];
  currentTag: Tag | null;
  loading: boolean;
  error: string | null;
}

const initialState: TagState = {
  tags: [],
  currentTag: null,
  loading: false,
  error: null,
};

// Create a new tag
export const createTag = createAsyncThunk(
  "tags/create",
  async (
    tagData: Omit<Tag, "id" | "createdAt" | "updatedAt">,
    { rejectWithValue }
  ) => {
    try {
      // Add timestamp
      const timestamp = new Date();

      // Ensure the tag name is in the correct format for storage
      const formattedTagName = formatTagForStorage(tagData.name);

      const newTag = {
        ...tagData,
        name: formattedTagName, // Use the formatted name
        createdAt: timestamp,
        updatedAt: timestamp,
      };

      const docRef = await addDoc(collection(db, "tags"), newTag);

      toast.success("Tag added successfully!");
      return { id: docRef.id, ...newTag };
    } catch (error: any) {
      toast.error("Failed to add tag");
      return rejectWithValue(error.message);
    }
  }
);

// Get all tags
export const fetchTags = createAsyncThunk(
  "tags/fetchAll",
  async (_, { rejectWithValue }) => {
    try {
      const querySnapshot = await getDocs(collection(db, "tags"));
      const tags = querySnapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      })) as Tag[];

      return tags;
    } catch (error: any) {
      toast.error("Failed to fetch tags");
      return rejectWithValue(error.message);
    }
  }
);

// Get a single tag by ID
export const fetchTagById = createAsyncThunk(
  "tags/fetchById",
  async (id: string, { rejectWithValue }) => {
    try {
      const docRef = doc(db, "tags", id);
      const docSnapshot = await getDoc(docRef);

      if (!docSnapshot.exists()) {
        throw new Error("Tag not found");
      }

      return { id: docSnapshot.id, ...docSnapshot.data() } as Tag;
    } catch (error: any) {
      toast.error("Failed to fetch tag");
      return rejectWithValue(error.message);
    }
  }
);

// Update a tag
export const updateTag = createAsyncThunk(
  "tags/update",
  async (
    { id, ...tagData }: Partial<Tag> & { id: string },
    { rejectWithValue }
  ) => {
    try {
      const docRef = doc(db, "tags", id);

      // If name is provided, ensure it's in the correct format for storage
      const formattedData = tagData.name
        ? { ...tagData, name: formatTagForStorage(tagData.name) }
        : tagData;

      const updateData = { ...formattedData, updatedAt: new Date() };

      await updateDoc(docRef, updateData);

      toast.success("Tag updated successfully!");
      return { id, ...updateData };
    } catch (error: any) {
      toast.error("Failed to update tag");
      return rejectWithValue(error.message);
    }
  }
);

// Delete a tag
export const deleteTag = createAsyncThunk(
  "tags/delete",
  async (id: string, { rejectWithValue }) => {
    try {
      const docRef = doc(db, "tags", id);
      await deleteDoc(docRef);

      toast.success("Tag deleted successfully!");
      return id;
    } catch (error: any) {
      toast.error("Failed to delete tag");
      return rejectWithValue(error.message);
    }
  }
);

const tagSlice = createSlice({
  name: "tags",
  initialState,
  reducers: {
    setCurrentTag: (state, action) => {
      state.currentTag = action.payload;
    },
    clearCurrentTag: (state) => {
      state.currentTag = null;
    },
  },
  extraReducers: (builder) => {
    builder
      // Create tag
      .addCase(createTag.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(createTag.fulfilled, (state, action) => {
        state.loading = false;
        state.tags.push(action.payload);
      })
      .addCase(createTag.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })

      // Fetch all tags
      .addCase(fetchTags.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchTags.fulfilled, (state, action) => {
        state.loading = false;
        state.tags = action.payload;
      })
      .addCase(fetchTags.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })

      // Fetch tag by ID
      .addCase(fetchTagById.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchTagById.fulfilled, (state, action) => {
        state.loading = false;
        state.currentTag = action.payload;
      })
      .addCase(fetchTagById.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })

      // Update tag
      .addCase(updateTag.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updateTag.fulfilled, (state, action) => {
        state.loading = false;
        const index = state.tags.findIndex(
          (tag) => tag.id === action.payload.id
        );
        if (index !== -1) {
          state.tags[index] = { ...state.tags[index], ...action.payload };
        }
        if (state.currentTag?.id === action.payload.id) {
          state.currentTag = { ...state.currentTag, ...action.payload };
        }
      })
      .addCase(updateTag.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })

      // Delete tag
      .addCase(deleteTag.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(deleteTag.fulfilled, (state, action) => {
        state.loading = false;
        state.tags = state.tags.filter((tag) => tag.id !== action.payload);
        if (state.currentTag?.id === action.payload) {
          state.currentTag = null;
        }
      })
      .addCase(deleteTag.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export const { setCurrentTag, clearCurrentTag } = tagSlice.actions;
export default tagSlice.reducer;
