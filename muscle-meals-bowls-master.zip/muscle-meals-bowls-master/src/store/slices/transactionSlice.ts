import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import {
  collection,
  query,
  where,
  orderBy,
  getDocs,
  Timestamp,
} from "firebase/firestore";
import { db, auth } from "@/lib/firebase";

// Interface for transaction data
interface Transaction {
  transactionId: string;
  userId: string;
  amount: number;
  type: "credit" | "debit";
  description: string;
  referenceId?: string;
  orderId?: string;
  paymentId?: string;
  createdAt: any;
  status: "pending" | "completed" | "failed";
}

// Interface for transaction state
interface TransactionState {
  transactions: Transaction[];
  loading: boolean;
  error: string | null;
}

const initialState: TransactionState = {
  transactions: [],
  loading: false,
  error: null,
};

// Helper function to convert Firestore data to serializable format
const convertTransaction = (doc: any): Transaction => {
  const data = doc.data();
  return {
    ...data,
    transactionId: doc.id,
    // Keep createdAt as is - we'll handle display formatting in the UI
  };
};

// Fetch wallet transactions for the current user
export const fetchWalletTransactions = createAsyncThunk(
  "transactions/fetchAll",
  async (_, { rejectWithValue }) => {
    try {
      const user = auth.currentUser;
      if (!user) throw new Error("No authenticated user");

      // Query transactions collection for user's transactions, sorted by date (latest first)
      const transactionsRef = collection(db, "walletTransactions");
      const transactionsQuery = query(
        transactionsRef,
        where("userId", "==", user.uid),
        orderBy("createdAt", "desc")
      );

      const transactionDocs = await getDocs(transactionsQuery);

      // Map documents to Transaction objects
      const transactions = transactionDocs.docs.map(convertTransaction);

      return transactions;
    } catch (error: any) {
      return rejectWithValue(error.message);
    }
  }
);

const transactionSlice = createSlice({
  name: "transactions",
  initialState,
  reducers: {
    clearTransactions: (state) => {
      state.transactions = [];
      state.loading = false;
      state.error = null;
    },
  },
  extraReducers: (builder) => {
    builder
      // Fetch Transactions
      .addCase(fetchWalletTransactions.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchWalletTransactions.fulfilled, (state, action) => {
        state.loading = false;
        state.transactions = action.payload;
      })
      .addCase(fetchWalletTransactions.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export const { clearTransactions } = transactionSlice.actions;
export default transactionSlice.reducer;
