import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import {
  collection,
  getDocs,
  query,
  orderBy,
  limit,
  DocumentData,
  QueryDocumentSnapshot,
  where,
  getCountFromServer,
} from "firebase/firestore";
import { db } from "@/lib/firebase";
import { toast } from "sonner";

// Define the User interface
export interface AdminUser {
  id: string;
  email: string | null;
  displayName: string | null;
  phoneNumber: string | null;
  createdAt: string | null;
  updatedAt: string | null;
  walletBalance: number;
  fitnessGoal: string | null;
  weight: number | null;
  height: number | null;
}

interface AdminUsersState {
  users: AdminUser[];
  loading: boolean;
  error: string | null;
  lastVisible: QueryDocumentSnapshot<DocumentData> | null;
  totalUsers: number;
  currentPage: number;
  totalPages: number;
  pageSize: number;
}

const initialState: AdminUsersState = {
  users: [],
  loading: false,
  error: null,
  lastVisible: null,
  totalUsers: 0,
  currentPage: 1,
  totalPages: 1,
  pageSize: 10,
};

// Helper function to convert timestamps
const convertTimestamps = (data: any) => {
  const result = { ...data };
  for (const key in result) {
    if (result[key] && typeof result[key] === "object" && result[key].seconds) {
      result[key] = new Date(result[key].seconds * 1000).toISOString();
    }
  }
  return result;
};

// Get total user count
export const fetchTotalUserCount = createAsyncThunk(
  "adminUsers/fetchTotalUserCount",
  async (_, { rejectWithValue }) => {
    try {
      const userCountRef = collection(db, "users");
      const snapshot = await getCountFromServer(userCountRef);
      return snapshot.data().count;
    } catch (error: any) {
      return rejectWithValue(error.message);
    }
  }
);

// Fetch users with pagination
export const fetchUsers = createAsyncThunk(
  "adminUsers/fetchUsers",
  async (
    { page, pageSize }: { page: number; pageSize: number },
    { rejectWithValue }
  ) => {
    try {
      const usersRef = collection(db, "users");

      // Get the total count first
      const countSnapshot = await getCountFromServer(usersRef);
      const totalCount = countSnapshot.data().count;
      const totalPages = Math.max(1, Math.ceil(totalCount / pageSize));

      // If page is out of bounds, adjust it
      const adjustedPage = Math.min(page, totalPages);

      // Get users for the current page
      const usersQuery = query(
        usersRef,
        orderBy("createdAt", "desc"),
        limit(pageSize)
      );

      const usersSnapshot = await getDocs(usersQuery);
      const usersData: AdminUser[] = [];

      // Fetch each user's wallet data
      for (const userDoc of usersSnapshot.docs) {
        const userData = userDoc.data();

        // Fetch wallet data
        const walletQuery = query(
          collection(db, "wallets"),
          where("userId", "==", userDoc.id),
          limit(1)
        );

        const walletSnapshot = await getDocs(walletQuery);
        let walletBalance = 0;

        if (!walletSnapshot.empty) {
          const walletData = walletSnapshot.docs[0].data();
          walletBalance = walletData.balance || 0;
        }

        // Process user data
        const processedUserData = convertTimestamps(userData);

        usersData.push({
          id: userDoc.id,
          email: processedUserData.email || null,
          displayName: processedUserData.displayName || null,
          phoneNumber: processedUserData.phoneNumber || null,
          createdAt: processedUserData.createdAt || null,
          updatedAt: processedUserData.updatedAt || null,
          walletBalance,
          fitnessGoal: processedUserData.fitnessGoal || null,
          weight: processedUserData.weight || null,
          height: processedUserData.height || null,
        });
      }

      return {
        users: usersData,
        totalCount,
        totalPages,
        currentPage: adjustedPage,
      };
    } catch (error: any) {
      toast.error("Failed to fetch users");
      return rejectWithValue(error.message);
    }
  }
);

// Search users
export const searchUsers = createAsyncThunk(
  "adminUsers/searchUsers",
  async (searchTerm: string, { rejectWithValue }) => {
    try {
      if (!searchTerm.trim()) {
        return { users: [], totalCount: 0, totalPages: 1, currentPage: 1 };
      }

      const usersRef = collection(db, "users");

      // Get all users (this is not efficient for large datasets but Firebase doesn't support direct text search)
      const usersSnapshot = await getDocs(usersRef);

      const usersData: AdminUser[] = [];

      for (const userDoc of usersSnapshot.docs) {
        const userData = userDoc.data();
        const processedUserData = convertTimestamps(userData);

        // Only include users that match the search term
        const email = (processedUserData.email || "").toLowerCase();
        const displayName = (processedUserData.displayName || "").toLowerCase();
        const phoneNumber = (processedUserData.phoneNumber || "").toLowerCase();
        const searchTermLower = searchTerm.toLowerCase();

        if (
          email.includes(searchTermLower) ||
          displayName.includes(searchTermLower) ||
          phoneNumber.includes(searchTermLower) ||
          userDoc.id.toLowerCase().includes(searchTermLower)
        ) {
          // Fetch wallet data
          const walletQuery = query(
            collection(db, "wallets"),
            where("userId", "==", userDoc.id),
            limit(1)
          );

          const walletSnapshot = await getDocs(walletQuery);
          let walletBalance = 0;

          if (!walletSnapshot.empty) {
            const walletData = walletSnapshot.docs[0].data();
            walletBalance = walletData.balance || 0;
          }

          usersData.push({
            id: userDoc.id,
            email: processedUserData.email || null,
            displayName: processedUserData.displayName || null,
            phoneNumber: processedUserData.phoneNumber || null,
            createdAt: processedUserData.createdAt || null,
            updatedAt: processedUserData.updatedAt || null,
            walletBalance,
            fitnessGoal: processedUserData.fitnessGoal || null,
            weight: processedUserData.weight || null,
            height: processedUserData.height || null,
          });
        }
      }

      const totalCount = usersData.length;
      const totalPages = Math.max(1, Math.ceil(totalCount / 10)); // Using default pageSize of 10 for search results

      return {
        users: usersData,
        totalCount,
        totalPages,
        currentPage: 1,
      };
    } catch (error: any) {
      toast.error("Failed to search users");
      return rejectWithValue(error.message);
    }
  }
);

const adminUsersSlice = createSlice({
  name: "adminUsers",
  initialState,
  reducers: {
    clearUsers: (state) => {
      state.users = [];
      state.lastVisible = null;
      state.currentPage = 1;
    },
    setPageSize: (state, action) => {
      state.pageSize = action.payload;
    },
    setCurrentPage: (state, action) => {
      state.currentPage = action.payload;
    },
  },
  extraReducers: (builder) => {
    builder
      // Fetch Users
      .addCase(fetchUsers.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchUsers.fulfilled, (state, action) => {
        state.loading = false;
        state.users = action.payload.users;
        state.totalUsers = action.payload.totalCount;
        state.totalPages = action.payload.totalPages;
        state.currentPage = action.payload.currentPage;
      })
      .addCase(fetchUsers.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })

      // Search Users
      .addCase(searchUsers.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(searchUsers.fulfilled, (state, action) => {
        state.loading = false;
        state.users = action.payload.users;
        state.totalUsers = action.payload.totalCount;
        state.totalPages = action.payload.totalPages;
        state.currentPage = action.payload.currentPage;
      })
      .addCase(searchUsers.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })

      // Fetch Total User Count
      .addCase(fetchTotalUserCount.fulfilled, (state, action) => {
        state.totalUsers = action.payload;
        state.totalPages = Math.max(
          1,
          Math.ceil(action.payload / state.pageSize)
        );
      });
  },
});

export const { clearUsers, setPageSize, setCurrentPage } =
  adminUsersSlice.actions;
export default adminUsersSlice.reducer;
