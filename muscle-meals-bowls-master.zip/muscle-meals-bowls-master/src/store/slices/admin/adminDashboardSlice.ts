import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import {
  collection,
  getCountFromServer,
  query,
  getDocs,
  orderBy,
  where,
  Timestamp,
} from "firebase/firestore";
import { db } from "@/lib/firebase";
import { toast } from "sonner";

export interface DashboardStats {
  totalOrders: number;
  totalUsers: number;
  revenue: number;
  activeMeals: number;
  totalSubscriptions: number;
  subscriptionRevenue: number;
  activeSubscriptions: number;
  monthlyRecurringRevenue: number;
  averageRevenuePerUser: number;
  churnRate: number;
  customerLifetimeValue: number;
  isLoading: boolean;
  error: string | null;
}

const initialState: DashboardStats = {
  totalOrders: 0,
  totalUsers: 0,
  revenue: 0,
  activeMeals: 0,
  totalSubscriptions: 0,
  subscriptionRevenue: 0,
  activeSubscriptions: 0,
  monthlyRecurringRevenue: 0,
  averageRevenuePerUser: 0,
  churnRate: 0,
  customerLifetimeValue: 0,
  isLoading: false,
  error: null,
};

// Fetch all dashboard stats in a single action
export const fetchDashboardStats = createAsyncThunk(
  "adminDashboard/fetchStats",
  async (_, { rejectWithValue }) => {
    try {
      // Create all promises to run in parallel
      const ordersPromise = getCountFromServer(collection(db, "orders"));
      const usersPromise = getCountFromServer(collection(db, "users"));
      const mealsPromise = getCountFromServer(query(collection(db, "meals")));
      const subscriptionsPromise = getCountFromServer(
        collection(db, "subscriptions")
      );
      const activeSubscriptionsPromise = getCountFromServer(
        query(collection(db, "subscriptions"), where("status", "==", "active"))
      );

      // Revenue calculation requires summing order amounts
      const revenuePromise = getDocs(
        query(collection(db, "orders"), orderBy("createdAt", "desc"))
      );

      // Fetch all subscriptions to calculate subscription revenue
      const subscriptionRevenuePromise = getDocs(
        collection(db, "subscriptions")
      );

      // Fetch active subscriptions for MRR calculation
      const activeSubscriptionsDataPromise = getDocs(
        query(collection(db, "subscriptions"), where("status", "==", "active"))
      );

      // For churn rate calculation - get canceled subscriptions in the last 30 days
      const thirtyDaysAgo = new Date();
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
      const timestamp30DaysAgo = Timestamp.fromDate(thirtyDaysAgo);

      const canceledSubscriptionsPromise = getDocs(
        query(
          collection(db, "subscriptions"),
          where("status", "==", "canceled"),
          where("updatedAt", ">=", timestamp30DaysAgo)
        )
      );

      // Wait for all promises to resolve
      const [
        ordersSnapshot,
        usersSnapshot,
        mealsSnapshot,
        revenueSnapshot,
        subscriptionsSnapshot,
        activeSubscriptionsSnapshot,
        subscriptionRevenueSnapshot,
        activeSubscriptionsDataSnapshot,
        canceledSubscriptionsSnapshot,
      ] = await Promise.all([
        ordersPromise,
        usersPromise,
        mealsPromise,
        revenuePromise,
        subscriptionsPromise,
        activeSubscriptionsPromise,
        subscriptionRevenuePromise,
        activeSubscriptionsDataPromise,
        canceledSubscriptionsPromise,
      ]);

      // Calculate total revenue from orders
      let totalRevenue = 0;
      revenueSnapshot.forEach((doc) => {
        const orderData = doc.data();
        totalRevenue += orderData.totalAmount || 0;
      });

      // Calculate total revenue from subscriptions
      let totalSubscriptionRevenue = 0;
      subscriptionRevenueSnapshot.forEach((doc) => {
        const subscriptionData = doc.data();
        if (subscriptionData.amount && subscriptionData.quantity) {
          totalSubscriptionRevenue +=
            subscriptionData.amount * subscriptionData.quantity;
        }
      });

      // Calculate Monthly Recurring Revenue (MRR)
      let monthlyRecurringRevenue = 0;
      activeSubscriptionsDataSnapshot.forEach((doc) => {
        const subscription = doc.data();
        if (subscription.amount && subscription.quantity) {
          // Calculate monthly value based on frequency
          switch (subscription.frequency?.toLowerCase()) {
            case "weekly":
              monthlyRecurringRevenue +=
                subscription.amount * subscription.quantity * 4; // 4 weeks per month
              break;
            case "biweekly":
              monthlyRecurringRevenue +=
                subscription.amount * subscription.quantity * 2; // 2 bi-weeks per month
              break;
            case "monthly":
              monthlyRecurringRevenue +=
                subscription.amount * subscription.quantity;
              break;
            case "quarterly":
              monthlyRecurringRevenue +=
                (subscription.amount * subscription.quantity) / 3; // 1/3 per month
              break;
            case "biannually":
              monthlyRecurringRevenue +=
                (subscription.amount * subscription.quantity) / 6; // 1/6 per month
              break;
            case "annually":
            case "yearly":
              monthlyRecurringRevenue +=
                (subscription.amount * subscription.quantity) / 12; // 1/12 per month
              break;
            default:
              // If frequency not specified, assume monthly
              monthlyRecurringRevenue +=
                subscription.amount * subscription.quantity;
          }
        }
      });

      // Calculate Average Revenue Per User (ARPU)
      const totalUsers = usersSnapshot.data().count;
      const averageRevenuePerUser =
        totalUsers > 0 ? monthlyRecurringRevenue / totalUsers : 0;

      // Calculate Churn Rate (customers canceled in last 30 days / total customers at start of period)
      const canceledSubscriptionsCount =
        canceledSubscriptionsSnapshot.docs.length;
      const totalActiveSubscriptions = activeSubscriptionsSnapshot.data().count;
      // Estimating total customers at start of period as current active + recently canceled
      const estimatedCustomersAtPeriodStart =
        totalActiveSubscriptions + canceledSubscriptionsCount;
      const churnRate =
        estimatedCustomersAtPeriodStart > 0
          ? canceledSubscriptionsCount / estimatedCustomersAtPeriodStart
          : 0;

      // Calculate Customer Lifetime Value (LTV) = ARPU / Churn Rate
      // If churn rate is 0, set a minimum value to avoid division by zero
      const effectiveChurnRate = churnRate > 0 ? churnRate : 0.01; // Assuming 1% minimum churn
      const customerLifetimeValue = averageRevenuePerUser / effectiveChurnRate;

      return {
        totalOrders: ordersSnapshot.data().count,
        totalUsers: usersSnapshot.data().count,
        revenue: totalRevenue,
        activeMeals: mealsSnapshot.data().count,
        totalSubscriptions: subscriptionsSnapshot.data().count,
        subscriptionRevenue: totalSubscriptionRevenue,
        activeSubscriptions: activeSubscriptionsSnapshot.data().count,
        monthlyRecurringRevenue,
        averageRevenuePerUser,
        churnRate,
        customerLifetimeValue,
      };
    } catch (error: any) {
      console.log(error);
      toast.error("Failed to load dashboard data");
      return rejectWithValue(error.message);
    }
  }
);

const adminDashboardSlice = createSlice({
  name: "adminDashboard",
  initialState,
  reducers: {
    clearDashboardStats: () => {
      return initialState;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchDashboardStats.pending, (state) => {
        state.isLoading = true;
        state.error = null;
      })
      .addCase(fetchDashboardStats.fulfilled, (state, action) => {
        state.isLoading = false;
        state.totalOrders = action.payload.totalOrders;
        state.totalUsers = action.payload.totalUsers;
        state.revenue = action.payload.revenue;
        state.activeMeals = action.payload.activeMeals;
        state.totalSubscriptions = action.payload.totalSubscriptions;
        state.subscriptionRevenue = action.payload.subscriptionRevenue;
        state.activeSubscriptions = action.payload.activeSubscriptions;
        state.monthlyRecurringRevenue = action.payload.monthlyRecurringRevenue;
        state.averageRevenuePerUser = action.payload.averageRevenuePerUser;
        state.churnRate = action.payload.churnRate;
        state.customerLifetimeValue = action.payload.customerLifetimeValue;
      })
      .addCase(fetchDashboardStats.rejected, (state, action) => {
        state.isLoading = false;
        state.error = action.payload as string;
      });
  },
});

export const { clearDashboardStats } = adminDashboardSlice.actions;
export default adminDashboardSlice.reducer;
