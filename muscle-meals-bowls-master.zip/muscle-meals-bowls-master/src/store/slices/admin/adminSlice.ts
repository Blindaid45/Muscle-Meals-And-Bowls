import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import {
  signInWithEmailAndPassword,
  signOut as firebaseSignOut,
  User,
  onAuthStateChanged,
} from "firebase/auth";
import { doc, getDoc } from "firebase/firestore";
import { auth, db } from "@/lib/firebase";
import { toast } from "sonner";

interface AdminState {
  isAdmin: boolean;
  loading: boolean;
  error: string | null;
}

const initialState: AdminState = {
  isAdmin: false,
  loading: false,
  error: null,
};

export const loginAdmin = createAsyncThunk(
  "admin/login",
  async (
    { email, password }: { email: string; password: string },
    { rejectWithValue }
  ) => {
    try {
      const userCredential = await signInWithEmailAndPassword(
        auth,
        email,
        password
      );
      const user = userCredential.user;

      // Check if user exists in admins collection
      const adminDoc = await getDoc(doc(db, "admins", user.uid));
      if (!adminDoc.exists()) {
        await firebaseSignOut(auth);
        throw new Error("Unauthorized access");
      }

      toast.success("Welcome back, Admin!");
      return true;
    } catch (error: any) {
      toast.error(error.message);
      return rejectWithValue(error.message);
    }
  }
);

export const checkAdminStatus = createAsyncThunk(
  "admin/checkStatus",
  async (user: User, { rejectWithValue }) => {
    try {
      const adminDoc = await getDoc(doc(db, "admins", user.uid));
      return adminDoc.exists();
    } catch (error: any) {
      return rejectWithValue(error.message);
    }
  }
);

export const checkAdminAuthState = createAsyncThunk(
  "admin/checkAuthState",
  async (_, { rejectWithValue }) => {
    try {
      return new Promise<boolean>((resolve, reject) => {
        // Set a timeout to ensure the promise resolves even if Firebase auth takes too long
        const timeoutId = setTimeout(() => {
          resolve(false);
        }, 5000); // 5 second timeout

        const unsubscribe = onAuthStateChanged(auth, async (user) => {
          unsubscribe();
          clearTimeout(timeoutId);

          if (!user) {
            resolve(false);
            return;
          }

          try {
            // Check if user is in admins collection
            const adminDoc = await getDoc(doc(db, "admins", user.uid));
            resolve(adminDoc.exists());
          } catch (error) {
            console.error("Error checking admin status:", error);
            // Resolve with false instead of rejecting to avoid stuck loading state
            resolve(false);
          }
        });
      });
    } catch (error: any) {
      console.error("Admin auth check error:", error);
      // Return false instead of rejecting with error
      return false;
    }
  }
);

// Add a simple action to reset loading state
export const resetAdminLoadingState = createAsyncThunk(
  "admin/resetLoading",
  async () => {
    return true; // Just a dummy value to trigger the reducer
  }
);

const adminSlice = createSlice({
  name: "admin",
  initialState,
  reducers: {
    clearAdminState: (state) => {
      state.isAdmin = false;
      state.loading = false;
      state.error = null;
    },
    setAdminLoading: (state, action) => {
      state.loading = action.payload;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(loginAdmin.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(loginAdmin.fulfilled, (state) => {
        state.loading = false;
        state.isAdmin = true;
      })
      .addCase(loginAdmin.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })
      .addCase(checkAdminStatus.fulfilled, (state, action) => {
        state.isAdmin = action.payload;
      })
      // Check Admin Auth State
      .addCase(checkAdminAuthState.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(checkAdminAuthState.fulfilled, (state, action) => {
        state.loading = false;
        state.isAdmin = action.payload;
      })
      .addCase(checkAdminAuthState.rejected, (state) => {
        state.loading = false;
        state.isAdmin = false;
      })
      // Reset loading state
      .addCase(resetAdminLoadingState.fulfilled, (state) => {
        state.loading = false;
      });
  },
});

export const { clearAdminState, setAdminLoading } = adminSlice.actions;
export default adminSlice.reducer;
