import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import { doc, getDoc, updateDoc, serverTimestamp } from "firebase/firestore";
import {
  updateProfile,
  updatePassword,
  reauthenticateWithCredential,
  EmailAuthProvider,
} from "firebase/auth";
import { db, auth } from "@/lib/firebase";
import { toast } from "sonner";

// Define the Admin Profile interface
export interface AdminProfile {
  id: string;
  name: string;
  email: string;
  phoneNumber?: string;
  role: string;
  createdAt?: string;
  updatedAt?: string;
}

interface AdminProfileState {
  profile: AdminProfile | null;
  loading: boolean;
  error: string | null;
}

const initialState: AdminProfileState = {
  profile: null,
  loading: false,
  error: null,
};

// Fetch admin profile data
export const fetchAdminProfile = createAsyncThunk(
  "adminProfile/fetch",
  async (_, { rejectWithValue }) => {
    try {
      const user = auth.currentUser;
      if (!user) throw new Error("No authenticated user");

      const adminDocRef = doc(db, "admins", user.uid);
      const adminDoc = await getDoc(adminDocRef);

      if (!adminDoc.exists()) {
        throw new Error("Admin profile not found");
      }

      return {
        id: user.uid,
        name: user.displayName || "",
        email: user.email || "",
        ...adminDoc.data(),
      } as AdminProfile;
    } catch (error: any) {
      return rejectWithValue(error.message);
    }
  }
);

// Update admin profile
export const updateAdminProfile = createAsyncThunk(
  "adminProfile/update",
  async (profileData: Partial<AdminProfile>, { rejectWithValue }) => {
    try {
      const user = auth.currentUser;
      if (!user) throw new Error("No authenticated user");

      // Update display name in Firebase Auth if provided
      if (profileData.name) {
        await updateProfile(user, { displayName: profileData.name });
      }

      // Update profile in Firestore
      const adminRef = doc(db, "admins", user.uid);
      const adminDoc = await getDoc(adminRef);

      if (!adminDoc.exists()) {
        throw new Error("Admin profile not found");
      }

      const updateData: Record<string, any> = {
        updatedAt: serverTimestamp(),
      };

      // Only include fields that are being updated
      if (profileData.phoneNumber !== undefined) {
        updateData.phoneNumber = profileData.phoneNumber;
      }

      await updateDoc(adminRef, updateData);

      toast.success("Profile updated successfully");

      // Get the updated document
      const updatedDoc = await getDoc(adminRef);

      return {
        id: user.uid,
        name: user.displayName || "",
        email: user.email || "",
        ...updatedDoc.data(),
      } as AdminProfile;
    } catch (error: any) {
      toast.error(error.message);
      return rejectWithValue(error.message);
    }
  }
);

// Update admin password
export const updateAdminPassword = createAsyncThunk(
  "adminProfile/updatePassword",
  async (
    {
      currentPassword,
      newPassword,
    }: { currentPassword: string; newPassword: string },
    { rejectWithValue }
  ) => {
    try {
      const user = auth.currentUser;
      if (!user || !user.email) throw new Error("No authenticated user");

      // Re-authenticate user before password change
      const credential = EmailAuthProvider.credential(
        user.email,
        currentPassword
      );
      await reauthenticateWithCredential(user, credential);

      // Update password
      await updatePassword(user, newPassword);

      toast.success("Password updated successfully");
      return true;
    } catch (error: any) {
      let errorMessage = error.message;
      if (error.code === "auth/wrong-password") {
        errorMessage = "Current password is incorrect";
      } else if (error.code === "auth/weak-password") {
        errorMessage = "New password is too weak";
      }

      toast.error(errorMessage);
      return rejectWithValue(errorMessage);
    }
  }
);

const adminProfileSlice = createSlice({
  name: "adminProfile",
  initialState,
  reducers: {
    clearAdminProfile: (state) => {
      state.profile = null;
      state.loading = false;
      state.error = null;
    },
  },
  extraReducers: (builder) => {
    builder
      // Fetch Profile
      .addCase(fetchAdminProfile.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchAdminProfile.fulfilled, (state, action) => {
        state.loading = false;
        state.profile = action.payload;
      })
      .addCase(fetchAdminProfile.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })

      // Update Profile
      .addCase(updateAdminProfile.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updateAdminProfile.fulfilled, (state, action) => {
        state.loading = false;
        state.profile = action.payload;
      })
      .addCase(updateAdminProfile.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })

      // Update Password
      .addCase(updateAdminPassword.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updateAdminPassword.fulfilled, (state) => {
        state.loading = false;
      })
      .addCase(updateAdminPassword.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export const { clearAdminProfile } = adminProfileSlice.actions;
export default adminProfileSlice.reducer;
