import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import { db } from "@/lib/firebase";
import {
  collection,
  getDocs,
  doc,
  getDoc,
  query,
  where,
  Timestamp,
} from "firebase/firestore";
import { toast } from "sonner";
import { AdminMealPlan } from "./adminMealPlanSlice";

// Public meal plan is essentially the same as AdminMealPlan but for public viewing
export interface PublicMealPlan extends AdminMealPlan {}

// State interface for public meal plans
interface PublicMealPlanState {
  publicMealPlans: PublicMealPlan[];
  currentPublicMealPlan: PublicMealPlan | null;
  featuredMealPlans: PublicMealPlan[];
  loading: boolean;
  error: string | null;
}

// Initial state
const initialState: PublicMealPlanState = {
  publicMealPlans: [],
  currentPublicMealPlan: null,
  featuredMealPlans: [],
  loading: false,
  error: null,
};

// Helper function to convert Firestore timestamps
const convertTimestamps = (data: any) => {
  const converted = { ...data };
  if (converted.createdAt instanceof Timestamp) {
    converted.createdAt = converted.createdAt.toDate();
  }
  if (converted.updatedAt instanceof Timestamp) {
    converted.updatedAt = converted.updatedAt.toDate();
  }
  return converted;
};

// Fetch all active admin meal plans for public viewing
export const fetchAllPublicMealPlans = createAsyncThunk(
  "publicMealPlans/fetchAll",
  async (_, { rejectWithValue }) => {
    try {
      const mealPlansRef = collection(db, "adminMealPlans");
      const q = query(mealPlansRef, where("isActive", "==", true));
      const querySnapshot = await getDocs(q);

      const mealPlans = querySnapshot.docs.map((doc) => ({
        id: doc.id,
        ...convertTimestamps(doc.data()),
      })) as PublicMealPlan[];

      return mealPlans;
    } catch (error: any) {
      toast.error("Failed to fetch meal plans");
      return rejectWithValue(error.message);
    }
  }
);

// Fetch featured meal plans (you can modify the criteria as needed)
export const fetchFeaturedMealPlans = createAsyncThunk(
  "publicMealPlans/fetchFeatured",
  async (_, { rejectWithValue }) => {
    try {
      const mealPlansRef = collection(db, "adminMealPlans");
      const q = query(
        mealPlansRef,
        where("isActive", "==", true),
        where("category", "==", "featured") // Assuming you have a featured category
      );
      const querySnapshot = await getDocs(q);

      const mealPlans = querySnapshot.docs.map((doc) => ({
        id: doc.id,
        ...convertTimestamps(doc.data()),
      })) as PublicMealPlan[];

      return mealPlans;
    } catch (error: any) {
      // Don't show error toast for featured plans as it's optional
      return rejectWithValue(error.message);
    }
  }
);

// Get a single public meal plan by ID
export const fetchPublicMealPlanById = createAsyncThunk(
  "publicMealPlans/fetchById",
  async (id: string, { rejectWithValue }) => {
    try {
      const docRef = doc(db, "adminMealPlans", id);
      const docSnapshot = await getDoc(docRef);

      if (!docSnapshot.exists()) {
        throw new Error("Meal plan not found");
      }

      const mealPlan = {
        id: docSnapshot.id,
        ...convertTimestamps(docSnapshot.data()),
      } as PublicMealPlan;

      // Check if the meal plan is active (public)
      if (!mealPlan.isActive) {
        throw new Error("This meal plan is not available");
      }

      return mealPlan;
    } catch (error: any) {
      toast.error("Failed to fetch meal plan details");
      return rejectWithValue(error.message);
    }
  }
);

// Fetch meal plans by category
export const fetchPublicMealPlansByCategory = createAsyncThunk(
  "publicMealPlans/fetchByCategory",
  async (category: string, { rejectWithValue }) => {
    try {
      const mealPlansRef = collection(db, "adminMealPlans");
      const q = query(
        mealPlansRef,
        where("isActive", "==", true),
        where("category", "==", category)
      );
      const querySnapshot = await getDocs(q);

      const mealPlans = querySnapshot.docs.map((doc) => ({
        id: doc.id,
        ...convertTimestamps(doc.data()),
      })) as PublicMealPlan[];

      return mealPlans;
    } catch (error: any) {
      toast.error(`Failed to fetch ${category} meal plans`);
      return rejectWithValue(error.message);
    }
  }
);

// Fetch meal plans by tags
export const fetchPublicMealPlansByTags = createAsyncThunk(
  "publicMealPlans/fetchByTags",
  async (tags: string[], { rejectWithValue }) => {
    try {
      const mealPlansRef = collection(db, "adminMealPlans");
      const q = query(
        mealPlansRef,
        where("isActive", "==", true),
        where("tags", "array-contains-any", tags)
      );
      const querySnapshot = await getDocs(q);

      const mealPlans = querySnapshot.docs.map((doc) => ({
        id: doc.id,
        ...convertTimestamps(doc.data()),
      })) as PublicMealPlan[];

      return mealPlans;
    } catch (error: any) {
      toast.error("Failed to fetch meal plans by tags");
      return rejectWithValue(error.message);
    }
  }
);

// Create the slice
const publicMealPlanSlice = createSlice({
  name: "publicMealPlans",
  initialState,
  reducers: {
    clearCurrentPublicMealPlan: (state) => {
      state.currentPublicMealPlan = null;
    },
    clearPublicMealPlanErrors: (state) => {
      state.error = null;
    },
    setCurrentPublicMealPlan: (state, action) => {
      state.currentPublicMealPlan = action.payload;
    },
  },
  extraReducers: (builder) => {
    builder
      // Fetch all public meal plans
      .addCase(fetchAllPublicMealPlans.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchAllPublicMealPlans.fulfilled, (state, action) => {
        state.loading = false;
        state.publicMealPlans = action.payload;
      })
      .addCase(fetchAllPublicMealPlans.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })

      // Fetch featured meal plans
      .addCase(fetchFeaturedMealPlans.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchFeaturedMealPlans.fulfilled, (state, action) => {
        state.loading = false;
        state.featuredMealPlans = action.payload;
      })
      .addCase(fetchFeaturedMealPlans.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })

      // Fetch public meal plan by ID
      .addCase(fetchPublicMealPlanById.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchPublicMealPlanById.fulfilled, (state, action) => {
        state.loading = false;
        state.currentPublicMealPlan = action.payload;
      })
      .addCase(fetchPublicMealPlanById.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })

      // Fetch by category
      .addCase(fetchPublicMealPlansByCategory.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchPublicMealPlansByCategory.fulfilled, (state, action) => {
        state.loading = false;
        state.publicMealPlans = action.payload;
      })
      .addCase(fetchPublicMealPlansByCategory.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })

      // Fetch by tags
      .addCase(fetchPublicMealPlansByTags.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchPublicMealPlansByTags.fulfilled, (state, action) => {
        state.loading = false;
        state.publicMealPlans = action.payload;
      })
      .addCase(fetchPublicMealPlansByTags.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export const {
  clearCurrentPublicMealPlan,
  clearPublicMealPlanErrors,
  setCurrentPublicMealPlan,
} = publicMealPlanSlice.actions;

export default publicMealPlanSlice.reducer;
