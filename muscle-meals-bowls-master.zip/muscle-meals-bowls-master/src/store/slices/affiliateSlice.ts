import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import {
  collection,
  doc,
  getDoc,
  getDocs,
  addDoc,
  updateDoc,
  query,
  where,
  orderBy,
  Timestamp,
  serverTimestamp,
} from "firebase/firestore";
import { db, auth } from "@/lib/firebase";
import {
  Affiliate,
  CouponUsage,
  AffiliateStats,
  CreateAffiliateRequest,
  ValidateCouponRequest,
  ValidateCouponResponse,
} from "@/types/affiliate";

interface AffiliateState {
  currentAffiliate: Affiliate | null;
  affiliateStats: AffiliateStats | null;
  couponUsages: CouponUsage[];
  validationResult: ValidateCouponResponse | null;
  loading: boolean;
  error: string | null;
  isValidating: boolean;
}

const initialState: AffiliateState = {
  currentAffiliate: null,
  affiliateStats: null,
  couponUsages: [],
  validationResult: null,
  loading: false,
  error: null,
  isValidating: false,
};

// Helper function to convert Firestore timestamps
const convertTimestamps = (data: any) => {
  const converted = { ...data };
  if (converted.createdAt instanceof Timestamp) {
    converted.createdAt = converted.createdAt.toDate().toISOString();
  }
  if (converted.updatedAt instanceof Timestamp) {
    converted.updatedAt = converted.updatedAt.toDate().toISOString();
  }
  if (converted.processedAt instanceof Timestamp) {
    converted.processedAt = converted.processedAt.toDate().toISOString();
  }
  return converted;
};

// Create affiliate account
export const createAffiliate = createAsyncThunk(
  "affiliate/create",
  async (request: CreateAffiliateRequest, { rejectWithValue }) => {
    try {
      const user = auth.currentUser;
      if (!user) throw new Error("No authenticated user");

      // Format coupon code: uppercase + MMB suffix
      const formattedCode = request.desiredCode.toUpperCase().trim() + "MMB";

      // Check if coupon code already exists
      const affiliatesRef = collection(db, "affiliates");
      const existingCodeQuery = query(
        affiliatesRef,
        where("couponCode", "==", formattedCode)
      );
      const existingCodeSnapshot = await getDocs(existingCodeQuery);

      if (!existingCodeSnapshot.empty) {
        throw new Error(
          "This coupon code is already taken. Please choose a different one."
        );
      }

      // Check if user already has an affiliate account
      const existingUserQuery = query(
        affiliatesRef,
        where("userId", "==", user.uid)
      );
      const existingUserSnapshot = await getDocs(existingUserQuery);

      if (!existingUserSnapshot.empty) {
        throw new Error("You already have an affiliate account.");
      }

      // Validate UPI ID format (basic validation)
      const upiRegex = /^[a-zA-Z0-9.\-_]{2,256}@[a-zA-Z][a-zA-Z0-9.\-_]{2,64}$/;
      if (!upiRegex.test(request.upiId)) {
        throw new Error("Please enter a valid UPI ID.");
      }

      // Create new affiliate record
      const affiliateData = {
        userId: user.uid,
        couponCode: formattedCode,
        upiId: request.upiId,
        isActive: true,
        totalEarnings: 0,
        totalReferrals: 0,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      };

      const affiliateDoc = await addDoc(affiliatesRef, affiliateData);

      return {
        affiliateId: affiliateDoc.id,
        ...affiliateData,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      } as Affiliate;
    } catch (error: any) {
      return rejectWithValue(error.message);
    }
  }
);

// Fetch current user's affiliate account
export const fetchUserAffiliate = createAsyncThunk(
  "affiliate/fetchUser",
  async (_, { rejectWithValue }) => {
    try {
      const user = auth.currentUser;
      if (!user) throw new Error("No authenticated user");

      const affiliatesRef = collection(db, "affiliates");
      const userQuery = query(affiliatesRef, where("userId", "==", user.uid));
      const userSnapshot = await getDocs(userQuery);

      if (userSnapshot.empty) {
        return null; // User doesn't have an affiliate account
      }

      const affiliateDoc = userSnapshot.docs[0];
      const affiliateData = convertTimestamps(affiliateDoc.data());

      return {
        affiliateId: affiliateDoc.id,
        ...affiliateData,
      } as Affiliate;
    } catch (error: any) {
      return rejectWithValue(error.message);
    }
  }
);

// Validate coupon code and calculate discount
export const validateCoupon = createAsyncThunk(
  "affiliate/validateCoupon",
  async (request: ValidateCouponRequest, { rejectWithValue }) => {
    try {
      const user = auth.currentUser;
      if (!user) throw new Error("No authenticated user");

      // Format the input coupon code to ensure consistency
      const formattedCode = request.couponCode.toUpperCase().trim();

      // Check if it ends with MMB, if not add it
      const finalCouponCode = formattedCode.endsWith("MMB")
        ? formattedCode
        : formattedCode + "MMB";

      // Find affiliate with this coupon code
      const affiliatesRef = collection(db, "affiliates");
      const affiliateQuery = query(
        affiliatesRef,
        where("couponCode", "==", finalCouponCode),
        where("isActive", "==", true)
      );
      const affiliateSnapshot = await getDocs(affiliateQuery);

      if (affiliateSnapshot.empty) {
        return {
          isValid: false,
          discountAmount: 0,
          discountPercentage: 0,
          finalAmount: request.subscriptionAmount,
          error: "Invalid or inactive coupon code",
        } as ValidateCouponResponse;
      }

      const affiliateDoc = affiliateSnapshot.docs[0];
      const affiliateData = affiliateDoc.data();

      // Check if user is trying to use their own coupon
      if (affiliateData.userId === user.uid) {
        return {
          isValid: false,
          discountAmount: 0,
          discountPercentage: 0,
          finalAmount: request.subscriptionAmount,
          error: "You cannot use your own coupon code",
        } as ValidateCouponResponse;
      }

      // Calculate discount based on subscription type
      const discountPercentage =
        request.subscriptionType === "monthly" ? 10 : 5;
      const discountAmount = Math.round(
        (request.subscriptionAmount * discountPercentage) / 100
      );
      const finalAmount = request.subscriptionAmount - discountAmount;

      return {
        isValid: true,
        discountAmount,
        discountPercentage,
        finalAmount,
        affiliateId: affiliateDoc.id,
        couponCode: finalCouponCode,
      } as ValidateCouponResponse;
    } catch (error: any) {
      return rejectWithValue(error.message);
    }
  }
);

// Fetch affiliate statistics
export const fetchAffiliateStats = createAsyncThunk(
  "affiliate/fetchStats",
  async (_, { rejectWithValue, getState }) => {
    try {
      const user = auth.currentUser;
      if (!user) throw new Error("No authenticated user");

      // Get user's affiliate account
      const affiliatesRef = collection(db, "affiliates");
      const userQuery = query(affiliatesRef, where("userId", "==", user.uid));
      const userSnapshot = await getDocs(userQuery);

      if (userSnapshot.empty) {
        return {
          totalEarnings: 0,
          totalReferrals: 0,
          pendingCommissions: 0,
          thisMonthEarnings: 0,
          thisMonthReferrals: 0,
        } as AffiliateStats;
      }

      const affiliateDoc = userSnapshot.docs[0];
      const affiliateData = affiliateDoc.data();
      const affiliateId = affiliateDoc.id;

      // Get coupon usages for this affiliate
      const usagesRef = collection(db, "couponUsages");
      const usagesQuery = query(
        usagesRef,
        where("affiliateId", "==", affiliateId),
        orderBy("createdAt", "desc")
      );
      const usagesSnapshot = await getDocs(usagesQuery);

      const usages = usagesSnapshot.docs.map((doc) =>
        convertTimestamps(doc.data())
      );

      // Use the values directly from the affiliate document
      const totalEarnings = Number(affiliateData.totalEarnings) || 0;
      const totalReferrals = Number(affiliateData.totalReferrals) || 0;

      const pendingCommissions = usages
        .filter((usage) => usage.status === "pending")
        .reduce((sum, usage) => sum + (Number(usage.commissionAmount) || 0), 0);

      // Calculate this month's stats
      const currentMonth = new Date().getMonth();
      const currentYear = new Date().getFullYear();
      const thisMonthUsages = usages.filter((usage) => {
        const usageDate = new Date(usage.createdAt);
        return (
          usageDate.getMonth() === currentMonth &&
          usageDate.getFullYear() === currentYear
        );
      });

      const thisMonthEarnings = thisMonthUsages
        .filter((usage) => usage.status === "processed")
        .reduce((sum, usage) => sum + (Number(usage.commissionAmount) || 0), 0);
      const thisMonthReferrals = thisMonthUsages.length;

      const stats = {
        totalEarnings,
        totalReferrals,
        pendingCommissions,
        thisMonthEarnings,
        thisMonthReferrals,
      } as AffiliateStats;

      return stats;
    } catch (error: any) {
      return rejectWithValue(error.message);
    }
  }
);

// Fetch coupon usage history
export const fetchCouponUsages = createAsyncThunk(
  "affiliate/fetchUsages",
  async (_, { rejectWithValue }) => {
    try {
      const user = auth.currentUser;
      if (!user) throw new Error("No authenticated user");

      // Get user's affiliate account
      const affiliatesRef = collection(db, "affiliates");
      const userQuery = query(affiliatesRef, where("userId", "==", user.uid));
      const userSnapshot = await getDocs(userQuery);

      if (userSnapshot.empty) {
        return [];
      }

      const affiliateId = userSnapshot.docs[0].id;

      // Get coupon usages for this affiliate
      const usagesRef = collection(db, "couponUsages");
      const usagesQuery = query(
        usagesRef,
        where("affiliateId", "==", affiliateId),
        orderBy("createdAt", "desc")
      );
      const usagesSnapshot = await getDocs(usagesQuery);

      return usagesSnapshot.docs.map((doc) => ({
        usageId: doc.id,
        ...convertTimestamps(doc.data()),
      })) as CouponUsage[];
    } catch (error: any) {
      return rejectWithValue(error.message);
    }
  }
);

const affiliateSlice = createSlice({
  name: "affiliate",
  initialState,
  reducers: {
    clearValidation: (state) => {
      state.validationResult = null;
      state.isValidating = false;
    },
    clearError: (state) => {
      state.error = null;
    },
    clearAffiliate: (state) => {
      state.currentAffiliate = null;
      state.affiliateStats = null;
      state.couponUsages = [];
      state.validationResult = null;
      state.error = null;
    },
  },
  extraReducers: (builder) => {
    builder
      // Create affiliate
      .addCase(createAffiliate.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(createAffiliate.fulfilled, (state, action) => {
        state.loading = false;
        state.currentAffiliate = action.payload;
      })
      .addCase(createAffiliate.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })
      // Fetch user affiliate
      .addCase(fetchUserAffiliate.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchUserAffiliate.fulfilled, (state, action) => {
        state.loading = false;
        state.currentAffiliate = action.payload;
      })
      .addCase(fetchUserAffiliate.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })
      // Validate coupon
      .addCase(validateCoupon.pending, (state) => {
        state.isValidating = true;
        state.error = null;
      })
      .addCase(validateCoupon.fulfilled, (state, action) => {
        state.isValidating = false;
        state.validationResult = action.payload;
      })
      .addCase(validateCoupon.rejected, (state, action) => {
        state.isValidating = false;
        state.error = action.payload as string;
      })
      // Fetch affiliate stats
      .addCase(fetchAffiliateStats.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchAffiliateStats.fulfilled, (state, action) => {
        state.loading = false;
        state.affiliateStats = action.payload;
      })
      .addCase(fetchAffiliateStats.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      })
      // Fetch coupon usages
      .addCase(fetchCouponUsages.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchCouponUsages.fulfilled, (state, action) => {
        state.loading = false;
        state.couponUsages = action.payload;
      })
      .addCase(fetchCouponUsages.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload as string;
      });
  },
});

export const { clearValidation, clearError, clearAffiliate } =
  affiliateSlice.actions;
export default affiliateSlice.reducer;
