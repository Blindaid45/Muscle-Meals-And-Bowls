import { useState, useCallback } from "react";
import { useAppDispatch, useAppSelector } from "@/store/hooks";
import { fetchMealById } from "@/store/slices/mealSlice";
import { MealPlanItem } from "@/store/slices/mealPlanSlice";
import { Meal } from "@/store/slices/mealSlice";

export function useMealPlanItems(items: MealPlanItem[]) {
  const dispatch = useAppDispatch();
  const { meals } = useAppSelector((state) => state.meals);
  const [mealDetailsMap, setMealDetailsMap] = useState<Record<string, Meal>>(
    {}
  );
  const [loadingMeals, setLoadingMeals] = useState<string[]>([]);

  // Helper function to get meal details
  const getMealDetails = useCallback(
    (mealId: string) => {
      // First check in our mealDetailsMap
      if (mealDetailsMap[mealId]) {
        return mealDetailsMap[mealId];
      }
      // Then check in the Redux store
      return meals.find((meal) => meal.id === mealId);
    },
    [mealDetailsMap, meals]
  );

  // Check if a meal is currently loading
  const isMealLoading = useCallback(
    (mealId: string) => {
      return loadingMeals.includes(mealId);
    },
    [loadingMeals]
  );

  // Fetch meal details for all meal items
  const fetchMealDetails = useCallback(async () => {
    // Collect all unique meal IDs
    const mealIds = new Set<string>();
    items.forEach((item) => {
      mealIds.add(item.mealId);
    });

    // Filter out IDs that we already have loaded
    const idsToFetch = Array.from(mealIds).filter(
      (id) => !mealDetailsMap[id] && !meals.some((m) => m.id === id)
    );

    if (idsToFetch.length === 0) return;

    // Mark these meals as loading
    setLoadingMeals((prev) => [...prev, ...idsToFetch]);

    // Fetch each meal's details
    const newMealDetails = { ...mealDetailsMap };

    for (const id of idsToFetch) {
      try {
        // First check if it's in the Redux store
        const existingMeal = meals.find((m) => m.id === id);
        if (existingMeal) {
          newMealDetails[id] = existingMeal;
        } else {
          // Fetch from Firebase
          const result = await dispatch(fetchMealById(id) as any).unwrap();
          newMealDetails[id] = result;
        }
      } catch (error) {
        console.error(`Failed to fetch meal details for ${id}:`, error);
      } finally {
        // Remove from loading state regardless of success or failure
        setLoadingMeals((prev) => prev.filter((loadingId) => loadingId !== id));
      }
    }

    setMealDetailsMap(newMealDetails);
  }, [dispatch, items, meals, mealDetailsMap]);

  return {
    mealDetailsMap,
    loadingMeals,
    fetchMealDetails,
    getMealDetails,
    isMealLoading,
  };
}
