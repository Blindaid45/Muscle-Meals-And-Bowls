import { useSelector, useDispatch } from "react-redux";
import { RootState, AppDispatch } from "../store/store";
import {
  loginUser,
  registerUser,
  signOut,
  clearError,
  loginWithGoogle,
  resetPassword,
} from "../store/slices/authSlice";

export const useAuth = () => {
  const dispatch = useDispatch<AppDispatch>();
  const { user, loading, error } = useSelector(
    (state: RootState) => state.auth
  );

  const login = (email: string, password: string) => {
    return dispatch(loginUser({ email, password }));
  };

  const register = (email: string, password: string, displayName: string) => {
    return dispatch(registerUser({ email, password, displayName }));
  };

  const loginWithGoogleProvider = () => {
    return dispatch(loginWithGoogle());
  };

  const forgotPassword = (email: string) => {
    return dispatch(resetPassword(email));
  };

  const logout = () => {
    return dispatch(signOut());
  };

  const resetError = () => {
    dispatch(clearError());
  };

  return {
    user,
    loading,
    error,
    login,
    register,
    loginWithGoogleProvider,
    forgotPassword,
    logout,
    resetError,
  };
};
