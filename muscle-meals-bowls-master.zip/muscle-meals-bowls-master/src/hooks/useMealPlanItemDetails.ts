import { useState, useEffect } from "react";
import { useAppDispatch, useAppSelector } from "@/store/hooks";
import { fetchMealById } from "@/store/slices/mealSlice";
import { Meal } from "@/store/slices/mealSlice";

// Type that captures the common structure between MealPlan and AdminMealPlan for this hook
interface MealPlanLike {
  items: {
    mealId: string;
    [key: string]: any;
  }[];
}

export function useMealPlanItemDetails<T extends MealPlanLike>(mealPlans: T[]) {
  const dispatch = useAppDispatch();
  const { meals } = useAppSelector((state) => state.meals);
  const [mealDetailsMap, setMealDetailsMap] = useState<Record<string, Meal>>(
    {}
  );
  const [loadingMeals, setLoadingMeals] = useState<string[]>([]);

  // Fetch meal details for all meal items
  useEffect(() => {
    const fetchMealDetails = async () => {
      // Collect all unique meal IDs from all plans
      const mealIds = new Set<string>();
      mealPlans.forEach((plan) => {
        plan.items.forEach((item) => {
          mealIds.add(item.mealId);
        });
      });

      // Filter out IDs that we already have loaded
      const idsToFetch = Array.from(mealIds).filter(
        (id) => !mealDetailsMap[id] && !meals.some((m) => m.id === id)
      );

      if (idsToFetch.length === 0) return;

      // Mark these meals as loading
      setLoadingMeals((prev) => [...prev, ...idsToFetch]);

      // Fetch each meal's details
      const newMealDetails = { ...mealDetailsMap };

      for (const id of idsToFetch) {
        try {
          // First check if it's in the Redux store
          const existingMeal = meals.find((m) => m.id === id);
          if (existingMeal) {
            newMealDetails[id] = existingMeal;
          } else {
            // Fetch from Firebase
            const result = await dispatch(fetchMealById(id) as any).unwrap();
            newMealDetails[id] = result;
          }
        } catch (error) {
          console.error(`Failed to fetch meal details for ${id}:`, error);
        } finally {
          // Remove from loading state regardless of success or failure
          setLoadingMeals((prev) =>
            prev.filter((loadingId) => loadingId !== id)
          );
        }
      }

      setMealDetailsMap(newMealDetails);
    };

    if (mealPlans.length > 0) {
      fetchMealDetails();
    }
  }, [dispatch, mealPlans, meals, mealDetailsMap]);

  // Helper function to get meal details from our map
  const getMealDetails = (mealId: string) => {
    // First check in our mealDetailsMap
    if (mealDetailsMap[mealId]) {
      return mealDetailsMap[mealId];
    }
    // Then check in the Redux store
    return meals.find((meal) => meal.id === mealId);
  };

  const isMealLoading = (mealId: string) => {
    return loadingMeals.includes(mealId);
  };

  return { mealDetailsMap, loadingMeals, getMealDetails, isMealLoading };
}
