import { useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { RootState, AppDispatch } from "../store/store";
import {
  createAffiliate,
  fetchUserAffiliate,
  validateCoupon,
  fetchAffiliateStats,
  fetchCouponUsages,
  clearValidation,
  clearError,
} from "../store/slices/affiliateSlice";
import {
  CreateAffiliateRequest,
  ValidateCouponRequest,
} from "../types/affiliate";

export const useAffiliate = () => {
  const dispatch = useDispatch<AppDispatch>();

  // Selectors
  const {
    currentAffiliate,
    affiliateStats,
    couponUsages,
    validationResult,
    loading,
    error,
    isValidating,
  } = useSelector((state: RootState) => state.affiliate);

  const user = useSelector((state: RootState) => state.auth.user);

  // Create affiliate account
  const handleCreateAffiliate = async (request: CreateAffiliateRequest) => {
    try {
      const result = await dispatch(createAffiliate(request));
      if (createAffiliate.fulfilled.match(result)) {
        // Fetch stats after successful creation
        await dispatch(fetchAffiliateStats());
        return { success: true, affiliate: result.payload };
      } else {
        return { success: false, error: result.payload as string };
      }
    } catch (error) {
      return { success: false, error: "Failed to create affiliate account" };
    }
  };

  // Validate coupon code
  const handleValidateCoupon = async (request: ValidateCouponRequest) => {
    try {
      const result = await dispatch(validateCoupon(request));
      if (validateCoupon.fulfilled.match(result)) {
        return { success: true, validation: result.payload };
      } else {
        return { success: false, error: result.payload as string };
      }
    } catch (error) {
      return { success: false, error: "Failed to validate coupon" };
    }
  };

  // Clear validation result
  const clearCouponValidation = () => {
    dispatch(clearValidation());
  };

  // Clear error
  const clearAffiliateError = () => {
    dispatch(clearError());
  };

  // Refresh affiliate data
  const refreshAffiliateData = async () => {
    if (user) {
      await Promise.all([
        dispatch(fetchUserAffiliate()),
        dispatch(fetchAffiliateStats()),
        dispatch(fetchCouponUsages()),
      ]);
    }
  };

  // Auto-fetch affiliate data when user is available
  useEffect(() => {
    if (user) {
      dispatch(fetchUserAffiliate());
    }
  }, [user, dispatch]);

  // Fetch stats and usages when affiliate is available
  useEffect(() => {
    if (currentAffiliate) {
      dispatch(fetchAffiliateStats());
      dispatch(fetchCouponUsages());
    }
  }, [currentAffiliate, dispatch]);

  return {
    // State
    currentAffiliate,
    affiliateStats,
    couponUsages,
    validationResult,
    loading,
    error,
    isValidating,

    // Actions
    handleCreateAffiliate,
    handleValidateCoupon,
    clearCouponValidation,
    clearAffiliateError,
    refreshAffiliateData,

    // Computed
    hasAffiliateAccount: !!currentAffiliate,
    isAffiliate: !!currentAffiliate && currentAffiliate.isActive,
  };
};
