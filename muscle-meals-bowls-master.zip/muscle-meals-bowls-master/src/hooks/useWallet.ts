import { useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { RootState, AppDispatch } from "../store/store";
import { fetchWalletDetails } from "../store/slices/walletSlice";
import { fetchWalletTransactions } from "../store/slices/transactionSlice";
import { WalletDetails } from "../lib/walletService";
import { topUpWallet, WalletTopUpRequest } from "../lib/razorpay";

export const useWallet = () => {
  const dispatch = useDispatch<AppDispatch>();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Select data from Redux store
  const wallet = useSelector((state: RootState) => state.wallet.wallet);
  const walletLoading = useSelector((state: RootState) => state.wallet.loading);
  const walletError = useSelector((state: RootState) => state.wallet.error);

  const transactions = useSelector(
    (state: RootState) => state.transactions.transactions
  );
  const transactionsLoading = useSelector(
    (state: RootState) => state.transactions.loading
  );
  const transactionsError = useSelector(
    (state: RootState) => state.transactions.error
  );

  // Combined data for API compatibility
  const walletDetails: WalletDetails = {
    wallet: wallet || { balance: 0, userId: "" },
    transactions: transactions || [],
  };

  // Fetch wallet data
  const fetchWalletData = async () => {
    setLoading(true);
    setError(null);

    try {
      await Promise.all([
        dispatch(fetchWalletDetails()),
        dispatch(fetchWalletTransactions()),
      ]);
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "Failed to fetch wallet data"
      );
    } finally {
      setLoading(false);
    }
  };

  // Handle wallet top-up
  const handleTopUp = async (topUpData: WalletTopUpRequest) => {
    setLoading(true);
    setError(null);

    try {
      await topUpWallet(topUpData);
      await fetchWalletData();
      return true;
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to process top-up");
      return false;
    } finally {
      setLoading(false);
    }
  };

  // Fetch data when component mounts
  useEffect(() => {
    fetchWalletData();
  }, []);

  return {
    wallet,
    transactions,
    walletDetails,
    loading: loading || walletLoading || transactionsLoading,
    error: error || walletError || transactionsError,
    fetchWalletData,
    handleTopUp,
  };
};
