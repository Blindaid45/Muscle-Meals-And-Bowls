import { useSelector, useDispatch } from "react-redux";
import { RootState } from "../store/store";
import {
  loginAdmin,
  checkAdminAuthState,
  resetAdminLoadingState,
  setAdminLoading,
} from "../store/slices/admin/adminSlice";
import { AppDispatch } from "../store/store";

export const useAdmin = () => {
  const dispatch = useDispatch<AppDispatch>();
  const { isAdmin, loading, error } = useSelector(
    (state: RootState) => state.admin
  );

  const login = (email: string, password: string) => {
    return dispatch(loginAdmin({ email, password }));
  };

  const checkAuthState = () => {
    return dispatch(checkAdminAuthState());
  };

  const resetLoadingState = () => {
    return dispatch(resetAdminLoadingState());
  };

  const setLoading = (loading: boolean) => {
    return dispatch(setAdminLoading(loading));
  };

  return {
    isAdmin,
    loading,
    error,
    login,
    checkAuthState,
    resetLoadingState,
    setLoading,
  };
};
