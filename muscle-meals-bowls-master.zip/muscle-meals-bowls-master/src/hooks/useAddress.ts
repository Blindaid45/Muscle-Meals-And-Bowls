import { useSelector, useDispatch } from 'react-redux';
import { RootState, AppDispatch } from '../store/store';
import { 
  fetchAddresses, 
  addAddress, 
  updateAddress, 
  deleteAddress 
} from '../store/slices/addressSlice';
import { Address, AddressFormData } from '../types/address';

export const useAddress = () => {
  const dispatch = useDispatch<AppDispatch>();
  const { addresses, loading, error } = useSelector((state: RootState) => state.address);

  const getAddresses = () => {
    return dispatch(fetchAddresses());
  };

  const createAddress = (addressData: AddressFormData) => {
    return dispatch(addAddress({ ...addressData, isDefault: addresses.length === 0 }));
  };

  const editAddress = (id: string, addressData: Partial<Address>) => {
    return dispatch(updateAddress({ id, ...addressData }));
  };

  const removeAddress = (id: string) => {
    return dispatch(deleteAddress(id));
  };

  return {
    addresses,
    loading,
    error,
    getAddresses,
    createAddress,
    editAddress,
    removeAddress,
  };
};