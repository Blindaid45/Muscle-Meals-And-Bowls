import { useSelector, useDispatch } from "react-redux";
import { RootState, AppDispatch } from "../store/store";
import {
  fetchAdminProfile,
  updateAdminProfile,
  updateAdminPassword,
  AdminProfile,
} from "../store/slices/admin/adminProfileSlice";

export const useAdminProfile = () => {
  const dispatch = useDispatch<AppDispatch>();
  const { profile, loading, error } = useSelector(
    (state: RootState) => state.adminProfile
  );

  const getProfile = () => {
    return dispatch(fetchAdminProfile());
  };

  const updateProfile = (profileData: Partial<AdminProfile>) => {
    return dispatch(updateAdminProfile(profileData));
  };

  const changePassword = (currentPassword: string, newPassword: string) => {
    return dispatch(updateAdminPassword({ currentPassword, newPassword }));
  };

  return {
    profile,
    loading,
    error,
    getProfile,
    updateProfile,
    changePassword,
  };
};
