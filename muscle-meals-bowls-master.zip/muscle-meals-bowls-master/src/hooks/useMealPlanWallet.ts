import {
  doc,
  updateDoc,
  addDoc,
  collection,
  serverTimestamp,
} from "firebase/firestore";
import { db, auth } from "@/lib/firebase";
import { useWallet } from "@/hooks/useWallet";
import { useState } from "react";
import { toast } from "sonner";

export function useMealPlanWallet() {
  const { wallet, fetchWalletData } = useWallet();
  const [useWalletForPayment, setUseWalletForPayment] = useState(false);

  // Function to handle wallet deduction
  const deductFromWallet = async (
    amount: number,
    description: string,
    referenceId?: string
  ) => {
    if (!wallet || !auth.currentUser) return false;

    try {
      // 1. Create transaction record
      const transactionData = {
        userId: auth.currentUser.uid,
        amount: amount,
        type: "debit",
        description: description,
        referenceId: referenceId || null,
        createdAt: serverTimestamp(),
        status: "completed",
      };

      await addDoc(collection(db, "walletTransactions"), transactionData);

      // 2. Update wallet balance
      const walletRef = doc(db, "wallets", wallet.userId);
      const newBalance = wallet.balance - amount;

      await updateDoc(walletRef, {
        balance: newBalance,
        updatedAt: serverTimestamp(),
      });

      // 3. Refresh wallet data
      await fetchWalletData();

      return true;
    } catch (error) {
      console.error("Error deducting from wallet:", error);
      return false;
    }
  };

  // Function to check if wallet has sufficient balance
  const hasWalletSufficientBalance = (amount: number): boolean => {
    if (!wallet) return false;
    return wallet.balance >= amount;
  };

  // Function to handle payment processing
  const processWalletPayment = async (
    amount: number,
    description: string,
    referenceId?: string
  ) => {
    if (amount <= 0) return true; // No payment needed

    if (!useWalletForPayment) {
      // If user chose not to use wallet, confirm with them about the price increase
      return confirm(
        `This will increase the total price by ${amount.toFixed(
          2
        )}. Do you want to continue?`
      );
    }

    // Check if wallet has enough balance
    if (!wallet || wallet.balance < amount) {
      toast.error(
        "Insufficient wallet balance. Please top up your wallet first."
      );
      return false;
    }

    // Process the wallet payment
    const success = await deductFromWallet(amount, description, referenceId);

    if (success) {
      toast.success(`${amount.toFixed(2)} deducted from your wallet`);
      return true;
    } else {
      toast.error("Failed to process wallet payment");
      return false;
    }
  };

  return {
    wallet,
    useWalletForPayment,
    setUseWalletForPayment,
    deductFromWallet,
    hasWalletSufficientBalance,
    processWalletPayment,
  };
}
