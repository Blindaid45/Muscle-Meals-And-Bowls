import { useSelector, useDispatch } from 'react-redux';
import { RootState, AppDispatch } from '../store/store';
import { updateUserProfile, fetchUserProfile } from '../store/slices/userSlice';

export const useProfile = () => {
  const dispatch = useDispatch<AppDispatch>();
  const { profile, loading, error } = useSelector((state: RootState) => state.user);

  const updateProfile = async (profileData: any) => {
    return dispatch(updateUserProfile(profileData)).unwrap();
  };

  const refreshProfile = () => {
    return dispatch(fetchUserProfile());
  };

  return {
    profile,
    loading,
    error,
    updateProfile,
    refreshProfile,
  };
};