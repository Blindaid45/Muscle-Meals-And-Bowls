import { httpsCallable } from "firebase/functions";
import { functions } from "@/lib/firebase";
import { Affiliate, CouponUsage, AffiliateStats } from "../types/affiliate";

// Define the function types
const processCouponUsageFunction = httpsCallable(
  functions,
  "processCouponUsage"
);
const processAffiliateCommissionFunction = httpsCallable(
  functions,
  "processAffiliateCommission"
);

// Cloud functions
const createAffiliateFunction = httpsCallable(functions, "createAffiliate");
const validateCouponFunction = httpsCallable(functions, "validateCoupon");
const fetchAffiliateStatsFunction = httpsCallable(
  functions,
  "fetchAffiliateStats"
);
const fetchCouponUsagesFunction = httpsCallable(functions, "fetchCouponUsages");
const processCouponWalletCreditsFunction = httpsCallable(
  functions,
  "processCouponWalletCredits"
);

export interface ProcessCouponUsageRequest {
  couponCode: string;
  subscriptionId: string;
  orderId?: string;
  originalAmount: number;
  discountAmount: number;
  finalAmount: number;
  subscriptionType: "weekly" | "monthly";
  affiliateId: string;
}

export interface ProcessCouponUsageResponse {
  success: boolean;
  usageId: string;
  commissionAmount: number;
  message: string;
}

export interface CreateAffiliateRequest {
  desiredCode: string;
  upiId: string;
}

export interface CreateAffiliateResponse {
  success: boolean;
  affiliate?: Affiliate;
  error?: string;
}

export interface ValidateCouponRequest {
  couponCode: string;
  subscriptionAmount: number;
  subscriptionType: "weekly" | "monthly";
}

export interface ValidateCouponResponse {
  isValid: boolean;
  discountAmount: number;
  finalAmount: number;
  affiliateId?: string;
  couponCode?: string;
  error?: string;
}

export interface ProcessCouponWalletCreditsRequest {
  userId: string;
  couponCode: string;
  discountAmount: number;
  commissionAmount: number;
  subscriptionId?: string;
  orderId?: string;
  originalAmount: number;
  finalAmount: number;
  subscriptionType: string;
}

export interface ProcessCouponWalletCreditsResponse {
  success: boolean;
  message: string;
  userCreditAmount: number;
  affiliateCreditAmount: number;
  error?: string;
}

/**
 * Process coupon usage after successful subscription creation
 */
export const processCouponUsage = async (
  request: ProcessCouponUsageRequest
): Promise<ProcessCouponUsageResponse> => {
  try {
    const result = await processCouponUsageFunction(request);
    return result.data as ProcessCouponUsageResponse;
  } catch (error: any) {
    console.error("Error processing coupon usage:", error);
    throw new Error(error.message || "Failed to process coupon usage");
  }
};

/**
 * Process affiliate commission (admin function)
 */
export const processAffiliateCommission = async (usageId: string) => {
  try {
    const result = await processAffiliateCommissionFunction({ usageId });
    return result.data;
  } catch (error: any) {
    console.error("Error processing affiliate commission:", error);
    throw new Error(error.message || "Failed to process commission");
  }
};

/**
 * Helper function to integrate coupon processing with subscription creation
 */
export const handleSubscriptionWithCoupon = async (
  subscriptionData: any,
  couponValidation: {
    isValid: boolean;
    discountAmount: number;
    finalAmount: number;
    affiliateId?: string;
  }
) => {
  try {
    // First create the subscription (this should be done by your existing subscription service)
    // const subscription = await createSubscription(subscriptionData);

    // If coupon was used, process the usage
    if (couponValidation.isValid && couponValidation.affiliateId) {
      const couponUsageRequest: ProcessCouponUsageRequest = {
        couponCode: subscriptionData.couponCode,
        subscriptionId: subscriptionData.subscriptionId,
        orderId: subscriptionData.orderId,
        originalAmount: subscriptionData.originalAmount,
        discountAmount: couponValidation.discountAmount,
        finalAmount: couponValidation.finalAmount,
        subscriptionType: subscriptionData.subscriptionType,
        affiliateId: couponValidation.affiliateId,
      };

      await processCouponUsage(couponUsageRequest);
    }

    return { success: true };
  } catch (error) {
    console.error("Error handling subscription with coupon:", error);
    throw error;
  }
};

// Service functions
export const affiliateService = {
  async createAffiliate(
    data: CreateAffiliateRequest
  ): Promise<CreateAffiliateResponse> {
    try {
      const result = await createAffiliateFunction(data);
      return result.data as CreateAffiliateResponse;
    } catch (error: any) {
      console.error("Error creating affiliate:", error);
      return {
        success: false,
        error: error.message || "Failed to create affiliate account",
      };
    }
  },

  async validateCoupon(
    data: ValidateCouponRequest
  ): Promise<ValidateCouponResponse> {
    try {
      const result = await validateCouponFunction(data);
      return result.data as ValidateCouponResponse;
    } catch (error: any) {
      console.error("Error validating coupon:", error);
      return {
        isValid: false,
        discountAmount: 0,
        finalAmount: data.subscriptionAmount,
        error: error.message || "Failed to validate coupon",
      };
    }
  },

  async fetchAffiliateStats(): Promise<AffiliateStats | null> {
    try {
      const result = await fetchAffiliateStatsFunction();
      const data = result.data as {
        success: boolean;
        stats?: AffiliateStats;
        error?: string;
      };

      if (data.success && data.stats) {
        return data.stats;
      }

      return null;
    } catch (error: any) {
      console.error("Error fetching affiliate stats:", error);
      return null;
    }
  },

  async fetchCouponUsages(): Promise<CouponUsage[]> {
    try {
      const result = await fetchCouponUsagesFunction();
      const data = result.data as {
        success: boolean;
        usages?: CouponUsage[];
        error?: string;
      };

      if (data.success && data.usages) {
        return data.usages;
      }

      return [];
    } catch (error: any) {
      console.error("Error fetching coupon usages:", error);
      return [];
    }
  },

  async processCouponWalletCredits(
    data: ProcessCouponWalletCreditsRequest
  ): Promise<ProcessCouponWalletCreditsResponse> {
    try {
      const result = await processCouponWalletCreditsFunction(data);
      return result.data as ProcessCouponWalletCreditsResponse;
    } catch (error: any) {
      console.error("Error processing coupon wallet credits:", error);
      return {
        success: false,
        message: error.message || "Failed to process wallet credits",
        userCreditAmount: 0,
        affiliateCreditAmount: 0,
        error: error.message,
      };
    }
  },
};
