// Re-export wallet functions for easier imports
export * from "./walletService";
