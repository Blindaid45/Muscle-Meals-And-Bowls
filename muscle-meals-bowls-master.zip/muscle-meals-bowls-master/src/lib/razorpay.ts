import { getFunctions, httpsCallable } from "firebase/functions";
import { auth } from "./firebase";

// Razorpay test key (replace with your actual key in production)
export const RAZORPAY_KEY_ID = import.meta.env.VITE_RAZORPAY_KEY_ID;

// Interface for meal subscription request
export interface MealSubscriptionRequest {
  mealId: string;
  quantity: number;
  startDate: Date;
  endDate: Date;
  frequency: string; // 'weekly', 'biweekly', 'monthly'
  amount: number;
  currency: string;
  // Coupon data
  couponCode?: string;
  discountAmount?: number;
  originalAmount?: number; // Amount after bulk discount (base for affiliate discount)
  affiliateId?: string;
  subscriptionType?: string;
  retailAmount?: number; // Original retail price before any discounts (for commission calculation)
}

// Interface for meal plan subscription request
export interface MealPlanSubscriptionRequest {
  mealPlanId: string;
  startDate: Date;
  endDate: Date;
  frequency: string; // 'weekly', 'biweekly', 'monthly'
  amount: number;
  currency: string;
  quantity: number;
  // Coupon data
  couponCode?: string;
  discountAmount?: number;
  originalAmount?: number; // Amount after bulk discount (base for affiliate discount)
  affiliateId?: string;
  subscriptionType?: string;
  retailAmount?: number; // Original retail price before any discounts (for commission calculation)
}

// Interface for wallet top-up request
export interface WalletTopUpRequest {
  amount: number;
  currency?: string;
}

// Interface for wallet debit request
export interface WalletDebitRequest {
  amount: number;
  purpose: string;
  description?: string;
  referenceId?: string;
}

// Interface for subscription update request
export interface SubscriptionUpdateRequest {
  subscriptionId: string;
  quantity?: number;
  itemId?: string;
  mealTime?: string;
}

// Interface for subscription cancellation request
export interface SubscriptionCancelRequest {
  subscriptionId: string;
  cancelAtCycleEnd?: boolean;
  reason?: string;
}

// Union type for all subscription requests
export type SubscriptionRequest =
  | MealSubscriptionRequest
  | MealPlanSubscriptionRequest;

// This function initializes Razorpay and creates a new order
export const createSubscription = async (
  subscriptionData: SubscriptionRequest
) => {
  try {
    // Ensure user is authenticated
    if (!auth.currentUser) {
      throw new Error("You must be logged in to create a subscription");
    }

    // Initialize Firebase Functions
    const functions = getFunctions();

    // First create a plan
    const createRazorpayPlan = httpsCallable(functions, "createRazorpayPlan");

    console.log("Creating plan with data:", subscriptionData);

    // Call the Cloud Function to create a plan
    const planResponse = await createRazorpayPlan({
      ...subscriptionData,
      // Convert dates to ISO strings for transmission
      startDate: subscriptionData.startDate.toISOString(),
      endDate: subscriptionData.endDate.toISOString(),
      // Include type of subscription
      type: "mealId" in subscriptionData ? "meal" : "mealPlan",
    });

    // Check if response data exists and extract the plan ID
    if (!planResponse.data) {
      throw new Error(
        "Invalid response: No data returned from createRazorpayPlan"
      );
    }

    const { planId } = planResponse.data as { planId: string; plan: any };

    if (!planId) {
      throw new Error(
        "Invalid response: No planId returned from createRazorpayPlan"
      );
    }

    console.log("Plan created with ID:", planId);

    // Now create a subscription with the plan
    const createRazorpaySubscription = httpsCallable(
      functions,
      "createRazorpaySubscription"
    );

    const subscriptionResponse = await createRazorpaySubscription({
      ...subscriptionData,
      planId: planId,
      // Convert dates to ISO strings for transmission
      startDate: subscriptionData.startDate.toISOString(),
      endDate: subscriptionData.endDate.toISOString(),
      // Include type of subscription
      type: "mealId" in subscriptionData ? "meal" : "mealPlan",
    });

    // Check if response data exists and extract the subscription ID
    if (!subscriptionResponse.data) {
      throw new Error(
        "Invalid response: No data returned from createRazorpaySubscription"
      );
    }

    const { subscriptionId } = subscriptionResponse.data as {
      subscriptionId: string;
      subscription: any;
    };

    if (!subscriptionId) {
      throw new Error(
        "Invalid response: No subscriptionId returned from createRazorpaySubscription"
      );
    }

    console.log("Subscription created with ID:", subscriptionId);

    // Load the Razorpay SDK dynamically
    return new Promise((resolve, reject) => {
      const script = document.createElement("script");
      script.src = "https://checkout.razorpay.com/v1/checkout.js";
      script.onload = () => {
        resolve(
          openRazorpaySubscriptionCheckout(
            subscriptionId,
            subscriptionData.amount,
            subscriptionData.currency
          )
        );
      };
      script.onerror = () => {
        reject(new Error("Failed to load Razorpay SDK"));
      };
      document.body.appendChild(script);
    });
  } catch (error) {
    console.error("Error creating subscription:", error);
    throw error;
  }
};

// Open Razorpay checkout for subscriptions
const openRazorpaySubscriptionCheckout = (
  subscriptionId: string,
  amount: number,
  currency: string
) => {
  return new Promise((resolve, reject) => {
    const options = {
      key: RAZORPAY_KEY_ID,
      subscription_id: subscriptionId,
      name: "Muscle Meals and Bowls",
      description: "Meal Subscription",
      image: "/logo.png", // Your logo URL
      prefill: {
        name: auth.currentUser?.displayName || "",
        email: auth.currentUser?.email || "",
        contact: "",
      },
      theme: {
        color: "#4f46e5", // primary color from your theme
      },
      handler: function (response: any) {
        // Call a verification Cloud Function
        const functions = getFunctions();
        const verifySubscription = httpsCallable(
          functions,
          "verifyRazorpaySubscription"
        );

        verifySubscription({
          razorpay_payment_id: response.razorpay_payment_id,
          razorpay_subscription_id: response.razorpay_subscription_id,
          razorpay_signature: response.razorpay_signature,
        })
          .then((result) => {
            resolve(result.data);
          })
          .catch((error) => {
            reject(error);
          });
      },
    };

    // @ts-ignore - Razorpay will be loaded dynamically
    const razorpayInstance = new window.Razorpay(options);
    razorpayInstance.open();
  });
};

// This function initializes Razorpay and creates a new order (old method)
export const createOneTimeOrder = async (
  subscriptionData: SubscriptionRequest
) => {
  try {
    // Ensure user is authenticated
    if (!auth.currentUser) {
      throw new Error("You must be logged in to create a subscription");
    }

    // Initialize Firebase Functions
    const functions = getFunctions();

    // This will call the Firebase Cloud Function (to be created)
    const createRazorpayOrder = httpsCallable(functions, "createRazorpayOrder");
    console.log("*************************************************");
    console.log(subscriptionData);
    console.log("*************************************************");
    // Call the Cloud Function with subscription data
    const response = await createRazorpayOrder({
      ...subscriptionData,
      // Convert dates to ISO strings for transmission
      startDate: subscriptionData.startDate.toISOString(),
      endDate: subscriptionData.endDate.toISOString(),
      // Include type of subscription
      type: "mealId" in subscriptionData ? "meal" : "mealPlan",
      // Pass coupon data if present
      ...(subscriptionData.couponCode && {
        couponCode: subscriptionData.couponCode,
        discountAmount: subscriptionData.discountAmount || 0,
        originalAmount:
          subscriptionData.originalAmount || subscriptionData.amount,
        affiliateId: subscriptionData.affiliateId,
        subscriptionType:
          subscriptionData.subscriptionType || subscriptionData.frequency,
        retailAmount:
          subscriptionData.retailAmount ||
          subscriptionData.originalAmount ||
          subscriptionData.amount,
      }),
    });

    // Log the full response to debug
    console.log("Razorpay response:", response);

    // Check if response data exists and extract the order ID
    if (!response.data) {
      throw new Error(
        "Invalid response: No data returned from createRazorpayOrder"
      );
    }

    const { orderId } = response.data as { orderId: string };

    if (!orderId) {
      throw new Error(
        "Invalid response: No orderId returned from createRazorpayOrder"
      );
    }

    // Load the Razorpay SDK dynamically
    return new Promise((resolve, reject) => {
      const script = document.createElement("script");
      script.src = "https://checkout.razorpay.com/v1/checkout.js";
      script.onload = () => {
        resolve(
          openRazorpayCheckout(
            orderId,
            subscriptionData.amount,
            subscriptionData.currency
          )
        );
      };
      script.onerror = () => {
        reject(new Error("Failed to load Razorpay SDK"));
      };
      document.body.appendChild(script);
    });
  } catch (error) {
    console.error("Error creating subscription:", error);
    throw error;
  }
};

// Open Razorpay checkout for one-time orders
const openRazorpayCheckout = (
  orderId: string,
  amount: number,
  currency: string
) => {
  return new Promise((resolve, reject) => {
    const options = {
      key: RAZORPAY_KEY_ID,
      amount: amount * 100, // Razorpay expects amount in paise
      currency: currency,
      name: "Muscle Meals and Bowls",
      description: "Meal Subscription",
      order_id: orderId,
      prefill: {
        name: auth.currentUser?.displayName || "",
        email: auth.currentUser?.email || "",
      },
      theme: {
        color: "#4f46e5", // primary color from your theme
      },
      handler: function (response: any) {
        // Call a verification Cloud Function (to be created)
        const functions = getFunctions();
        const verifyPayment = httpsCallable(functions, "verifyRazorpayPayment");

        verifyPayment({
          razorpay_payment_id: response.razorpay_payment_id,
          razorpay_order_id: response.razorpay_order_id,
          razorpay_signature: response.razorpay_signature,
        })
          .then((result) => {
            resolve(result.data);
          })
          .catch((error) => {
            reject(error);
          });
      },
    };

    // @ts-ignore - Razorpay will be loaded dynamically
    const razorpayInstance = new window.Razorpay(options);
    razorpayInstance.open();
  });
};

// Function to handle the subscription process
export const handleSubscription = async (
  subscriptionData: SubscriptionRequest
) => {
  try {
    // For upfront payments with coupon support, use one-time orders instead of subscriptions
    // This ensures better webhook handling for coupon processing
    const result = await createOneTimeOrder(subscriptionData);
    return result;
  } catch (error) {
    console.error("Subscription failed:", error);
    throw error;
  }
};

// This function handles wallet top-up using Razorpay
export const topUpWallet = async (topUpData: WalletTopUpRequest) => {
  try {
    // Ensure user is authenticated
    if (!auth.currentUser) {
      throw new Error("You must be logged in to top up your wallet");
    }

    // Default currency to INR if not provided
    const currency = topUpData.currency || "INR";

    // Initialize Firebase Functions
    const functions = getFunctions();

    // Call the Cloud Function to create a wallet top-up order
    const createWalletTopUpOrderFunc = httpsCallable(
      functions,
      "createWalletTopUpOrder"
    );
    console.log(createWalletTopUpOrderFunc);
    const response = await createWalletTopUpOrderFunc({
      amount: topUpData.amount,
      currency: currency,
    });

    // Check if response data exists and extract the order ID
    if (!response.data) {
      throw new Error(
        "Invalid response: No data returned from createWalletTopUpOrder"
      );
    }

    const { orderId, key_id } = response.data as {
      orderId: string;
      amount: number;
      currency: string;
      key_id: string;
    };

    if (!orderId) {
      throw new Error("Invalid response: No orderId returned");
    }

    // Load the Razorpay SDK dynamically
    return new Promise((resolve, reject) => {
      const script = document.createElement("script");
      script.src = "https://checkout.razorpay.com/v1/checkout.js";
      script.onload = () => {
        resolve(
          openWalletTopUpCheckout(orderId, topUpData.amount, currency, key_id)
        );
      };
      script.onerror = () => {
        reject(new Error("Failed to load Razorpay SDK"));
      };
      document.body.appendChild(script);
    });
  } catch (error) {
    console.error("Error creating wallet top-up:", error);
    throw error;
  }
};

// Open Razorpay checkout for wallet top-up
const openWalletTopUpCheckout = (
  orderId: string,
  amount: number,
  currency: string,
  key_id: string
) => {
  return new Promise((resolve, reject) => {
    const options = {
      key: key_id || RAZORPAY_KEY_ID,
      amount: amount * 100, // Razorpay expects amount in paise
      currency: currency,
      name: "Muscle Meals and Bowls",
      description: "Wallet Top Up",
      order_id: orderId,
      prefill: {
        name: auth.currentUser?.displayName || "",
        email: auth.currentUser?.email || "",
      },
      theme: {
        color: "#4f46e5", // primary color from your theme
      },
      handler: function (response: any) {
        try {
          // Call a verification Cloud Function
          const functions = getFunctions();
          const verifyWalletTopUp = httpsCallable(
            functions,
            "verifyWalletTopUp"
          );

          verifyWalletTopUp({
            razorpay_payment_id: response.razorpay_payment_id,
            razorpay_order_id: response.razorpay_order_id,
            razorpay_signature: response.razorpay_signature,
          })
            .then((result) => {
              resolve(result.data);
            })
            .catch((error) => {
              reject(error);
            });
        } catch (error) {
          console.error("Wallet top-up verification failed:", error);
          reject(error);
        }
      },
    };

    // @ts-ignore - Razorpay will be loaded dynamically
    const razorpayInstance = new window.Razorpay(options);
    razorpayInstance.open();
  });
};

/**
 * Update an existing subscription
 */
export const updateSubscription = async (
  updateData: SubscriptionUpdateRequest
) => {
  try {
    // Ensure user is authenticated
    if (!auth.currentUser) {
      throw new Error("You must be logged in to update a subscription");
    }

    // Initialize Firebase Functions
    const functions = getFunctions();
    const updateSubscriptionFunc = httpsCallable(
      functions,
      "updateSubscription"
    );

    // Call the Cloud Function to update subscription
    const response = await updateSubscriptionFunc(updateData);

    // Return the result
    return response.data;
  } catch (error) {
    console.error("Error updating subscription:", error);
    throw error;
  }
};

/**
 * Cancel a subscription
 */
export const cancelSubscription = async (
  cancelData: SubscriptionCancelRequest
) => {
  try {
    // Ensure user is authenticated
    if (!auth.currentUser) {
      throw new Error("You must be logged in to cancel a subscription");
    }

    // Initialize Firebase Functions
    const functions = getFunctions();
    const cancelSubscriptionFunc = httpsCallable(
      functions,
      "cancelSubscription"
    );

    // Call the Cloud Function to cancel subscription
    const response = await cancelSubscriptionFunc(cancelData);

    // Return the result
    return response.data;
  } catch (error) {
    console.error("Error cancelling subscription:", error);
    throw error;
  }
};
