import { auth } from "./firebase";
import { store } from "../store/store";
import { fetchWalletDetails } from "../store/slices/walletSlice";
import { fetchWalletTransactions } from "../store/slices/transactionSlice";

// Interface for combined wallet data
export interface WalletDetails {
  wallet: {
    balance: number;
    userId: string;
    createdAt?: string;
    updatedAt?: string;
  };
  transactions: Array<{
    transactionId: string;
    userId: string;
    amount: number;
    type: "credit" | "debit";
    description: string;
    referenceId?: string;
    orderId?: string;
    paymentId?: string;
    createdAt: any;
    status: "pending" | "completed" | "failed";
  }>;
}

/**
 * Get wallet details and transactions for the current user
 *
 * @returns A promise that resolves to the wallet details object
 */
export const getWalletDetails = async (): Promise<WalletDetails> => {
  // Ensure user is authenticated
  if (!auth.currentUser) {
    throw new Error("You must be logged in to access wallet details");
  }

  // Dispatch both actions to fetch data
  await store.dispatch(fetchWalletDetails());
  await store.dispatch(fetchWalletTransactions());

  // Get updated state
  const state = store.getState();
  const { wallet } = state.wallet;
  const { transactions } = state.transactions;

  // Return combined wallet details
  return {
    wallet: wallet || {
      balance: 0,
      userId: auth.currentUser.uid,
    },
    transactions: transactions || [],
  };
};
