import {
  ref,
  uploadBytes,
  getDownloadURL,
  deleteObject,
} from "firebase/storage";
import { storage } from "@/lib/firebase";

interface UploadOptions {
  folder: string;
  fileName: string;
  file: File;
  metadata?: { [key: string]: string };
}

interface UploadResult {
  url: string;
  path: string;
  metadata: {
    name: string;
    size: number;
    type: string;
    lastModified: number;
    [key: string]: any;
  };
}

/**
 * Extract the storage path from a Firebase Storage URL
 * @param url - Firebase Storage download URL
 * @returns Storage path or null if not a valid Firebase Storage URL
 */
export function extractStoragePathFromUrl(url: string): string | null {
  try {
    if (!url.includes("firebase") || !url.includes("googleapis.com")) {
      return null;
    }

    // Parse the URL to extract the path
    const urlObj = new URL(url);
    const pathParts = urlObj.pathname.split("/");

    // Find the 'o' parameter which contains the encoded path
    const encodedPath = pathParts[pathParts.length - 1];
    if (encodedPath) {
      return decodeURIComponent(encodedPath);
    }

    return null;
  } catch (error) {
    console.warn("Failed to extract storage path from URL:", error);
    return null;
  }
}

export async function uploadFile({
  folder,
  fileName,
  file,
  metadata = {},
}: UploadOptions): Promise<UploadResult> {
  try {
    // Create a storage reference
    const path = `${folder}/${fileName}`;
    const storageRef = ref(storage, path);

    // Ensure all metadata values are strings
    const stringifiedMetadata: Record<string, string> = {};
    Object.entries(metadata).forEach(([key, value]) => {
      // Skip null/undefined values
      if (value !== null && value !== undefined) {
        stringifiedMetadata[key] = String(value);
      }
    });

    // Add file metadata
    const fileMetadata = {
      contentType: file.type,
      customMetadata: {
        ...stringifiedMetadata,
        originalName: file.name,
        size: file.size.toString(),
        lastModified: file.lastModified.toString(),
      },
    };

    // Upload file
    const snapshot = await uploadBytes(storageRef, file, fileMetadata);

    // Get download URL
    const url = await getDownloadURL(snapshot.ref);

    // For the return value, convert numeric string values back to numbers
    // to maintain consistent types in the application
    const originalMetadata: Record<string, any> = {};

    Object.entries(metadata).forEach(([key, value]) => {
      originalMetadata[key] = value;
    });

    return {
      url,
      path,
      metadata: {
        name: file.name,
        size: file.size,
        type: file.type,
        lastModified: file.lastModified,
        ...originalMetadata,
      },
    };
  } catch (error: any) {
    throw new Error(`Error uploading file: ${error.message}`);
  }
}

export async function deleteFile(path: string): Promise<void> {
  try {
    const fileRef = ref(storage, path);
    await deleteObject(fileRef);
  } catch (error: any) {
    throw new Error(`Error deleting file: ${error.message}`);
  }
}

/**
 * Delete a file using its download URL
 * @param url - Firebase Storage download URL
 */
export async function deleteFileByUrl(url: string): Promise<void> {
  const path = extractStoragePathFromUrl(url);
  if (!path) {
    throw new Error("Invalid Firebase Storage URL");
  }
  await deleteFile(path);
}
