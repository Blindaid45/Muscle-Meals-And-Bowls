export const themes = {
  light: {
    primary: {
      DEFAULT: '#0D7377',
      foreground: '#FFFFFF',
    },
    secondary: {
      DEFAULT: '#FF5722',
      foreground: '#FFFFFF',
    },
    accent: {
      DEFAULT: '#FF5722',
      foreground: '#FFFFFF',
    },
    muted: {
      DEFAULT: '#F5F5F5',
      foreground: '#292929',
    },
    background: '#FFFFFF',
    foreground: '#292929',
  },
  dark: {
    primary: {
      DEFAULT: '#32C8CD',
      foreground: '#FFFFFF',
    },
    secondary: {
      DEFAULT: '#FFAB91',
      foreground: '#292929',
    },
    accent: {
      DEFAULT: '#FFAB91',
      foreground: '#292929',
    },
    muted: {
      DEFAULT: '#292929',
      foreground: '#F5F5F5',
    },
    background: '#121212',
    foreground: '#F5F5F5',
  },
};