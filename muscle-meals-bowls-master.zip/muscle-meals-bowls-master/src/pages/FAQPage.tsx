import { useEffect } from "react";
import { motion } from "framer-motion";
import FAQ from "@/components/FAQ";
import { ArrowDownCircle } from "lucide-react";

export default function FAQPage() {
  // Scroll to top when component mounts
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const handleScrollToFAQ = () => {
    const faqSection = document.getElementById("faq-section");
    if (faqSection) {
      faqSection.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-primary-50/30">
      {/* Hero Section */}
      <motion.section
        className="relative py-16 md:py-24 px-4 flex flex-col items-center justify-center"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.6 }}
      >
        <div className="absolute inset-0 overflow-hidden">
          <div
            className="absolute top-0 left-0 w-full h-full bg-primary-500/5 
            bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] 
            from-primary-100/20 via-transparent to-transparent"
          ></div>
        </div>

        <motion.h1
          className="text-4xl md:text-5xl lg:text-6xl font-bold text-center text-primary-500 mb-6 relative z-10"
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2, duration: 0.8 }}
        >
          Got Questions?
        </motion.h1>

        <motion.p
          className="text-xl text-gray-600 text-center max-w-2xl mb-10 relative z-10"
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.4, duration: 0.8 }}
        >
          Find answers to all your questions about our meal subscription service
        </motion.p>

        <motion.button
          onClick={handleScrollToFAQ}
          className="flex items-center gap-2 text-primary-500 hover:text-primary-600 transition-colors"
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.6, duration: 0.8 }}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          <span>Scroll to FAQs</span>
          <motion.div
            animate={{ y: [0, 5, 0] }}
            transition={{ repeat: Infinity, duration: 1.5 }}
          >
            <ArrowDownCircle size={20} />
          </motion.div>
        </motion.button>
      </motion.section>

      {/* FAQ Section */}
      <section id="faq-section" className="py-12 md:py-20">
        <FAQ hideTitle={false} />
      </section>

      {/* Contact Section */}
      <motion.section
        className="py-16 px-4 text-center"
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        viewport={{ once: true }}
      >
        <h2 className="text-2xl md:text-3xl font-bold text-primary-500 mb-4">
          Still have questions?
        </h2>
        <p className="text-gray-600 max-w-xl mx-auto mb-8">
          Our team is just a message away. Contact us and we'll get back to you
          as soon as possible.
        </p>
        <motion.a
          href="mailto:support@musclemealsbowls.com"
          className="inline-block px-8 py-3 rounded-lg bg-primary-500 text-white font-medium 
                   hover:bg-primary-600 transition-colors shadow-md hover:shadow-lg"
          whileHover={{ scale: 1.03 }}
          whileTap={{ scale: 0.97 }}
        >
          Contact Us
        </motion.a>
      </motion.section>
    </div>
  );
}
