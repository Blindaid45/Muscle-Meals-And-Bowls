import { useState, useEffect } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { motion } from "framer-motion";
import { Eye, EyeOff, LockKeyhole, Mail } from "lucide-react";
import Button from "../components/ui/Button";
import { useAuth } from "../hooks/useAuth";
import { TextGradient } from "../components/ui/TextGradient";
import { BackgroundBeams } from "../components/ui/BackgroundBeams";
import GoogleSignInButton from "../components/auth/GoogleSignInButton";
import { toast } from "sonner";

const LoginPage = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const { login, loading, error, user, resetError } = useAuth();
  const navigate = useNavigate();

  const [searchParams] = useSearchParams();

  // Get redirect URI from query parameters
  const redirectUri = searchParams.get("redirect");

  // Default to home page if no redirect is specified
  const defaultPath = "/";

  // Clear errors when component mounts
  useEffect(() => {
    resetError();
  }, [resetError]);

  useEffect(() => {
    if (user) {
      // If there's a redirect URI in query params, use it
      if (redirectUri) {
        // Decode the URI component to get the original path
        const decodedRedirect = decodeURIComponent(redirectUri);
        navigate(decodedRedirect);
      } else {
        // Check if there's a redirect in session storage (legacy support)
        const sessionRedirect = sessionStorage.getItem("redirectUrl");
        if (sessionRedirect) {
          sessionStorage.removeItem("redirectUrl");
          navigate(sessionRedirect);
        } else {
          // Default to home if no redirect is found
          navigate(defaultPath);
        }
      }
    }

    return () => {
      resetError();
    };
  }, [user, navigate, redirectUri, resetError]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Simple client-side validation
    if (!email.trim()) {
      toast.error("Please enter your email address");
      return;
    }

    if (!password.trim()) {
      toast.error("Please enter your password");
      return;
    }

    await login(email, password);
  };

  return (
    <div className="min-h-screen flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8 bg-neutral-light relative overflow-hidden">
      <BackgroundBeams />

      <div className="max-w-md w-full space-y-8 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center"
        >
          <Link to="/" className="inline-block">
            <div className="h-14 w-14 mx-auto bg-primary rounded-full flex items-center justify-center">
              <span className="text-white text-2xl font-bold">M</span>
            </div>
          </Link>
          <h2 className="mt-6 text-3xl font-extrabold">
            <TextGradient>Welcome back</TextGradient>
          </h2>
          <p className="mt-2 text-sm text-gray-600">
            Sign in to your account to manage your orders and subscriptions
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="bg-white/80 backdrop-blur-sm p-8 rounded-xl shadow-md"
        >
          {error && (
            <div className="mb-4 p-3 rounded bg-red-50 border border-red-200 text-red-600 text-sm">
              <p className="font-medium">Sign-in failed</p>
              <p>{error}</p>
            </div>
          )}

          {/* Show redirect message if there's a redirect URI */}
          {redirectUri && (
            <div className="mb-4 p-3 rounded bg-blue-50 border border-blue-200 text-blue-600 text-sm">
              Please log in to continue
            </div>
          )}

          <form className="space-y-6" onSubmit={handleSubmit}>
            <div>
              <label htmlFor="email" className="label">
                Email address
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Mail className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  id="email"
                  name="email"
                  type="email"
                  autoComplete="email"
                  required
                  className="input pl-10"
                  placeholder="your@email.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
              </div>
            </div>

            <div>
              <label htmlFor="password" className="label">
                Password
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <LockKeyhole className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  id="password"
                  name="password"
                  type={showPassword ? "text" : "password"}
                  autoComplete="current-password"
                  required
                  className="input pl-10 pr-10"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
                <div className="absolute inset-y-0 right-0 pr-3 flex items-center">
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="text-gray-400 hover:text-gray-500 focus:outline-none"
                  >
                    {showPassword ? (
                      <EyeOff className="h-5 w-5" />
                    ) : (
                      <Eye className="h-5 w-5" />
                    )}
                  </button>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <input
                  id="remember-me"
                  name="remember-me"
                  type="checkbox"
                  className="h-4 w-4 text-primary focus:ring-primary border-gray-300 rounded"
                />
                <label
                  htmlFor="remember-me"
                  className="ml-2 block text-sm text-gray-900"
                >
                  Remember me
                </label>
              </div>

              <div className="text-sm">
                <Link
                  to="/auth/forgot-password"
                  className="font-medium text-primary hover:text-primary-dark"
                >
                  Forgot password?
                </Link>
              </div>
            </div>

            <Button variant="accent" fullWidth type="submit" disabled={loading}>
              {loading ? "Signing in..." : "Sign in"}
            </Button>

            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-gray-300"></div>
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-2 bg-white text-gray-500">
                  Or continue with
                </span>
              </div>
            </div>

            <GoogleSignInButton fullWidth />
          </form>
        </motion.div>

        <p className="mt-6 text-center text-sm text-gray-600">
          Don't have an account?{" "}
          <Link
            to="/auth/register"
            className="font-medium text-primary hover:text-primary-dark"
          >
            Sign up now
          </Link>
        </p>
      </div>
    </div>
  );
};

export default LoginPage;
