import { useState } from "react";
import { useWallet } from "../hooks/useWallet";
import { motion, AnimatePresence } from "framer-motion";

export default function WalletPage() {
  const [isTopUpExpanded, setIsTopUpExpanded] = useState<boolean>(false);
  const [isQuickTopUpLoading, setIsQuickTopUpLoading] =
    useState<boolean>(false);
  const [amount, setAmount] = useState<number>(300);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);

  // Use our wallet hook
  const { walletDetails, loading, error, handleTopUp } = useWallet();

  // Handle quick top-up with ₹300
  const handleQuickTopUp = async () => {
    try {
      setIsQuickTopUpLoading(true);

      const success = await handleTopUp({ amount: 300 });

      if (!success) {
        console.error("Quick top-up failed");
      }
    } catch (err) {
      console.error("Quick top-up failed:", err);
    } finally {
      setIsQuickTopUpLoading(false);
    }
  };

  // Handle form submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (amount <= 0) {
      return;
    }

    try {
      setIsProcessing(true);
      const success = await handleTopUp({ amount });

      if (success) {
        // Reset form and collapse top-up section
        setIsTopUpExpanded(false);
        setAmount(300);
      }
    } catch (err) {
      console.error("Top-up failed:", err);
    } finally {
      setIsProcessing(false);
    }
  };

  // Quick amount selection options
  const amountOptions = [100, 300, 500, 1000];

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="flex flex-col md:flex-row justify-between items-start mb-8">
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
        >
          <h1 className="text-3xl font-bold">Your Wallet</h1>
          <p className="text-gray-600 mt-2">
            Manage your wallet and top up balance
          </p>
        </motion.div>

        {/* Wallet Balance Card - Top Right */}
        <motion.div
          className="bg-white shadow-md rounded-lg p-6 mt-4 md:mt-0 w-full md:w-72"
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.3, delay: 0.1 }}
          whileHover={{ boxShadow: "0 8px 30px rgba(0,0,0,0.12)" }}
        >
          <div className="text-gray-600 font-medium">Available Balance</div>
          {loading ? (
            <div className="h-8 bg-gray-200 animate-pulse rounded mt-2"></div>
          ) : (
            <motion.div
              className="text-3xl font-bold text-green-600 mt-1"
              initial={{ scale: 0.9 }}
              animate={{ scale: 1 }}
              transition={{ duration: 0.3 }}
            >
              ₹{walletDetails?.wallet?.balance || 0}
            </motion.div>
          )}

          {/* Quick Top-Up Button */}
          <motion.button
            onClick={handleQuickTopUp}
            disabled={isQuickTopUpLoading}
            whileTap={{ scale: 0.97 }}
            className={`mt-4 w-full py-2 rounded-md font-medium text-white 
              ${
                isQuickTopUpLoading
                  ? "bg-gray-400"
                  : "bg-indigo-600 hover:bg-indigo-700"
              }`}
          >
            {isQuickTopUpLoading ? "Processing..." : "Quick Top-Up ₹300"}
          </motion.button>

          <motion.button
            onClick={() => setIsTopUpExpanded(!isTopUpExpanded)}
            whileTap={{ scale: 0.97 }}
            className={`mt-2 w-full py-2 border rounded-md font-medium transition-colors
              ${
                isTopUpExpanded
                  ? "bg-indigo-600 text-white"
                  : "border-indigo-600 text-indigo-600 hover:bg-indigo-50"
              }`}
          >
            {isTopUpExpanded ? "Cancel" : "Custom Top-Up"}
          </motion.button>
        </motion.div>
      </div>

      {error && (
        <motion.div
          className="mb-6 p-3 bg-red-50 text-red-600 rounded-md"
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: "auto" }}
          transition={{ duration: 0.3 }}
        >
          {error}
        </motion.div>
      )}

      {/* Custom Top-Up Section - Expandable */}
      <AnimatePresence>
        {isTopUpExpanded && (
          <motion.div
            className="bg-white shadow-md rounded-lg p-6 mb-8"
            initial={{ opacity: 0, height: 0, overflow: "hidden" }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
          >
            <h2 className="text-xl font-bold mb-4">Top Up Your Wallet</h2>

            <form onSubmit={handleSubmit}>
              <div className="mb-4">
                <label
                  htmlFor="amount"
                  className="block text-sm font-medium text-gray-700 mb-1"
                >
                  Amount (₹)
                </label>
                <input
                  type="number"
                  id="amount"
                  value={amount}
                  onChange={(e) => setAmount(Number(e.target.value))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                  placeholder="Enter amount"
                  min="1"
                />
              </div>

              {/* Quick amount selection */}
              <div className="flex flex-wrap gap-2 mb-4">
                {amountOptions.map((option) => (
                  <motion.button
                    key={option}
                    type="button"
                    onClick={() => setAmount(option)}
                    whileTap={{ scale: 0.95 }}
                    className={`px-3 py-1 rounded ${
                      amount === option
                        ? "bg-indigo-100 text-indigo-700 border border-indigo-300"
                        : "bg-gray-100 text-gray-700 border border-gray-200 hover:bg-gray-200"
                    }`}
                  >
                    ₹{option}
                  </motion.button>
                ))}
              </div>

              <motion.button
                type="submit"
                disabled={isProcessing || amount <= 0}
                whileTap={{ scale: 0.97 }}
                className={`w-full py-2 px-4 rounded-md text-white font-medium 
                  ${
                    isProcessing || amount <= 0
                      ? "bg-gray-400 cursor-not-allowed"
                      : "bg-indigo-600 hover:bg-indigo-700"
                  }`}
              >
                {isProcessing ? "Processing..." : "Top Up Wallet"}
              </motion.button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Transaction History Section */}
      <motion.div
        className="bg-white shadow-md rounded-lg p-6"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.2 }}
      >
        <h2 className="text-xl font-bold mb-4">Transaction History</h2>
        {loading ? (
          <div className="animate-pulse">
            {[...Array(5)].map((_, i) => (
              <div
                key={i}
                className="flex justify-between py-3 border-b border-gray-100"
              >
                <div className="w-1/2 h-6 bg-gray-200 rounded"></div>
                <div className="w-1/4 h-6 bg-gray-200 rounded"></div>
              </div>
            ))}
          </div>
        ) : walletDetails?.transactions?.length > 0 ? (
          <div className="divide-y divide-gray-100">
            {walletDetails.transactions.map((tx: any, index: number) => (
              <motion.div
                key={tx.transactionId}
                className="py-3"
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.3, delay: index * 0.05 }}
                whileHover={{ backgroundColor: "#f9fafb" }}
              >
                <div className="flex justify-between">
                  <div>
                    <span
                      className={`font-medium ${
                        tx.type === "credit" ? "text-green-600" : "text-red-600"
                      }`}
                    >
                      {tx.type === "credit" ? "+" : "-"} ₹{tx.amount}
                    </span>
                    <p className="text-sm text-gray-700 mt-1">
                      {tx.description}
                    </p>
                  </div>
                  <div className="text-right">
                    <span className="text-gray-500 text-sm">
                      {new Date(
                        tx.createdAt.seconds * 1000
                      ).toLocaleDateString()}
                    </span>
                    <p className="text-xs text-gray-500 mt-1">
                      {new Date(
                        tx.createdAt.seconds * 1000
                      ).toLocaleTimeString()}
                    </p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        ) : (
          <motion.div
            className="py-8 text-center text-gray-500"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3 }}
          >
            No transactions yet. Top up your wallet to get started.
          </motion.div>
        )}
      </motion.div>
    </div>
  );
}
