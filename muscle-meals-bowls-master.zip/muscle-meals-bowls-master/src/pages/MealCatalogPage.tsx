import { useState, useEffect, useMemo } from "react";
import { motion } from "framer-motion";
import { Filter, Search } from "lucide-react";
import { useDispatch, useSelector } from "react-redux";
import { fetchMeals } from "@/store/slices/mealSlice";
import { RootState } from "@/store/store";
import MealCard from "@/components/meals/MealCard";
import { Spinner } from "@/components/ui/spinner";
import { formatTagForDisplay } from "@/utils/tagUtils";

const MealCatalogPage = () => {
  const dispatch = useDispatch();
  const { meals, loading, error } = useSelector(
    (state: RootState) => state.meals
  );

  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [isFilterOpen, setIsFilterOpen] = useState(false);

  // Fetch meals on component mount
  useEffect(() => {
    dispatch(fetchMeals() as any);
  }, [dispatch]);

  // Extract unique categories from meals' tags
  const categories = useMemo(() => {
    if (!meals || meals.length === 0) return ["All"];

    const uniqueTags = new Set<string>();
    meals.forEach((meal) => {
      if (meal.tags && meal.tags.length > 0) {
        meal.tags.forEach((tag) => uniqueTags.add(tag));
      }
    });

    return ["All", ...Array.from(uniqueTags)];
  }, [meals]);

  // Filter meals based on search term and selected category
  const filteredMeals = useMemo(() => {
    return meals.filter((meal) => {
      // Search term filter
      const matchesSearch =
        meal.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        meal.description.toLowerCase().includes(searchTerm.toLowerCase());

      // Category filter
      const matchesCategory =
        selectedCategory === "All" ||
        (meal.tags && meal.tags.includes(selectedCategory));

      return matchesSearch && matchesCategory;
    });
  }, [meals, searchTerm, selectedCategory]);

  // Show loading state
  if (loading && meals.length === 0) {
    return (
      <div className="container mx-auto px-4 py-12 flex justify-center items-center min-h-[60vh]">
        <Spinner size="lg" />
      </div>
    );
  }

  // Show error state
  if (error && meals.length === 0) {
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <h1 className="text-3xl font-bold text-primary mb-4">
          Error Loading Meals
        </h1>
        <p className="mb-8">{error}</p>
        <button
          className="btn btn-primary"
          onClick={() => dispatch(fetchMeals() as any)}
        >
          Try Again
        </button>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <motion.h1
        className="text-4xl font-bold text-primary mb-8"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        Meal Catalog
      </motion.h1>

      {/* Search and Filter */}
      <div className="mb-8">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-grow">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-gray-400" />
            </div>
            <input
              type="text"
              placeholder="Search meals..."
              className="input pl-10"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          {/* Filter button (mobile) */}
          <button
            className="md:hidden btn btn-secondary flex items-center"
            onClick={() => setIsFilterOpen(!isFilterOpen)}
          >
            <Filter className="h-5 w-5 mr-2" />
            Filters
          </button>

          {/* Desktop filters */}
          <div className="hidden md:flex items-center gap-2 flex-wrap">
            {categories.map((category) => (
              <button
                key={category}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                  selectedCategory === category
                    ? "bg-primary text-white"
                    : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
                onClick={() => setSelectedCategory(category)}
              >
                {category === "All" ? "All" : formatTagForDisplay(category)}
              </button>
            ))}
          </div>
        </div>

        {/* Mobile filters */}
        {isFilterOpen && (
          <motion.div
            className="md:hidden mt-4 flex flex-wrap gap-2"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
          >
            {categories.map((category) => (
              <button
                key={category}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                  selectedCategory === category
                    ? "bg-primary text-white"
                    : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
                onClick={() => setSelectedCategory(category)}
              >
                {category === "All" ? "All" : formatTagForDisplay(category)}
              </button>
            ))}
          </motion.div>
        )}
      </div>

      {/* Results count */}
      <p className="text-gray-600 mb-6">
        Showing {filteredMeals.length}{" "}
        {filteredMeals.length === 1 ? "meal" : "meals"}
        {selectedCategory !== "All" &&
          ` in ${formatTagForDisplay(selectedCategory)}`}
      </p>

      {/* Meals grid with loading indicator for subsequent loads */}
      {loading && meals.length > 0 && (
        <div className="flex justify-center mb-6">
          <Spinner />
        </div>
      )}

      {/* Meals grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {filteredMeals.map((meal, index) => (
          <motion.div
            key={meal.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
          >
            <MealCard meal={meal} />
          </motion.div>
        ))}
      </div>

      {/* Empty state */}
      {filteredMeals.length === 0 && !loading && (
        <div className="text-center py-16">
          <p className="text-xl text-gray-500 mb-4">
            No meals found matching your criteria
          </p>
          <button
            className="btn btn-primary"
            onClick={() => {
              setSearchTerm("");
              setSelectedCategory("All");
            }}
          >
            Clear filters
          </button>
        </div>
      )}
    </div>
  );
};

export default MealCatalogPage;
