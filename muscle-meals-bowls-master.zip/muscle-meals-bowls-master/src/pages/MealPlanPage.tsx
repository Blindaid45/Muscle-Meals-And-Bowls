import { useState, useEffect } from "react";
import { useAppDispatch, useAppSelector } from "@/store/hooks";
import {
  fetchUserMealPlans,
  clearMealPlanErrors,
  deleteMealPlan,
} from "@/store/slices/mealPlanSlice";
import { Spinner } from "@/components/ui/spinner";
import { toast } from "sonner";
import MealPlanModal from "@/components/mealPlan/MealPlanModal";
import SubscriptionPlanModal from "@/components/mealPlan/SubscriptionPlanModal";
import MealPlanHeader from "@/components/mealPlan/page/MealPlanHeader";
import EmptyMealPlanState from "@/components/mealPlan/page/EmptyMealPlanState";
import MealPlanGrid from "@/components/mealPlan/page/MealPlanGrid";
import DeleteConfirmationModal from "@/components/mealPlan/page/DeleteConfirmationModal";
import { useMealPlanItemDetails } from "@/hooks/useMealPlanItemDetails";

const MealPlanPage = () => {
  const dispatch = useAppDispatch();
  const { mealPlans, loading, error } = useAppSelector(
    (state) => state.mealPlans
  );

  // UI State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isSubscriptionModalOpen, setIsSubscriptionModalOpen] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);
  const [selectedPlanForSubscription, setSelectedPlanForSubscription] =
    useState<any>(null);
  const [isDeleteConfirmOpen, setIsDeleteConfirmOpen] = useState(false);
  const [planToDelete, setPlanToDelete] = useState<string | null>(null);

  // Get meal item details for all plans
  const { isMealLoading, getMealDetails } = useMealPlanItemDetails(mealPlans);

  // Load meal plans on mount
  useEffect(() => {
    dispatch(fetchUserMealPlans());
    return () => {
      dispatch(clearMealPlanErrors());
    };
  }, [dispatch]);

  // Modal handlers
  const handleOpenModal = (planId?: string) => {
    setSelectedPlan(planId || null);
    setIsModalOpen(true);
  };

  const handleCloseModal = () => {
    setIsModalOpen(false);
    setSelectedPlan(null);
  };

  const handleOpenSubscriptionModal = (plan: any) => {
    setSelectedPlanForSubscription(plan);
    setIsSubscriptionModalOpen(true);
  };

  const handleCloseSubscriptionModal = () => {
    setIsSubscriptionModalOpen(false);
    setSelectedPlanForSubscription(null);
  };

  // Delete handlers
  const handleDeleteConfirm = (planId: string) => {
    setPlanToDelete(planId);
    setIsDeleteConfirmOpen(true);
  };

  const handleDeletePlan = async () => {
    if (!planToDelete) return;

    try {
      await dispatch(deleteMealPlan(planToDelete)).unwrap();
      toast.success("Meal plan deleted successfully");
      setIsDeleteConfirmOpen(false);
      setPlanToDelete(null);
    } catch (error) {
      toast.error("Failed to delete meal plan");
    }
  };

  const cancelDelete = () => {
    setIsDeleteConfirmOpen(false);
    setPlanToDelete(null);
  };

  // Loading state
  if (loading && mealPlans.length === 0) {
    return (
      <div className="flex justify-center items-center min-h-[500px]">
        <Spinner size="lg" />
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Header with title and create button */}
      <MealPlanHeader onCreatePlan={() => handleOpenModal()} />

      {/* Show error message if any */}
      {error && (
        <div className="bg-red-50 text-red-700 p-4 rounded-lg mb-6">
          {error}
        </div>
      )}

      {/* Empty state when no meal plans */}
      {mealPlans.length === 0 ? (
        <EmptyMealPlanState onCreatePlan={() => handleOpenModal()} />
      ) : (
        /* Grid of meal plan cards */
        <MealPlanGrid
          mealPlans={mealPlans}
          getMealDetails={getMealDetails}
          isMealLoading={isMealLoading}
          onEdit={handleOpenModal}
          onDelete={handleDeleteConfirm}
          onSubscribe={handleOpenSubscriptionModal}
        />
      )}

      {/* Meal Plan Creation/Edit Modal */}
      <MealPlanModal
        isOpen={isModalOpen}
        onClose={handleCloseModal}
        planId={selectedPlan}
      />

      {/* Subscription Modal */}
      {selectedPlanForSubscription && (
        <SubscriptionPlanModal
          isOpen={isSubscriptionModalOpen}
          onClose={handleCloseSubscriptionModal}
          mealPlan={selectedPlanForSubscription}
        />
      )}

      {/* Delete Confirmation Modal */}
      <DeleteConfirmationModal
        isOpen={isDeleteConfirmOpen}
        onCancel={cancelDelete}
        onConfirm={handleDeletePlan}
      />
    </div>
  );
};

export default MealPlanPage;
