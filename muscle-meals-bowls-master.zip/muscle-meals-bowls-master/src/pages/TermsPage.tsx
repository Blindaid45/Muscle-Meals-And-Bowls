import { useEffect } from "react";
import { motion } from "framer-motion";
import { ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";

export default function TermsPage() {
  // Scroll to top when component mounts
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } },
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-primary-50/30">
      {/* Hero Section */}
      <motion.section
        className="relative py-16 md:py-20 px-4 flex flex-col items-center justify-center"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.6 }}
      >
        <div className="absolute inset-0 overflow-hidden">
          <div
            className="absolute top-0 left-0 w-full h-full bg-primary-500/5 
            bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] 
            from-primary-100/20 via-transparent to-transparent"
          ></div>
        </div>

        <motion.h1
          className="text-4xl md:text-5xl lg:text-6xl font-bold text-center text-primary-500 mb-6 relative z-10"
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2, duration: 0.8 }}
        >
          Terms & Conditions
        </motion.h1>

        <motion.p
          className="text-xl text-gray-600 text-center max-w-2xl mb-6 relative z-10"
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.4, duration: 0.8 }}
        >
          Please read these terms carefully before using our services
        </motion.p>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6, duration: 0.8 }}
          className="text-sm text-gray-500 mb-8"
        >
          Last updated:{" "}
          {new Date().toLocaleDateString("en-US", {
            month: "long",
            day: "numeric",
            year: "numeric",
          })}
        </motion.div>
      </motion.section>

      {/* Content Section */}
      <section className="py-6 md:py-12">
        <motion.div
          className="container mx-auto px-4 max-w-4xl"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          <motion.div
            className="bg-white rounded-xl shadow-sm p-6 md:p-10 mb-8"
            variants={itemVariants}
          >
            <h2 className="text-2xl font-bold text-primary-500 mb-4">
              Acceptance of Terms
            </h2>
            <p className="text-gray-700 mb-4">
              By accessing or using Muscle Meals and Bowls' website, mobile
              application, or meal delivery service, you agree to be bound by
              these Terms and Conditions. If you do not agree to these Terms,
              please do not use our services.
            </p>
            <p className="text-gray-700">
              We reserve the right to modify these Terms at any time. Your
              continued use of our services following the posting of changes
              constitutes your acceptance of such changes.
            </p>
          </motion.div>

          <motion.div
            className="bg-white rounded-xl shadow-sm p-6 md:p-10 mb-8"
            variants={itemVariants}
          >
            <h2 className="text-2xl font-bold text-primary-500 mb-4">
              Services
            </h2>
            <p className="text-gray-700 mb-4">
              Muscle Meals and Bowls provides meal preparation and delivery
              services, offering high-protein meals delivered to the customer's
              specified delivery address according to the subscription plan
              selected.
            </p>
            <p className="text-gray-700 mb-4">
              We reserve the right to modify, suspend, or discontinue any part
              of our services at any time without prior notice.
            </p>
          </motion.div>

          <motion.div
            className="bg-white rounded-xl shadow-sm p-6 md:p-10 mb-8"
            variants={itemVariants}
          >
            <h2 className="text-2xl font-bold text-primary-500 mb-4">
              Account Registration
            </h2>
            <p className="text-gray-700 mb-4">
              To use certain features of our service, you may be required to
              register for an account. You agree to:
            </p>
            <ul className="list-disc pl-6 space-y-2 text-gray-700 mb-4">
              <li>Provide accurate, current, and complete information</li>
              <li>Maintain and promptly update your account information</li>
              <li>Maintain the security of your account credentials</li>
              <li>
                Accept responsibility for all activities that occur under your
                account
              </li>
            </ul>
            <p className="text-gray-700">
              We reserve the right to suspend or terminate accounts that violate
              our Terms or for any other reason at our discretion.
            </p>
          </motion.div>

          <motion.div
            className="bg-white rounded-xl shadow-sm p-6 md:p-10 mb-8"
            variants={itemVariants}
          >
            <h2 className="text-2xl font-bold text-primary-500 mb-4">
              Orders and Delivery
            </h2>
            <p className="text-gray-700 mb-4">
              By placing an order, you agree to:
            </p>
            <ul className="list-disc pl-6 space-y-2 text-gray-700 mb-4">
              <li>Provide accurate delivery information</li>
              <li>
                Ensure someone is available to receive the delivery during the
                specified time windows
              </li>
              <li>Inspect all delivered meals promptly</li>
              <li>Refrigerate or consume meals as instructed</li>
            </ul>
            <p className="text-gray-700 mb-4">
              We strive to deliver meals at the scheduled times, but cannot
              guarantee exact delivery times due to various factors.
            </p>
            <p className="text-gray-700">
              We currently deliver to Marathahalli and Whitefield in Bangalore.
              Delivery areas may change without prior notice.
            </p>
          </motion.div>

          <motion.div
            className="bg-white rounded-xl shadow-sm p-6 md:p-10 mb-8"
            variants={itemVariants}
          >
            <h2 className="text-2xl font-bold text-primary-500 mb-4">
              Subscription Plans and Payment
            </h2>
            <p className="text-gray-700 mb-4">
              By subscribing to our meal plans, you agree to:
            </p>
            <ul className="list-disc pl-6 space-y-2 text-gray-700 mb-4">
              <li>Pay all fees associated with your selected plan</li>
              <li>
                Provide current, complete, and accurate payment information
              </li>
              <li>
                Authorize us to charge your payment method for the subscription
                fees
              </li>
              <li>Update your payment information as needed</li>
            </ul>
            <p className="text-gray-700">
              You may cancel or reschedule your subscription with at least 48
              hours' notice. Refunds will be issued as per our policy upon
              cancellation.
            </p>
          </motion.div>

          <motion.div
            className="bg-white rounded-xl shadow-sm p-6 md:p-10 mb-8"
            variants={itemVariants}
          >
            <h2 className="text-2xl font-bold text-primary-500 mb-4">
              Food Allergies and Special Diets
            </h2>
            <p className="text-gray-700 mb-4">
              While we strive to accommodate dietary preferences and
              restrictions, we cannot guarantee that our meals are free from
              specific allergens. If you have severe food allergies, please:
            </p>
            <ul className="list-disc pl-6 space-y-2 text-gray-700 mb-4">
              <li>Inform us of your allergies when placing your order</li>
              <li>
                Understand that our meals are prepared in facilities that may
                process common allergens
              </li>
              <li>Use caution and inspect all meals before consumption</li>
            </ul>
            <p className="text-gray-700">
              You acknowledge that you are solely responsible for determining
              whether our meals are safe for your consumption.
            </p>
          </motion.div>

          <motion.div
            className="bg-white rounded-xl shadow-sm p-6 md:p-10 mb-8"
            variants={itemVariants}
          >
            <h2 className="text-2xl font-bold text-primary-500 mb-4">
              Limitation of Liability
            </h2>
            <p className="text-gray-700 mb-4">
              To the maximum extent permitted by law, Muscle Meals and Bowls
              shall not be liable for any indirect, incidental, special,
              consequential, or punitive damages, or any loss of profits or
              revenues, whether incurred directly or indirectly, or any loss of
              data, use, goodwill, or other intangible losses.
            </p>
            <p className="text-gray-700">
              Our liability is limited to the amount paid by you for the meal
              plan in the relevant transaction.
            </p>
          </motion.div>

          <motion.div
            className="bg-white rounded-xl shadow-sm p-6 md:p-10 mb-12"
            variants={itemVariants}
          >
            <h2 className="text-2xl font-bold text-primary-500 mb-4">
              Contact Information
            </h2>
            <p className="text-gray-700 mb-4">
              If you have any questions about these Terms & Conditions, please
              contact us at:
            </p>
            <p className="text-gray-700 font-medium">
              Email: musclemealsandbowls@gmail.com
              <br />
              Phone: +91 79759 90939
            </p>
          </motion.div>

          <motion.div
            className="flex justify-center mb-12"
            variants={itemVariants}
          >
            <Link to="/" className="group">
              <motion.div
                className="flex items-center gap-2 text-primary-500 font-medium"
                whileHover={{ x: -5 }}
                transition={{ duration: 0.2 }}
              >
                <ArrowLeft
                  size={20}
                  className="group-hover:-translate-x-1 transition-transform duration-200"
                />
                <span>Back to Home</span>
              </motion.div>
            </Link>
          </motion.div>
        </motion.div>
      </section>
    </div>
  );
}
