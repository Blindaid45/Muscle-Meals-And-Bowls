import { useParams, Link, useNavigate } from "react-router-dom";
import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchMealById, fetchMeals } from "@/store/slices/mealSlice";
import MealDetail from "@/components/meals/MealDetail";
import { Spinner } from "@/components/ui/spinner";
import ImageSlider from "@/components/ui/ImageSlider";
import { RootState } from "@/store/store";
import { formatTagForDisplay } from "@/utils/tagUtils";
import { getMealImages } from "@/utils/imageUtils";

const MealDetailPage = () => {
  const { id } = useParams<{ id: string }>();
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const { currentMeal, meals, loading, error } = useSelector(
    (state: RootState) => state.meals
  );

  useEffect(() => {
    if (id) {
      dispatch(fetchMealById(id) as any);
    }

    // Fetch all meals if we don't have them yet (for recommendations)
    if (meals.length === 0) {
      dispatch(fetchMeals() as any);
    }
  }, [dispatch, id, meals.length]);

  const handleMealClick = (mealId: string | undefined) => () => {
    if (mealId) {
      window.scrollTo(0, 0);
      navigate(`/meals/${mealId}`);
    }
  };

  // Show loading state
  if (loading && !currentMeal) {
    return (
      <div className="container mx-auto px-4 py-12 flex justify-center items-center">
        <Spinner />
      </div>
    );
  }

  // Show error state
  if (error) {
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <h1 className="text-3xl font-bold text-primary mb-4">Error</h1>
        <p className="mb-8">{error}</p>
        <Link to="/meals" className="btn btn-primary">
          Back to Catalog
        </Link>
      </div>
    );
  }

  // If no meal is found, show a message
  if (!currentMeal) {
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <h1 className="text-3xl font-bold text-primary mb-4">Meal Not Found</h1>
        <p className="mb-8">
          The meal you're looking for doesn't exist or has been removed.
        </p>
        <Link to="/meals" className="btn btn-primary">
          Back to Catalog
        </Link>
      </div>
    );
  }

  return (
    <div>
      <MealDetail meal={currentMeal} />

      {/* Recommended meals section */}
      <div className="container mx-auto px-4 py-12">
        <h2 className="text-2xl font-bold text-primary mb-6">
          You Might Also Like
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
          {meals
            .filter((m) => m.id !== currentMeal.id)
            .slice(0, 3)
            .map((relatedMeal) => (
              <div
                key={relatedMeal.id}
                onClick={handleMealClick(relatedMeal.id)}
                className="block bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow cursor-pointer"
              >
                <div className="h-40">
                  <ImageSlider
                    images={getMealImages(relatedMeal)}
                    aspectRatio="landscape"
                    showArrows={false}
                    showDots={true}
                    autoplay={false}
                  />
                </div>
                <div className="p-4">
                  <h3 className="font-semibold mb-1">{relatedMeal.name}</h3>
                  <p className="text-sm text-gray-500 line-clamp-2">
                    {relatedMeal.description}
                  </p>
                  {relatedMeal.tags && relatedMeal.tags.length > 0 && (
                    <div className="mt-2">
                      <span className="text-xs px-2 py-1 bg-gray-100 rounded-full">
                        {formatTagForDisplay(relatedMeal.tags[0])}
                      </span>
                    </div>
                  )}
                </div>
              </div>
            ))}
        </div>
      </div>
    </div>
  );
};

export default MealDetailPage;
