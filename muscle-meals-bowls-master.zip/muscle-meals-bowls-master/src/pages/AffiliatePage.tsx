import { motion } from "framer-motion";
import { useAffiliate } from "../hooks/useAffiliate";
import AffiliateRegistrationForm from "../components/affiliate/AffiliateRegistrationForm";
import AffiliateDashboard from "../components/affiliate/AffiliateDashboard";
import {
  Sparkles,
  TrendingUp,
  Zap,
  BarChart3,
  UserPlus,
  Share2,
  Gift,
  Coins,
} from "lucide-react";
import Avvvatars from "avvvatars-react";
import { useSelector } from "react-redux";
import { RootState } from "../store/store";
import { useEffect, useState } from "react";

export default function AffiliatePage() {
  const { hasAffiliateAccount, loading } = useAffiliate();
  const user = useSelector((state: RootState) => state.auth.user);
  const [showContent, setShowContent] = useState(false);

  // Add timeout to prevent infinite loading
  useEffect(() => {
    const timer = setTimeout(() => {
      setShowContent(true);
    }, 3000); // Show content after 3 seconds max

    if (!loading) {
      setShowContent(true);
      clearTimeout(timer);
    }

    return () => clearTimeout(timer);
  }, [loading]);

  if (loading && !showContent) {
    return (
      <div className="container mx-auto py-8 px-4">
        <div className="max-w-4xl mx-auto">
          <div className="animate-pulse">
            <div className="h-8 bg-gray-200 rounded mb-4 w-1/3"></div>
            <div className="h-4 bg-gray-200 rounded mb-8 w-2/3"></div>
            <div className="bg-white shadow-md rounded-lg p-6">
              <div className="h-6 bg-gray-200 rounded mb-4"></div>
              <div className="space-y-4">
                <div className="h-4 bg-gray-200 rounded"></div>
                <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                <div className="h-10 bg-gray-200 rounded"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="max-w-4xl mx-auto">
        {/* Page Header */}
        <motion.div
          className="text-center mb-8"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
        >
          <div className="flex items-center justify-center mb-4">
            {user && (
              <div className="mr-4">
                <Avvvatars
                  value={user.email || user.uid}
                  size={48}
                  style="shape"
                  shadow
                />
              </div>
            )}
            <div>
              <h1 className="text-3xl font-bold text-gray-900 mb-2 flex items-center gap-2">
                {hasAffiliateAccount ? (
                  <>
                    <BarChart3 className="text-indigo-600" size={32} />
                    Affiliate Dashboard
                  </>
                ) : (
                  <>
                    <Sparkles className="text-indigo-600" size={32} />
                    Affiliate Program
                  </>
                )}
              </h1>
              <p className="text-gray-600 max-w-2xl mx-auto">
                {hasAffiliateAccount
                  ? "Manage your affiliate account and track your earnings"
                  : "Join our affiliate program and start earning commissions by referring customers to our meal subscription service"}
              </p>
            </div>
          </div>
        </motion.div>

        {/* Main Content */}
        {hasAffiliateAccount ? (
          <AffiliateDashboard />
        ) : (
          <div className="space-y-8">
            {/* Benefits Overview */}
            <motion.div
              className="bg-gradient-to-r from-indigo-600 to-purple-600 rounded-xl p-8 text-white shadow-lg"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.4, delay: 0.1 }}
            >
              <div className="text-center mb-8">
                <div className="flex items-center justify-center mb-4">
                  <TrendingUp size={48} className="text-yellow-300" />
                </div>
                <h2 className="text-3xl font-bold mb-2">
                  Start Earning Today!
                </h2>
                <p className="text-indigo-100 text-lg">
                  Join thousands of affiliates earning passive income with our
                  program
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <motion.div
                  className="text-center bg-white bg-opacity-10 rounded-lg p-6 backdrop-blur-sm"
                  whileHover={{ scale: 1.05 }}
                  transition={{ duration: 0.2 }}
                >
                  <Coins size={40} className="mx-auto mb-3 text-yellow-300" />
                  <h3 className="font-semibold mb-2 text-lg">
                    High Commissions
                  </h3>
                  <p className="text-indigo-100 text-sm">
                    Earn up to 10% commission on every successful referral
                  </p>
                </motion.div>
                <motion.div
                  className="text-center bg-white bg-opacity-10 rounded-lg p-6 backdrop-blur-sm"
                  whileHover={{ scale: 1.05 }}
                  transition={{ duration: 0.2 }}
                >
                  <Zap size={40} className="mx-auto mb-3 text-yellow-300" />
                  <h3 className="font-semibold mb-2 text-lg">Quick Payouts</h3>
                  <p className="text-indigo-100 text-sm">
                    Get paid within 24-48 hours directly to your UPI
                  </p>
                </motion.div>
                <motion.div
                  className="text-center bg-white bg-opacity-10 rounded-lg p-6 backdrop-blur-sm"
                  whileHover={{ scale: 1.05 }}
                  transition={{ duration: 0.2 }}
                >
                  <BarChart3
                    size={40}
                    className="mx-auto mb-3 text-yellow-300"
                  />
                  <h3 className="font-semibold mb-2 text-lg">
                    Real-time Tracking
                  </h3>
                  <p className="text-indigo-100 text-sm">
                    Monitor your earnings and referrals in real-time
                  </p>
                </motion.div>
              </div>
            </motion.div>

            {/* How It Works */}
            <motion.div
              className="bg-white shadow-lg rounded-xl p-8 border border-gray-100"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: 0.2 }}
            >
              <div className="text-center mb-8">
                <h2 className="text-2xl font-bold text-gray-900 mb-2 flex items-center justify-center gap-2">
                  <Sparkles className="text-indigo-600" size={28} />
                  How It Works
                </h2>
                <p className="text-gray-600">Simple steps to start earning</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <motion.div
                  className="text-center group"
                  whileHover={{ y: -5 }}
                  transition={{ duration: 0.2 }}
                >
                  <div className="w-16 h-16 bg-gradient-to-r from-indigo-500 to-purple-500 text-white rounded-full flex items-center justify-center mx-auto mb-4 font-bold text-lg shadow-lg group-hover:shadow-xl transition-shadow">
                    <UserPlus size={24} />
                  </div>
                  <h3 className="font-semibold mb-2 text-gray-900">Sign Up</h3>
                  <p className="text-sm text-gray-600">
                    Create your affiliate account with a unique promo code
                  </p>
                </motion.div>

                <motion.div
                  className="text-center group"
                  whileHover={{ y: -5 }}
                  transition={{ duration: 0.2 }}
                >
                  <div className="w-16 h-16 bg-gradient-to-r from-indigo-500 to-purple-500 text-white rounded-full flex items-center justify-center mx-auto mb-4 font-bold text-lg shadow-lg group-hover:shadow-xl transition-shadow">
                    <Share2 size={24} />
                  </div>
                  <h3 className="font-semibold mb-2 text-gray-900">Share</h3>
                  <p className="text-sm text-gray-600">
                    Share your promo code with friends and family
                  </p>
                </motion.div>

                <motion.div
                  className="text-center group"
                  whileHover={{ y: -5 }}
                  transition={{ duration: 0.2 }}
                >
                  <div className="w-16 h-16 bg-gradient-to-r from-indigo-500 to-purple-500 text-white rounded-full flex items-center justify-center mx-auto mb-4 font-bold text-lg shadow-lg group-hover:shadow-xl transition-shadow">
                    <Gift size={24} />
                  </div>
                  <h3 className="font-semibold mb-2 text-gray-900">
                    They Save
                  </h3>
                  <p className="text-sm text-gray-600">
                    Your referrals get discounts on their subscriptions
                  </p>
                </motion.div>

                <motion.div
                  className="text-center group"
                  whileHover={{ y: -5 }}
                  transition={{ duration: 0.2 }}
                >
                  <div className="w-16 h-16 bg-gradient-to-r from-indigo-500 to-purple-500 text-white rounded-full flex items-center justify-center mx-auto mb-4 font-bold text-lg shadow-lg group-hover:shadow-xl transition-shadow">
                    <Coins size={24} />
                  </div>
                  <h3 className="font-semibold mb-2 text-gray-900">You Earn</h3>
                  <p className="text-sm text-gray-600">
                    Receive commission directly to your UPI account
                  </p>
                </motion.div>
              </div>
            </motion.div>

            {/* Registration Form */}
            <AffiliateRegistrationForm />
          </div>
        )}
      </div>
    </div>
  );
}
