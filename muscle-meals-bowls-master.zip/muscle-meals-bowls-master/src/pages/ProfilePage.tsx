import { useState, useEffect } from "react";
import { useAuth } from "../hooks/useAuth";
import { useProfile } from "../hooks/useProfile";
import ProfileSidebar from "../components/layout/ProfileSidebar";
import AccountInfoTab from "../components/profile/AccountInfoTab";
import OrdersTab from "../components/profile/OrdersTab";
import SubscriptionTab from "../components/profile/SubscriptionTab";
import AddressesTab from "../components/profile/AddressesTab";

const ProfilePage = () => {
  const [activeTab, setActiveTab] = useState("account");
  const { user } = useAuth();
  const { profile, loading, refreshProfile } = useProfile();

  // Refresh the profile when the page loads
  useEffect(() => {
    refreshProfile();
  }, []);

  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold text-primary mb-8">My Profile</h1>

      <div className="flex flex-col md:flex-row gap-8">
        {/* Sidebar */}
        <ProfileSidebar
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          displayName={profile?.displayName || user?.displayName || ""}
          email={user?.email || null}
          photoURL={profile?.photoURL || user?.photoURL}
        />

        {/* Main Content */}
        <div className="md:w-3/4">
          <div className="bg-white rounded-xl shadow-md overflow-hidden">
            {activeTab === "account" && (
              <AccountInfoTab user={user} profile={profile} loading={loading} />
            )}

            {activeTab === "orders" && <OrdersTab />}

            {activeTab === "subscription" && <SubscriptionTab />}

            {activeTab === "addresses" && (
              <AddressesTab isActive={activeTab === "addresses"} />
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;
