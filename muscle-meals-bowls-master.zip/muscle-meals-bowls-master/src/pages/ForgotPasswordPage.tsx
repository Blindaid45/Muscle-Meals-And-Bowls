import { useState, useEffect } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { motion } from "framer-motion";
import { Mail, ArrowLeft } from "lucide-react";
import Button from "../components/ui/Button";
import { useAuth } from "../hooks/useAuth";
import { TextGradient } from "../components/ui/TextGradient";
import { BackgroundBeams } from "../components/ui/BackgroundBeams";
import { toast } from "sonner";

const ForgotPasswordPage = () => {
  const [email, setEmail] = useState("");
  const [emailSent, setEmailSent] = useState(false);
  const { forgotPassword, loading, error, resetError } = useAuth();

  const [searchParams] = useSearchParams();

  // Check if user was redirected after a successful password reset
  const resetSuccess = searchParams.get("reset") === "success";

  // Clear errors when component mounts
  useEffect(() => {
    resetError();

    // If the user was redirected after a successful reset, show a success message
    if (resetSuccess) {
      toast.success(
        "Your password has been reset successfully. You can now log in with your new password."
      );
    }
  }, [resetError, resetSuccess]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Simple validation
    if (!email.trim()) {
      toast.error("Please enter your email address");
      return;
    }

    try {
      const result = await forgotPassword(email);
      // Only set emailSent to true if the reset was actually successful
      // Redux Toolkit wraps the payload in a property called 'payload'
      if (
        result.payload &&
        typeof result.payload === "object" &&
        "success" in result.payload
      ) {
        setEmailSent(true);
      }
    } catch (error) {
      // Error is already handled in the thunk
      console.error("Password reset error:", error);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8 bg-neutral-light relative overflow-hidden">
      <BackgroundBeams />

      <div className="max-w-md w-full space-y-8 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center"
        >
          <Link to="/" className="inline-block">
            <div className="h-14 w-14 mx-auto bg-primary rounded-full flex items-center justify-center">
              <span className="text-white text-2xl font-bold">M</span>
            </div>
          </Link>
          <h2 className="mt-6 text-3xl font-extrabold">
            <TextGradient>Reset your password</TextGradient>
          </h2>
          <p className="mt-2 text-sm text-gray-600">
            {emailSent
              ? "Check your email for a reset link"
              : "Enter your email and we'll send you a link to reset your password"}
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="bg-white/80 backdrop-blur-sm p-8 rounded-xl shadow-md"
        >
          {error && !emailSent && (
            <div className="mb-4 p-3 rounded bg-red-50 border border-red-200 text-red-600 text-sm">
              <p className="font-medium">Password reset failed</p>
              <p>{error}</p>
            </div>
          )}

          {emailSent ? (
            <div className="text-center space-y-4">
              <div className="p-4 bg-green-50 rounded-lg border border-green-200 text-green-700 mb-4">
                <p className="font-medium">Email sent!</p>
                <p className="text-sm">
                  We've sent password reset instructions to {email}. Please
                  check your inbox.
                </p>
              </div>

              <p className="text-sm text-gray-600">
                Didn't receive the email? Check your spam folder or try again.
              </p>

              <div className="mt-4 flex flex-col gap-3">
                <Button
                  variant="outline"
                  onClick={() => setEmailSent(false)}
                  fullWidth
                >
                  Try again
                </Button>

                <Link to="/auth/login">
                  <Button variant="accent" fullWidth>
                    Back to login
                  </Button>
                </Link>
              </div>
            </div>
          ) : (
            <form className="space-y-6" onSubmit={handleSubmit}>
              <div>
                <label htmlFor="email" className="label">
                  Email address
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Mail className="h-5 w-5 text-gray-400" />
                  </div>
                  <input
                    id="email"
                    name="email"
                    type="email"
                    autoComplete="email"
                    required
                    className="input pl-10"
                    placeholder="your@email.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </div>
              </div>

              <Button
                variant="accent"
                fullWidth
                type="submit"
                disabled={loading}
              >
                {loading ? "Sending..." : "Send reset link"}
              </Button>

              <div className="text-center">
                <Link
                  to="/auth/login"
                  className="inline-flex items-center text-sm text-primary hover:text-primary-dark"
                >
                  <ArrowLeft className="h-4 w-4 mr-1" />
                  Back to login
                </Link>
              </div>
            </form>
          )}
        </motion.div>
      </div>
    </div>
  );
};

export default ForgotPasswordPage;
