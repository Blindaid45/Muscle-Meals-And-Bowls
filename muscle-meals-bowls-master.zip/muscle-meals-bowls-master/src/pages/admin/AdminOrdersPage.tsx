import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { AppDispatch, RootState } from "../../store/store";
import { fetchAllSubscriptions } from "../../store/slices/subscriptionSlice";
import { format } from "date-fns";

import Button from "@/components/ui/Button";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { CalendarIcon } from "lucide-react";

// Import components
import OrdersHeader from "./components/OrdersHeader";
import SearchAndFilter from "./components/SearchAndFilter";
import OrdersTable from "./components/OrdersTable";
import OrderDetailsDialog from "./components/OrderDetailsDialog";
import MealQuantitySummary from "./components/MealQuantitySummary";

// Import interfaces and utilities
import {
  UserData,
  MealPlanData,
  SubscriptionWithMealPlan,
} from "./types/orderTypes";
import { fetchUserDetails, fetchMealPlanDetails } from "./utils/dataFetching";
import { generateMealSummary } from "./utils/mealCalculations";

const AdminOrdersPage: React.FC = () => {
  const dispatch = useDispatch<AppDispatch>();
  const { subscriptions, loading, error } = useSelector(
    (state: RootState) => state.subscriptions
  );
  const [selectedSubscription, setSelectedSubscription] =
    useState<SubscriptionWithMealPlan | null>(null);
  const [openDialog, setOpenDialog] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [userData, setUserData] = useState<UserData | null>(null);
  const [mealPlanData, setMealPlanData] = useState<MealPlanData | null>(null);
  const [loadingDetails, setLoadingDetails] = useState(false);
  const [mealsDetails, setMealsDetails] = useState<{ [key: string]: any }>({});
  const [sortColumn, setSortColumn] = useState<string>("startDate");
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("desc");
  const [mealSummary, setMealSummary] = useState<any>({});
  const [loadingMealQuantities, setLoadingMealQuantities] = useState(false);
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());

  useEffect(() => {
    dispatch(fetchAllSubscriptions());
  }, [dispatch]);

  useEffect(() => {
    const fetchMealSummary = async () => {
      if (subscriptions.length === 0 || loading) return;

      setLoadingMealQuantities(true);
      try {
        console.log("🔄 Fetching meal summary for date:", selectedDate);
        console.log("📋 Using subscriptions:", subscriptions.length);
        const summary = await generateMealSummary(subscriptions, selectedDate);
        console.log("✅ Got meal summary:", Object.keys(summary));
        setMealSummary(summary);
      } catch (error) {
        console.error("❌ Error generating meal summary:", error);
      } finally {
        setLoadingMealQuantities(false);
      }
    };

    fetchMealSummary();
  }, [subscriptions, loading, selectedDate]);

  const handleDateChange = React.useCallback((date: Date | undefined) => {
    if (date) {
      console.log("📅 Date changed to:", date);
      setSelectedDate(date);
    }
  }, []);

  const handleViewDetails = async (subscription: SubscriptionWithMealPlan) => {
    setSelectedSubscription(subscription);
    setOpenDialog(true);
    setLoadingDetails(true);
    setUserData(null);
    setMealPlanData(null);
    setMealsDetails({});

    try {
      // Fetch user data if userId exists
      if (subscription.userId) {
        const userData = await fetchUserDetails(subscription.userId);
        setUserData(userData);
      }

      // Fetch meal plan data if itemId exists
      if (subscription.itemId) {
        const { mealPlanData, mealDetails } = await fetchMealPlanDetails(
          subscription.itemId
        );
        setMealPlanData(mealPlanData);
        setMealsDetails(mealDetails || {});
      }
    } catch (error) {
      console.error("Error fetching details:", error);
    } finally {
      setLoadingDetails(false);
    }
  };

  const handleCloseDialog = () => {
    setOpenDialog(false);
    setUserData(null);
    setMealPlanData(null);
    setMealsDetails({});
  };

  const handleSort = (column: string) => {
    if (sortColumn === column) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortColumn(column);
      setSortDirection("asc");
    }
  };

  const filteredSubscriptions = subscriptions
    .filter((sub) => {
      const matchesSearch =
        searchTerm === "" ||
        sub.subscriptionId?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        sub.userId?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        sub.mealPlan?.name?.toLowerCase().includes(searchTerm.toLowerCase());

      const matchesStatus =
        statusFilter === "all" ||
        sub.status?.toLowerCase() === statusFilter.toLowerCase();

      return matchesSearch && matchesStatus;
    })
    .sort((a, b) => {
      const aValue = a[sortColumn as keyof typeof a];
      const bValue = b[sortColumn as keyof typeof b];

      if (!aValue && !bValue) return 0;
      if (!aValue) return sortDirection === "asc" ? 1 : -1;
      if (!bValue) return sortDirection === "asc" ? -1 : 1;

      // Handle dates in different formats
      if (
        sortColumn === "startDate" ||
        sortColumn === "endDate" ||
        sortColumn === "createdAt"
      ) {
        // Firebase timestamps
        if (
          typeof aValue === "object" &&
          aValue !== null &&
          "seconds" in aValue &&
          typeof bValue === "object" &&
          bValue !== null &&
          "seconds" in bValue
        ) {
          const aSeconds = (aValue as { seconds: number }).seconds;
          const bSeconds = (bValue as { seconds: number }).seconds;

          return sortDirection === "asc"
            ? aSeconds - bSeconds
            : bSeconds - aSeconds;
        }

        // String dates
        const dateA = new Date(aValue as string).getTime();
        const dateB = new Date(bValue as string).getTime();

        if (isNaN(dateA) || isNaN(dateB)) {
          return sortDirection === "asc"
            ? String(aValue).localeCompare(String(bValue))
            : String(bValue).localeCompare(String(aValue));
        }

        return sortDirection === "asc" ? dateA - dateB : dateB - dateA;
      }

      // Regular string/number sorting
      if (typeof aValue === "string" && typeof bValue === "string") {
        return sortDirection === "asc"
          ? aValue.localeCompare(bValue)
          : bValue.localeCompare(aValue);
      }

      return sortDirection === "asc"
        ? Number(aValue) - Number(bValue)
        : Number(bValue) - Number(aValue);
    });

  return (
    <div className="p-6 space-y-8 max-w-7xl mx-auto">
      {/* Header with title and stats */}
      <OrdersHeader subscriptions={subscriptions} />

      {/* Date Selector for Meal Quantities */}
      <div className="flex justify-end mb-2">
        <div className="flex items-center space-x-2">
          <span className="text-sm font-medium">Meal quantities for:</span>
          <Popover>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                className="w-[200px] justify-start text-left font-normal"
              >
                <CalendarIcon className="mr-2 h-4 w-4" />
                {format(selectedDate, "PPP")}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0">
              <Calendar
                mode="single"
                selected={selectedDate}
                onSelect={handleDateChange}
                initialFocus
                defaultMonth={selectedDate}
                disabled={(date) => {
                  const yesterday = new Date();
                  yesterday.setDate(yesterday.getDate() - 1);
                  yesterday.setHours(0, 0, 0, 0);
                  return date <= yesterday;
                }}
              />
            </PopoverContent>
          </Popover>
        </div>
      </div>

      {/* Meal Quantity Summary */}
      <MealQuantitySummary
        mealSummary={mealSummary}
        loading={loadingMealQuantities}
        selectedDate={selectedDate}
      />

      {/* Search and filter */}
      <SearchAndFilter
        searchTerm={searchTerm}
        setSearchTerm={setSearchTerm}
        statusFilter={statusFilter}
        setStatusFilter={setStatusFilter}
      />

      {loading ? (
        <div className="flex justify-center py-12">
          <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-primary"></div>
        </div>
      ) : error ? (
        <div className="text-center py-8">
          <div className="text-red-500 text-lg">{error}</div>
          <Button
            variant="outline"
            className="mt-4"
            onClick={() => dispatch(fetchAllSubscriptions())}
          >
            Retry
          </Button>
        </div>
      ) : (
        <OrdersTable
          filteredSubscriptions={filteredSubscriptions}
          sortColumn={sortColumn}
          sortDirection={sortDirection}
          handleSort={handleSort}
          handleViewDetails={handleViewDetails}
        />
      )}

      {/* Order Detail Dialog */}
      <OrderDetailsDialog
        openDialog={openDialog}
        setOpenDialog={setOpenDialog}
        selectedSubscription={selectedSubscription}
        userData={userData}
        mealPlanData={mealPlanData}
        mealsDetails={mealsDetails}
        loadingDetails={loadingDetails}
        handleCloseDialog={handleCloseDialog}
      />
    </div>
  );
};

export default AdminOrdersPage;
