import React from "react";
import { SubscriptionWithMealPlan } from "../types/orderTypes";

interface OrdersHeaderProps {
  subscriptions: SubscriptionWithMealPlan[];
}

const OrdersHeader: React.FC<OrdersHeaderProps> = ({ subscriptions }) => {
  return (
    <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
      <h1 className="text-3xl font-bold tracking-tight">Customer Orders</h1>

      <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 w-full md:w-auto">
        <div className="bg-white rounded-lg shadow p-4 text-center">
          <p className="text-sm text-gray-500">Total Orders</p>
          <p className="text-2xl font-semibold text-primary">
            {subscriptions.length}
          </p>
        </div>
        <div className="bg-white rounded-lg shadow p-4 text-center">
          <p className="text-sm text-gray-500">Active</p>
          <p className="text-2xl font-semibold text-green-600">
            {
              subscriptions.filter((s) => s.status?.toLowerCase() === "active")
                .length
            }
          </p>
        </div>
        <div className="bg-white rounded-lg shadow p-4 text-center sm:col-span-1 col-span-2">
          <p className="text-sm text-gray-500">Pending</p>
          <p className="text-2xl font-semibold text-yellow-600">
            {
              subscriptions.filter((s) => s.status?.toLowerCase() === "pending")
                .length
            }
          </p>
        </div>
      </div>
    </div>
  );
};

export default OrdersHeader;
