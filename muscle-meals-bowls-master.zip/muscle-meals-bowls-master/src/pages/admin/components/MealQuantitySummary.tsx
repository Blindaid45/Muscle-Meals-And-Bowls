import React, { useState, useCallback, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Download, ChevronDown } from "lucide-react";

interface AggregatedMealItem {
  name: string;
  totalQuantity: number;
  unit: string;
}

interface MealSummary {
  [mealTime: string]: AggregatedMealItem[];
}

interface MealQuantitySummaryProps {
  mealSummary: MealSummary;
  loading: boolean;
  selectedDate?: Date;
}

// Animation presets with reduced durations for better responsiveness
const fadeInUp = {
  initial: { opacity: 0, y: 10 },
  animate: { opacity: 1, y: 0, transition: { duration: 0.15 } },
};

const MealQuantitySummary: React.FC<MealQuantitySummaryProps> = ({
  mealSummary,
  loading,
  selectedDate = new Date(),
}) => {
  // Use a Map for better performance with toggles
  const [expandedSections, setExpandedSections] = useState<{
    [key: string]: boolean;
  }>({});

  // Memoize the toggle function
  const toggleSection = useCallback((mealTime: string) => {
    setExpandedSections((prev) => ({
      ...prev,
      [mealTime]: !prev[mealTime],
    }));
  }, []);

  const handleDownloadCSV = useCallback(() => {
    // Create CSV content
    let csvContent = "Meal Time,Meal Name,Quantity,Unit\n";

    Object.entries(mealSummary).forEach(([mealTime, meals]) => {
      meals.forEach((meal) => {
        csvContent += `${mealTime},${meal.name},${meal.totalQuantity},${meal.unit}\n`;
      });
    });

    // Create download link
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);

    // Get date for filename
    const date = selectedDate.toISOString().split("T")[0];
    link.setAttribute("download", `meal-summary-${date}.csv`);

    // Trigger download
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    // Clean up the URL object
    URL.revokeObjectURL(url);
  }, [mealSummary, selectedDate]);

  // Format the date for display (memoized)
  const formattedDate = useMemo(() => {
    return selectedDate.toLocaleDateString("en-US", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  }, [selectedDate]);

  // Calculate total unique meal items (memoized)
  const totalMealItems = useMemo(() => {
    return Object.values(mealSummary).reduce(
      (total, meals) => total + meals.length,
      0
    );
  }, [mealSummary]);

  if (loading) {
    return (
      <motion.div
        {...fadeInUp}
        className="bg-white rounded-lg shadow-lg p-5 mb-6 overflow-hidden"
      >
        <h2 className="text-lg font-semibold mb-2 text-primary-700">
          Daily Meal Preparation Summary
        </h2>
        <div className="flex justify-center py-8">
          <motion.div
            animate={{ rotate: 360 }}
            transition={{
              repeat: Infinity,
              duration: 1,
              ease: "linear",
            }}
            className="h-8 w-8 rounded-full border-t-2 border-primary border-opacity-80"
          />
        </div>
      </motion.div>
    );
  }

  if (!mealSummary || Object.keys(mealSummary).length === 0) {
    return (
      <motion.div
        {...fadeInUp}
        className="bg-white rounded-lg shadow-lg p-5 mb-6"
      >
        <h2 className="text-lg font-semibold mb-2 text-primary-700">
          Daily Meal Preparation Summary
        </h2>
        <p className="text-gray-500 py-6 text-center">
          No meal data available for {formattedDate}
        </p>
      </motion.div>
    );
  }

  return (
    <motion.div
      {...fadeInUp}
      className="bg-white rounded-lg shadow-lg p-5 mb-6 overflow-hidden"
    >
      <div className="flex justify-between items-center mb-5">
        <div>
          <h2 className="text-lg font-semibold text-primary-700">
            Daily Meal Preparation Summary
          </h2>
          <p className="text-sm text-gray-500">For {formattedDate}</p>
        </div>
        <motion.button
          whileTap={{ scale: 0.97 }}
          onClick={handleDownloadCSV}
          className="px-4 py-2 bg-primary text-white text-sm rounded-lg flex items-center gap-2 hover:bg-primary-600 transition-colors"
        >
          <Download size={16} />
          <span>Download Report</span>
        </motion.button>
      </div>

      {totalMealItems > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {Object.entries(mealSummary).map(([mealTime, meals]) => (
            <div
              key={mealTime}
              className="border border-gray-100 rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow duration-300"
            >
              <button
                className="w-full px-4 py-3 bg-gradient-to-r from-primary-50 to-white flex justify-between items-center cursor-pointer hover:bg-gray-50 transition-colors duration-150 focus:outline-none"
                onClick={() => toggleSection(mealTime)}
                aria-expanded={expandedSections[mealTime] || false}
              >
                <h3 className="font-medium text-primary-700 capitalize flex items-center">
                  {mealTime}
                  <span className="text-xs ml-2 text-primary-400 flex items-center">
                    ({meals.length} {meals.length === 1 ? "item" : "items"})
                  </span>
                </h3>
                <ChevronDown
                  size={18}
                  className={`text-primary-400 transform transition-transform duration-150 ${
                    expandedSections[mealTime] ? "rotate-180" : ""
                  }`}
                />
              </button>

              <AnimatePresence initial={false}>
                {expandedSections[mealTime] && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.15 }}
                    className="overflow-hidden"
                  >
                    <div className="space-y-1 px-4 py-3">
                      {meals.map((meal) => (
                        <div
                          key={meal.name}
                          className="flex justify-between items-center py-2 border-b border-gray-50 last:border-0"
                        >
                          <span className="text-gray-700">{meal.name}</span>
                          <span className="font-medium text-primary-600 flex items-center gap-1">
                            {meal.totalQuantity}
                            <span className="text-primary-400 text-sm">
                              {meal.unit}
                            </span>
                          </span>
                        </div>
                      ))}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ))}
        </div>
      ) : (
        <p className="text-gray-500 text-center py-8">
          No meal data available for this date
        </p>
      )}
    </motion.div>
  );
};

export default React.memo(MealQuantitySummary);
