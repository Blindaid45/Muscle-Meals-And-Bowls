import React from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import Button from "@/components/ui/Button";
import { CreditCard, User, Clock, Utensils, Calendar, Tag } from "lucide-react";
import {
  SubscriptionWithMealPlan,
  UserData,
  MealPlanData,
  MealItem,
} from "../types/orderTypes";
import {
  formatDate,
  formatShortDate,
  getStatusColor,
  getDayName,
  formatMealTime,
} from "../utils/formatters";

interface OrderDetailsDialogProps {
  openDialog: boolean;
  setOpenDialog: (isOpen: boolean) => void;
  selectedSubscription: SubscriptionWithMealPlan | null;
  userData: UserData | null;
  mealPlanData: MealPlanData | null;
  mealsDetails: { [key: string]: any };
  loadingDetails: boolean;
  handleCloseDialog: () => void;
}

const OrderDetailsDialog: React.FC<OrderDetailsDialogProps> = ({
  openDialog,
  setOpenDialog,
  selectedSubscription,
  userData,
  mealPlanData,
  mealsDetails,
  loadingDetails,
  handleCloseDialog,
}) => {
  if (!selectedSubscription) return null;

  return (
    <Dialog open={openDialog} onOpenChange={setOpenDialog}>
      <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
        <DialogHeader className="sticky top-0 z-10 bg-white pb-2">
          <DialogTitle className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <span className="text-xl">Order Details</span>
              <span className="text-sm text-gray-500">
                {selectedSubscription.subscriptionId || "N/A"}
              </span>
            </div>
            <span
              className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium ${getStatusColor(
                selectedSubscription.status || "Unknown"
              )}`}
            >
              {selectedSubscription.status || "Unknown"}
            </span>
          </DialogTitle>
        </DialogHeader>

        <div className="mt-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Subscription Info Card */}
            <Card className="shadow-sm border border-gray-200 overflow-hidden">
              <CardHeader className="border-b bg-gray-50 pb-3">
                <CardTitle className="text-lg flex items-center">
                  <CreditCard className="h-5 w-5 mr-2 text-primary" />
                  Subscription Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4 pt-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-gray-500">Created</p>
                    <p className="font-medium">
                      {formatDate(selectedSubscription.createdAt)}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-500">Payment ID</p>
                    <p className="font-medium text-primary">
                      {selectedSubscription.paymentId || "N/A"}
                    </p>
                  </div>
                </div>

                <div className="pt-2">
                  <p className="text-sm text-gray-500">Item ID</p>
                  <p className="font-medium">
                    {selectedSubscription.itemId || "N/A"}
                  </p>
                </div>

                <div className="pt-2">
                  <p className="text-sm text-gray-500">Frequency</p>
                  <p className="capitalize font-medium">
                    {selectedSubscription.frequency || "N/A"}
                  </p>
                </div>

                <div className="border rounded-lg p-3 bg-gray-50 mt-4">
                  <p className="text-sm text-gray-500 mb-1">Duration</p>
                  <div className="flex items-center space-x-2">
                    <Clock className="h-4 w-4 text-gray-500" />
                    <p className="font-medium">
                      {formatShortDate(selectedSubscription.startDate)} —{" "}
                      {formatShortDate(selectedSubscription.endDate)}
                    </p>
                  </div>
                </div>

                <div className="border-t pt-4 mt-2">
                  <p className="text-sm text-gray-500">Amount</p>
                  <p className="text-xl font-bold text-primary">
                    {selectedSubscription.currency || ""}{" "}
                    {selectedSubscription.amount || 0}
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Customer Info */}
            <Card className="shadow-sm border border-gray-200 overflow-hidden">
              <CardHeader className="border-b bg-gray-50 pb-3">
                <CardTitle className="text-lg flex items-center">
                  <User className="h-5 w-5 mr-2 text-primary" />
                  Customer Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4 pt-4">
                {loadingDetails ? (
                  <div className="flex justify-center py-12">
                    <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"></div>
                  </div>
                ) : userData ? (
                  <>
                    <div className="flex items-center">
                      <div className="w-12 h-12 rounded-full bg-gray-100 flex items-center justify-center text-gray-700 mr-4">
                        <User className="h-6 w-6" />
                      </div>
                      <div>
                        <p className="font-medium">
                          {userData.displayName || "N/A"}
                        </p>
                        <p className="text-sm text-gray-500">
                          {userData.email || "No email"}
                        </p>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4 mt-4 border-t pt-4">
                      <div>
                        <p className="text-sm text-gray-500">Customer ID</p>
                        <p className="font-medium truncate" title={userData.id}>
                          {userData.id?.substring(0, 12)}...
                        </p>
                      </div>

                      {userData.phoneNumber && (
                        <div>
                          <p className="text-sm text-gray-500">Phone</p>
                          <p className="font-medium">{userData.phoneNumber}</p>
                        </div>
                      )}
                    </div>

                    {userData.address && (
                      <div className="border-t pt-4 mt-2">
                        <p className="text-sm text-gray-500 mb-1">Address</p>
                        <p className="font-medium">
                          {typeof userData.address === "object"
                            ? Object.values(userData.address)
                                .filter(Boolean)
                                .join(", ")
                            : userData.address}
                        </p>
                      </div>
                    )}
                  </>
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    <User className="h-12 w-12 mx-auto opacity-20 mb-3" />
                    <p>No customer information available</p>
                    <p className="text-sm mt-1">
                      User data could not be retrieved
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Meal Plan Info Card */}
          <div className="mt-6">
            <Card className="shadow-sm border border-gray-200 overflow-hidden">
              <CardHeader className="border-b bg-gray-50 pb-3">
                <CardTitle className="text-lg flex items-center">
                  <Utensils className="h-5 w-5 mr-2 text-primary" />
                  Meal Plan Details
                </CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                {loadingDetails ? (
                  <div className="flex justify-center py-12">
                    <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"></div>
                  </div>
                ) : mealPlanData ? (
                  <div>
                    <div className="p-4 md:p-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-4">
                          <div>
                            <p className="text-sm text-gray-500">Plan Name</p>
                            <p className="text-lg font-semibold text-primary">
                              {mealPlanData.name || "N/A"}
                            </p>
                          </div>

                          <div>
                            <p className="text-sm text-gray-500">Description</p>
                            <p className="italic">
                              {mealPlanData.description || "No description"}
                            </p>
                          </div>

                          <div className="flex items-center space-x-3">
                            <div className="bg-gray-100 p-2 rounded-lg">
                              <p className="text-sm text-gray-500">Duration</p>
                              <p className="font-medium">
                                {mealPlanData.duration || 0} days
                              </p>
                            </div>

                            <div className="bg-gray-100 p-2 rounded-lg">
                              <p className="text-sm text-gray-500">Price</p>
                              <p className="font-medium">
                                ₹{mealPlanData.totalPrice || 0}
                              </p>
                            </div>
                          </div>

                          {mealPlanData.tags && (
                            <div>
                              <p className="text-sm text-gray-500 mb-2 flex items-center">
                                <Tag className="h-4 w-4 mr-1" />
                                Tags
                              </p>
                              <div className="flex flex-wrap gap-1.5">
                                {Array.isArray(mealPlanData.tags) ? (
                                  mealPlanData.tags.map(
                                    (tag: string, index: number) => (
                                      <span
                                        key={index}
                                        className="inline-flex items-center px-2.5 py-1 rounded text-xs font-medium bg-primary-50 text-primary-700 border border-primary-200"
                                      >
                                        {tag}
                                      </span>
                                    )
                                  )
                                ) : (
                                  <span className="text-gray-500">No tags</span>
                                )}
                              </div>
                            </div>
                          )}
                        </div>

                        <div className="space-y-4">
                          <div>
                            <p className="text-sm text-gray-500 mb-2 flex items-center">
                              <span className="mr-1">📊</span>
                              Nutritional Information
                            </p>
                            <div className="grid grid-cols-2 gap-3">
                              <div className="bg-blue-50 p-3 rounded-lg border border-blue-100">
                                <p className="text-xs text-blue-600 uppercase font-semibold">
                                  Calories
                                </p>
                                <p className="text-xl font-bold text-blue-700">
                                  {mealPlanData.totalCalories || 0}
                                </p>
                              </div>
                              <div className="bg-green-50 p-3 rounded-lg border border-green-100">
                                <p className="text-xs text-green-600 uppercase font-semibold">
                                  Protein
                                </p>
                                <p className="text-xl font-bold text-green-700">
                                  {mealPlanData.totalProtein || 0}g
                                </p>
                              </div>
                              <div className="bg-amber-50 p-3 rounded-lg border border-amber-100">
                                <p className="text-xs text-amber-600 uppercase font-semibold">
                                  Carbs
                                </p>
                                <p className="text-xl font-bold text-amber-700">
                                  {mealPlanData.totalCarbs || 0}g
                                </p>
                              </div>
                              <div className="bg-red-50 p-3 rounded-lg border border-red-100">
                                <p className="text-xs text-red-600 uppercase font-semibold">
                                  Fat
                                </p>
                                <p className="text-xl font-bold text-red-700">
                                  {mealPlanData.totalFat || 0}g
                                </p>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Meal Plan Schedule */}
                    {mealPlanData.items &&
                      Array.isArray(mealPlanData.items) &&
                      mealPlanData.items.length > 0 && (
                        <div className="border-t border-gray-200">
                          <div className="p-4 bg-gray-50 border-b border-gray-200">
                            <h3 className="text-lg font-medium flex items-center gap-2">
                              <Calendar className="h-5 w-5 text-primary" />
                              Meal Schedule
                            </h3>
                          </div>

                          <div className="overflow-x-auto">
                            <table className="min-w-full">
                              <thead>
                                <tr className="bg-gray-50 border-b border-gray-200">
                                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">
                                    Day
                                  </th>
                                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">
                                    Meal Item
                                  </th>
                                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">
                                    Meal Times
                                  </th>
                                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">
                                    Quantity
                                  </th>
                                </tr>
                              </thead>
                              <tbody className="divide-y divide-gray-200">
                                {/* Group items by day for easier reading */}
                                {mealPlanData.items.flatMap((item: MealItem) =>
                                  item.dayNumbers.map((dayNumber: number) => (
                                    <tr
                                      key={`${item.id}-${dayNumber}`}
                                      className="hover:bg-gray-50 transition-colors"
                                    >
                                      <td className="px-4 py-3 text-sm font-medium">
                                        <div className="flex items-center space-x-1">
                                          <div className="w-8 h-8 rounded-full bg-primary-50 flex items-center justify-center text-primary-700 font-semibold">
                                            {dayNumber}
                                          </div>
                                          <span>{getDayName(dayNumber)}</span>
                                        </div>
                                      </td>
                                      <td className="px-4 py-3">
                                        <div className="flex items-center">
                                          <div className="mr-3">
                                            <div className="w-10 h-10 rounded-md bg-gray-100 flex items-center justify-center text-gray-500">
                                              <Utensils className="h-5 w-5" />
                                            </div>
                                          </div>
                                          <div>
                                            <div className="text-sm font-medium">
                                              {mealsDetails[item.mealId]
                                                ?.name || "Unknown Meal"}
                                            </div>
                                            <div className="text-xs text-gray-500 max-w-[260px] truncate">
                                              {mealsDetails[item.mealId]
                                                ?.description ||
                                                "No description"}
                                            </div>
                                          </div>
                                        </div>
                                      </td>
                                      <td className="px-4 py-3">
                                        <div className="flex flex-wrap gap-1">
                                          {item.mealTimes.map(
                                            (mealTime: string, idx: number) => (
                                              <span
                                                key={idx}
                                                className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800 border border-blue-200"
                                              >
                                                {formatMealTime(mealTime)}
                                              </span>
                                            )
                                          )}
                                        </div>
                                      </td>
                                      <td className="px-4 py-3 text-sm font-medium">
                                        {item.quantity}g
                                      </td>
                                    </tr>
                                  ))
                                )}
                              </tbody>
                            </table>
                          </div>
                        </div>
                      )}
                  </div>
                ) : (
                  <div className="text-center py-16 text-gray-500">
                    <Utensils className="h-12 w-12 mx-auto opacity-20 mb-3" />
                    <p className="text-lg">
                      No meal plan information available
                    </p>
                    <p className="text-sm">
                      Meal plan data could not be retrieved
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>

        <DialogFooter className="mt-6 space-x-2 sticky bottom-0 bg-white py-3">
          <Button variant="outline" onClick={handleCloseDialog}>
            Close
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default OrderDetailsDialog;
