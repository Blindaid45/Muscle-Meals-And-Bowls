import React from "react";
import {
  Table,
  TableHeader,
  TableRow,
  TableHead,
  TableBody,
  TableCell,
} from "@/components/ui/table";
import {
  ChevronRight,
  User,
  Calendar,
  Wallet,
  Mail,
  Phone,
  Filter,
} from "lucide-react";
import { AdminUser } from "@/store/slices/admin/adminUsersSlice";
import { format } from "date-fns";

interface UsersTableProps {
  users: AdminUser[];
  loading: boolean;
  sortColumn: string;
  sortDirection: "asc" | "desc";
  handleSort: (column: string) => void;
}

const UsersTable: React.FC<UsersTableProps> = ({
  users,
  loading,
  sortColumn,
  sortDirection,
  handleSort,
}) => {
  const formatDate = (dateString: string | null) => {
    if (!dateString) return "N/A";
    try {
      return format(new Date(dateString), "dd MMM yyyy");
    } catch (error) {
      return "Invalid date";
    }
  };

  return (
    <div className="rounded-lg border border-gray-200 overflow-hidden">
      <div className="overflow-x-auto">
        <Table>
          <TableHeader className="bg-gray-50">
            <TableRow>
              <TableHead
                className="font-medium cursor-pointer hover:bg-gray-100"
                onClick={() => handleSort("id")}
              >
                <div className="flex items-center space-x-1">
                  <span>User ID</span>
                  {sortColumn === "id" && (
                    <ChevronRight
                      className={`h-4 w-4 transform ${
                        sortDirection === "asc" ? "rotate-90" : "-rotate-90"
                      }`}
                    />
                  )}
                </div>
              </TableHead>
              <TableHead className="font-medium">Name</TableHead>
              <TableHead className="font-medium">Email</TableHead>
              <TableHead className="font-medium">Phone</TableHead>
              <TableHead
                className="font-medium cursor-pointer hover:bg-gray-100"
                onClick={() => handleSort("walletBalance")}
              >
                <div className="flex items-center space-x-1">
                  <span>Wallet Balance</span>
                  {sortColumn === "walletBalance" && (
                    <ChevronRight
                      className={`h-4 w-4 transform ${
                        sortDirection === "asc" ? "rotate-90" : "-rotate-90"
                      }`}
                    />
                  )}
                </div>
              </TableHead>
              <TableHead
                className="font-medium cursor-pointer hover:bg-gray-100"
                onClick={() => handleSort("createdAt")}
              >
                <div className="flex items-center space-x-1">
                  <span>Created At</span>
                  {sortColumn === "createdAt" && (
                    <ChevronRight
                      className={`h-4 w-4 transform ${
                        sortDirection === "asc" ? "rotate-90" : "-rotate-90"
                      }`}
                    />
                  )}
                </div>
              </TableHead>
              <TableHead className="font-medium">Fitness Goal</TableHead>
              <TableHead className="font-medium">Height</TableHead>
              <TableHead className="font-medium">Weight</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              <TableRow>
                <TableCell colSpan={9} className="h-40 text-center">
                  <div className="flex flex-col items-center justify-center">
                    <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"></div>
                    <p className="text-gray-500 mt-3">Loading users...</p>
                  </div>
                </TableCell>
              </TableRow>
            ) : users.length > 0 ? (
              users.map((user) => (
                <TableRow
                  key={user.id}
                  className="hover:bg-gray-50 transition-colors duration-150"
                >
                  <TableCell className="font-medium">
                    <div className="flex flex-col">
                      <span className="text-primary">
                        {user.id.substring(0, 8)}...
                      </span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-2">
                      <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center text-gray-600">
                        <User className="h-4 w-4" />
                      </div>
                      <span>{user.displayName || "N/A"}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-1">
                      <Mail className="h-4 w-4 text-gray-500" />
                      <span>{user.email || "N/A"}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-1">
                      <Phone className="h-4 w-4 text-gray-500" />
                      <span>{user.phoneNumber || "N/A"}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-1">
                      <Wallet className="h-4 w-4 text-gray-500" />
                      <span className="text-green-600 font-medium">
                        ₹{user.walletBalance || 0}
                      </span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-1">
                      <Calendar className="h-4 w-4 text-gray-500" />
                      <span>{formatDate(user.createdAt)}</span>
                    </div>
                  </TableCell>
                  <TableCell>{user.fitnessGoal || "N/A"}</TableCell>
                  <TableCell>
                    {user.height ? `${user.height} cm` : "N/A"}
                  </TableCell>
                  <TableCell>
                    {user.weight ? `${user.weight} kg` : "N/A"}
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell
                  colSpan={9}
                  className="h-40 text-center text-gray-500"
                >
                  <div className="flex flex-col items-center justify-center">
                    <Filter className="h-8 w-8 mb-2 opacity-30" />
                    <p className="text-lg">No users found</p>
                    <p className="text-sm mt-1">
                      Try changing your search criteria
                    </p>
                  </div>
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
};

export default UsersTable;
