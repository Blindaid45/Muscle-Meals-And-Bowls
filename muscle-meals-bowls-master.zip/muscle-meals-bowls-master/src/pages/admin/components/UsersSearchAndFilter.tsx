import React from "react";
import { Search } from "lucide-react";
import Button from "@/components/ui/Button";

interface UsersSearchAndFilterProps {
  searchTerm: string;
  setSearchTerm: (term: string) => void;
  handleSearch: () => void;
  handleClearSearch: () => void;
}

const UsersSearchAndFilter: React.FC<UsersSearchAndFilterProps> = ({
  searchTerm,
  setSearchTerm,
  handleSearch,
  handleClearSearch,
}) => {
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") {
      handleSearch();
    }
  };

  return (
    <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-4 rounded-lg border border-gray-200 shadow-sm">
      <div className="relative flex-1">
        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
          <Search className="h-5 w-5 text-gray-400" />
        </div>
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          onKeyDown={handleKeyDown}
          className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-primary focus:border-primary sm:text-sm"
          placeholder="Search by name, email, or ID..."
        />
      </div>

      <div className="flex gap-2">
        <Button
          onClick={handleSearch}
          className="bg-primary hover:bg-primary-dark text-white"
          size="sm"
        >
          Search
        </Button>
        {searchTerm && (
          <Button onClick={handleClearSearch} variant="outline" size="sm">
            Clear
          </Button>
        )}
      </div>
    </div>
  );
};

export default UsersSearchAndFilter;
