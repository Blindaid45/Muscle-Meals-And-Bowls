import React from "react";
import { Users, Activity, Wallet } from "lucide-react";
import { AdminUser } from "@/store/slices/admin/adminUsersSlice";

interface UsersHeaderProps {
  totalUsers: number;
  users: AdminUser[];
}

const UsersHeader: React.FC<UsersHeaderProps> = ({ totalUsers, users }) => {
  // Calculate total wallet balance across all loaded users
  const totalWalletBalance = users.reduce(
    (total, user) => total + (user.walletBalance || 0),
    0
  );

  // Calculate average wallet balance
  const averageWalletBalance =
    users.length > 0 ? totalWalletBalance / users.length : 0;

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold">Users Management</h1>
        <p className="text-gray-600">View and manage all users</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white p-5 rounded-lg border border-gray-200 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-500 text-sm font-medium">Total Users</p>
              <p className="text-3xl font-bold mt-1">{totalUsers}</p>
            </div>
            <div className="w-12 h-12 rounded-full bg-blue-50 flex items-center justify-center">
              <Users className="h-6 w-6 text-blue-500" />
            </div>
          </div>
        </div>

        <div className="bg-white p-5 rounded-lg border border-gray-200 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-500 text-sm font-medium">
                Total Wallet Balance
              </p>
              <p className="text-3xl font-bold mt-1">₹{totalWalletBalance}</p>
            </div>
            <div className="w-12 h-12 rounded-full bg-green-50 flex items-center justify-center">
              <Wallet className="h-6 w-6 text-green-500" />
            </div>
          </div>
        </div>

        <div className="bg-white p-5 rounded-lg border border-gray-200 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-500 text-sm font-medium">
                Avg. Wallet Balance
              </p>
              <p className="text-3xl font-bold mt-1">
                ₹{averageWalletBalance.toFixed(2)}
              </p>
            </div>
            <div className="w-12 h-12 rounded-full bg-purple-50 flex items-center justify-center">
              <Activity className="h-6 w-6 text-purple-500" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UsersHeader;
