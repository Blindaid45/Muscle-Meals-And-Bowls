import React from "react";
import {
  Table,
  TableHeader,
  TableRow,
  TableHead,
  TableBody,
  TableCell,
} from "@/components/ui/table";
import Button from "@/components/ui/Button";
import {
  CreditCard,
  User,
  Clock,
  ChevronRight,
  Eye,
  Filter,
} from "lucide-react";
import { SubscriptionWithMealPlan } from "../types/orderTypes";
import { formatShortDate, getStatusColor } from "../utils/formatters";

interface OrdersTableProps {
  filteredSubscriptions: SubscriptionWithMealPlan[];
  sortColumn: string;
  sortDirection: "asc" | "desc";
  handleSort: (column: string) => void;
  handleViewDetails: (subscription: SubscriptionWithMealPlan) => void;
}

const OrdersTable: React.FC<OrdersTableProps> = ({
  filteredSubscriptions,
  sortColumn,
  sortDirection,
  handleSort,
  handleViewDetails,
}) => {
  return (
    <div className="rounded-lg border border-gray-200 overflow-hidden">
      <div className="overflow-x-auto">
        <Table>
          <TableHeader className="bg-gray-50">
            <TableRow>
              <TableHead
                className="font-medium cursor-pointer hover:bg-gray-100"
                onClick={() => handleSort("subscriptionId")}
              >
                <div className="flex items-center space-x-1">
                  <span>Order ID</span>
                  {sortColumn === "subscriptionId" && (
                    <ChevronRight
                      className={`h-4 w-4 transform ${
                        sortDirection === "asc" ? "rotate-90" : "-rotate-90"
                      }`}
                    />
                  )}
                </div>
              </TableHead>
              <TableHead className="font-medium">Customer</TableHead>
              <TableHead className="font-medium">Plan</TableHead>
              <TableHead
                className="font-medium cursor-pointer hover:bg-gray-100"
                onClick={() => handleSort("amount")}
              >
                <div className="flex items-center space-x-1">
                  <span>Amount</span>
                  {sortColumn === "amount" && (
                    <ChevronRight
                      className={`h-4 w-4 transform ${
                        sortDirection === "asc" ? "rotate-90" : "-rotate-90"
                      }`}
                    />
                  )}
                </div>
              </TableHead>
              <TableHead
                className="font-medium cursor-pointer hover:bg-gray-100"
                onClick={() => handleSort("startDate")}
              >
                <div className="flex items-center space-x-1">
                  <span>Start Date</span>
                  {sortColumn === "startDate" && (
                    <ChevronRight
                      className={`h-4 w-4 transform ${
                        sortDirection === "asc" ? "rotate-90" : "-rotate-90"
                      }`}
                    />
                  )}
                </div>
              </TableHead>
              <TableHead className="font-medium">Status</TableHead>
              <TableHead className="font-medium text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredSubscriptions.length > 0 ? (
              filteredSubscriptions.map((subscription) => (
                <TableRow
                  key={subscription.subscriptionId}
                  className="hover:bg-gray-50 transition-colors duration-150"
                >
                  <TableCell className="font-medium">
                    <div className="flex flex-col">
                      <span className="text-primary">
                        {subscription.subscriptionId?.substring(0, 8) || "N/A"}
                        ...
                      </span>
                      <span className="text-xs text-gray-500">
                        {formatShortDate(subscription.createdAt)}
                      </span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-2">
                      <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center text-gray-600">
                        <User className="h-4 w-4" />
                      </div>
                      <span>
                        {subscription.userId?.substring(0, 10) || "N/A"}...
                      </span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="max-w-[180px] truncate font-medium">
                      {subscription.frequency || "N/A"}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-1">
                      <CreditCard className="h-4 w-4 text-gray-500" />
                      <span>
                        {subscription.currency || ""} {subscription.amount || 0}
                      </span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-1">
                      <Clock className="h-4 w-4 text-gray-500" />
                      <span>{formatShortDate(subscription.startDate)}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <span
                      className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium ${getStatusColor(
                        subscription?.status || "Unknown"
                      )}`}
                    >
                      {subscription.status || "Unknown"}
                    </span>
                  </TableCell>
                  <TableCell className="text-right">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleViewDetails(subscription)}
                      className="hover:bg-gray-100"
                    >
                      <Eye className="h-4 w-4 mr-1" />
                      View
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell
                  colSpan={7}
                  className="h-40 text-center text-gray-500"
                >
                  <div className="flex flex-col items-center justify-center">
                    <Filter className="h-8 w-8 mb-2 opacity-30" />
                    <p className="text-lg">No orders found</p>
                    <p className="text-sm mt-1">
                      Try changing your search or filter criteria
                    </p>
                  </div>
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
};

export default OrdersTable;
