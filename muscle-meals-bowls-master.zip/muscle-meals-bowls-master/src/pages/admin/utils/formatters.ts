import { format } from "date-fns";

// Function to format date
export const formatDate = (
  dateString: string | { seconds: number; nanoseconds: number }
) => {
  try {
    if (!dateString) return "N/A";

    // Handle Firebase Timestamp objects
    if (typeof dateString === "object" && "seconds" in dateString) {
      return format(
        new Date(dateString.seconds * 1000),
        "MMM dd, yyyy hh:mm a"
      );
    }

    // Handle ISO string or timestamp string
    if (typeof dateString === "string") {
      const date = dateString.includes("T")
        ? new Date(dateString)
        : new Date(parseInt(dateString));
      return format(date, "MMM dd, yyyy hh:mm a");
    }

    return "Invalid date";
  } catch (error) {
    console.error("Error formatting date:", error, dateString);
    return String(dateString) || "Invalid date";
  }
};

// Function to get short date format
export const formatShortDate = (
  dateString: string | { seconds: number; nanoseconds: number }
) => {
  try {
    if (!dateString) return "N/A";

    // Handle Firebase Timestamp objects
    if (typeof dateString === "object" && "seconds" in dateString) {
      return format(new Date(dateString.seconds * 1000), "MMM dd, yyyy");
    }

    // Handle ISO string or timestamp string
    if (typeof dateString === "string") {
      const date = dateString.includes("T")
        ? new Date(dateString)
        : new Date(parseInt(dateString));
      return format(date, "MMM dd, yyyy");
    }

    return "Invalid date";
  } catch (error) {
    return "N/A";
  }
};

// Function to convert day number to day name
export const getDayName = (dayNumber: number) => {
  const days = [
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday",
    "Sunday",
  ];
  return days[dayNumber - 1] || `Day ${dayNumber}`;
};

// Function to format meal time
export const formatMealTime = (mealTime: string) => {
  return mealTime.charAt(0).toUpperCase() + mealTime.slice(1);
};

// Function to get status color
export const getStatusColor = (status: string) => {
  switch (status?.toLowerCase()) {
    case "active":
      return "bg-green-100 text-green-800 border border-green-300";
    case "pending":
      return "bg-yellow-100 text-yellow-800 border border-yellow-300";
    case "cancelled":
      return "bg-red-100 text-red-800 border border-red-300";
    default:
      return "bg-gray-100 text-gray-800 border border-gray-300";
  }
};
