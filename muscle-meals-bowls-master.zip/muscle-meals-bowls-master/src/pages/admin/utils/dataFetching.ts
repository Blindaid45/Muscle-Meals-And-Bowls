import { doc, getDoc } from "firebase/firestore";

import { UserData, MealPlanData } from "../types/orderTypes";
import { db } from "@/lib/firebase";

// Function to fetch user details
export const fetchUserDetails = async (
  userId: string
): Promise<UserData | null> => {
  if (!userId) return null;

  try {
    const userDoc = await getDoc(doc(db, "users", userId));
    if (userDoc.exists()) {
      const userData = { id: userDoc.id, ...userDoc.data() };
      console.log("User data:", userData);
      return userData as UserData;
    } else {
      console.log("No user found with ID:", userId);
      return null;
    }
  } catch (error) {
    console.error("Error fetching user:", error);
    return null;
  }
};

// Function to fetch meal plan details
export const fetchMealPlanDetails = async (
  itemId: string
): Promise<{
  mealPlanData: MealPlanData | null;
  mealDetails: { [key: string]: any };
}> => {
  if (!itemId) return { mealPlanData: null, mealDetails: {} };

  try {
    const mealPlanDoc = await getDoc(doc(db, "mealPlans", itemId));
    if (mealPlanDoc.exists()) {
      const mealPlanData = {
        id: mealPlanDoc.id,
        ...mealPlanDoc.data(),
      } as MealPlanData;
      console.log("Meal plan data:", mealPlanData);

      // Fetch details for each meal in the plan
      const mealDetails: { [key: string]: any } = {};

      if (mealPlanData.items && Array.isArray(mealPlanData.items)) {
        const mealIds = mealPlanData.items
          .map((item: any) => item.mealId)
          .filter(Boolean);
        const uniqueMealIds = [...new Set(mealIds)]; // Remove duplicates

        await Promise.all(
          uniqueMealIds.map(async (mealId: string) => {
            try {
              const mealDoc = await getDoc(doc(db, "meals", mealId));
              if (mealDoc.exists()) {
                mealDetails[mealId] = { id: mealId, ...mealDoc.data() };
              }
            } catch (err) {
              console.error(`Error fetching meal ${mealId}:`, err);
            }
          })
        );

        console.log("Individual meals details:", mealDetails);
      }

      return { mealPlanData, mealDetails };
    } else {
      console.log("No meal plan found with ID:", itemId);
      return { mealPlanData: null, mealDetails: {} };
    }
  } catch (error) {
    console.error("Error fetching meal plan:", error);
    return { mealPlanData: null, mealDetails: {} };
  }
};
