import { WEEKDAYS } from "@/components/mealPlan/constants";
import { SubscriptionWithMealPlan } from "../types/orderTypes";
import { fetchMealPlanDetails } from "./dataFetching";

interface MealQuantity {
  mealId: string;
  name: string;
  quantity: number;
  unit: string;
}

interface MealTimeQuantities {
  [mealTime: string]: MealQuantity[];
}

interface AggregatedMealItem {
  name: string;
  totalQuantity: number;
  unit: string;
}

interface MealSummary {
  [mealTime: string]: AggregatedMealItem[];
}

export const calculateDailyMealQuantities = async (
  subscriptions: SubscriptionWithMealPlan[],
  date: Date = new Date()
): Promise<MealTimeQuantities> => {
  try {
    // Create a date object for consistent comparisons, reset to midnight in local timezone
    const selectedDate = new Date(date);
    selectedDate.setHours(0, 0, 0, 0);

 
  
  

    // Get day of week (0 = Sunday, 1 = Monday, etc.)
    const dayOfWeek = date.getDay();
  

    const weekday = WEEKDAYS[dayOfWeek].id;
    

    // Filter active subscriptions that are valid for the selected date
    const activeSubscriptions = subscriptions.filter((sub) => {
      if (sub.status !== "active") return false;

     

      // Handle subscription start date, normalize to midnight for comparison
      let startDate = null;
      if (sub.startDate) {
        if (typeof sub.startDate === "object" && "seconds" in sub.startDate) {
          startDate = new Date(sub.startDate.seconds * 1000);
        } else {
          startDate = new Date(sub.startDate);
        }
        startDate.setHours(0, 0, 0, 0);
      }
      

      // Handle subscription end date, normalize to end of day for comparison
      let endDate = null;
      if (sub.endDate) {
        if (typeof sub.endDate === "object" && "seconds" in sub.endDate) {
          endDate = new Date(sub.endDate.seconds * 1000);
        } else {
          endDate = new Date(sub.endDate);
        }
        endDate.setHours(23, 59, 59, 999);
      }
      

      // Compare dates directly using normalized date objects
      if (startDate && selectedDate < startDate) {
       
        return false;
      }

      // If endDate exists and selected date is after end date, exclude
      if (endDate && selectedDate > endDate) {
        
        return false;
      }

      
      return true;
    });

   

    if (activeSubscriptions.length === 0) {
     
      return {};
    }

    // Initialize result object
    const mealQuantities: MealTimeQuantities = {};

    // Map to store already processed meal plans to avoid duplicate fetching
    const processedMealPlans = new Map();

    // Process each subscription
    await Promise.all(
      activeSubscriptions.map(async (subscription) => {
        if (!subscription.itemId) {
          
          return;
        }

        let mealPlanData;
        let mealDetails;

        // Check if we've already processed this meal plan
        if (processedMealPlans.has(subscription.itemId)) {
          const cached = processedMealPlans.get(subscription.itemId);
          mealPlanData = cached.mealPlanData;
          mealDetails = cached.mealDetails;
         
        } else {
         
          const result = await fetchMealPlanDetails(subscription.itemId);
          mealPlanData = result.mealPlanData;
          mealDetails = result.mealDetails;
         

          // Cache the result
          processedMealPlans.set(subscription.itemId, {
            mealPlanData,
            mealDetails,
          });
        }

        if (!mealPlanData || !mealPlanData.items) {
         
          return;
        }

        // Process each meal in the plan
        mealPlanData.items.forEach((item: any) => {
          const { mealId, quantity = 1, dayNumbers = [] } = item;
         

          if (!mealId) {
          
            return;
          }

          // Skip if this meal is not scheduled for the current day of week
          if (dayNumbers.length > 0 && !dayNumbers.includes(weekday)) {
           
            return;
          }

          const mealInfo = mealDetails[mealId];
          if (!mealInfo) {
           
            return;
          }

          const { name, unit = "g" } = mealInfo;

          // Handle both single mealTime string and array of mealTimes
          const mealTimes = Array.isArray(item.mealTimes)
            ? item.mealTimes
            : item.mealTime
            ? [item.mealTime]
            : ["unspecified"];

         

          // Process each meal time for this item
          mealTimes.forEach((mealTime: string) => {
            // Initialize meal time array if it doesn't exist
            if (!mealQuantities[mealTime]) {
              mealQuantities[mealTime] = [];
            }

            // Check if this meal already exists in the array
            const existingMealIndex = mealQuantities[mealTime].findIndex(
              (m) => m.mealId === mealId
            );

            if (existingMealIndex >= 0) {
              // Update existing meal quantity
              mealQuantities[mealTime][existingMealIndex].quantity += quantity;
              
            } else {
              // Add new meal to the array
              mealQuantities[mealTime].push({
                mealId,
                name,
                quantity,
                unit,
              });
              
            }
          });
        });
      })
    );

  
    return mealQuantities;
  } catch (error) {
    console.error("❌ Error calculating meal quantities:", error);
    return {};
  }
};

/**
 * Generates a meal summary for a given date, grouping by meal time and
 * aggregating quantities for each meal item.
 *
 * @param subscriptions - Array of active subscriptions with meal plans
 * @param date - Date to generate summary for (defaults to today)
 * @returns A summary of meals grouped by meal time with aggregated quantities
 */
export const generateMealSummary = async (
  subscriptions: SubscriptionWithMealPlan[],
  date: Date = new Date()
): Promise<MealSummary> => {
  try {
    

    // Get the raw meal quantities by meal time
    const mealTimeQuantities = await calculateDailyMealQuantities(
      subscriptions,
      date
    );

    // Initialize the meal summary object
    const mealSummary: MealSummary = {};

    // Process each meal time
    for (const [mealTime, meals] of Object.entries(mealTimeQuantities)) {
      // Initialize this meal time in the summary
      mealSummary[mealTime] = [];

      // Create a map to aggregate meals by name
      const mealMap = new Map<string, AggregatedMealItem>();

      // Process each meal in this meal time
      meals.forEach((meal) => {
        const { name, quantity, unit } = meal;

        // Check if this meal name is already in our map
        if (mealMap.has(name)) {
          // Update the quantity
          const existingMeal = mealMap.get(name)!;
          existingMeal.totalQuantity += quantity;
          
        } else {
          // Add new meal to the map
          mealMap.set(name, {
            name,
            totalQuantity: quantity,
            unit,
          });
          
        }
      });

      // Convert the map values to an array and store in the summary
      mealSummary[mealTime] = Array.from(mealMap.values());
    }

   
    return mealSummary;
  } catch (error) {
    console.error("❌ Error generating meal summary:", error);
    return {};
  }
};

/**
 * Formats the meal summary into a human-readable string
 *
 * @param mealSummary - The meal summary object
 * @returns A formatted string representation of the meal summary
 */
export const formatMealSummary = (mealSummary: MealSummary): string => {
  if (Object.keys(mealSummary).length === 0) {
    return "No meals scheduled for today.";
  }

  let formattedSummary = "";

  // Process each meal time
  for (const [mealTime, meals] of Object.entries(mealSummary)) {
    // Capitalize the first letter of meal time
    const formattedMealTime =
      mealTime.charAt(0).toUpperCase() + mealTime.slice(1);

    formattedSummary += `\n${formattedMealTime}:\n`;

    if (meals.length === 0) {
      formattedSummary += "  No meals scheduled\n";
    } else {
      // Add each meal item with its quantity
      meals.forEach((meal) => {
        formattedSummary += `  - ${meal.name}: ${meal.totalQuantity}${meal.unit}\n`;
      });
    }
  }

  return formattedSummary;
};
