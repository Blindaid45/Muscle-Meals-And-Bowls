import React, { useEffect, useState, useMemo } from "react";
import { useDispatch, useSelector } from "react-redux";
import { AppDispatch, RootState } from "../../store/store";
import {
  fetchUsers,
  fetchTotalUserCount,
  searchUsers,
  clearUsers,
  setCurrentPage,
  AdminUser,
} from "../../store/slices/admin/adminUsersSlice";

// Import components
import UsersHeader from "./components/UsersHeader";
import UsersSearchAndFilter from "./components/UsersSearchAndFilter";
import UsersTable from "./components/UsersTable";
import Pagination from "@/components/ui/Pagination";

const AdminUsersPage: React.FC = () => {
  const dispatch = useDispatch<AppDispatch>();
  const {
    users,
    loading,
    error,
    totalUsers,
    currentPage,
    totalPages,
    pageSize,
  } = useSelector((state: RootState) => state.adminUsers);

  const [searchTerm, setSearchTerm] = useState("");
  const [sortColumn, setSortColumn] = useState<string>("createdAt");
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("desc");
  const [isSearchActive, setIsSearchActive] = useState(false);

  // Initial data loading
  useEffect(() => {
    dispatch(fetchTotalUserCount());
    loadUsers(1);
  }, [dispatch]);

  const loadUsers = (page: number) => {
    dispatch(fetchUsers({ page, pageSize }));
  };

  // Handle page change
  const handlePageChange = (page: number) => {
    if (page !== currentPage && !loading) {
      dispatch(setCurrentPage(page));
      loadUsers(page);
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  };

  // Handle search
  const handleSearch = () => {
    if (searchTerm.trim()) {
      setIsSearchActive(true);
      dispatch(searchUsers(searchTerm));
    }
  };

  // Handle clear search
  const handleClearSearch = () => {
    setSearchTerm("");
    setIsSearchActive(false);
    loadUsers(1);
  };

  // Handle sorting
  const handleSort = (column: string) => {
    if (sortColumn === column) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortColumn(column);
      setSortDirection("asc");
    }
  };

  // Sort users based on current sort criteria
  const sortedUsers = useMemo(() => {
    if (!users.length) return [];

    return [...users].sort((a, b) => {
      const aValue = a[sortColumn as keyof AdminUser];
      const bValue = b[sortColumn as keyof AdminUser];

      if (!aValue && !bValue) return 0;
      if (!aValue) return sortDirection === "asc" ? 1 : -1;
      if (!bValue) return sortDirection === "asc" ? -1 : 1;

      // Handle dates
      if (sortColumn === "createdAt" || sortColumn === "updatedAt") {
        const dateA = new Date(aValue as string).getTime();
        const dateB = new Date(bValue as string).getTime();

        if (isNaN(dateA) || isNaN(dateB)) {
          return sortDirection === "asc"
            ? String(aValue).localeCompare(String(bValue))
            : String(bValue).localeCompare(String(aValue));
        }

        return sortDirection === "asc" ? dateA - dateB : dateB - dateA;
      }

      // Handle numbers
      if (typeof aValue === "number" && typeof bValue === "number") {
        return sortDirection === "asc" ? aValue - bValue : bValue - aValue;
      }

      // Handle strings
      return sortDirection === "asc"
        ? String(aValue).localeCompare(String(bValue))
        : String(bValue).localeCompare(String(aValue));
    });
  }, [users, sortColumn, sortDirection]);

  return (
    <div className="p-6 space-y-8 max-w-7xl mx-auto">
      {/* Header with title and stats */}
      <UsersHeader totalUsers={totalUsers} users={users} />

      {/* Search and filter */}
      <UsersSearchAndFilter
        searchTerm={searchTerm}
        setSearchTerm={setSearchTerm}
        handleSearch={handleSearch}
        handleClearSearch={handleClearSearch}
      />

      {error ? (
        <div className="text-center py-8">
          <div className="text-red-500 text-lg">{error}</div>
          <button
            className="mt-4 px-4 py-2 bg-primary text-white rounded-md"
            onClick={() => loadUsers(1)}
          >
            Retry
          </button>
        </div>
      ) : (
        <>
          <UsersTable
            users={sortedUsers}
            loading={loading}
            sortColumn={sortColumn}
            sortDirection={sortDirection}
            handleSort={handleSort}
          />

          <Pagination
            currentPage={currentPage}
            totalPages={totalPages}
            onPageChange={handlePageChange}
            isLoading={loading}
          />
        </>
      )}

      {/* Show results count information */}
      {!loading && !error && users.length > 0 && (
        <div className="text-sm text-gray-500 text-center">
          Showing {users.length} {users.length === 1 ? "user" : "users"}
          {totalUsers > 0 ? ` of ${totalUsers} total` : ""}
          {isSearchActive ? " (filtered results)" : ""}
        </div>
      )}
    </div>
  );
};

export default AdminUsersPage;
