import AdminMealPlanManagement from "@/components/admin/AdminMealPlanManagement";

export default function AdminMealPlansPage() {
  return (
    <>
      <div className="px-6 py-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Meal Plans</h1>
            <p className="text-gray-600 mt-1">
              Manage admin meal plans available to all users
            </p>
          </div>
        </div>

        <AdminMealPlanManagement />
      </div>
    </>
  );
}
