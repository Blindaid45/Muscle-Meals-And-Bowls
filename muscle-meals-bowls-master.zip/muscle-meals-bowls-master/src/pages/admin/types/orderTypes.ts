// Interfaces for user and meal data
export interface UserData {
  id: string;
  email: string;
  displayName?: string;
  phoneNumber?: string;
  address?: {
    street?: string;
    city?: string;
    state?: string;
    postalCode?: string;
    country?: string;
  };
  createdAt?: any;
  [key: string]: any;
}

export interface MealItem {
  mealId: string;
  quantity: number;
  mealTime?: string;
  frequency?: string[];
  [key: string]: any;
}

export interface MealData {
  id: string;
  name: string;
  description?: string;
  image?: string;
  price?: number;
  unit?: string;
  [key: string]: any;
}

export interface MealPlanData {
  id: string;
  name: string;
  description?: string;
  price?: number;
  duration?: number;
  items: MealItem[];
  [key: string]: any;
}

export interface SubscriptionWithMealPlan {
  subscriptionId?: string;
  userId?: string;
  itemId?: string;
  status?: string;
  startDate?: any;
  endDate?: any;
  createdAt?: any;
  mealPlan?: {
    name?: string;
    [key: string]: any;
  };
  [key: string]: any;
}
