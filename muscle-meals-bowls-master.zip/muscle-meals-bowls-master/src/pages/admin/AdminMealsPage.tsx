import MealManagement from "@/components/admin/MealManagement";
import TagManagement from "@/components/admin/TagManagement";

export default function AdminMealsPage() {
  return (
    <div className="p-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Meal Management</h1>
        <p className="text-gray-600 mt-2">
          Manage your meal offerings and categorization tags
        </p>
      </div>

      {/* Tag Management Section - Collapsible by default */}
      <TagManagement />

      {/* Meal Management Section */}
      <MealManagement />
    </div>
  );
}
