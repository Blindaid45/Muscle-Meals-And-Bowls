import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Trash2, ShoppingBag, ArrowRight } from "lucide-react";
import Button from "../components/ui/Button";
import QuantitySelector from "../components/ui/QuantitySelector";
import { Link, useNavigate } from "react-router-dom";

// Sample cart items
const initialCartItems = [
  {
    id: 1,
    name: "Protein-Packed Chicken Bowl",
    price: 250,
    baseQuantity: 300,
    quantity: 300,
    image:
      "https://images.pexels.com/photos/1640773/pexels-photo-1640773.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    protein: 35,
    carbs: 40,
    fat: 12,
    calories: 412,
  },
  {
    id: 5,
    name: "Keto Friendly Plate",
    price: 270,
    baseQuantity: 300,
    quantity: 350,
    image:
      "https://images.pexels.com/photos/1410235/pexels-photo-1410235.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    protein: 32,
    carbs: 5,
    fat: 38,
    calories: 490,
  },
  {
    id: 2,
    name: "Low-Carb Salmon Plate",
    price: 320,
    baseQuantity: 250,
    quantity: 250,
    image:
      "https://images.pexels.com/photos/3763847/pexels-photo-3763847.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    protein: 28,
    carbs: 8,
    fat: 22,
    calories: 340,
  },
];

const CartPage = () => {
  const navigate = useNavigate();
  const [cartItems, setCartItems] = useState(initialCartItems);
  const [totalNutrition, setTotalNutrition] = useState({
    protein: 0,
    carbs: 0,
    fat: 0,
    calories: 0,
  });

  // Calculate subtotal
  const subtotal = cartItems.reduce((total, item) => {
    const itemPrice = (item.price / item.baseQuantity) * item.quantity;
    return total + itemPrice;
  }, 0);

  // Apply discount logic
  let discount = 0;
  let discountMessage = "";

  if (subtotal >= 2000) {
    discount = subtotal * 0.1;
    discountMessage = "10% off orders above ₹2000";
  } else if (subtotal >= 1000) {
    discount = subtotal * 0.05;
    discountMessage = "5% off orders above ₹1000";
  }

  const deliveryFee = 100;
  const total = subtotal - discount + deliveryFee;

  const handleQuantityChange = (id: number, newQuantity: number) => {
    setCartItems((prevItems) =>
      prevItems.map((item) =>
        item.id === id ? { ...item, quantity: newQuantity } : item
      )
    );
  };

  const handleRemoveItem = (id: number) => {
    setCartItems((prevItems) => prevItems.filter((item) => item.id !== id));
  };

  // Calculate total nutritional content
  useEffect(() => {
    const nutrition = cartItems.reduce(
      (acc, item) => {
        const factor = item.quantity / item.baseQuantity;
        return {
          protein: acc.protein + Math.round(item.protein * factor),
          carbs: acc.carbs + Math.round(item.carbs * factor),
          fat: acc.fat + Math.round(item.fat * factor),
          calories: acc.calories + Math.round(item.calories * factor),
        };
      },
      { protein: 0, carbs: 0, fat: 0, calories: 0 }
    );

    setTotalNutrition(nutrition);
  }, [cartItems]);

  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold text-primary mb-8">Your Cart</h1>

      {cartItems.length > 0 ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-xl shadow-md overflow-hidden">
              {/* Header */}
              <div className="px-6 py-4 border-b">
                <h2 className="font-semibold text-lg">
                  Cart Items ({cartItems.length})
                </h2>
              </div>

              {/* Items */}
              <div>
                {cartItems.map((item, index) => {
                  // Calculate scaled nutritional values
                  const scaleFactor = item.quantity / item.baseQuantity;
                  const scaledProtein = Math.round(item.protein * scaleFactor);
                  const scaledCarbs = Math.round(item.carbs * scaleFactor);
                  const scaledFat = Math.round(item.fat * scaleFactor);
                  const scaledCalories = Math.round(
                    item.calories * scaleFactor
                  );

                  // Calculate item total price
                  const itemPrice = (
                    (item.price / item.baseQuantity) *
                    item.quantity
                  ).toFixed(2);

                  return (
                    <motion.div
                      key={item.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.3, delay: index * 0.1 }}
                      className={`p-6 ${
                        index !== cartItems.length - 1 ? "border-b" : ""
                      }`}
                    >
                      <div className="flex flex-col sm:flex-row gap-4">
                        {/* Image */}
                        <div className="sm:w-24 sm:h-24 flex-shrink-0">
                          <img
                            src={item.image}
                            alt={item.name}
                            className="w-full h-full object-cover rounded-md"
                          />
                        </div>

                        {/* Details */}
                        <div className="flex-grow">
                          <div className="flex flex-col sm:flex-row sm:justify-between mb-3">
                            <h3 className="font-semibold text-lg">
                              {item.name}
                            </h3>
                            <p className="font-bold text-primary text-xl">
                              ₹{itemPrice}
                            </p>
                          </div>

                          <div className="flex flex-wrap gap-2 mb-3">
                            <span className="text-sm bg-gray-100 px-2 py-1 rounded">
                              Protein: {scaledProtein}g
                            </span>
                            <span className="text-sm bg-gray-100 px-2 py-1 rounded">
                              Carbs: {scaledCarbs}g
                            </span>
                            <span className="text-sm bg-gray-100 px-2 py-1 rounded">
                              Fat: {scaledFat}g
                            </span>
                            <span className="text-sm bg-gray-100 px-2 py-1 rounded">
                              Calories: {scaledCalories} kcal
                            </span>
                          </div>

                          <div className="flex justify-between items-center">
                            <QuantitySelector
                              initialValue={item.quantity}
                              min={50}
                              max={500}
                              step={50}
                              onChange={(value) =>
                                handleQuantityChange(item.id, value)
                              }
                            />

                            <button
                              className="text-red-500 hover:text-red-700 transition-colors"
                              onClick={() => handleRemoveItem(item.id)}
                            >
                              <Trash2 className="h-5 w-5" />
                            </button>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            </div>

            {/* Nutrition Summary */}
            <div className="mt-8 bg-white rounded-xl shadow-md overflow-hidden">
              <div className="px-6 py-4 border-b">
                <h2 className="font-semibold text-lg">
                  Total Nutritional Content
                </h2>
              </div>

              <div className="p-6">
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                  <div className="bg-red-50 p-4 rounded-lg text-center">
                    <p className="text-sm text-gray-600">Protein</p>
                    <p className="text-2xl font-bold text-red-600">
                      {totalNutrition.protein}g
                    </p>
                  </div>

                  <div className="bg-yellow-50 p-4 rounded-lg text-center">
                    <p className="text-sm text-gray-600">Carbs</p>
                    <p className="text-2xl font-bold text-yellow-600">
                      {totalNutrition.carbs}g
                    </p>
                  </div>

                  <div className="bg-green-50 p-4 rounded-lg text-center">
                    <p className="text-sm text-gray-600">Fat</p>
                    <p className="text-2xl font-bold text-green-600">
                      {totalNutrition.fat}g
                    </p>
                  </div>

                  <div className="bg-blue-50 p-4 rounded-lg text-center">
                    <p className="text-sm text-gray-600">Calories</p>
                    <p className="text-2xl font-bold text-blue-600">
                      {totalNutrition.calories}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl shadow-md overflow-hidden sticky top-24">
              <div className="px-6 py-4 border-b">
                <h2 className="font-semibold text-lg">Order Summary</h2>
              </div>

              <div className="p-6">
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span>Subtotal</span>
                    <span>₹{subtotal.toFixed(2)}</span>
                  </div>

                  {discount > 0 && (
                    <div className="flex justify-between text-green-600">
                      <span>Discount ({discountMessage})</span>
                      <span>-₹{discount.toFixed(2)}</span>
                    </div>
                  )}

                  <div className="flex justify-between">
                    <span>Delivery Fee</span>
                    <span>₹{deliveryFee.toFixed(2)}</span>
                  </div>

                  <div className="border-t pt-4 mt-4">
                    <div className="flex justify-between font-bold text-xl">
                      <span>Total</span>
                      <span className="text-primary">₹{total.toFixed(2)}</span>
                    </div>
                  </div>
                </div>

                <div className="mt-8">
                  <Button
                    variant="accent"
                    fullWidth
                    icon={<ShoppingBag className="h-5 w-5" />}
                  >
                    Proceed to Checkout
                  </Button>
                </div>

                <div className="mt-4">
                  <a
                    href="/meals"
                    className="text-primary font-medium text-sm flex items-center justify-center"
                  >
                    <ArrowRight className="h-4 w-4 mr-1" />
                    Continue Shopping
                  </a>
                </div>

                <div className="mt-6 p-4 bg-neutral-light rounded-lg">
                  <h3 className="font-medium mb-2">Discount Information</h3>
                  <ul className="text-sm text-gray-600 space-y-1">
                    <li>• 5% off orders above ₹1000</li>
                    <li>• 10% off orders above ₹2000</li>
                    <li>• 15% off for subscribers</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        // Empty cart
        <div className="text-center py-16 bg-white rounded-xl shadow-md">
          <ShoppingBag className="h-16 w-16 mx-auto text-gray-300 mb-4" />
          <h2 className="text-2xl font-semibold mb-2">Your cart is empty</h2>
          <p className="text-gray-600 mb-8">
            Looks like you haven't added any meals to your cart yet.
          </p>
          <Button variant="accent" onClick={() => navigate("/meals")}>
            Browse Meals
          </Button>
        </div>
      )}
    </div>
  );
};

export default CartPage;
