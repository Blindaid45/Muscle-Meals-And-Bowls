import { useEffect } from "react";
import { motion } from "framer-motion";
import { ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";

export default function PrivacyPolicyPage() {
  // Scroll to top when component mounts
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } },
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-primary-50/30">
      {/* Hero Section */}
      <motion.section
        className="relative py-16 md:py-20 px-4 flex flex-col items-center justify-center"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.6 }}
      >
        <div className="absolute inset-0 overflow-hidden">
          <div
            className="absolute top-0 left-0 w-full h-full bg-primary-500/5 
            bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] 
            from-primary-100/20 via-transparent to-transparent"
          ></div>
        </div>

        <motion.h1
          className="text-4xl md:text-5xl lg:text-6xl font-bold text-center text-primary-500 mb-6 relative z-10"
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2, duration: 0.8 }}
        >
          Privacy Policy
        </motion.h1>

        <motion.p
          className="text-xl text-gray-600 text-center max-w-2xl mb-6 relative z-10"
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.4, duration: 0.8 }}
        >
          How we collect, use, and protect your personal information
        </motion.p>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6, duration: 0.8 }}
          className="text-sm text-gray-500 mb-8"
        >
          Last updated:{" "}
          {new Date().toLocaleDateString("en-US", {
            month: "long",
            day: "numeric",
            year: "numeric",
          })}
        </motion.div>
      </motion.section>

      {/* Content Section */}
      <section className="py-6 md:py-12">
        <motion.div
          className="container mx-auto px-4 max-w-4xl"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          <motion.div
            className="bg-white rounded-xl shadow-sm p-6 md:p-10 mb-8"
            variants={itemVariants}
          >
            <h2 className="text-2xl font-bold text-primary-500 mb-4">
              Introduction
            </h2>
            <p className="text-gray-700 mb-4">
              At Muscle Meals and Bowls, we take your privacy seriously. This
              Privacy Policy explains how we collect, use, disclose, and
              safeguard your information when you visit our website or use our
              meal delivery service.
            </p>
            <p className="text-gray-700 mb-4">
              Please read this privacy policy carefully. If you do not agree
              with the terms of this privacy policy, please do not access the
              site or use our services.
            </p>
          </motion.div>

          <motion.div
            className="bg-white rounded-xl shadow-sm p-6 md:p-10 mb-8"
            variants={itemVariants}
          >
            <h2 className="text-2xl font-bold text-primary-500 mb-4">
              Information We Collect
            </h2>
            <p className="text-gray-700 mb-4">
              We may collect personal information that you voluntarily provide
              to us when you:
            </p>
            <ul className="list-disc pl-6 space-y-2 text-gray-700 mb-4">
              <li>Register for an account</li>
              <li>Place an order for our meal delivery service</li>
              <li>Sign up for our newsletter</li>
              <li>Respond to a survey or fill out a form</li>
              <li>Contact us with inquiries or feedback</li>
            </ul>
            <p className="text-gray-700">
              The personal information we collect may include your name, email
              address, phone number, delivery address, billing information, and
              dietary preferences or restrictions.
            </p>
          </motion.div>

          <motion.div
            className="bg-white rounded-xl shadow-sm p-6 md:p-10 mb-8"
            variants={itemVariants}
          >
            <h2 className="text-2xl font-bold text-primary-500 mb-4">
              How We Use Your Information
            </h2>
            <p className="text-gray-700 mb-4">
              We may use the information we collect from you for various
              purposes, including:
            </p>
            <ul className="list-disc pl-6 space-y-2 text-gray-700 mb-4">
              <li>Processing and fulfilling your orders</li>
              <li>Sending order confirmations and delivery updates</li>
              <li>Managing your account and providing customer support</li>
              <li>
                Sending promotional offers and newsletters (if you've opted in)
              </li>
              <li>Improving our website and service offerings</li>
              <li>Analyzing usage patterns and trends</li>
              <li>
                Protecting against fraudulent or unauthorized transactions
              </li>
            </ul>
          </motion.div>

          <motion.div
            className="bg-white rounded-xl shadow-sm p-6 md:p-10 mb-8"
            variants={itemVariants}
          >
            <h2 className="text-2xl font-bold text-primary-500 mb-4">
              Information Security
            </h2>
            <p className="text-gray-700 mb-4">
              We implement appropriate security measures to protect your
              personal information from unauthorized access, alteration,
              disclosure, or destruction. However, no method of transmission
              over the Internet or electronic storage is 100% secure, so we
              cannot guarantee absolute security.
            </p>
          </motion.div>

          <motion.div
            className="bg-white rounded-xl shadow-sm p-6 md:p-10 mb-8"
            variants={itemVariants}
          >
            <h2 className="text-2xl font-bold text-primary-500 mb-4">
              Third-Party Disclosure
            </h2>
            <p className="text-gray-700 mb-4">
              We do not sell, trade, or otherwise transfer your personally
              identifiable information to outside parties except in the
              following cases:
            </p>
            <ul className="list-disc pl-6 space-y-2 text-gray-700 mb-4">
              <li>
                To trusted third parties who assist us in operating our website
                or service
              </li>
              <li>When required by law or to protect our rights</li>
              <li>With your consent for specific purposes disclosed to you</li>
            </ul>
          </motion.div>

          <motion.div
            className="bg-white rounded-xl shadow-sm p-6 md:p-10 mb-8"
            variants={itemVariants}
          >
            <h2 className="text-2xl font-bold text-primary-500 mb-4">
              Your Rights
            </h2>
            <p className="text-gray-700 mb-4">You have the right to:</p>
            <ul className="list-disc pl-6 space-y-2 text-gray-700 mb-4">
              <li>Access and receive a copy of your personal data</li>
              <li>Request rectification or erasure of your personal data</li>
              <li>Object to or restrict processing of your personal data</li>
              <li>Opt-out of marketing communications</li>
            </ul>
            <p className="text-gray-700">
              To exercise any of these rights, please contact us using the
              information provided below.
            </p>
          </motion.div>

          <motion.div
            className="bg-white rounded-xl shadow-sm p-6 md:p-10 mb-12"
            variants={itemVariants}
          >
            <h2 className="text-2xl font-bold text-primary-500 mb-4">
              Contact Us
            </h2>
            <p className="text-gray-700 mb-4">
              If you have any questions or concerns regarding this Privacy
              Policy, please contact us at:
            </p>
            <p className="text-gray-700 font-medium">
              Email: musclemealsandbowls@gmail.com
              <br />
              Phone: +91 79759 90939
            </p>
          </motion.div>

          <motion.div
            className="flex justify-center mb-12"
            variants={itemVariants}
          >
            <Link to="/" className="group">
              <motion.div
                className="flex items-center gap-2 text-primary-500 font-medium"
                whileHover={{ x: -5 }}
                transition={{ duration: 0.2 }}
              >
                <ArrowLeft
                  size={20}
                  className="group-hover:-translate-x-1 transition-transform duration-200"
                />
                <span>Back to Home</span>
              </motion.div>
            </Link>
          </motion.div>
        </motion.div>
      </section>
    </div>
  );
}
