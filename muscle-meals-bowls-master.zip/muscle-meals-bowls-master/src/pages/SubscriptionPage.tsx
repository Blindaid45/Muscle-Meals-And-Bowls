import { motion } from "framer-motion";
import { useEffect, useState } from "react";
import { useAppDispatch, useAppSelector } from "@/store/hooks";
import {
  PublicMealPlan,
  fetchAllPublicMealPlans,
} from "@/store/slices/publicMealPlanSlice";
import { createFromAdminMealPlan } from "@/store/slices/mealPlanSlice";
import { Spinner } from "@/components/ui/spinner";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";

import Button from "../components/ui/Button";
import { BENEFITS, TESTIMONIALS } from "@/components/mealPlan/constants";
import SubscriptionPlanCard from "@/components/subscription/SubscriptionPlanCard";

import { useMealPlanItemDetails } from "@/hooks/useMealPlanItemDetails";
import FAQ from "@/components/FAQ";

const SubscriptionPage = () => {
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const { publicMealPlans, loading } = useAppSelector(
    (state) => state.publicMealPlans
  );

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  };

  const [isCreatingPlan, setIsCreatingPlan] = useState(false);

  // Get meal item details for all plans
  const { isMealLoading, getMealDetails } =
    useMealPlanItemDetails(publicMealPlans);

  useEffect(() => {
    dispatch(fetchAllPublicMealPlans());
  }, [dispatch]);

  const handleOpenSubscriptionModal = async (plan: PublicMealPlan) => {
    try {
      if (!plan.id) {
        throw new Error("Plan ID is missing");
      }

      // First create a copy of the admin meal plan in the user's collection
      setIsCreatingPlan(true);

      // Create a personal copy of the admin meal plan
      await dispatch(createFromAdminMealPlan(plan.id)).unwrap();

      setIsCreatingPlan(false);
      navigate("/user/meal-plans");
    } catch (error) {
      setIsCreatingPlan(false);
      toast.error("Failed to initialize subscription. Please try again.");
      console.error("Subscription initialization error:", error);
    }
  };

  return (
    <div>
      {/* Available Subscription Plans */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-primary mb-12 text-center">
            Available Meal Plans
          </h2>

          {loading || isCreatingPlan ? (
            <div className="flex flex-col justify-center items-center min-h-[200px]">
              <Spinner size="lg" />
              {isCreatingPlan && (
                <p className="mt-4 text-gray-600">
                  Creating your personalized meal plan...
                </p>
              )}
            </div>
          ) : publicMealPlans.length === 0 ? (
            <div className="text-center text-gray-500">
              <p>No subscription plans available at the moment.</p>
              <p>Please check back later!</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {publicMealPlans.map((plan) => (
                <SubscriptionPlanCard
                  key={plan.id}
                  plan={plan}
                  getMealDetails={getMealDetails}
                  isMealLoading={isMealLoading}
                  onSubscribe={handleOpenSubscriptionModal}
                />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Features */}
      <section className="py-16 bg-neutral-light">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-primary mb-12 text-center">
            Subscription Benefits
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {BENEFITS.map((benefit, index) => (
              <motion.div
                key={index}
                className="bg-white p-6 rounded-xl shadow-md"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
              >
                <div className="h-12 w-12 rounded-full bg-primary-100 flex items-center justify-center mb-4">
                  <span className="text-primary font-bold">{index + 1}</span>
                </div>
                <h3 className="text-xl font-bold mb-2">{benefit.title}</h3>
                <p className="text-gray-600">{benefit.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-primary mb-12 text-center">
            What Subscribers Say
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {TESTIMONIALS.map((testimonial, index) => (
              <motion.div
                key={index}
                className="bg-neutral-light p-6 rounded-xl shadow-md"
                initial={{ opacity: 0, x: index % 2 === 0 ? -20 : 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5 }}
              >
                <div className="flex items-center mb-4">
                  <img
                    src={testimonial.image}
                    alt={testimonial.name}
                    className="w-12 h-12 rounded-full mr-4"
                  />
                  <div>
                    <h4 className="font-bold">{testimonial.name}</h4>
                    <p className="text-sm text-gray-500">{testimonial.role}</p>
                  </div>
                </div>

                <p className="italic text-gray-600">"{testimonial.quote}"</p>

                <div className="mt-4 flex">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <svg
                      key={star}
                      className="w-5 h-5 text-yellow-400"
                      fill="currentColor"
                      viewBox="0 0 20 20"
                    >
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path>
                    </svg>
                  ))}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 bg-neutral-light">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-primary mb-8 text-center">
            Frequently Asked Questions
          </h2>

          <div className="max-w-3xl mx-auto">
            <FAQ hideTitle={true} />
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="bg-primary text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <motion.h2
            className="text-3xl md:text-4xl font-bold mb-4"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            Ready for Consistent Nutrition?
          </motion.h2>

          <motion.p
            className="max-w-2xl mx-auto mb-8 text-primary-100"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            Join now and enjoy free delivery for your first week. Experience the
            convenience of regular, precisely portioned meals delivered to your
            door.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <Button
              variant="accent"
              size="lg"
              onClick={() => {
                scrollToTop();
                toast.info("Select an available plan to subscribe.");
              }}
            >
              Subscribe Now
            </Button>
          </motion.div>
        </div>
        <hr className="my-12" />
      </section>
    </div>
  );
};

export default SubscriptionPage;
