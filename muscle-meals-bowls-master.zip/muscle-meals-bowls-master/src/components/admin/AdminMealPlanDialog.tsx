import { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/Button";
import ImageUpload from "@/components/ui/ImageUpload";
import {
  CalendarCheck,
  Check,
  X,
  Search,
  Filter,
  Info,
  Package,
} from "lucide-react";
import {
  createAdminMealPlan,
  updateAdminMealPlan,
  AdminMealPlan,
  AdminMealPlanItem,
  calculateAdminMealPlanTotals,
} from "@/store/slices/adminMealPlanSlice";
import { fetchMeals, Meal } from "@/store/slices/mealSlice";
import { fetchTags } from "@/store/slices/tagSlice";
import { AppDispatch, RootState } from "@/store/store";
import { toast } from "sonner";
import { formatTagForDisplay, formatTagForStorage } from "@/utils/tagUtils";
import { motion, AnimatePresence } from "framer-motion";

interface AdminMealPlanDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit?: () => void;
  editMode?: boolean;
  mealPlan?: AdminMealPlan;
}

interface MealPlanFormData {
  name: string;
  description: string;
  duration: number;
  isActive: boolean;
  tags: string[];
  category?: string;
  featuredImage?: string;
  items: AdminMealPlanItem[];
}

const defaultFormData: MealPlanFormData = {
  name: "",
  description: "",
  duration: 7,
  isActive: false,
  tags: [],
  category: "",
  featuredImage: "",
  items: [],
};

export default function AdminMealPlanDialog({
  isOpen,
  onClose,
  onSubmit,
  editMode = false,
  mealPlan,
}: AdminMealPlanDialogProps) {
  const dispatch = useDispatch<AppDispatch>();
  const { loading } = useSelector((state: RootState) => state.adminMealPlans);
  const { meals, loading: mealsLoading } = useSelector(
    (state: RootState) => state.meals
  );
  const { tags } = useSelector((state: RootState) => state.tags);

  const [formData, setFormData] = useState<MealPlanFormData>(defaultFormData);
  const [activeTab, setActiveTab] = useState<"details" | "meals">("details");
  const [searchTerm, setSearchTerm] = useState("");
  const [activeTagFilter, setActiveTagFilter] = useState<string | null>(null);
  const [expandedMealId, setExpandedMealId] = useState<string | null>(null);
  const [nutritionTotals, setNutritionTotals] = useState({
    totalCalories: 0,
    totalProtein: 0,
    totalCarbs: 0,
    totalFat: 0,
    totalFiber: 0,
    totalPrice: 0,
  });

  // Fetch meals and tags when component mounts
  useEffect(() => {
    dispatch(fetchMeals());
    dispatch(fetchTags());
  }, [dispatch]);

  // Initialize form data when editing a meal plan
  useEffect(() => {
    if (editMode && mealPlan) {
      setFormData({
        name: mealPlan.name,
        description: mealPlan.description,
        duration: mealPlan.duration,
        isActive: mealPlan.isActive,
        tags: mealPlan.tags,
        category: mealPlan.category || "",
        featuredImage: mealPlan.featuredImage || "",
        items: mealPlan.items,
      });
    } else {
      setFormData(defaultFormData);
    }
  }, [editMode, mealPlan, isOpen]);

  // Calculate nutrition totals when items change
  useEffect(() => {
    const calculateTotals = async () => {
      if (formData.items.length === 0) {
        setNutritionTotals({
          totalCalories: 0,
          totalProtein: 0,
          totalCarbs: 0,
          totalFat: 0,
          totalFiber: 0,
          totalPrice: 0,
        });
        return;
      }

      try {
        const result = await dispatch(
          calculateAdminMealPlanTotals(formData.items)
        ).unwrap();
        setNutritionTotals(result);
      } catch (error) {
        console.error("Failed to calculate totals:", error);
      }
    };

    calculateTotals();
  }, [formData.items, dispatch]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      const mealPlanData = {
        ...formData,
        // Ensure all tags are in the correct storage format
        tags: formData.tags.map((tag) => formatTagForStorage(tag)),
        // Include the calculated nutrition totals
        ...nutritionTotals,
        // Add required subscribedUsers property
        subscribedUsers: [],
      };

      if (editMode && mealPlan?.id) {
        // Update existing meal plan
        await dispatch(
          updateAdminMealPlan({
            id: mealPlan.id,
            ...mealPlanData,
          })
        ).unwrap();
        toast.success("Meal plan updated successfully");
      } else {
        // Create new meal plan
        await dispatch(createAdminMealPlan(mealPlanData)).unwrap();
        toast.success("Meal plan created successfully");
      }

      // Reset form
      setFormData(defaultFormData);
      setActiveTab("details");

      // If onSubmit callback is provided, call it
      if (onSubmit) {
        onSubmit();
      }

      onClose();
    } catch (error) {
      console.error("Failed to save meal plan:", error);
      toast.error(`Failed to ${editMode ? "update" : "create"} meal plan`);
    }
  };

  const handleChange = (
    e: React.ChangeEvent<
      HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement
    >
  ) => {
    const { name, value, type } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]:
        type === "number"
          ? parseInt(value, 10) || 0
          : name === "isActive"
          ? value === "true"
          : value,
    }));
  };

  const handleTagToggle = (tagName: string) => {
    setFormData((prev) => {
      if (prev.tags.includes(tagName)) {
        return { ...prev, tags: prev.tags.filter((t) => t !== tagName) };
      } else {
        return { ...prev, tags: [...prev.tags, tagName] };
      }
    });
  };

  const handleReset = () => {
    setFormData(defaultFormData);
    setActiveTab("details");
    setSearchTerm("");
    setActiveTagFilter(null);
    setExpandedMealId(null);
  };

  // Filter meals based on search term and tag filter
  const filteredMeals = meals.filter((meal) => {
    const matchesSearch =
      searchTerm === "" ||
      meal.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      meal.description.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesTag =
      activeTagFilter === null || meal.tags.includes(activeTagFilter);

    return matchesSearch && matchesTag;
  });

  // Get unique tags from meals
  const getUniqueMealTags = () => {
    const uniqueTags = new Set<string>();
    meals.forEach((meal) => {
      meal.tags.forEach((tag) => uniqueTags.add(tag));
    });
    return Array.from(uniqueTags);
  };

  // Quick add meal function - adds meal with default settings
  const handleQuickAddMeal = (meal: Meal) => {
    if (!meal.id) {
      toast.error("Invalid meal selected");
      return;
    }

    // Check if meal is already added
    const existingItem = formData.items.find((item) => item.mealId === meal.id);
    if (existingItem) {
      toast.info("Meal is already added to the plan");
      return;
    }

    const newItem: AdminMealPlanItem = {
      id: crypto.randomUUID(),
      mealId: meal.id,
      quantity: meal.baseQuantity || 300,
      dayNumbers: [1], // Default to day 1
      mealTimes: ["lunch"], // Default to lunch
      notes: "",
    };

    setFormData((prev) => ({
      ...prev,
      items: [...prev.items, newItem],
    }));

    toast.success(`${meal.name} added to meal plan`);
  };

  // Check if a meal is already selected/added
  const isMealSelected = (mealId: string) => {
    return formData.items.some((item) => item.mealId === mealId);
  };

  // Get meal details by ID
  const getMealById = (id: string): Meal | undefined => {
    return meals.find((meal) => meal.id === id);
  };

  // Remove a meal item from the meal plan
  const handleRemoveMealItem = (itemId: string) => {
    setFormData((prev) => ({
      ...prev,
      items: prev.items.filter((item) => item.id !== itemId),
    }));
    toast.success("Meal removed from plan");
  };

  return (
    <Dialog
      open={isOpen}
      onOpenChange={(open) => {
        if (!open) {
          handleReset();
        }
        onClose();
      }}
    >
      <DialogContent className="sm:max-w-[800px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl font-bold">
            <CalendarCheck className="h-5 w-5" />
            {editMode ? "Edit Meal Plan" : "Create New Meal Plan"}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="mt-4">
          <div className="flex mb-6 border-b border-gray-200">
            <button
              type="button"
              onClick={() => setActiveTab("details")}
              className={`py-2 px-4 ${
                activeTab === "details"
                  ? "text-primary-600 border-b-2 border-primary-600 font-medium"
                  : "text-gray-500 hover:text-gray-700"
              }`}
            >
              Basic Details
            </button>
            <button
              type="button"
              onClick={() => setActiveTab("meals")}
              className={`py-2 px-4 ${
                activeTab === "meals"
                  ? "text-primary-600 border-b-2 border-primary-600 font-medium"
                  : "text-gray-500 hover:text-gray-700"
              }`}
            >
              Meal Selection
            </button>
          </div>

          {activeTab === "details" && (
            <div className="space-y-4">
              <div className="grid grid-cols-3 gap-4">
                <div className="col-span-2">
                  <div className="space-y-4">
                    <div>
                      <label className="label" htmlFor="name">
                        Meal Plan Name
                      </label>
                      <input
                        type="text"
                        id="name"
                        name="name"
                        className="input"
                        value={formData.name}
                        onChange={handleChange}
                        placeholder="Enter meal plan name"
                        required
                      />
                    </div>

                    <div>
                      <label className="label" htmlFor="description">
                        Description
                      </label>
                      <textarea
                        id="description"
                        name="description"
                        className="input min-h-[100px]"
                        value={formData.description}
                        onChange={handleChange}
                        placeholder="Enter meal plan description"
                        required
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="label" htmlFor="duration">
                          Duration (days)
                        </label>
                        <input
                          type="number"
                          id="duration"
                          name="duration"
                          className="input"
                          value={formData.duration}
                          onChange={handleChange}
                          min="1"
                          max="30"
                          required
                        />
                      </div>

                      <div>
                        <label className="label" htmlFor="category">
                          Category (optional)
                        </label>
                        <input
                          type="text"
                          id="category"
                          name="category"
                          className="input"
                          value={formData.category}
                          onChange={handleChange}
                          placeholder="E.g. Keto, Muscle Building"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="label" htmlFor="isActive">
                        Status
                      </label>
                      <select
                        id="isActive"
                        name="isActive"
                        className="input"
                        value={formData.isActive.toString()}
                        onChange={handleChange}
                      >
                        <option value="true">Active</option>
                        <option value="false">Inactive</option>
                      </select>
                      <p className="text-sm text-gray-500 mt-1">
                        Active meal plans are visible to all users.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="col-span-1">
                  <label className="label mb-2">
                    Featured Image (Optional)
                  </label>

                  <ImageUpload
                    value={formData.featuredImage}
                    onChange={(url) =>
                      setFormData((prev) => ({ ...prev, featuredImage: url }))
                    }
                    onRemove={() =>
                      setFormData((prev) => ({ ...prev, featuredImage: "" }))
                    }
                    folder="meal-plans"
                    aspectRatio="4/3"
                    maxSizeInMB={5}
                    disabled={loading}
                    className="mb-4"
                  />

                  {/* Nutrition summary */}
                  <div className="mt-4 p-4 bg-gray-50 rounded-lg">
                    <h3 className="text-sm font-medium text-gray-700 mb-3">
                      Nutrition Summary
                    </h3>
                    <div className="grid grid-cols-2 gap-2">
                      <div className="bg-white p-2 rounded border border-gray-200 text-center">
                        <div className="text-xs text-gray-500">Calories</div>
                        <div className="text-lg font-bold text-primary-600">
                          {nutritionTotals.totalCalories.toFixed(1)}
                        </div>
                      </div>
                      <div className="bg-white p-2 rounded border border-gray-200 text-center">
                        <div className="text-xs text-gray-500">Protein</div>
                        <div className="text-lg font-bold text-primary-600">
                          {nutritionTotals.totalProtein.toFixed(1)}g
                        </div>
                      </div>
                      <div className="bg-white p-2 rounded border border-gray-200 text-center">
                        <div className="text-xs text-gray-500">Carbs</div>
                        <div className="text-lg font-bold text-primary-600">
                          {nutritionTotals.totalCarbs.toFixed(1)}g
                        </div>
                      </div>
                      <div className="bg-white p-2 rounded border border-gray-200 text-center">
                        <div className="text-xs text-gray-500">Fat</div>
                        <div className="text-lg font-bold text-primary-600">
                          {nutritionTotals.totalFat.toFixed(1)}g
                        </div>
                      </div>
                      <div className="bg-white p-2 rounded border border-gray-200 text-center">
                        <div className="text-xs text-gray-500">Fiber</div>
                        <div className="text-lg font-bold text-primary-600">
                          {nutritionTotals.totalFiber.toFixed(1)}g
                        </div>
                      </div>
                      <div className="bg-white p-2 rounded border border-gray-200 text-center">
                        <div className="text-xs text-gray-500">Total Price</div>
                        <div className="text-lg font-bold text-primary-600">
                          ₹{nutritionTotals.totalPrice.toFixed(2)}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-4">
                <label className="label mb-2">Tags</label>
                {tags.length === 0 ? (
                  <p className="text-sm text-gray-500 italic mb-2">
                    No tags available. Please add tags in the Tag Management
                    section.
                  </p>
                ) : (
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
                    {tags.map((tag) => {
                      const isSelected = formData.tags.includes(tag.name);
                      return (
                        <div
                          key={tag.id}
                          onClick={() => handleTagToggle(tag.name)}
                          className={`
                            flex items-center justify-between px-3 py-2 rounded-md cursor-pointer transition-colors
                            ${
                              isSelected
                                ? "bg-primary-500 text-white"
                                : "bg-gray-100 hover:bg-gray-200 text-gray-800"
                            }
                          `}
                          style={
                            !isSelected && tag.color
                              ? { borderLeft: `3px solid ${tag.color}` }
                              : {}
                          }
                        >
                          <span className="text-sm">
                            {formatTagForDisplay(tag.name)}
                          </span>
                          {isSelected && <Check className="h-4 w-4" />}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          )}

          {activeTab === "meals" && (
            <div className="space-y-4">
              {/* Status summary */}
              <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg mb-4">
                <h3 className="font-medium text-blue-800 mb-1">
                  <Info className="inline-block h-4 w-4 mr-1 mb-0.5" />
                  Meal Selection
                </h3>
                <p className="text-sm text-blue-700">
                  Select meals to include in this plan. You can add the same
                  meal multiple times with different configurations.
                </p>
                <div className="mt-2 grid grid-cols-2 gap-2 text-sm text-blue-700">
                  <div>Plan duration: {formData.duration} days</div>
                  <div>Current meals: {formData.items.length}</div>
                </div>
              </div>

              {/* Selected meals list */}
              {formData.items.length > 0 && (
                <div className="mb-6">
                  <h3 className="font-medium text-gray-800 mb-2">
                    Selected Meals
                  </h3>
                  <div className="space-y-2 mb-6">
                    {formData.items.map((item) => {
                      const meal = getMealById(item.mealId);
                      return (
                        <div
                          key={item.id}
                          className="flex items-center justify-between p-3 bg-gray-50 rounded-lg border border-gray-200"
                        >
                          <div className="flex items-center gap-3">
                            <div className="h-12 w-12 bg-gray-200 rounded-md overflow-hidden flex-shrink-0">
                              {meal?.image ? (
                                <img
                                  src={meal.image}
                                  alt={meal?.name}
                                  className="h-full w-full object-cover"
                                />
                              ) : (
                                <Package className="h-full w-full p-2 text-gray-400" />
                              )}
                            </div>
                            <div>
                              <p className="font-medium text-gray-800">
                                {meal?.name || "Unknown Meal"}
                              </p>
                              <p className="text-sm text-gray-500">
                                {item.quantity}
                                {meal?.unit || "g"} • Days:{" "}
                                {item.dayNumbers.join(", ")} • Meals:{" "}
                                {item.mealTimes
                                  .map(
                                    (t) =>
                                      t.charAt(0).toUpperCase() + t.slice(1)
                                  )
                                  .join(", ")}
                              </p>
                            </div>
                          </div>
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => handleRemoveMealItem(item.id!)}
                          >
                            <X className="h-4 w-4" />
                          </Button>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Meal selection section */}
              <div className="border border-gray-200 rounded-lg p-4">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="font-medium text-gray-800">
                    Add Meals to Plan
                  </h3>
                  <div className="text-sm text-gray-500">
                    Click any meal below to add it instantly
                  </div>
                </div>

                {/* Quick tip */}
                <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg mb-4">
                  <p className="text-sm text-blue-700">
                    💡 <strong>Quick Add:</strong> Simply click on any meal card
                    to add it to your plan with default settings (300g, Day 1,
                    Lunch time). You can modify these settings later by editing
                    the selected meals above.
                  </p>
                </div>

                {/* Meal selection */}
                <div>
                  <h4 className="font-medium text-gray-800 mb-2">
                    Available Meals
                  </h4>

                  {/* Search and filters */}
                  <div className="flex flex-col md:flex-row gap-2 mb-4">
                    <div className="relative flex-grow">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                      <input
                        type="text"
                        placeholder="Search meals..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-10 pr-4 py-2 w-full rounded-lg border border-gray-200 focus:ring-2 focus:ring-primary-300 focus:border-primary-500 outline-none"
                      />
                      {searchTerm && (
                        <button
                          type="button"
                          onClick={() => setSearchTerm("")}
                          className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                        >
                          <X className="h-4 w-4" />
                        </button>
                      )}
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="text-sm text-gray-500">
                        <Filter className="h-4 w-4 inline mr-1" />
                        Filter:
                      </span>

                      {activeTagFilter && (
                        <button
                          type="button"
                          onClick={() => setActiveTagFilter(null)}
                          className="px-2 py-1 text-xs bg-primary-50 text-primary-700 rounded-full flex items-center"
                        >
                          <X className="h-3 w-3 mr-1" />
                          Clear
                        </button>
                      )}

                      <div className="flex-grow overflow-x-auto whitespace-nowrap py-1 flex gap-2">
                        {getUniqueMealTags().map((tag) => (
                          <button
                            key={tag}
                            type="button"
                            onClick={() =>
                              setActiveTagFilter(
                                activeTagFilter === tag ? null : tag
                              )
                            }
                            className={`px-2 py-1 text-xs rounded-full flex items-center whitespace-nowrap
                              ${
                                activeTagFilter === tag
                                  ? "bg-primary-500 text-white"
                                  : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                              }
                            `}
                          >
                            {formatTagForDisplay(tag)}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Meals grid */}
                  {mealsLoading ? (
                    <div className="flex justify-center py-8">
                      <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary-500"></div>
                    </div>
                  ) : filteredMeals.length === 0 ? (
                    <div className="text-center py-8 text-gray-500">
                      No meals found matching your criteria
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-h-[400px] overflow-y-auto p-1">
                      {filteredMeals.map((meal) => {
                        const isSelected = isMealSelected(meal.id!);
                        return (
                          <div
                            key={meal.id}
                            onClick={() => {
                              if (meal.id) {
                                if (isSelected) {
                                  // If already selected, show info instead of adding again
                                  toast.info("Meal is already in the plan");
                                } else {
                                  // Quick add the meal
                                  handleQuickAddMeal(meal);
                                }
                                // Toggle expanded view for meal details
                                setExpandedMealId(
                                  expandedMealId === meal.id ? null : meal.id
                                );
                              }
                            }}
                            className={`
                              cursor-pointer border rounded-lg overflow-hidden transition-all relative
                              ${
                                isSelected
                                  ? "border-green-500 bg-green-50 shadow-md"
                                  : "border-gray-200 hover:border-gray-300 hover:shadow-sm"
                              }
                            `}
                          >
                            {/* Green tick indicator for selected meals */}
                            {isSelected && (
                              <div className="absolute top-2 right-2 z-10">
                                <div className="bg-green-500 text-white rounded-full h-6 w-6 flex items-center justify-center shadow-md">
                                  <Check className="h-4 w-4" />
                                </div>
                              </div>
                            )}

                            <div className="flex">
                              <div className="h-24 w-24 bg-gray-200 flex-shrink-0">
                                {meal.image ? (
                                  <img
                                    src={meal.image}
                                    alt={meal.name}
                                    className="h-full w-full object-cover"
                                  />
                                ) : (
                                  <div className="h-full w-full flex items-center justify-center">
                                    <Package className="h-8 w-8 text-gray-400" />
                                  </div>
                                )}
                              </div>
                              <div className="p-3 flex-grow">
                                <div className="flex justify-between items-start pr-8">
                                  <h5
                                    className={`font-medium mb-1 ${
                                      isSelected
                                        ? "text-green-800"
                                        : "text-gray-800"
                                    }`}
                                  >
                                    {meal.name}
                                  </h5>
                                </div>
                                <p
                                  className={`text-sm mb-1 truncate ${
                                    isSelected
                                      ? "text-green-600"
                                      : "text-gray-500"
                                  }`}
                                >
                                  {meal.description}
                                </p>
                                <div className="flex justify-between items-center text-sm">
                                  <span
                                    className={`font-medium ${
                                      isSelected
                                        ? "text-green-900"
                                        : "text-gray-900"
                                    }`}
                                  >
                                    ₹{meal.price}
                                  </span>
                                  <span
                                    className={
                                      isSelected
                                        ? "text-green-600"
                                        : "text-gray-500"
                                    }
                                  >
                                    {meal.baseQuantity}g
                                  </span>
                                </div>
                              </div>
                            </div>

                            <AnimatePresence>
                              {expandedMealId === meal.id && (
                                <motion.div
                                  initial={{ height: 0, opacity: 0 }}
                                  animate={{ height: "auto", opacity: 1 }}
                                  exit={{ height: 0, opacity: 0 }}
                                  transition={{ duration: 0.2 }}
                                  className="overflow-hidden"
                                >
                                  <div
                                    className={`p-3 pt-0 border-t ${
                                      isSelected
                                        ? "border-green-200 bg-green-25"
                                        : "border-gray-100"
                                    }`}
                                  >
                                    <div className="grid grid-cols-5 gap-1 mb-2">
                                      <div className="text-xs text-center">
                                        <span
                                          className={
                                            isSelected
                                              ? "text-green-600"
                                              : "text-gray-500"
                                          }
                                        >
                                          Cal
                                        </span>
                                        <p
                                          className={`font-medium ${
                                            isSelected
                                              ? "text-green-800"
                                              : "text-gray-800"
                                          }`}
                                        >
                                          {meal.calories.toFixed(1)}
                                        </p>
                                      </div>
                                      <div className="text-xs text-center">
                                        <span
                                          className={
                                            isSelected
                                              ? "text-green-600"
                                              : "text-gray-500"
                                          }
                                        >
                                          Pro
                                        </span>
                                        <p
                                          className={`font-medium ${
                                            isSelected
                                              ? "text-green-800"
                                              : "text-gray-800"
                                          }`}
                                        >
                                          {meal.protein.toFixed(1)}g
                                        </p>
                                      </div>
                                      <div className="text-xs text-center">
                                        <span
                                          className={
                                            isSelected
                                              ? "text-green-600"
                                              : "text-gray-500"
                                          }
                                        >
                                          Carb
                                        </span>
                                        <p
                                          className={`font-medium ${
                                            isSelected
                                              ? "text-green-800"
                                              : "text-gray-800"
                                          }`}
                                        >
                                          {meal.carbs.toFixed(1)}g
                                        </p>
                                      </div>
                                      <div className="text-xs text-center">
                                        <span
                                          className={
                                            isSelected
                                              ? "text-green-600"
                                              : "text-gray-500"
                                          }
                                        >
                                          Fat
                                        </span>
                                        <p
                                          className={`font-medium ${
                                            isSelected
                                              ? "text-green-800"
                                              : "text-gray-800"
                                          }`}
                                        >
                                          {meal.fat.toFixed(1)}g
                                        </p>
                                      </div>
                                      <div className="text-xs text-center">
                                        <span
                                          className={
                                            isSelected
                                              ? "text-green-600"
                                              : "text-gray-500"
                                          }
                                        >
                                          Fiber
                                        </span>
                                        <p
                                          className={`font-medium ${
                                            isSelected
                                              ? "text-green-800"
                                              : "text-gray-800"
                                          }`}
                                        >
                                          {meal.fiber.toFixed(1)}g
                                        </p>
                                      </div>
                                    </div>

                                    <div className="flex flex-wrap gap-1">
                                      {meal.tags.map((tag, idx) => (
                                        <span
                                          key={idx}
                                          className={`px-1.5 py-0.5 text-xs rounded-full ${
                                            isSelected
                                              ? "bg-green-100 text-green-700"
                                              : "bg-gray-100 text-gray-700"
                                          }`}
                                        >
                                          {formatTagForDisplay(tag)}
                                        </span>
                                      ))}
                                    </div>

                                    {/* Show current configuration if meal is selected */}
                                    {isSelected && (
                                      <div className="mt-2 p-2 bg-green-100 rounded text-xs">
                                        <div className="font-medium text-green-800 mb-1">
                                          Added with defaults:
                                        </div>
                                        <div className="text-green-700">
                                          • Quantity: {meal.baseQuantity || 300}
                                          g<br />
                                          • Day: 1<br />• Meal time: Lunch
                                        </div>
                                      </div>
                                    )}
                                  </div>
                                </motion.div>
                              )}
                            </AnimatePresence>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          <DialogFooter className="mt-8 pt-4 border-t border-gray-100">
            <Button
              variant="secondary"
              onClick={() => {
                handleReset();
                onClose();
              }}
              type="button"
            >
              Cancel
            </Button>
            <Button variant="accent" type="submit" disabled={loading}>
              {loading
                ? editMode
                  ? "Updating..."
                  : "Creating..."
                : editMode
                ? "Update Plan"
                : "Create Plan"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
