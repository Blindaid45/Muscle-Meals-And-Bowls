import { useState, useEffect, useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/Button";
import { UtensilsCrossed, Check, X, Upload, Trash2 } from "lucide-react";
import { createMeal } from "@/store/slices/mealSlice";
import { fetchTags } from "@/store/slices/tagSlice";
import { AppDispatch, RootState } from "@/store/store";
import { toast } from "sonner";
import { formatTagForDisplay, formatTagForStorage } from "@/utils/tagUtils";
import { uploadFile } from "@/lib/storageService";
import ImageSlider from "@/components/ui/ImageSlider";
import { MEAL_UNITS, DEFAULT_UNIT } from "@/constants/units";

interface AddMealDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit?: () => void;
}

interface MealFormData {
  name: string;
  description: string;
  price: number;
  baseQuantity: number;
  unit: string;
  protein: number;
  carbs: number;
  fat: number;
  fiber: number;
  calories: number;
  tags: string[];
  images: { url: string; path: string }[];
}

interface UploadingImage {
  id: string;
  file: File;
  progress: number;
  error?: string;
}

const defaultFormData: MealFormData = {
  name: "",
  description: "",
  price: 0,
  baseQuantity: 300,
  unit: DEFAULT_UNIT,
  protein: 0,
  carbs: 0,
  fat: 0,
  fiber: 0,
  calories: 0,
  tags: [],
  images: [],
};

export default function AddMealDialog({
  isOpen,
  onClose,
  onSubmit,
}: AddMealDialogProps) {
  const dispatch = useDispatch<AppDispatch>();
  const { loading } = useSelector((state: RootState) => state.meals);
  const { tags } = useSelector((state: RootState) => state.tags);
  const [formData, setFormData] = useState<MealFormData>(defaultFormData);
  const [activeTab, setActiveTab] = useState<"details" | "nutrition">(
    "details"
  );
  const [uploadingImages, setUploadingImages] = useState<UploadingImage[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Fetch tags when component mounts
  useEffect(() => {
    dispatch(fetchTags());
  }, [dispatch]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Check if there are still images being uploaded
    if (uploadingImages.length > 0) {
      toast.error("Please wait for all images to finish uploading");
      return;
    }

    // Ensure at least one image is uploaded
    if (formData.images.length === 0) {
      toast.error("Please upload at least one image");
      return;
    }

    try {
      // Clone the form data and ensure tag names are in storage format
      const mealData = {
        ...formData,
        // Use the first image URL as the main image (for backward compatibility)
        image: formData.images[0].url,
        // Ensure all tags are in the correct storage format (lowercase with underscores)
        tags: formData.tags.map((tag) => formatTagForStorage(tag)),
      };

      // Dispatch the action to create a new meal
      await dispatch(createMeal(mealData)).unwrap();
      toast.success("Meal added successfully");

      // Reset form
      setFormData(defaultFormData);
      setUploadingImages([]);

      // If onSubmit callback is provided, call it
      if (onSubmit) {
        onSubmit();
      }

      onClose();
    } catch (error) {
      console.error("Failed to add meal:", error);
      toast.error("Failed to add meal");
    }
  };

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]:
        name === "price" ||
        name === "baseQuantity" ||
        name === "protein" ||
        name === "carbs" ||
        name === "fat" ||
        name === "fiber" ||
        name === "calories"
          ? parseFloat(value) || 0
          : value,
    }));
  };

  const handleTagToggle = (tagName: string) => {
    setFormData((prev) => {
      if (prev.tags.includes(tagName)) {
        return { ...prev, tags: prev.tags.filter((t) => t !== tagName) };
      } else {
        return { ...prev, tags: [...prev.tags, tagName] };
      }
    });
  };

  const handleReset = () => {
    setFormData(defaultFormData);
    setUploadingImages([]);
    setActiveTab("details");
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    // Process each file
    Array.from(files).forEach((file) => {
      // Validate file type
      if (!file.type.startsWith("image/")) {
        toast.error(`File ${file.name} is not an image`);
        return;
      }

      // Validate file size (max 5MB)
      if (file.size > 5 * 1024 * 1024) {
        toast.error(`File ${file.name} exceeds 5MB size limit`);
        return;
      }

      // Add file to uploading images
      const uploadId =
        Date.now().toString() + Math.random().toString(36).substring(2);
      setUploadingImages((prev) => [
        ...prev,
        {
          id: uploadId,
          file,
          progress: 0,
        },
      ]);

      // Start upload process
      uploadImage(file, uploadId);
    });

    // Clear the file input
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const uploadImage = async (file: File, uploadId: string) => {
    try {
      // Generate a unique filename
      const fileExtension = file.name.split(".").pop();
      const fileName = `meal_${Date.now()}_${Math.random()
        .toString(36)
        .substring(2)}.${fileExtension}`;

      // Upload to Firebase Storage
      const result = await uploadFile({
        folder: "meal_images",
        fileName,
        file,
      });

      // Add the uploaded image to form data
      setFormData((prev) => ({
        ...prev,
        images: [...prev.images, { url: result.url, path: result.path }],
      }));

      // Remove from uploading images
      setUploadingImages((prev) => prev.filter((img) => img.id !== uploadId));

      toast.success(`Image ${file.name} uploaded successfully`);
    } catch (error) {
      console.error("Error uploading image:", error);

      // Update uploading images with error
      setUploadingImages((prev) =>
        prev.map((img) =>
          img.id === uploadId ? { ...img, error: "Upload failed" } : img
        )
      );

      toast.error(`Failed to upload image ${file.name}`);
    }
  };

  const handleRemoveImage = (index: number) => {
    setFormData((prev) => ({
      ...prev,
      images: prev.images.filter((_, i) => i !== index),
    }));
  };

  const handleRemoveUploadingImage = (id: string) => {
    setUploadingImages((prev) => prev.filter((img) => img.id !== id));
  };

  const triggerFileInput = () => {
    fileInputRef.current?.click();
  };

  return (
    <Dialog
      open={isOpen}
      onOpenChange={(open) => {
        if (!open) {
          handleReset();
        }
        onClose();
      }}
    >
      <DialogContent className="sm:max-w-[650px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl font-bold">
            <UtensilsCrossed className="h-5 w-5" />
            Add New Meal
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="mt-4">
          <div className="flex mb-6 border-b border-gray-200">
            <button
              type="button"
              onClick={() => setActiveTab("details")}
              className={`py-2 px-4 ${
                activeTab === "details"
                  ? "text-primary-600 border-b-2 border-primary-600 font-medium"
                  : "text-gray-500 hover:text-gray-700"
              }`}
            >
              Basic Details
            </button>
            <button
              type="button"
              onClick={() => setActiveTab("nutrition")}
              className={`py-2 px-4 ${
                activeTab === "nutrition"
                  ? "text-primary-600 border-b-2 border-primary-600 font-medium"
                  : "text-gray-500 hover:text-gray-700"
              }`}
            >
              Nutrition Info
            </button>
          </div>

          {activeTab === "details" && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 gap-4">
                <div>
                  <label className="label" htmlFor="name">
                    Meal Name
                  </label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    className="input"
                    value={formData.name}
                    onChange={handleChange}
                    placeholder="Enter meal name"
                    required
                  />
                </div>

                <div>
                  <label className="label" htmlFor="description">
                    Description
                  </label>
                  <textarea
                    id="description"
                    name="description"
                    className="input min-h-[100px]"
                    value={formData.description}
                    onChange={handleChange}
                    placeholder="Enter meal description"
                    required
                  />
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <label className="label" htmlFor="price">
                      Price (₹)
                    </label>
                    <input
                      type="number"
                      id="price"
                      name="price"
                      className="input"
                      value={formData.price}
                      onChange={handleChange}
                      min="0"
                      step="0.01"
                      required
                    />
                  </div>

                  <div>
                    <label className="label" htmlFor="baseQuantity">
                      Base Quantity
                    </label>
                    <input
                      type="number"
                      id="baseQuantity"
                      name="baseQuantity"
                      className="input"
                      value={formData.baseQuantity}
                      onChange={handleChange}
                      min="1"
                      step="1"
                      required
                    />
                  </div>

                  <div>
                    <label className="label" htmlFor="unit">
                      Unit
                    </label>
                    <select
                      id="unit"
                      name="unit"
                      className="input"
                      value={formData.unit}
                      onChange={handleChange}
                      required
                    >
                      {MEAL_UNITS.map((unitOption) => (
                        <option key={unitOption.value} value={unitOption.value}>
                          {unitOption.label}
                        </option>
                      ))}
                    </select>
                    <p className="text-xs text-gray-500 mt-1">
                      {
                        MEAL_UNITS.find((u) => u.value === formData.unit)
                          ?.description
                      }
                    </p>
                  </div>
                </div>

                {/* Images Section */}
                <div>
                  <label className="label mb-2">Images</label>

                  {/* Image slider for preview if there are images */}
                  {formData.images.length > 0 && (
                    <div className="mb-4">
                      <ImageSlider
                        images={formData.images.map((img) => img.url)}
                        aspectRatio="landscape"
                      />
                    </div>
                  )}

                  {/* Upload area */}
                  <div
                    onClick={triggerFileInput}
                    className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center cursor-pointer hover:bg-gray-50 transition-colors"
                  >
                    <Upload className="h-8 w-8 mx-auto text-gray-400 mb-2" />
                    <p className="text-sm text-gray-500">
                      Click to upload images
                    </p>
                    <p className="text-xs text-gray-400 mt-1">
                      PNG, JPG, WEBP up to 5MB
                    </p>
                    <input
                      type="file"
                      ref={fileInputRef}
                      className="hidden"
                      accept="image/*"
                      multiple
                      onChange={handleFileChange}
                    />
                  </div>
                </div>

                {/* Image gallery */}
                {(formData.images.length > 0 || uploadingImages.length > 0) && (
                  <div>
                    <label className="label mb-2">Image Gallery</label>

                    <div className="grid grid-cols-4 gap-3">
                      {/* Uploaded images */}
                      {formData.images.map((image, index) => (
                        <div
                          key={index}
                          className="relative group border rounded-md overflow-hidden aspect-square"
                        >
                          <img
                            src={image.url}
                            alt={`Meal image ${index + 1}`}
                            className="w-full h-full object-cover"
                          />
                          <button
                            type="button"
                            onClick={() => handleRemoveImage(index)}
                            className="absolute top-1 right-1 bg-red-500 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      ))}

                      {/* Images being uploaded */}
                      {uploadingImages.map((image) => (
                        <div
                          key={image.id}
                          className="relative border rounded-md overflow-hidden aspect-square bg-gray-100 flex items-center justify-center"
                        >
                          <div className="absolute inset-0 flex items-center justify-center">
                            <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin"></div>
                          </div>
                          <div className="absolute bottom-0 left-0 right-0 bg-white bg-opacity-80 py-1 px-2 text-xs text-center">
                            {image.error ? (
                              <span className="text-red-500">
                                {image.error}
                              </span>
                            ) : (
                              <span>Uploading...</span>
                            )}
                          </div>
                          <button
                            type="button"
                            onClick={() => handleRemoveUploadingImage(image.id)}
                            className="absolute top-1 right-1 bg-red-500 text-white rounded-full p-1"
                          >
                            <X className="h-4 w-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                <div>
                  <label className="label mb-2">Tags</label>
                  {tags.length === 0 ? (
                    <p className="text-sm text-gray-500 italic mb-2">
                      No tags available. Please add tags in the Tag Management
                      section.
                    </p>
                  ) : (
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
                      {tags.map((tag) => {
                        const isSelected = formData.tags.includes(tag.name);
                        return (
                          <div
                            key={tag.id}
                            onClick={() => handleTagToggle(tag.name)}
                            className={`
                              flex items-center justify-between px-3 py-2 rounded-md cursor-pointer transition-colors
                              ${
                                isSelected
                                  ? "bg-primary-500 text-white"
                                  : "bg-gray-100 hover:bg-gray-200 text-gray-800"
                              }
                            `}
                            style={
                              !isSelected && tag.color
                                ? { borderLeft: `3px solid ${tag.color}` }
                                : {}
                            }
                          >
                            <span className="text-sm">
                              {formatTagForDisplay(tag.name)}
                            </span>
                            {isSelected && <Check className="h-4 w-4" />}
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {activeTab === "nutrition" && (
            <div className="space-y-4">
              <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg mb-4">
                <h3 className="font-medium text-yellow-800 mb-1">
                  Nutrition Information
                </h3>
                <p className="text-sm text-yellow-700">
                  Please provide accurate nutrition values per serving (based on
                  the base quantity).
                </p>
              </div>

              <div className="grid grid-cols-2 gap-x-4 gap-y-6">
                <div>
                  <label className="label" htmlFor="protein">
                    Protein (g)
                  </label>
                  <input
                    type="number"
                    id="protein"
                    name="protein"
                    className="input"
                    value={formData.protein}
                    onChange={handleChange}
                    min="0"
                    required
                  />
                </div>

                <div>
                  <label className="label" htmlFor="carbs">
                    Carbs (g)
                  </label>
                  <input
                    type="number"
                    id="carbs"
                    name="carbs"
                    className="input"
                    value={formData.carbs}
                    onChange={handleChange}
                    min="0"
                    required
                  />
                </div>

                <div>
                  <label className="label" htmlFor="fat">
                    Fat (g)
                  </label>
                  <input
                    type="number"
                    id="fat"
                    name="fat"
                    className="input"
                    value={formData.fat}
                    onChange={handleChange}
                    min="0"
                    required
                  />
                </div>

                <div>
                  <label className="label" htmlFor="fiber">
                    Fiber (g)
                  </label>
                  <input
                    type="number"
                    id="fiber"
                    name="fiber"
                    className="input"
                    value={formData.fiber}
                    onChange={handleChange}
                    min="0"
                    required
                  />
                </div>

                <div>
                  <label className="label" htmlFor="calories">
                    Calories (kcal)
                  </label>
                  <input
                    type="number"
                    id="calories"
                    name="calories"
                    className="input"
                    value={formData.calories}
                    onChange={handleChange}
                    min="0"
                    required
                  />
                </div>
              </div>

              <div className="mt-6 p-4 bg-gray-50 rounded-lg">
                <h3 className="text-sm font-medium text-gray-700 mb-3">
                  Calculated Nutrition Summary
                </h3>
                <div className="grid grid-cols-5 gap-2">
                  <div className="bg-white p-3 rounded border border-gray-200 text-center">
                    <div className="text-xs text-gray-500">Protein</div>
                    <div className="text-lg font-bold text-primary-600">
                      {formData.protein}g
                    </div>
                  </div>
                  <div className="bg-white p-3 rounded border border-gray-200 text-center">
                    <div className="text-xs text-gray-500">Carbs</div>
                    <div className="text-lg font-bold text-primary-600">
                      {formData.carbs}g
                    </div>
                  </div>
                  <div className="bg-white p-3 rounded border border-gray-200 text-center">
                    <div className="text-xs text-gray-500">Fat</div>
                    <div className="text-lg font-bold text-primary-600">
                      {formData.fat}g
                    </div>
                  </div>
                  <div className="bg-white p-3 rounded border border-gray-200 text-center">
                    <div className="text-xs text-gray-500">Fiber</div>
                    <div className="text-lg font-bold text-primary-600">
                      {formData.fiber}g
                    </div>
                  </div>
                  <div className="bg-white p-3 rounded border border-gray-200 text-center">
                    <div className="text-xs text-gray-500">Calories</div>
                    <div className="text-lg font-bold text-primary-600">
                      {formData.calories}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          <DialogFooter className="mt-8 pt-4 border-t border-gray-100">
            <Button
              variant="secondary"
              onClick={() => {
                handleReset();
                onClose();
              }}
              type="button"
            >
              Cancel
            </Button>
            <Button
              variant="accent"
              type="submit"
              disabled={loading || uploadingImages.length > 0}
            >
              {loading
                ? "Adding..."
                : uploadingImages.length > 0
                ? "Uploading..."
                : "Add Meal"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
