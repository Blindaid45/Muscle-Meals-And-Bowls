import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { AppDispatch, RootState } from "@/store/store";
import {
  fetchAllAdminMealPlans,
  updateAdminMealPlan,
  deleteAdminMealPlan,
  AdminMealPlan,
} from "@/store/slices/adminMealPlanSlice";
import { fetchMeals } from "@/store/slices/mealSlice";
import { Button } from "@/components/ui/Button";
import {
  Plus,
  Edit,
  Trash2,
  Calendar,
  PackageOpen,
  Users,
  ChevronRight,
  Search,
  X,
  AlertTriangle,
  Sparkles,
  ToggleLeft,
  ToggleRight,
  Tag,
  Filter,
} from "lucide-react";
import { toast } from "sonner";
import { motion, AnimatePresence } from "framer-motion";
import { formatTagForDisplay } from "@/utils/tagUtils";
import AdminMealPlanDialog from "./AdminMealPlanDialog";

export default function AdminMealPlanManagement() {
  const dispatch = useDispatch<AppDispatch>();
  const { adminMealPlans, loading } = useSelector(
    (state: RootState) => state.adminMealPlans
  );

  const { meals } = useSelector((state: RootState) => state.meals);

  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [selectedMealPlan, setSelectedMealPlan] =
    useState<AdminMealPlan | null>(null);
  const [expandedMealPlanId, setExpandedMealPlanId] = useState<string | null>(
    null
  );
  const [searchTerm, setSearchTerm] = useState("");
  const [activeFilter, setActiveFilter] = useState<string | null>(null);
  const [filterActive, setFilterActive] = useState<boolean | null>(null);

  useEffect(() => {
    dispatch(fetchAllAdminMealPlans());
    dispatch(fetchMeals());
  }, [dispatch]);

  const handleAddMealPlan = () => {
    setIsAddDialogOpen(true);
  };

  const handleEditMealPlan = (mealPlan: AdminMealPlan) => {
    setSelectedMealPlan(mealPlan);
    setIsEditDialogOpen(true);
  };

  const handleDeleteMealPlan = async (id: string) => {
    if (window.confirm("Are you sure you want to delete this meal plan?")) {
      try {
        await dispatch(deleteAdminMealPlan(id)).unwrap();
        toast.success("Meal plan deleted successfully");
      } catch (error) {
        console.error("Failed to delete meal plan:", error);
        toast.error("Failed to delete meal plan");
      }
    }
  };

  const toggleMealPlanActive = async (mealPlan: AdminMealPlan) => {
    try {
      await dispatch(
        updateAdminMealPlan({
          id: mealPlan.id!,
          isActive: !mealPlan.isActive,
        })
      ).unwrap();
      toast.success(
        `Meal plan ${
          mealPlan.isActive ? "deactivated" : "activated"
        } successfully`
      );
    } catch (error) {
      console.error("Failed to update meal plan status:", error);
      toast.error("Failed to update meal plan status");
    }
  };

  const toggleExpandMealPlan = (id: string) => {
    setExpandedMealPlanId(expandedMealPlanId === id ? null : id);
  };

  // Get unique tags across all meal plans
  const getUsedTags = () => {
    const usedTagNames = new Set<string>();
    adminMealPlans.forEach((mealPlan) => {
      mealPlan.tags.forEach((tag) => usedTagNames.add(tag));
    });
    return Array.from(usedTagNames);
  };

  // Filter meal plans based on search term, active filter, and active status
  const filteredMealPlans = adminMealPlans.filter((mealPlan) => {
    const matchesSearch =
      mealPlan.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      mealPlan.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesTag = activeFilter
      ? mealPlan.tags.includes(activeFilter)
      : true;
    const matchesActive =
      filterActive !== null ? mealPlan.isActive === filterActive : true;
    return matchesSearch && matchesTag && matchesActive;
  });

  // Get meal information for a meal plan item
  const getMealInfo = (mealId: string) => {
    return meals.find((meal) => meal.id === mealId);
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
      {/* Header with Search and Filters */}
      <div className="p-6 border-b border-gray-100">
        <div className="flex flex-col sm:flex-row gap-4 justify-between items-center mb-4">
          <div className="relative w-full sm:w-96">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <input
              type="text"
              placeholder="Search meal plans..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-4 py-2 w-full rounded-lg border border-gray-200 focus:ring-2 focus:ring-primary-300 focus:border-primary-500 outline-none"
            />
            {searchTerm && (
              <button
                onClick={() => setSearchTerm("")}
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
              >
                <X className="h-4 w-4" />
              </button>
            )}
          </div>

          <Button
            onClick={handleAddMealPlan}
            variant="accent"
            className="whitespace-nowrap"
          >
            <Plus className="h-4 w-4 mr-2" />
            Add New Meal Plan
          </Button>
        </div>

        {/* Filters */}
        <div className="flex flex-wrap gap-2 mt-4">
          <div className="flex items-center mr-2">
            <Filter className="h-4 w-4 mr-1 text-gray-500" />
            <span className="text-sm text-gray-500">Filter:</span>
          </div>

          {/* Reset filters button */}
          {(activeFilter || filterActive !== null) && (
            <button
              onClick={() => {
                setActiveFilter(null);
                setFilterActive(null);
              }}
              className="px-2 py-1 text-xs bg-primary-50 text-primary-700 rounded-full flex items-center"
            >
              <X className="h-3 w-3 mr-1" />
              Clear All
            </button>
          )}

          {/* Active status filter */}
          <button
            onClick={() => setFilterActive(filterActive === true ? null : true)}
            className={`px-2 py-1 text-xs rounded-full flex items-center transition-colors ${
              filterActive === true
                ? "bg-green-500 text-white"
                : "bg-gray-100 text-gray-700 hover:bg-gray-200"
            }`}
          >
            <ToggleRight className="h-3 w-3 mr-1" />
            <span>Active</span>
          </button>

          <button
            onClick={() =>
              setFilterActive(filterActive === false ? null : false)
            }
            className={`px-2 py-1 text-xs rounded-full flex items-center transition-colors ${
              filterActive === false
                ? "bg-gray-500 text-white"
                : "bg-gray-100 text-gray-700 hover:bg-gray-200"
            }`}
          >
            <ToggleLeft className="h-3 w-3 mr-1" />
            <span>Inactive</span>
          </button>

          {/* Tag filters */}
          {getUsedTags().map((tag) => (
            <button
              key={tag}
              onClick={() => setActiveFilter(activeFilter === tag ? null : tag)}
              className={`px-2 py-1 text-xs rounded-full flex items-center transition-colors ${
                activeFilter === tag
                  ? "bg-primary-500 text-white"
                  : "bg-gray-100 text-gray-700 hover:bg-gray-200"
              }`}
            >
              <Tag className="h-3 w-3 mr-1" />
              <span>{formatTagForDisplay(tag)}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Meal Plan Cards */}
      <div className="p-6">
        {loading ? (
          <div className="flex justify-center items-center py-16">
            <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary-500"></div>
          </div>
        ) : filteredMealPlans.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            {searchTerm || activeFilter !== null || filterActive !== null ? (
              <>
                <AlertTriangle className="h-12 w-12 text-amber-400 mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-1">
                  No matches found
                </h3>
                <p className="text-gray-500 max-w-md mb-4">
                  No meal plans match your current search or filters. Try
                  adjusting your criteria.
                </p>
                <Button
                  onClick={() => {
                    setSearchTerm("");
                    setActiveFilter(null);
                    setFilterActive(null);
                  }}
                  variant="outline"
                >
                  Clear all filters
                </Button>
              </>
            ) : (
              <>
                <Sparkles className="h-12 w-12 text-primary-400 mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-1">
                  No meal plans added yet
                </h3>
                <p className="text-gray-500 max-w-md mb-4">
                  Get started by adding your first admin meal plan.
                </p>
                <Button onClick={handleAddMealPlan} variant="accent">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Your First Meal Plan
                </Button>
              </>
            )}
          </div>
        ) : (
          <div>
            <div className="text-sm text-gray-500 mb-4">
              Showing {filteredMealPlans.length}{" "}
              {filteredMealPlans.length === 1 ? "meal plan" : "meal plans"}
              {searchTerm || activeFilter || filterActive !== null
                ? " matching your filters"
                : ""}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <AnimatePresence>
                {filteredMealPlans.map((mealPlan) => (
                  <motion.div
                    key={mealPlan.id}
                    layout
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    transition={{ duration: 0.2 }}
                    className="bg-white rounded-xl shadow-sm overflow-hidden border border-gray-100 hover:shadow-md transition-all duration-300"
                  >
                    <div className="relative h-48 overflow-hidden group">
                      {mealPlan.featuredImage ? (
                        <img
                          src={mealPlan.featuredImage}
                          alt={mealPlan.name}
                          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                        />
                      ) : (
                        <div className="w-full h-full bg-gray-200 flex items-center justify-center">
                          <Calendar className="h-16 w-16 text-gray-400" />
                        </div>
                      )}
                      <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/40 to-transparent" />

                      <div className="absolute top-3 left-3">
                        <span
                          className={`px-2 py-1 rounded-full text-xs font-medium ${
                            mealPlan.isActive
                              ? "bg-green-500 text-white"
                              : "bg-gray-500 text-white"
                          }`}
                        >
                          {mealPlan.isActive ? "Active" : "Inactive"}
                        </span>
                      </div>

                      <div className="absolute bottom-0 left-0 right-0 p-4">
                        <h3 className="text-white font-semibold text-xl mb-1 truncate">
                          {mealPlan.name}
                        </h3>
                        <div className="flex justify-between items-center">
                          <p className="text-white text-sm">
                            {mealPlan.duration} days
                          </p>
                          <p className="text-white text-sm">
                            {mealPlan.items.length} meals
                          </p>
                        </div>
                      </div>

                      {/* Quick action buttons that appear on hover */}
                      <div className="absolute top-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                        <div className="flex gap-2">
                          <button
                            onClick={() => toggleMealPlanActive(mealPlan)}
                            className="bg-white/90 hover:bg-white h-8 w-8 rounded-full flex items-center justify-center text-gray-700 hover:text-green-500 transition-colors"
                          >
                            {mealPlan.isActive ? (
                              <ToggleRight className="h-4 w-4" />
                            ) : (
                              <ToggleLeft className="h-4 w-4" />
                            )}
                          </button>
                          <button
                            onClick={() => handleEditMealPlan(mealPlan)}
                            className="bg-white/90 hover:bg-white h-8 w-8 rounded-full flex items-center justify-center text-gray-700 hover:text-primary-500 transition-colors"
                          >
                            <Edit className="h-4 w-4" />
                          </button>
                          <button
                            onClick={() => handleDeleteMealPlan(mealPlan.id!)}
                            className="bg-white/90 hover:bg-white h-8 w-8 rounded-full flex items-center justify-center text-gray-700 hover:text-red-500 transition-colors"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      </div>
                    </div>

                    <div className="p-4">
                      {/* Tags */}
                      <div className="flex flex-wrap gap-1 mb-3">
                        {mealPlan.tags.map((tag, index) => (
                          <span
                            key={index}
                            className="inline-flex items-center gap-1 px-2 py-1 bg-gray-100 text-xs rounded-full"
                          >
                            <Tag className="h-3 w-3" />
                            {formatTagForDisplay(tag)}
                          </span>
                        ))}
                        {mealPlan.category && (
                          <span className="inline-flex items-center gap-1 px-2 py-1 bg-primary-100 text-primary-700 text-xs rounded-full">
                            {mealPlan.category}
                          </span>
                        )}
                      </div>

                      {/* Nutrition summary */}
                      <div className="grid grid-cols-6 gap-1 mb-3">
                        <div className="flex flex-col items-center p-2 bg-gray-50 rounded-lg">
                          <span className="text-xs text-gray-500">Cal</span>
                          <span className="font-medium">
                            {mealPlan.totalCalories.toFixed(1)}
                          </span>
                        </div>
                        <div className="flex flex-col items-center p-2 bg-gray-50 rounded-lg">
                          <span className="text-xs text-gray-500">Protein</span>
                          <span className="font-medium">
                            {mealPlan.totalProtein.toFixed(1)}g
                          </span>
                        </div>
                        <div className="flex flex-col items-center p-2 bg-gray-50 rounded-lg">
                          <span className="text-xs text-gray-500">Carbs</span>
                          <span className="font-medium">
                            {mealPlan.totalCarbs.toFixed(1)}g
                          </span>
                        </div>
                        <div className="flex flex-col items-center p-2 bg-gray-50 rounded-lg">
                          <span className="text-xs text-gray-500">Fat</span>
                          <span className="font-medium">
                            {mealPlan.totalFat.toFixed(1)}g
                          </span>
                        </div>
                        <div className="flex flex-col items-center p-2 bg-gray-50 rounded-lg">
                          <span className="text-xs text-gray-500">Fiber</span>
                          <span className="font-medium">
                            {mealPlan.totalFiber.toFixed(1)}g
                          </span>
                        </div>
                        <div className="flex flex-col items-center p-2 bg-gray-50 rounded-lg">
                          <span className="text-xs text-gray-500">Price</span>
                          <span className="font-medium">
                            ₹{mealPlan.totalPrice.toFixed(0)}
                          </span>
                        </div>
                      </div>

                      {/* User stats */}
                      <div className="flex items-center gap-2 mb-3 text-sm text-gray-600">
                        <Users className="h-4 w-4" />
                        <span>
                          {mealPlan.subscribedUsers.length} subscribers
                        </span>
                      </div>

                      {/* Description and meal items (expandable) */}
                      <motion.div
                        animate={{
                          height:
                            expandedMealPlanId === mealPlan.id ? "auto" : "0",
                          opacity: expandedMealPlanId === mealPlan.id ? 1 : 0,
                          marginBottom:
                            expandedMealPlanId === mealPlan.id ? "12px" : "0",
                        }}
                        transition={{ duration: 0.2 }}
                        className="overflow-hidden"
                      >
                        <p className="text-gray-600 text-sm mb-4">
                          {mealPlan.description}
                        </p>

                        <h4 className="font-medium text-gray-800 mb-2">
                          Meals included:
                        </h4>
                        <div className="space-y-2">
                          {mealPlan.items.map((item) => {
                            const meal = getMealInfo(item.mealId);
                            return (
                              <div
                                key={item.id}
                                className="flex items-center gap-3 p-2 bg-gray-50 rounded-lg"
                              >
                                <div className="h-10 w-10 bg-gray-200 rounded-md overflow-hidden flex-shrink-0">
                                  {meal?.image ? (
                                    <img
                                      src={meal.image}
                                      alt={meal?.name}
                                      className="h-full w-full object-cover"
                                    />
                                  ) : (
                                    <PackageOpen className="h-full w-full p-2 text-gray-400" />
                                  )}
                                </div>
                                <div className="flex-1 min-w-0">
                                  <p className="font-medium text-sm text-gray-800 truncate">
                                    {meal?.name || "Unknown Meal"}
                                  </p>
                                  <p className="text-xs text-gray-500">
                                    {item.quantity}
                                    {meal?.unit || "g"} •{" "}
                                    {item.dayNumbers.length} days •{" "}
                                    {item.mealTimes.join(", ")}
                                  </p>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </motion.div>

                      <div className="flex justify-between items-center">
                        <button
                          onClick={() => toggleExpandMealPlan(mealPlan.id!)}
                          className="text-gray-500 text-sm flex items-center gap-1 hover:text-gray-800 transition-colors"
                        >
                          <span>
                            {expandedMealPlanId === mealPlan.id
                              ? "Less info"
                              : "More info"}
                          </span>
                          <ChevronRight
                            className={`h-4 w-4 transition-transform duration-200 ${
                              expandedMealPlanId === mealPlan.id
                                ? "rotate-90"
                                : ""
                            }`}
                          />
                        </button>

                        <div className="flex gap-2">
                          <Button
                            variant={mealPlan.isActive ? "outline" : "default"}
                            size="sm"
                            onClick={() => toggleMealPlanActive(mealPlan)}
                            className="h-8 px-3"
                          >
                            {mealPlan.isActive ? (
                              <>
                                <ToggleRight className="h-3 w-3 mr-1" />
                                Deactivate
                              </>
                            ) : (
                              <>
                                <ToggleLeft className="h-3 w-3 mr-1" />
                                Activate
                              </>
                            )}
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleEditMealPlan(mealPlan)}
                            className="h-8 px-3"
                          >
                            <Edit className="h-3 w-3 mr-1" />
                            Edit
                          </Button>
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => handleDeleteMealPlan(mealPlan.id!)}
                            className="h-8 px-3"
                          >
                            <Trash2 className="h-3 w-3 mr-1" />
                            Delete
                          </Button>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>
          </div>
        )}
      </div>

      {/* Replace placeholder dialogs with AdminMealPlanDialog */}
      <AdminMealPlanDialog
        isOpen={isAddDialogOpen}
        onClose={() => setIsAddDialogOpen(false)}
        onSubmit={() => dispatch(fetchAllAdminMealPlans())}
        editMode={false}
      />

      {isEditDialogOpen && selectedMealPlan && (
        <AdminMealPlanDialog
          isOpen={isEditDialogOpen}
          onClose={() => setIsEditDialogOpen(false)}
          onSubmit={() => dispatch(fetchAllAdminMealPlans())}
          editMode={true}
          mealPlan={selectedMealPlan}
        />
      )}
    </div>
  );
}
