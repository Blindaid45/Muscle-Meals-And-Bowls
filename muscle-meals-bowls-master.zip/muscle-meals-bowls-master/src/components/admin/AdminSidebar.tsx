import { useState, useEffect } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import {
  LayoutDashboard,
  UtensilsCrossed,
  Users,
  Menu,
  X,
  ChevronRight,
  ShoppingBag,
  Settings,
  LogOut,
  CalendarCheck,
} from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { toast } from "sonner";
import { useAdminProfile } from "@/hooks/useAdminProfile";
import { TextGradient } from "../ui/TextGradient";

interface AdminSidebarProps {
  onToggle?: (isOpen: boolean) => void;
}

export default function AdminSidebar({ onToggle }: AdminSidebarProps) {
  const location = useLocation();
  const navigate = useNavigate();
  const [isOpen, setIsOpen] = useState(true);
  const [isMobile, setIsMobile] = useState(window.innerWidth < 1024);
  const { logout } = useAuth();

  const { profile } = useAdminProfile();

  // Handle resize events
  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 1024);
      if (window.innerWidth >= 1024) {
        setIsOpen(true);
      } else {
        setIsOpen(false);
      }
    };

    window.addEventListener("resize", handleResize);
    handleResize(); // Set initial state

    return () => {
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  // Notify parent component about sidebar state changes
  useEffect(() => {
    if (onToggle) {
      onToggle(isOpen);
    }
  }, [isOpen, onToggle]);

  // Handle clicking outside to close sidebar on mobile
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      const sidebar = document.getElementById("admin-sidebar");
      const toggleButton = document.getElementById("sidebar-toggle");

      if (
        isMobile &&
        isOpen &&
        sidebar &&
        !sidebar.contains(e.target as Node) &&
        toggleButton &&
        !toggleButton.contains(e.target as Node)
      ) {
        setIsOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [isMobile, isOpen]);

  const isActive = (path: string) => {
    return location.pathname === path;
  };

  // Handle logout
  const handleLogout = async () => {
    try {
      await logout();
      toast.success("You've been successfully signed out");
      navigate("/auth/login");
    } catch (error) {
      console.error("Logout error:", error);
      toast.error("There was a problem signing you out. Please try again.");
    }
  };

  const mainMenuItems = [
    { path: "/admin", icon: LayoutDashboard, label: "Dashboard" },
    { path: "/admin/meals", icon: UtensilsCrossed, label: "Meals" },
    { path: "/admin/meal-plans", icon: CalendarCheck, label: "Meal Plans" },
    { path: "/admin/users", icon: Users, label: "Users" },
    { path: "/admin/orders", icon: ShoppingBag, label: "Orders" },
    {
      path: "/admin/affiliate-management",
      icon: Users,
      label: "Affiliate Management",
    },
  ];

  const secondaryMenuItems = [
    { path: "/admin/settings", icon: Settings, label: "Settings" },
    { action: handleLogout, icon: LogOut, label: "Logout" },
  ];

  const renderMenuItem = (item: any, index: number) => {
    const Icon = item.icon;
    const active = item.path ? isActive(item.path) : false;

    // If item has an action property, use a button instead of a Link
    if (item.action) {
      return (
        <button
          key={index}
          onClick={() => {
            item.action();
            if (isMobile) setIsOpen(false);
          }}
          className={`flex items-center gap-3 px-4 py-3 my-1 rounded-lg transition-all group
            text-gray-600 hover:bg-gray-50 w-full text-left
          `}
        >
          <div className="flex items-center justify-center text-gray-500 group-hover:text-gray-700">
            <Icon className="w-5 h-5" />
          </div>
          <span
            className={`transition-opacity duration-200 ${
              !isOpen && !isMobile ? "opacity-0 w-0 hidden" : "opacity-100"
            }`}
          >
            {item.label}
          </span>
        </button>
      );
    }

    // Standard menu item with Link
    return (
      <Link
        key={index}
        to={item.path}
        className={`flex items-center gap-3 px-4 py-3 my-1 rounded-lg transition-all group
          ${
            active
              ? "bg-primary-50 text-primary-700 font-medium"
              : "text-gray-600 hover:bg-gray-50"
          }
        `}
        onClick={() => isMobile && setIsOpen(false)}
      >
        <div
          className={`flex items-center justify-center ${
            active
              ? "text-primary-600"
              : "text-gray-500 group-hover:text-gray-700"
          }`}
        >
          <Icon className="w-5 h-5" />
        </div>
        <span
          className={`transition-opacity duration-200 ${
            !isOpen && !isMobile ? "opacity-0 w-0 hidden" : "opacity-100"
          }`}
        >
          {item.label}
        </span>
        {active && (
          <ChevronRight
            className={`ml-auto w-4 h-4 text-primary-600 ${
              !isOpen && !isMobile ? "hidden" : ""
            }`}
          />
        )}
      </Link>
    );
  };

  // Get admin name initial or fallback to "A"
  const getAdminInitial = () => {
    if (profile?.name) {
      return profile.name.charAt(0).toUpperCase();
    }
    return "A";
  };

  return (
    <>
      {/* Mobile Hamburger Toggle */}
      <button
        id="sidebar-toggle"
        className="lg:hidden fixed top-4 left-4 z-50 p-2 rounded-md bg-white shadow-md text-gray-700 hover:bg-gray-100 focus:outline-none"
        onClick={() => setIsOpen(!isOpen)}
        aria-label="Toggle navigation menu"
      >
        {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
      </button>

      {/* Backdrop overlay for mobile */}
      {isMobile && isOpen && (
        <div
          className="fixed inset-0 bg-black/20 backdrop-blur-sm z-30 lg:hidden"
          onClick={() => setIsOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        id="admin-sidebar"
        className={`
          fixed lg:sticky top-0 left-0 h-screen bg-white z-40 shadow-lg
          transition-all duration-300 ease-in-out flex flex-col
          ${
            isMobile
              ? isOpen
                ? "w-72 translate-x-0"
                : "w-0 -translate-x-full"
              : isOpen
              ? "w-64"
              : "w-20"
          }
          lg:translate-x-0
        `}
      >
        {/* Logo header */}
        <div className="p-4 border-b border-gray-100 flex items-center justify-between">
          <div className="flex items-center gap-3 overflow-hidden">
            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary-600 flex items-center justify-center text-white font-bold">
              <span className="text-white text-sm font-bold">
                {getAdminInitial()}
              </span>
            </div>
            <h1
              className={`text-xl font-semibold text-gray-800 transition-opacity duration-200 whitespace-nowrap ${
                !isOpen && !isMobile ? "opacity-0 w-0" : "opacity-100"
              }`}
            >
              <TextGradient>Admin Panel</TextGradient>
            </h1>
          </div>
          {!isMobile && (
            <button
              className="p-1 rounded-md text-gray-500 hover:bg-gray-100 flex-shrink-0"
              onClick={() => setIsOpen(!isOpen)}
              aria-label="Toggle sidebar width"
            >
              <ChevronRight
                className={`w-5 h-5 transition-transform duration-300 ${
                  isOpen ? "rotate-180" : ""
                }`}
              />
            </button>
          )}
        </div>

        {/* Main navigation */}
        <div className="flex-1 overflow-y-auto py-4 px-3">
          <div
            className={`mb-2 px-4 transition-opacity duration-200 ${
              !isOpen && !isMobile
                ? "opacity-0 h-0 overflow-hidden"
                : "opacity-100"
            }`}
          >
            <h2 className="text-xs font-semibold uppercase text-gray-500 tracking-wider">
              Main Menu
            </h2>
          </div>
          <nav className="space-y-1">
            {mainMenuItems.map((item, index) => renderMenuItem(item, index))}
          </nav>

          <div
            className={`mt-8 mb-2 px-4 transition-opacity duration-200 ${
              !isOpen && !isMobile
                ? "opacity-0 h-0 overflow-hidden"
                : "opacity-100"
            }`}
          >
            <h2 className="text-xs font-semibold uppercase text-gray-500 tracking-wider">
              Account
            </h2>
          </div>
          <nav className="space-y-1">
            {secondaryMenuItems.map((item, index) =>
              renderMenuItem(item, index)
            )}
          </nav>
        </div>

        {/* User profile */}
        <div
          className={`mt-auto border-t border-gray-100 p-4 transition-all duration-300 ${
            !isOpen && !isMobile ? "py-4 px-2" : ""
          }`}
        >
          <div className="flex items-center gap-3 overflow-hidden">
            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary-600 flex items-center justify-center text-white font-bold">
              <span className="text-white text-sm font-bold">
                {getAdminInitial()}
              </span>
            </div>
            <div
              className={`transition-opacity duration-200 overflow-hidden whitespace-nowrap ${
                !isOpen && !isMobile ? "opacity-0 w-0" : "opacity-100"
              }`}
            >
              {/* Admin Info Section */}
              {profile && (
                <div className="p-4 border-b border-gray-100">
                  <div className="text-sm font-medium text-gray-900">
                    {profile.name || "Admin"}
                  </div>
                  <div className="text-xs text-gray-500 truncate">
                    {profile.email || ""}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </aside>
    </>
  );
}
