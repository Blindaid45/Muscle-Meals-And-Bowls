import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  collection,
  getDocs,
  query,
  orderBy,
  where,
  doc,
  updateDoc,
  addDoc,
  serverTimestamp,
} from "firebase/firestore";
import { auth, db } from "../../lib/firebase";
import {
  Users,
  DollarSign,
  Clock,
  CheckCircle,
  XCircle,
  Eye,
  RefreshCw,
  CreditCard,
  AlertCircle,
  Copy,
} from "lucide-react";
import { toast } from "sonner";

interface Affiliate {
  affiliateId: string;
  userId: string;
  couponCode: string;
  upiId: string;
  totalEarnings: number;
  totalReferrals: number;
  isActive: boolean;
  createdAt: string;
}

interface PayoutRequest {
  id: string;
  affiliateId: string;
  userId: string;
  requestedAmount: number;
  upiId: string;
  couponCode: string;
  status: "pending" | "approved" | "paid" | "rejected";
  createdAt: string;
  requestedAt: string;
  processedAt?: string;
  processedBy?: string;
}

export default function AffiliateManagement() {
  const [affiliates, setAffiliates] = useState<Affiliate[]>([]);
  const [payoutRequests, setPayoutRequests] = useState<PayoutRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedTab, setSelectedTab] = useState<"affiliates" | "payouts">(
    "affiliates"
  );
  const [processingPayouts, setProcessingPayouts] = useState<Set<string>>(
    new Set()
  );

  // Fetch affiliates and payout requests
  const fetchData = async () => {
    setLoading(true);
    try {
      // Fetch affiliates
      const affiliatesRef = collection(db, "affiliates");
      const affiliatesQuery = query(
        affiliatesRef,
        orderBy("createdAt", "desc")
      );
      const affiliatesSnapshot = await getDocs(affiliatesQuery);

      const affiliatesData = affiliatesSnapshot.docs.map((doc) => ({
        affiliateId: doc.id,
        ...doc.data(),
        createdAt:
          doc.data().createdAt?.toDate?.()?.toISOString() ||
          new Date().toISOString(),
      })) as Affiliate[];

      // Fetch payout requests
      const payoutRequestsRef = collection(db, "payoutRequests");
      const payoutRequestsQuery = query(
        payoutRequestsRef,
        orderBy("createdAt", "desc")
      );
      const payoutRequestsSnapshot = await getDocs(payoutRequestsQuery);

      const payoutRequestsData = payoutRequestsSnapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
        createdAt:
          doc.data().createdAt?.toDate?.()?.toISOString() ||
          new Date().toISOString(),
        requestedAt:
          doc.data().requestedAt?.toDate?.()?.toISOString() ||
          new Date().toISOString(),
        processedAt: doc.data().processedAt?.toDate?.()?.toISOString(),
      })) as PayoutRequest[];

      setAffiliates(affiliatesData);
      setPayoutRequests(payoutRequestsData);
    } catch (error) {
      console.error("Error fetching data:", error);
      toast.error("Failed to fetch affiliate data");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  // Handle payout approval/payment
  const handleProcessPayout = async (
    requestId: string,
    action: "paid" | "rejected"
  ) => {
    setProcessingPayouts((prev) => new Set(prev).add(requestId));

    try {
      const request = payoutRequests.find((r) => r.id === requestId);
      if (!request) throw new Error("Payout request not found");

      // Update payout request status
      const payoutRequestRef = doc(db, "payoutRequests", requestId);
      await updateDoc(payoutRequestRef, {
        status: action,
        processedAt: serverTimestamp(),
        processedBy: auth.currentUser?.uid,
      });

      if (action === "paid") {
        // Find and update user's wallet balance
        const walletsRef = collection(db, "wallets");
        const walletQuery = query(
          walletsRef,
          where("userId", "==", request.userId)
        );
        const walletSnapshot = await getDocs(walletQuery);

        if (!walletSnapshot.empty) {
          const walletDoc = walletSnapshot.docs[0];
          const currentBalance = walletDoc.data().balance || 0;
          const newBalance = Math.max(
            0,
            currentBalance - request.requestedAmount
          );

          // Update wallet balance
          await updateDoc(doc(db, "wallets", walletDoc.id), {
            balance: newBalance,
            updatedAt: serverTimestamp(),
          });

          console.log(
            `Wallet updated: ${currentBalance} -> ${newBalance} (deducted ₹${request.requestedAmount})`
          );
        } else {
          console.warn("Wallet not found for user:", request.userId);
        }

        // Update existing scheduled transaction to completed
        const walletTransactionsRef = collection(db, "walletTransactions");
        const scheduledTransactionQuery = query(
          walletTransactionsRef,
          where("affiliateId", "==", request.affiliateId),
          where("status", "==", "scheduled"),
          where("amount", "==", request.requestedAmount)
        );
        const scheduledSnapshot = await getDocs(scheduledTransactionQuery);

        if (!scheduledSnapshot.empty) {
          // Update the existing scheduled transaction
          const scheduledDoc = scheduledSnapshot.docs[0];
          await updateDoc(doc(db, "walletTransactions", scheduledDoc.id), {
            status: "completed",
            description: `Payout completed for ₹${request.requestedAmount}`,
            payoutRequestId: requestId,
            processedAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
        } else {
          // Fallback: create new transaction if scheduled one doesn't exist
          await addDoc(walletTransactionsRef, {
            userId: request.userId,
            affiliateId: request.affiliateId,
            type: "debit",
            amount: request.requestedAmount,
            status: "completed",
            description: `Payout completed for ₹${request.requestedAmount}`,
            payoutRequestId: requestId,
            createdAt: serverTimestamp(),
          });
        }

        // Reset affiliate total earnings to 0
        const affiliateRef = doc(db, "affiliates", request.affiliateId);
        await updateDoc(affiliateRef, {
          totalEarnings: 0,
          updatedAt: serverTimestamp(),
        });

        toast.success(
          "Payout marked as paid successfully! Wallet balance updated."
        );
      } else {
        // Remove scheduled transaction for rejected payout
        const walletTransactionsRef = collection(db, "walletTransactions");
        const scheduledTransactionQuery = query(
          walletTransactionsRef,
          where("affiliateId", "==", request.affiliateId),
          where("status", "==", "scheduled"),
          where("amount", "==", request.requestedAmount)
        );
        const scheduledSnapshot = await getDocs(scheduledTransactionQuery);

        for (const transDoc of scheduledSnapshot.docs) {
          await updateDoc(doc(db, "walletTransactions", transDoc.id), {
            status: "cancelled",
            description: `Payout request rejected for ₹${request.requestedAmount}`,
            updatedAt: serverTimestamp(),
          });
        }

        toast.success("Payout request rejected");
      }

      await fetchData();
    } catch (error) {
      console.error("Error processing payout:", error);
      toast.error("Failed to process payout request");
    } finally {
      setProcessingPayouts((prev) => {
        const newSet = new Set(prev);
        newSet.delete(requestId);
        return newSet;
      });
    }
  };

  // Copy UPI ID to clipboard
  const copyUpiId = async (upiId: string) => {
    try {
      await navigator.clipboard.writeText(upiId);
      toast.success("UPI ID copied to clipboard!");
    } catch (err) {
      toast.error("Failed to copy UPI ID");
    }
  };

  // Format date
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-IN", {
      year: "numeric",
      month: "short",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  // Format currency
  const formatCurrency = (amount: number) => {
    return `₹${amount.toLocaleString("en-IN")}`;
  };

  // Get status color
  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-yellow-100 text-yellow-800 border-yellow-200";
      case "approved":
        return "bg-blue-100 text-blue-800 border-blue-200";
      case "paid":
        return "bg-green-100 text-green-800 border-green-200";
      case "rejected":
        return "bg-red-100 text-red-800 border-red-200";
      default:
        return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  // Get status icon
  const getStatusIcon = (status: string) => {
    switch (status) {
      case "pending":
        return <Clock className="text-yellow-500" size={16} />;
      case "approved":
        return <Eye className="text-blue-500" size={16} />;
      case "paid":
        return <CheckCircle className="text-green-500" size={16} />;
      case "rejected":
        return <XCircle className="text-red-500" size={16} />;
      default:
        return <AlertCircle className="text-gray-500" size={16} />;
    }
  };

  if (loading) {
    return (
      <div className="bg-white shadow-xl rounded-2xl p-8 border border-gray-100">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded mb-4"></div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="h-24 bg-gray-200 rounded-lg"></div>
            ))}
          </div>
          <div className="h-48 bg-gray-200 rounded-lg"></div>
        </div>
      </div>
    );
  }

  const pendingPayouts = payoutRequests.filter((r) => r.status === "pending");
  const totalAffiliates = affiliates.length;
  const totalPendingAmount = pendingPayouts.reduce(
    (sum, r) => sum + r.requestedAmount,
    0
  );

  return (
    <motion.div
      className="bg-white shadow-xl rounded-2xl overflow-hidden border border-gray-100"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
    >
      {/* Header */}
      <div className="bg-gradient-to-r from-purple-600 to-indigo-600 px-8 py-6 text-white">
        <div className="flex justify-between items-center">
          <div>
            <h2 className="text-2xl font-bold flex items-center gap-2">
              <Users size={28} />
              Affiliate Management
            </h2>
            <p className="text-purple-100 mt-1">
              Manage affiliates and process payout requests
            </p>
          </div>
          <motion.button
            onClick={fetchData}
            whileTap={{ scale: 0.95 }}
            className="px-4 py-2 bg-white bg-opacity-20 rounded-lg text-sm font-medium hover:bg-opacity-30 transition-colors flex items-center gap-2 backdrop-blur-sm"
          >
            <RefreshCw size={16} />
            Refresh
          </motion.button>
        </div>
      </div>

      <div className="p-8">
        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <motion.div
            className="bg-blue-50 border border-blue-200 rounded-xl p-6 shadow-sm"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 mb-1">
                  Total Affiliates
                </p>
                <p className="text-2xl font-bold text-blue-600">
                  {totalAffiliates}
                </p>
              </div>
              <div className="bg-blue-100 p-3 rounded-full">
                <Users className="text-blue-600" size={24} />
              </div>
            </div>
          </motion.div>

          <motion.div
            className="bg-yellow-50 border border-yellow-200 rounded-xl p-6 shadow-sm"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 mb-1">
                  Pending Requests
                </p>
                <p className="text-2xl font-bold text-yellow-600">
                  {pendingPayouts.length}
                </p>
              </div>
              <div className="bg-yellow-100 p-3 rounded-full">
                <Clock className="text-yellow-600" size={24} />
              </div>
            </div>
          </motion.div>

          <motion.div
            className="bg-green-50 border border-green-200 rounded-xl p-6 shadow-sm"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 mb-1">
                  Pending Amount
                </p>
                <p className="text-2xl font-bold text-green-600">
                  {formatCurrency(totalPendingAmount)}
                </p>
              </div>
              <div className="bg-green-100 p-3 rounded-full">
                <DollarSign className="text-green-600" size={24} />
              </div>
            </div>
          </motion.div>
        </div>

        {/* Tabs */}
        <div className="border-b border-gray-200 mb-6">
          <nav className="flex space-x-8">
            {[
              { id: "affiliates", label: "All Affiliates", icon: Users },
              { id: "payouts", label: "Payout Requests", icon: CreditCard },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setSelectedTab(tab.id as any)}
                className={`py-3 px-1 border-b-2 font-medium text-sm transition-colors flex items-center gap-2 ${
                  selectedTab === tab.id
                    ? "border-indigo-500 text-indigo-600"
                    : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                }`}
              >
                <tab.icon size={18} />
                {tab.label}
              </button>
            ))}
          </nav>
        </div>

        {/* Tab Content */}
        <AnimatePresence mode="wait">
          {selectedTab === "affiliates" && (
            <motion.div
              key="affiliates"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
            >
              {affiliates.length > 0 ? (
                <div className="space-y-4">
                  {affiliates.map((affiliate, index) => (
                    <motion.div
                      key={affiliate.affiliateId}
                      className="border border-gray-200 rounded-xl p-6 bg-white shadow-sm hover:shadow-md transition-shadow"
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.05 }}
                    >
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-3">
                            <div className="bg-indigo-100 rounded-full p-2">
                              <Users className="text-indigo-600" size={20} />
                            </div>
                            <div>
                              <h4 className="font-semibold text-gray-900">
                                {affiliate.couponCode}
                              </h4>
                              <p className="text-sm text-gray-600">
                                Joined: {formatDate(affiliate.createdAt)}
                              </p>
                            </div>
                          </div>

                          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                            <div className="bg-gray-50 rounded-lg p-3">
                              <span className="text-gray-500 text-xs">
                                Total Earnings
                              </span>
                              <p className="font-semibold text-gray-900">
                                {formatCurrency(affiliate.totalEarnings)}
                              </p>
                            </div>
                            <div className="bg-blue-50 rounded-lg p-3">
                              <span className="text-gray-500 text-xs">
                                Referrals
                              </span>
                              <p className="font-semibold text-blue-600">
                                {affiliate.totalReferrals}
                              </p>
                            </div>
                            <div className="bg-green-50 rounded-lg p-3">
                              <span className="text-gray-500 text-xs">
                                Status
                              </span>
                              <p className="font-semibold text-green-600">
                                {affiliate.isActive ? "Active" : "Inactive"}
                              </p>
                            </div>
                            <div className="bg-purple-50 rounded-lg p-3">
                              <span className="text-gray-500 text-xs">
                                UPI ID
                              </span>
                              <div className="flex items-center gap-2">
                                <p className="font-semibold text-purple-600 text-xs truncate">
                                  {affiliate.upiId}
                                </p>
                                <button
                                  onClick={() => copyUpiId(affiliate.upiId)}
                                  className="text-purple-500 hover:text-purple-700"
                                >
                                  <Copy size={12} />
                                </button>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <div className="bg-gray-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                    <Users className="text-gray-400" size={32} />
                  </div>
                  <h3 className="text-lg font-medium text-gray-900 mb-2">
                    No affiliates found
                  </h3>
                  <p className="text-gray-600 max-w-sm mx-auto">
                    No affiliate accounts have been created yet.
                  </p>
                </div>
              )}
            </motion.div>
          )}

          {selectedTab === "payouts" && (
            <motion.div
              key="payouts"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
            >
              {payoutRequests.length > 0 ? (
                <div className="space-y-4">
                  {payoutRequests.map((request, index) => (
                    <motion.div
                      key={request.id}
                      className="border border-gray-200 rounded-xl p-6 bg-white shadow-sm hover:shadow-md transition-shadow"
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.05 }}
                    >
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-3">
                            <div className="bg-green-100 rounded-full p-2">
                              <CreditCard
                                className="text-green-600"
                                size={20}
                              />
                            </div>
                            <div>
                              <h4 className="font-semibold text-gray-900">
                                Payout Request - {request.couponCode}
                              </h4>
                              <p className="text-sm text-gray-600">
                                Requested: {formatDate(request.requestedAt)}
                              </p>
                            </div>
                            <div
                              className={`px-3 py-1 rounded-full text-xs font-medium border flex items-center gap-1 ${getStatusColor(
                                request.status
                              )}`}
                            >
                              {getStatusIcon(request.status)}
                              {request.status.charAt(0).toUpperCase() +
                                request.status.slice(1)}
                            </div>
                          </div>

                          <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-sm">
                            <div className="bg-gray-50 rounded-lg p-3">
                              <span className="text-gray-500 text-xs">
                                Amount
                              </span>
                              <p className="font-semibold text-gray-900">
                                {formatCurrency(request.requestedAmount)}
                              </p>
                            </div>
                            <div className="bg-purple-50 rounded-lg p-3">
                              <span className="text-gray-500 text-xs">
                                UPI ID
                              </span>
                              <div className="flex items-center gap-2">
                                <p className="font-semibold text-purple-600 text-xs truncate">
                                  {request.upiId}
                                </p>
                                <button
                                  onClick={() => copyUpiId(request.upiId)}
                                  className="text-purple-500 hover:text-purple-700"
                                >
                                  <Copy size={12} />
                                </button>
                              </div>
                            </div>
                            {request.processedAt && (
                              <div className="bg-blue-50 rounded-lg p-3">
                                <span className="text-gray-500 text-xs">
                                  Processed
                                </span>
                                <p className="font-semibold text-blue-600 text-xs">
                                  {formatDate(request.processedAt)}
                                </p>
                              </div>
                            )}
                          </div>
                        </div>

                        {request.status === "pending" && (
                          <div className="flex gap-2 ml-4">
                            <motion.button
                              onClick={() =>
                                handleProcessPayout(request.id, "paid")
                              }
                              disabled={processingPayouts.has(request.id)}
                              whileTap={{ scale: 0.95 }}
                              className="bg-green-500 text-white hover:bg-green-600 px-4 py-2 rounded-md font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                            >
                              {processingPayouts.has(request.id) ? (
                                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                              ) : (
                                "Mark Paid"
                              )}
                            </motion.button>
                            <motion.button
                              onClick={() =>
                                handleProcessPayout(request.id, "rejected")
                              }
                              disabled={processingPayouts.has(request.id)}
                              whileTap={{ scale: 0.95 }}
                              className="bg-red-500 text-white hover:bg-red-600 px-4 py-2 rounded-md font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                            >
                              Reject
                            </motion.button>
                          </div>
                        )}
                      </div>
                    </motion.div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <div className="bg-gray-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                    <CreditCard className="text-gray-400" size={32} />
                  </div>
                  <h3 className="text-lg font-medium text-gray-900 mb-2">
                    No payout requests
                  </h3>
                  <p className="text-gray-600 max-w-sm mx-auto">
                    No payout requests have been submitted yet.
                  </p>
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}
