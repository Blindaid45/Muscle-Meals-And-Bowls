import { useEffect, useState, useRef } from "react";
import { useDispatch, useSelector } from "react-redux";

import {
  fetchTags,
  createTag,
  updateTag,
  deleteTag,
  Tag,
} from "@/store/slices/tagSlice";
import { Button } from "@/components/ui/Button";
import {
  Plus,
  Edit,
  Trash2,
  X,
  Check,
  HashIcon,
  Save,
  Loader2,
  RefreshCcw,
  ChevronDown,
  ChevronRight,
  Tag as TagIcon,
} from "lucide-react";
import { toast } from "sonner";
import { motion, AnimatePresence } from "framer-motion";
import { formatTagForStorage, formatTagForDisplay } from "@/utils/tagUtils";
import { AppDispatch, RootState } from "@/store/store";

export default function TagManagement() {
  const dispatch = useDispatch<AppDispatch>();
  const { tags, loading } = useSelector((state: RootState) => state.tags);

  const [isExpanded, setIsExpanded] = useState(false);
  const [isAddingTag, setIsAddingTag] = useState(false);
  const [editingTagId, setEditingTagId] = useState<string | null>(null);
  const [newTagName, setNewTagName] = useState("");
  const [newTagDescription, setNewTagDescription] = useState("");
  const [newTagColor, setNewTagColor] = useState("#3B82F6"); // Default blue color
  const [editTagName, setEditTagName] = useState("");
  const [editTagDescription, setEditTagDescription] = useState("");
  const [editTagColor, setEditTagColor] = useState("");

  const newTagInputRef = useRef<HTMLInputElement>(null);
  const editTagInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    dispatch(fetchTags());
  }, [dispatch]);

  useEffect(() => {
    if (isAddingTag && newTagInputRef.current) {
      newTagInputRef.current.focus();
    }
  }, [isAddingTag]);

  useEffect(() => {
    if (editingTagId && editTagInputRef.current) {
      editTagInputRef.current.focus();
    }
  }, [editingTagId]);

  const handleAddTag = async () => {
    if (!newTagName.trim()) {
      toast.error("Tag name cannot be empty");
      return;
    }
    try {
      const formattedTagName = formatTagForStorage(newTagName);

      await dispatch(
        createTag({
          name: formattedTagName,
          description: newTagDescription.trim() || undefined,
          color: newTagColor,
        })
      ).unwrap();

      setNewTagName("");
      setNewTagDescription("");
      setNewTagColor("#3B82F6");
      setIsAddingTag(false);
    } catch (error) {
      console.error("Failed to add tag:", error);
    }
  };

  const startEditTag = (tag: Tag) => {
    setEditingTagId(tag.id || null);
    // Show the display version (capitalized with spaces) when editing
    setEditTagName(formatTagForDisplay(tag.name));
    setEditTagDescription(tag.description || "");
    setEditTagColor(tag.color || "#3B82F6");
  };

  const handleUpdateTag = async () => {
    if (!editTagName.trim() || !editingTagId) {
      toast.error("Tag name cannot be empty");
      return;
    }

    try {
      // Format tag name for storage (lowercase with underscores)
      const formattedTagName = formatTagForStorage(editTagName);

      await dispatch(
        updateTag({
          id: editingTagId,
          name: formattedTagName,
          description: editTagDescription.trim() || undefined,
          color: editTagColor,
        })
      ).unwrap();

      setEditingTagId(null);
    } catch (error) {
      console.error("Failed to update tag:", error);
    }
  };

  const handleDeleteTag = async (id: string) => {
    if (
      window.confirm(
        "Are you sure you want to delete this tag? It may affect meals that use this tag."
      )
    ) {
      try {
        await dispatch(deleteTag(id)).unwrap();
      } catch (error) {
        console.error("Failed to delete tag:", error);
      }
    }
  };

  const cancelAddTag = () => {
    setIsAddingTag(false);
    setNewTagName("");
    setNewTagDescription("");
    setNewTagColor("#3B82F6");
  };

  const cancelEditTag = () => {
    setEditingTagId(null);
  };

  const toggleExpanded = () => {
    setIsExpanded(!isExpanded);
    // If we're expanding and tags are not loaded yet, fetch them
    if (!isExpanded && tags.length === 0 && !loading) {
      dispatch(fetchTags());
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden mb-8">
      {/* Header with toggle button */}
      <div
        className="p-5 border-b border-gray-100 flex justify-between items-center cursor-pointer"
        onClick={toggleExpanded}
      >
        <div className="flex items-center gap-2">
          <TagIcon className="h-6 w-6 text-primary-500" />
          <h2 className="text-xl font-semibold text-gray-900">
            Tag Management
          </h2>
        </div>

        <div className="flex items-center gap-3">
          {loading && (
            <Loader2 className="h-5 w-5 animate-spin text-gray-400" />
          )}

          <Button
            variant="ghost"
            size="sm"
            className="p-2 h-9 w-9"
            onClick={(e) => {
              e.stopPropagation(); // Prevent the header click from toggling
              if (isExpanded) {
                dispatch(fetchTags());
              } else {
                toggleExpanded();
              }
            }}
          >
            <RefreshCcw className="h-5 w-5" />
          </Button>

          <Button variant="ghost" size="sm" className="p-2 h-9 w-9">
            {isExpanded ? (
              <ChevronDown className="h-6 w-6 text-gray-500" />
            ) : (
              <ChevronRight className="h-6 w-6 text-gray-500" />
            )}
          </Button>
        </div>
      </div>

      {/* Collapsible content */}
      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="overflow-hidden"
          >
            <div className="p-6 border-b border-gray-100 flex justify-between items-center">
              <div>
                <p className="text-sm text-gray-500">
                  Create and manage tags for categorizing meals
                </p>
              </div>

              <div className="flex space-x-2">
                {!isAddingTag && (
                  <Button
                    onClick={() => setIsAddingTag(true)}
                    variant="accent"
                    className="whitespace-nowrap"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Add Tag
                  </Button>
                )}
              </div>
            </div>

            <div className="p-6">
              {/* Add Tag Form */}
              {isAddingTag && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="mb-6 p-4 border border-gray-200 rounded-lg bg-gray-50"
                >
                  <h3 className="text-sm font-medium mb-3 text-gray-700">
                    Add New Tag
                  </h3>
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Tag Name <span className="text-red-500">*</span>
                      </label>
                      <input
                        ref={newTagInputRef}
                        type="text"
                        value={newTagName}
                        onChange={(e) => setNewTagName(e.target.value)}
                        placeholder="Enter tag name (e.g. High Protein)"
                        className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                      />
                      {newTagName && (
                        <p className="text-xs text-gray-500 mt-1">
                          Will be stored as: {formatTagForStorage(newTagName)}
                        </p>
                      )}
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Description (optional)
                      </label>
                      <input
                        type="text"
                        value={newTagDescription}
                        onChange={(e) => setNewTagDescription(e.target.value)}
                        placeholder="Short description"
                        className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Color
                      </label>
                      <div className="flex items-center space-x-2">
                        <input
                          type="color"
                          value={newTagColor}
                          onChange={(e) => setNewTagColor(e.target.value)}
                          className="h-8 w-8 border border-gray-300 rounded cursor-pointer"
                        />
                        <span className="text-sm text-gray-500">
                          {newTagColor}
                        </span>
                      </div>
                    </div>

                    <div className="flex justify-end space-x-2">
                      <Button variant="outline" onClick={cancelAddTag}>
                        <X className="h-4 w-4 mr-1" />
                        Cancel
                      </Button>
                      <Button variant="accent" onClick={handleAddTag}>
                        <Check className="h-4 w-4 mr-1" />
                        Save Tag
                      </Button>
                    </div>
                  </div>
                </motion.div>
              )}

              {/* Tags List */}
              <div className="space-y-2">
                {tags.length === 0 && !loading ? (
                  <div className="text-center py-12">
                    <HashIcon className="h-12 w-12 mx-auto text-gray-300 mb-4" />
                    <h3 className="text-lg font-medium text-gray-500 mb-1">
                      No tags yet
                    </h3>
                    <p className="text-gray-400 mb-4">
                      Create your first tag to organize meals
                    </p>
                    {!isAddingTag && (
                      <Button
                        onClick={() => setIsAddingTag(true)}
                        variant="outline"
                        className="mx-auto"
                      >
                        <Plus className="h-4 w-4 mr-2" />
                        Add Your First Tag
                      </Button>
                    )}
                  </div>
                ) : (
                  <div className="overflow-hidden border border-gray-200 rounded-lg">
                    <table className="min-w-full divide-y divide-gray-200">
                      <thead className="bg-gray-50">
                        <tr>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Tag
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Description
                          </th>
                          <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Actions
                          </th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-gray-200">
                        {tags.map((tag: Tag) => (
                          <tr key={tag.id} className="hover:bg-gray-50">
                            {editingTagId === tag.id ? (
                              // Edit mode
                              <td className="px-6 py-4 whitespace-nowrap">
                                <input
                                  ref={editTagInputRef}
                                  type="text"
                                  value={editTagName}
                                  onChange={(e) =>
                                    setEditTagName(e.target.value)
                                  }
                                  className="w-full p-1 border border-gray-300 rounded-md focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                                />
                                {editTagName && (
                                  <p className="text-xs text-gray-500 mt-1">
                                    Will be stored as:{" "}
                                    {formatTagForStorage(editTagName)}
                                  </p>
                                )}
                                <div className="flex items-center space-x-2 mt-2">
                                  <input
                                    type="color"
                                    value={editTagColor}
                                    onChange={(e) =>
                                      setEditTagColor(e.target.value)
                                    }
                                    className="h-6 w-6 border border-gray-300 rounded cursor-pointer"
                                  />
                                  <span className="text-xs text-gray-500">
                                    {editTagColor}
                                  </span>
                                </div>
                              </td>
                            ) : (
                              // View mode
                              <td className="px-6 py-4 whitespace-nowrap">
                                <div className="flex items-center">
                                  <div
                                    className="h-4 w-4 rounded-full mr-2"
                                    style={{
                                      backgroundColor: tag.color || "#3B82F6",
                                    }}
                                  />
                                  <span className="font-medium">
                                    {formatTagForDisplay(tag.name)}
                                  </span>
                                </div>
                              </td>
                            )}

                            {editingTagId === tag.id ? (
                              <td className="px-6 py-4">
                                <input
                                  type="text"
                                  value={editTagDescription}
                                  onChange={(e) =>
                                    setEditTagDescription(e.target.value)
                                  }
                                  placeholder="Short description"
                                  className="w-full p-1 border border-gray-300 rounded-md focus:ring-2 focus:ring-primary-500 focus:border-primary-500"
                                />
                              </td>
                            ) : (
                              <td className="px-6 py-4 text-sm text-gray-500">
                                {tag.description || "-"}
                              </td>
                            )}

                            <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                              {editingTagId === tag.id ? (
                                <div className="flex justify-end space-x-2">
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={cancelEditTag}
                                  >
                                    Cancel
                                  </Button>
                                  <Button
                                    variant="accent"
                                    size="sm"
                                    onClick={handleUpdateTag}
                                  >
                                    <Save className="h-3 w-3 mr-1" />
                                    Save
                                  </Button>
                                </div>
                              ) : (
                                <div className="flex justify-end space-x-2">
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => startEditTag(tag)}
                                  >
                                    <Edit className="h-3 w-3 mr-1" />
                                    Edit
                                  </Button>
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => handleDeleteTag(tag.id!)}
                                    className="text-red-600 hover:text-red-800 hover:bg-red-50"
                                  >
                                    <Trash2 className="h-3 w-3 mr-1" />
                                    Delete
                                  </Button>
                                </div>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
