import { useState, useEffect, useRef } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";

interface ImageSliderProps {
  images: string[];
  aspectRatio?: "square" | "landscape" | "portrait";
  showArrows?: boolean;
  showDots?: boolean;
  autoplay?: boolean;
  autoplayInterval?: number;
}

export default function ImageSlider({
  images = [],
  aspectRatio = "landscape",
  showArrows = true,
  showDots = true,
  autoplay = false,
  autoplayInterval = 5000,
}: ImageSliderProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [touchStart, setTouchStart] = useState(0);
  const sliderRef = useRef<HTMLDivElement>(null);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  // Set the aspect ratio class based on the prop
  const aspectRatioClass =
    aspectRatio === "square"
      ? "aspect-square"
      : aspectRatio === "portrait"
      ? "aspect-[3/4]"
      : "aspect-[4/3]";

  // Handle autoplay
  useEffect(() => {
    if (autoplay && images.length > 1) {
      intervalRef.current = setInterval(() => {
        setCurrentIndex((prevIndex) => (prevIndex + 1) % images.length);
      }, autoplayInterval);
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [autoplay, autoplayInterval, images.length]);

  // Navigation functions
  const goToPrevious = (e: React.MouseEvent) => {
    if (e && e.preventDefault) {
      e.preventDefault();
      e.stopPropagation();
    }

    setCurrentIndex((prevIndex) =>
      prevIndex === 0 ? images.length - 1 : prevIndex - 1
    );
  };

  const goToNext = (e: React.MouseEvent) => {
    if (e && e.preventDefault) {
      e.preventDefault();
      e.stopPropagation();
    }

    setCurrentIndex((prevIndex) => (prevIndex + 1) % images.length);
  };

  const goToIndex = (index: number, e: React.MouseEvent) => {
    if (e && e.preventDefault) {
      e.preventDefault();
      e.stopPropagation();
    }

    setCurrentIndex(index);
  };

  // Touch handlers for swipe gestures
  const handleTouchStart = (e: React.TouchEvent) => {
    setTouchStart(e.touches[0].clientX);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!touchStart) return;

    const touchEnd = e.touches[0].clientX;
    const diff = touchStart - touchEnd;

    // Minimum swipe distance requirement (50px)
    if (Math.abs(diff) > 50) {
      if (diff > 0) {
        // Swipe left
        goToNext(e as any);
      } else {
        // Swipe right
        goToPrevious(e as any);
      }
      setTouchStart(0);
    }
  };

  // Ensure image array is an array, with valid strings
  const safeImages = Array.isArray(images)
    ? images.filter((img) => typeof img === "string" && img.trim() !== "")
    : [];

  // If there are no images, show a placeholder
  if (safeImages.length === 0) {
    return (
      <div
        className={`bg-gray-100 rounded-lg ${aspectRatioClass} flex items-center justify-center`}
      >
        <p className="text-gray-400">No images available</p>
      </div>
    );
  }

  // If there's only one image, show it without controls
  if (safeImages.length === 1) {
    return (
      <div
        className={`relative rounded-lg overflow-hidden ${aspectRatioClass}`}
      >
        <img
          src={safeImages[0]}
          alt="Product"
          className="w-full h-full object-cover"
        />
      </div>
    );
  }

  return (
    <div
      ref={sliderRef}
      className={`relative rounded-lg overflow-hidden ${aspectRatioClass} group`}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onClick={(e) => e.stopPropagation()}
    >
      {/* Images */}
      <div className="w-full h-full">
        {safeImages.map((image, index) => (
          <div
            key={index}
            className={`absolute inset-0 transition-opacity duration-300 ${
              index === currentIndex ? "opacity-100 z-10" : "opacity-0 z-0"
            }`}
          >
            <img
              src={image}
              alt={`Slide ${index + 1}`}
              className="w-full h-full object-cover"
            />
          </div>
        ))}
      </div>

      {/* Navigation arrows */}
      {showArrows && safeImages.length > 1 && (
        <>
          <button
            className="absolute left-2 top-1/2 transform -translate-y-1/2 bg-white/70 hover:bg-white/90 text-gray-800 rounded-full p-1.5 z-20 opacity-70 md:opacity-0 group-hover:opacity-100 transition-opacity"
            onClick={goToPrevious}
            aria-label="Previous slide"
          >
            <ChevronLeft className="h-5 w-5" />
          </button>
          <button
            className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-white/70 hover:bg-white/90 text-gray-800 rounded-full p-1.5 z-20 opacity-70 md:opacity-0 group-hover:opacity-100 transition-opacity"
            onClick={goToNext}
            aria-label="Next slide"
          >
            <ChevronRight className="h-5 w-5" />
          </button>
        </>
      )}

      {/* Dot indicators */}
      {showDots && safeImages.length > 1 && (
        <div className="absolute bottom-2 left-0 right-0 flex justify-center gap-1.5 z-20">
          {safeImages.map((_, index) => (
            <button
              key={index}
              className={`w-2 h-2 rounded-full transition-all ${
                index === currentIndex
                  ? "bg-white w-4"
                  : "bg-white/50 hover:bg-white/80"
              }`}
              onClick={(e) => goToIndex(index, e)}
              aria-label={`Go to slide ${index + 1}`}
            />
          ))}
        </div>
      )}
    </div>
  );
}
