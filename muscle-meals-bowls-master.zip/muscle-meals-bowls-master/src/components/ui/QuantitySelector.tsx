import { useState, useEffect } from "react";
import { Plus, Minus } from "lucide-react";
import { motion } from "framer-motion";

interface QuantitySelectorProps {
  initialValue?: number;
  min?: number;
  max?: number;
  step?: number;
  unit?: string;
  baseQuantity: number; // Admin-set base quantity
  onChange?: (value: number) => void;
}

const QuantitySelector = ({
  initialValue = 100,
  min = 50,
  max = 500,
  step = 50,
  unit = "g",
  baseQuantity = 50, // Provide a default value for baseQuantity
  onChange,
}: QuantitySelectorProps) => {
  // Make sure baseQuantity is valid
  const safeBaseQuantity = baseQuantity <= 0 ? 50 : baseQuantity;

  // Use the higher of initialValue and safeBaseQuantity
  const [quantity, setQuantity] = useState(
    Math.max(initialValue || safeBaseQuantity, safeBaseQuantity)
  );

  // Update quantity when initialValue or baseQuantity changes
  useEffect(() => {
    const newQuantity = Math.max(
      initialValue || safeBaseQuantity,
      safeBaseQuantity
    );
    setQuantity(newQuantity);
    // Call onChange to sync with parent component
    if (onChange) {
      onChange(newQuantity);
    }
  }, [initialValue, safeBaseQuantity]);

  const increment = () => {
    const newValue = Math.min(quantity + step, max);
    setQuantity(newValue);
    if (onChange) {
      onChange(newValue);
    }
  };

  const decrement = () => {
    const newValue = Math.max(quantity - step, safeBaseQuantity);
    setQuantity(newValue);
    if (onChange) {
      onChange(newValue);
    }
  };

  return (
    <div className="flex items-center">
      <motion.button
        whileTap={{ scale: quantity > safeBaseQuantity ? 0.9 : 1 }}
        className={`w-8 h-8 flex items-center justify-center rounded-full ${
          quantity <= safeBaseQuantity
            ? "bg-gray-200 text-gray-400 cursor-not-allowed"
            : "bg-primary-100 text-primary"
        }`}
        onClick={decrement}
        disabled={quantity <= safeBaseQuantity}
      >
        <Minus size={16} />
      </motion.button>

      <div className="mx-3 min-w-[80px] text-center">
        <motion.span
          key={quantity}
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 10 }}
          className="font-montserrat font-semibold text-lg"
        >
          {quantity}
          <span className="text-sm ml-1">{unit}</span>
        </motion.span>
      </div>

      <motion.button
        whileTap={{ scale: 0.9 }}
        className={`w-8 h-8 flex items-center justify-center rounded-full ${
          quantity >= max
            ? "bg-gray-200 text-gray-400 cursor-not-allowed"
            : "bg-primary-100 text-primary"
        }`}
        onClick={increment}
        disabled={quantity >= max}
      >
        <Plus size={16} />
      </motion.button>
    </div>
  );
};

export default QuantitySelector;
