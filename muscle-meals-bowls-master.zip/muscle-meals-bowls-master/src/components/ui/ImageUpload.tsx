import React, { useState, useRef } from "react";
import { Upload, X, Image as ImageIcon, Loader2 } from "lucide-react";
import { uploadFile, deleteFileByUrl } from "@/lib/storageService";
import { toast } from "sonner";

interface ImageUploadProps {
  value?: string; // Current image URL
  onChange: (url: string) => void; // Callback when image changes
  onRemove?: () => void; // Callback when image is removed
  folder: string; // Storage folder (e.g., "meal-plans", "meals")
  className?: string;
  disabled?: boolean;
  aspectRatio?: string; // CSS aspect ratio (e.g., "4/3", "1/1")
  maxSizeInMB?: number;
  acceptedTypes?: string[];
}

export default function ImageUpload({
  value,
  onChange,
  onRemove,
  folder,
  className = "",
  disabled = false,
  aspectRatio = "4/3",
  maxSizeInMB = 5,
  acceptedTypes = ["image/jpeg", "image/png", "image/webp"],
}: ImageUploadProps) {
  const [isUploading, setIsUploading] = useState(false);
  const [dragActive, setDragActive] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const validateFile = (file: File): string | null => {
    // Check file type
    if (!acceptedTypes.includes(file.type)) {
      return `Please select a valid image file (${acceptedTypes.join(", ")})`;
    }

    // Check file size
    const maxSizeInBytes = maxSizeInMB * 1024 * 1024;
    if (file.size > maxSizeInBytes) {
      return `File size must be less than ${maxSizeInMB}MB`;
    }

    return null;
  };

  const generateFileName = (file: File): string => {
    const timestamp = Date.now();
    const randomString = Math.random().toString(36).substring(2, 15);
    const extension = file.name.split(".").pop();
    return `${timestamp}_${randomString}.${extension}`;
  };

  const handleFileUpload = async (file: File) => {
    const validationError = validateFile(file);
    if (validationError) {
      toast.error(validationError);
      return;
    }

    setIsUploading(true);

    try {
      // Generate unique filename
      const fileName = generateFileName(file);

      // Upload to Firebase Storage
      const result = await uploadFile({
        folder,
        fileName,
        file,
        metadata: {
          uploadedAt: new Date().toISOString(),
          originalName: file.name,
        },
      });

      // Call onChange with the new URL
      onChange(result.url);
      toast.success("Image uploaded successfully!");
    } catch (error: any) {
      console.error("Upload error:", error);
      toast.error("Failed to upload image. Please try again.");
    } finally {
      setIsUploading(false);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleFileUpload(file);
    }
    // Reset input value to allow selecting the same file again
    e.target.value = "";
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragActive(false);

    const file = e.dataTransfer.files?.[0];
    if (file) {
      handleFileUpload(file);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setDragActive(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setDragActive(false);
  };

  const handleRemove = async () => {
    if (value && onRemove) {
      try {
        // Delete from Firebase Storage if it's a Firebase Storage URL
        if (value.includes("firebase")) {
          try {
            await deleteFileByUrl(value);
          } catch (deleteError) {
            console.warn("Could not delete file from storage:", deleteError);
            // Continue with removal from form even if storage deletion fails
          }
        }

        onRemove();
        toast.success("Image removed successfully!");
      } catch (error) {
        console.error("Remove error:", error);
        toast.error("Failed to remove image");
      }
    }
  };

  const openFileDialog = () => {
    if (!disabled && fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  return (
    <div className={`relative ${className}`}>
      <input
        ref={fileInputRef}
        type="file"
        accept={acceptedTypes.join(",")}
        onChange={handleFileSelect}
        className="hidden"
        disabled={disabled || isUploading}
      />

      <div
        className={`
          relative border-2 border-dashed rounded-lg overflow-hidden transition-colors
          ${dragActive ? "border-primary-500 bg-primary-50" : "border-gray-300"}
          ${
            disabled
              ? "opacity-50 cursor-not-allowed"
              : "cursor-pointer hover:border-primary-400"
          }
        `}
        style={{ aspectRatio }}
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onClick={openFileDialog}
      >
        {value ? (
          // Show uploaded image
          <div className="relative w-full h-full">
            <img
              src={value}
              alt="Uploaded image"
              className="w-full h-full object-cover"
            />
            {/* Remove button overlay */}
            {!disabled && (
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  handleRemove();
                }}
                className="absolute top-2 right-2 p-1 bg-red-500 text-white rounded-full hover:bg-red-600 transition-colors"
              >
                <X className="h-4 w-4" />
              </button>
            )}
            {/* Upload overlay when uploading */}
            {isUploading && (
              <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
                <Loader2 className="h-8 w-8 text-white animate-spin" />
              </div>
            )}
          </div>
        ) : (
          // Show upload area
          <div className="flex flex-col items-center justify-center h-full p-4 text-gray-500">
            {isUploading ? (
              <>
                <Loader2 className="h-8 w-8 animate-spin mb-2" />
                <p className="text-sm">Uploading...</p>
              </>
            ) : (
              <>
                <Upload className="h-8 w-8 mb-2" />
                <p className="text-sm text-center">
                  <span className="font-medium">Click to upload</span> or drag
                  and drop
                </p>
                <p className="text-xs text-gray-400 mt-1">
                  {acceptedTypes
                    .map((type) => type.split("/")[1])
                    .join(", ")
                    .toUpperCase()}{" "}
                  up to {maxSizeInMB}MB
                </p>
              </>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
