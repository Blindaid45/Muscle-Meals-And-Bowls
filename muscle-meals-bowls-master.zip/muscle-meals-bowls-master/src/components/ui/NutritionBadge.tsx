import { motion } from "framer-motion";

interface NutritionBadgeProps {
  label: string;
  value: string | number;
  unit?: string;
  color?: "blue" | "red" | "green" | "yellow" | "purple";
}

const NutritionBadge = ({
  label,
  value,
  unit = "g",
  color = "blue",
}: NutritionBadgeProps) => {
  const colorVariants = {
    blue: "bg-blue-100 text-blue-800 border-blue-200",
    red: "bg-red-100 text-red-800 border-red-200",
    green: "bg-green-100 text-green-800 border-green-200",
    yellow: "bg-yellow-100 text-yellow-800 border-yellow-200",
    purple: "bg-purple-100 text-purple-800 border-purple-200",
  };

  return (
    <motion.div
      className={`inline-flex flex-col items-center px-3 py-1 rounded-lg border ${colorVariants[color]}`}
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <span className="text-xs font-medium uppercase">{label}</span>
      <span className="text-sm font-bold">
        {value}
        {unit}
      </span>
    </motion.div>
  );
};

export default NutritionBadge;
