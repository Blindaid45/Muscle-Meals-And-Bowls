import { useEffect, useRef } from "react";
import { motion } from "framer-motion";

export const BackgroundBeams = () => {
  const beamRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!beamRef.current) return;

    const updateMousePosition = (ev: MouseEvent) => {
      if (!beamRef.current) return;
      const { clientX, clientY } = ev;
      beamRef.current.style.setProperty("--x", `${clientX}px`);
      beamRef.current.style.setProperty("--y", `${clientY}px`);
    };

    window.addEventListener("mousemove", updateMousePosition);

    return () => {
      window.removeEventListener("mousemove", updateMousePosition);
    };
  }, []);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="relative overflow-hidden"
      ref={beamRef}
    >
      <div className="absolute inset-0 z-0 bg-gradient-to-br from-primary/30 via-transparent to-secondary/30" />
      <div className="relative z-10">
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center bg-neutral-light [mask-image:radial-gradient(ellipse_at_center,transparent_20%,black)]"></div>
      </div>
    </motion.div>
  );
};