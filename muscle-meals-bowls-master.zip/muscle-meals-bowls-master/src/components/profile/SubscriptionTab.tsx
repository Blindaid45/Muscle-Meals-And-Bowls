import { motion } from "framer-motion";
import { Clock } from "lucide-react";
import Button from "../ui/Button";

const SubscriptionTab = () => {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.3 }}
      className="p-6"
    >
      <h2 className="text-2xl font-bold mb-6">Subscription</h2>

      <div className="text-center py-12">
        <Clock className="h-12 w-12 mx-auto text-gray-300 mb-4" />
        <h3 className="text-lg font-semibold mb-1">No active subscription</h3>
        <p className="text-gray-500 mb-6">
          Subscribe to get regular meal deliveries
        </p>
        <Button
          variant="accent"
          onClick={() => (window.location.href = "/subscriptions")}
        >
          View Plans
        </Button>
      </div>
    </motion.div>
  );
};

export default SubscriptionTab;
