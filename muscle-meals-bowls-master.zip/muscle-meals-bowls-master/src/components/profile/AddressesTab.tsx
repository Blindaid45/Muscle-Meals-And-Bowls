import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { MapPin } from "lucide-react";
import Button from "../ui/Button";
import { useAddress } from "../../hooks/useAddress";
import AddressModal from "../address/AddressModal";
import { AddressFormData } from "../../types/address";

interface AddressesTabProps {
  isActive: boolean;
}

const AddressesTab = ({ isActive }: AddressesTabProps) => {
  const [isAddressModalOpen, setIsAddressModalOpen] = useState(false);
  const [selectedAddress, setSelectedAddress] = useState<
    AddressFormData | undefined
  >();

  const {
    addresses,
    loading: addressLoading,
    getAddresses,
    createAddress,
    editAddress,
    removeAddress,
  } = useAddress();

  useEffect(() => {
    if (isActive) {
      getAddresses();
    }
  }, [isActive]);

  const handleAddAddress = async (data: AddressFormData) => {
    await createAddress(data);
    setIsAddressModalOpen(false);
  };

  const handleEditAddress = async (data: AddressFormData) => {
    if (selectedAddress?.id) {
      await editAddress(selectedAddress.id, data);
      setIsAddressModalOpen(false);
      setSelectedAddress(undefined);
    }
  };

  const handleDeleteAddress = async (id: string) => {
    if (confirm("Are you sure you want to delete this address?")) {
      await removeAddress(id);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.3 }}
      className="p-6"
    >
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Delivery Addresses</h2>
        <Button
          variant="accent"
          onClick={() => {
            setSelectedAddress(undefined);
            setIsAddressModalOpen(true);
          }}
        >
          Add New Address
        </Button>
      </div>

      {addressLoading ? (
        <div className="flex justify-center py-12">
          <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"></div>
        </div>
      ) : addresses.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {addresses.map((address) => (
            <div
              key={address.id}
              className="border rounded-lg p-4 relative hover:border-primary transition-colors"
            >
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <span className="font-medium">{address.name}</span>
                    <span className="text-xs px-2 py-1 rounded-full bg-primary-100 text-primary capitalize">
                      {address.type}
                    </span>
                    {address.isDefault && (
                      <span className="text-xs px-2 py-1 rounded-full bg-secondary-100 text-secondary">
                        Default
                      </span>
                    )}
                  </div>
                  <p className="text-sm text-gray-600">{address.street}</p>
                  {address.landmark && (
                    <p className="text-sm text-gray-600">
                      Landmark: {address.landmark}
                    </p>
                  )}
                  <p className="text-sm text-gray-600">
                    {address.area}, {address.city}, {address.state} -{" "}
                    {address.pincode}
                  </p>
                </div>

                <div className="flex gap-2">
                  <button
                    onClick={() => {
                      setSelectedAddress(address);
                      setIsAddressModalOpen(true);
                    }}
                    className="text-primary hover:text-primary-dark"
                  >
                    Edit
                  </button>
                  <button
                    onClick={() => handleDeleteAddress(address.id)}
                    className="text-red-500 hover:text-red-700"
                  >
                    Delete
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-12">
          <MapPin className="h-12 w-12 mx-auto text-gray-300 mb-4" />
          <h3 className="text-lg font-semibold mb-1">No addresses saved</h3>
          <p className="text-gray-500 mb-6">
            Add delivery addresses for easier checkout
          </p>
          <Button variant="accent" onClick={() => setIsAddressModalOpen(true)}>
            Add Address
          </Button>
        </div>
      )}

      <AddressModal
        isOpen={isAddressModalOpen}
        onClose={() => {
          setIsAddressModalOpen(false);
          setSelectedAddress(undefined);
        }}
        onSubmit={selectedAddress ? handleEditAddress : handleAddAddress}
        initialData={selectedAddress}
        loading={addressLoading}
      />
    </motion.div>
  );
};

export default AddressesTab;
