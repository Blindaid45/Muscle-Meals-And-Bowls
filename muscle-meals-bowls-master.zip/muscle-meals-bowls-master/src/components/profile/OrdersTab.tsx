import { motion } from "framer-motion";
import { ShoppingBag } from "lucide-react";
import Button from "../ui/Button";
import { useNavigate } from "react-router-dom";

const OrdersTab = () => {
  const navigate = useNavigate();

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.3 }}
      className="p-6"
    >
      <h2 className="text-2xl font-bold mb-6">Order History</h2>

      <div className="text-center py-12">
        <ShoppingBag className="h-12 w-12 mx-auto text-gray-300 mb-4" />
        <h3 className="text-lg font-semibold mb-1">No orders yet</h3>
        <p className="text-gray-500 mb-6">
          Your order history will appear here
        </p>
        <Button variant="accent" onClick={() => navigate("/meals")}>
          Browse Meals
        </Button>
      </div>
    </motion.div>
  );
};

export default OrdersTab;
