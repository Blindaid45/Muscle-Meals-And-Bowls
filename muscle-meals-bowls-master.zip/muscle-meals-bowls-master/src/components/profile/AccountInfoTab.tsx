import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import Button from "../ui/Button";
import { useProfile } from "../../hooks/useProfile";
import { toast } from "sonner";
import { User, UserProfile } from "../../types/user";

interface AccountInfoTabProps {
  user: User | null;
  profile: UserProfile | null;
  loading: boolean;
}

const AccountInfoTab = ({ user, profile, loading }: AccountInfoTabProps) => {
  const { updateProfile } = useProfile();

  // Form state
  const [formData, setFormData] = useState({
    displayName: user?.displayName || "",
    phoneNumber: "",
    weight: "",
    height: "",
    fitnessGoal: "",
  });

  // Update form data when profile is loaded
  useEffect(() => {
    if (profile) {
      setFormData({
        displayName: profile.displayName || user?.displayName || "",
        phoneNumber: profile.phoneNumber || "",
        weight: profile.weight?.toString() || "",
        height: profile.height?.toString() || "",
        fitnessGoal: profile.fitnessGoal || "",
      });
    }
  }, [profile, user]);

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await updateProfile({
        displayName: formData.displayName,
        phoneNumber: formData.phoneNumber,
        weight: formData.weight ? parseFloat(formData.weight) : null,
        height: formData.height ? parseFloat(formData.height) : null,
        fitnessGoal: formData.fitnessGoal,
      });
      toast.success("Profile updated successfully");
    } catch (error) {
      toast.error("Failed to update profile");
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.3 }}
      className="p-6"
    >
      <h2 className="text-2xl font-bold mb-6">Account Information</h2>

      <form className="space-y-6" onSubmit={handleSubmit}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="label" htmlFor="displayName">
              Full Name
            </label>
            <input
              type="text"
              id="displayName"
              name="displayName"
              className="input"
              value={formData.displayName}
              onChange={handleInputChange}
              placeholder="Enter your full name"
            />
          </div>

          <div>
            <label className="label">Email Address</label>
            <input
              type="email"
              className="input"
              value={user?.email || ""}
              disabled
            />
          </div>

          <div>
            <label className="label" htmlFor="phoneNumber">
              Phone Number
            </label>
            <input
              type="tel"
              id="phoneNumber"
              name="phoneNumber"
              className="input"
              value={formData.phoneNumber}
              onChange={handleInputChange}
              placeholder="Enter your phone number"
            />
          </div>
        </div>

        <hr />

        <div>
          <h3 className="font-semibold mb-3">Fitness Profile</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <label className="label" htmlFor="weight">
                Weight (kg)
              </label>
              <input
                type="number"
                id="weight"
                name="weight"
                className="input"
                value={formData.weight}
                onChange={handleInputChange}
                placeholder="Enter your weight"
              />
            </div>

            <div>
              <label className="label" htmlFor="height">
                Height (cm)
              </label>
              <input
                type="number"
                id="height"
                name="height"
                className="input"
                value={formData.height}
                onChange={handleInputChange}
                placeholder="Enter your height"
              />
            </div>

            <div>
              <label className="label" htmlFor="fitnessGoal">
                Fitness Goal
              </label>
              <select
                id="fitnessGoal"
                name="fitnessGoal"
                className="input"
                value={formData.fitnessGoal}
                onChange={handleInputChange}
              >
                <option value="">Select a goal</option>
                <option value="muscle_gain">Muscle Gain</option>
                <option value="fat_loss">Fat Loss</option>
                <option value="maintenance">Maintenance</option>
                <option value="performance">Athletic Performance</option>
              </select>
            </div>
          </div>
        </div>

        <div className="flex justify-end">
          <Button variant="accent" type="submit" disabled={loading}>
            {loading ? "Saving..." : "Save Changes"}
          </Button>
        </div>
      </form>
    </motion.div>
  );
};

export default AccountInfoTab;
