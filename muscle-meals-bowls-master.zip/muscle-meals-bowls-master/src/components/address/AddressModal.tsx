import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Home, Briefcase, MapPin } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from '@/components/ui/Button';
import { AddressFormData } from '@/types/address';
import { useAuth } from '@/hooks/useAuth';

interface AddressModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: AddressFormData) => void;
  initialData?: AddressFormData;
  loading?: boolean;
}

const defaultFormData: AddressFormData = {
  name: '',
  street: '',
  landmark: '',
  area: '',
  city: '',
  state: '',
  pincode: '',
  type: 'home'
};

export default function AddressModal({ 
  isOpen, 
  onClose, 
  onSubmit, 
  initialData,
  loading = false 
}: AddressModalProps) {
  const { user } = useAuth();
  const [formData, setFormData] = useState<AddressFormData>(defaultFormData);

  useEffect(() => {
    if (initialData) {
      setFormData(initialData);
    } else {
      setFormData({
        ...defaultFormData,
        name: user?.displayName || ''
      });
    }
  }, [initialData, isOpen, user?.displayName]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>{initialData ? 'Edit Address' : 'Add New Address'}</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="label" htmlFor="name">Full Name</label>
            <input
              type="text"
              id="name"
              name="name"
              className="input"
              value={formData.name}
              onChange={handleChange}
              placeholder="Enter your full name"
              required
            />
          </div>

          <div>
            <label className="label" htmlFor="street">Street Address</label>
            <textarea
              id="street"
              name="street"
              className="input min-h-[80px]"
              value={formData.street}
              onChange={handleChange}
              placeholder="Enter your street address"
              required
            />
          </div>

          <div>
            <label className="label" htmlFor="landmark">Landmark (Optional)</label>
            <input
              type="text"
              id="landmark"
              name="landmark"
              className="input"
              value={formData.landmark}
              onChange={handleChange}
              placeholder="Enter a nearby landmark"
            />
          </div>

          <div>
            <label className="label" htmlFor="area">Area/Locality</label>
            <input
              type="text"
              id="area"
              name="area"
              className="input"
              value={formData.area}
              onChange={handleChange}
              placeholder="Enter your area/locality"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="label" htmlFor="city">City</label>
              <input
                type="text"
                id="city"
                name="city"
                className="input"
                value={formData.city}
                onChange={handleChange}
                placeholder="Enter city"
                required
              />
            </div>

            <div>
              <label className="label" htmlFor="state">State</label>
              <input
                type="text"
                id="state"
                name="state"
                className="input"
                value={formData.state}
                onChange={handleChange}
                placeholder="Enter state"
                required
              />
            </div>
          </div>

          <div>
            <label className="label" htmlFor="pincode">PIN Code</label>
            <input
              type="text"
              id="pincode"
              name="pincode"
              className="input"
              value={formData.pincode}
              onChange={handleChange}
              placeholder="Enter PIN code"
              pattern="[0-9]{6}"
              maxLength={6}
              required
            />
          </div>

          <div>
            <label className="label">Address Type</label>
            <div className="flex gap-4">
              <label className="flex items-center">
                <input
                  type="radio"
                  name="type"
                  value="home"
                  checked={formData.type === 'home'}
                  onChange={handleChange}
                  className="sr-only"
                />
                <div className={`flex items-center gap-2 px-4 py-2 rounded-lg cursor-pointer border ${
                  formData.type === 'home' ? 'bg-primary-100 border-primary' : 'border-gray-200'
                }`}>
                  <Home className="h-4 w-4" />
                  <span>Home</span>
                </div>
              </label>

              <label className="flex items-center">
                <input
                  type="radio"
                  name="type"
                  value="work"
                  checked={formData.type === 'work'}
                  onChange={handleChange}
                  className="sr-only"
                />
                <div className={`flex items-center gap-2 px-4 py-2 rounded-lg cursor-pointer border ${
                  formData.type === 'work' ? 'bg-primary-100 border-primary' : 'border-gray-200'
                }`}>
                  <Briefcase className="h-4 w-4" />
                  <span>Work</span>
                </div>
              </label>

              <label className="flex items-center">
                <input
                  type="radio"
                  name="type"
                  value="other"
                  checked={formData.type === 'other'}
                  onChange={handleChange}
                  className="sr-only"
                />
                <div className={`flex items-center gap-2 px-4 py-2 rounded-lg cursor-pointer border ${
                  formData.type === 'other' ? 'bg-primary-100 border-primary' : 'border-gray-200'
                }`}>
                  <MapPin className="h-4 w-4" />
                  <span>Other</span>
                </div>
              </label>
            </div>
          </div>

          <DialogFooter>
            <Button
              variant="secondary"
              onClick={onClose}
              type="button"
            >
              Cancel
            </Button>
            <Button
              variant="primary"
              type="submit"
              disabled={loading}
            >
              {loading ? 'Saving...' : initialData ? 'Update Address' : 'Add Address'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}