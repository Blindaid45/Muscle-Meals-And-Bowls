import { useState } from "react";
import { Calendar } from "lucide-react";

import Button from "@/components/ui/Button";
import { PublicMealPlan } from "@/store/slices/publicMealPlanSlice";
import MealPlanNutrition from "../mealPlan/page/MealPlanNutrition";
import MealPlanItemsList from "../mealPlan/page/MealPlanItemsList";
import { Meal } from "@/store/slices/mealSlice";

interface SubscriptionPlanCardProps {
  plan: PublicMealPlan;
  getMealDetails: (mealId: string) => Meal | undefined;
  isMealLoading: (mealId: string) => boolean;
  onSubscribe: (plan: PublicMealPlan) => void;
}

const SubscriptionPlanCard = ({
  plan,
  getMealDetails,
  isMealLoading,
  onSubscribe,
}: SubscriptionPlanCardProps) => {
  const [expandedItems, setExpandedItems] = useState(false);

  const toggleExpand = () => {
    setExpandedItems(!expandedItems);
  };

  return (
    <div className="bg-white rounded-xl shadow-md overflow-hidden relative">
      {/* Featured tag */}
      {plan.category === "featured" && (
        <div className="absolute top-0 left-0 bg-amber-500 text-white px-4 py-1 rounded-br-lg flex items-center">
          <span className="text-xs font-medium">Featured</span>
        </div>
      )}

      <div className="p-6">
        {/* Card header with title and description */}
        <div className="mb-4">
          <h3 className="text-xl font-semibold mb-2">{plan.name}</h3>
          <p className="text-gray-600 text-sm line-clamp-2">
            {plan.description}
          </p>
        </div>

        {/* Duration badge */}
        <div className="inline-block bg-primary-100 text-primary px-3 py-1 rounded-full text-sm mb-4">
          {plan.duration} days
        </div>

        {/* Nutrition grid */}
        <MealPlanNutrition
          protein={plan.totalProtein}
          carbs={plan.totalCarbs}
          fat={plan.totalFat}
          fiber={plan.totalFiber}
          calories={plan.totalCalories}
        />

        {/* Price and tags */}
        <div className="flex justify-between items-center text-xs text-gray-500 mb-4 mt-4">
          <div className="text-primary text-lg font-semibold">
            ₹{plan.totalPrice.toFixed(2)}
          </div>
          <div className="flex flex-wrap gap-1">
            {plan.tags.map((tag, index) => (
              <span
                key={index}
                className="px-2 py-1 bg-gray-100 rounded-full text-xs"
              >
                {tag}
              </span>
            ))}
          </div>
        </div>

        {/* Meal Items Section */}
        <div className="border-t pt-4">
          <button
            onClick={toggleExpand}
            className="w-full text-left text-sm font-medium text-primary hover:text-primary-dark flex items-center justify-between"
          >
            <span>View Meal Items ({plan.items.length})</span>
            <span className="transform transition-transform duration-200">
              {expandedItems ? "▲" : "▼"}
            </span>
          </button>

          {expandedItems && (
            <MealPlanItemsList
              items={plan.items}
              getMealDetails={getMealDetails}
              isMealLoading={isMealLoading}
            />
          )}
        </div>

        {/* Subscribe button */}
        <div className="mt-4 flex justify-center">
          <Button
            variant="accent"
            size="lg"
            icon={<Calendar className="h-4 w-4" />}
            onClick={() => onSubscribe(plan)}
            className="w-full"
          >
            Subscribe Now
          </Button>
        </div>
      </div>
    </div>
  );
};

export default SubscriptionPlanCard;
