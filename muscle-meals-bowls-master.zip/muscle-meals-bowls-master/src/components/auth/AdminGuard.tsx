import { useEffect, useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { useAdmin } from "@/hooks/useAdmin";

interface AdminGuardProps {
  children: React.ReactNode;
}

export default function AdminGuard({ children }: AdminGuardProps) {
  const { user, loading: authLoading } = useAuth();
  const { isAdmin, loading: adminLoading, checkAuthState } = useAdmin();
  const navigate = useNavigate();
  const location = useLocation();
  const [authCheckAttempted, setAuthCheckAttempted] = useState(false);

  useEffect(() => {
    let timeoutId: NodeJS.Timeout;

    const checkAdminAuth = async () => {
      try {
        // Set a timeout to force-complete the auth check
        timeoutId = setTimeout(() => {
          setAuthCheckAttempted(true);
          if (adminLoading) {
            console.warn("Admin auth check timed out");
            navigate("/auth/admin");
          }
        }, 6000); // 6 seconds timeout

        await checkAuthState().unwrap();
        setAuthCheckAttempted(true);
      } catch (error) {
        console.error("Admin auth check failed:", error);
        setAuthCheckAttempted(true);
        navigate("/auth/admin");
      }
    };

    if (!authCheckAttempted) {
      checkAdminAuth();
    }

    return () => {
      if (timeoutId) clearTimeout(timeoutId);
    };
  }, [checkAuthState, navigate, adminLoading, authCheckAttempted]);

  useEffect(() => {
    if (authCheckAttempted && !authLoading && !adminLoading) {
      if (!user || !isAdmin) {
        // Store the current URL if it's an admin page for redirection after login
        const currentPath = location.pathname;
        if (currentPath.startsWith("/admin")) {
          sessionStorage.setItem("adminRedirectUrl", currentPath);
        }
        navigate("/auth/admin");
      }
    }
  }, [
    user,
    isAdmin,
    authLoading,
    adminLoading,
    navigate,
    location,
    authCheckAttempted,
  ]);

  // If auth check is completed and still loading, show loader
  if ((!authCheckAttempted || authLoading || adminLoading) && !isAdmin) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  return isAdmin ? <>{children}</> : null;
}
