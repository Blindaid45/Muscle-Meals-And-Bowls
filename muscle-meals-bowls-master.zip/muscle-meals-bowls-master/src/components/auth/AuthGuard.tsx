import { useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { useDispatch } from "react-redux";
import { checkAuthState } from "@/store/slices/authSlice";
import { AppDispatch } from "@/store/store";

interface AuthGuardProps {
  children: React.ReactNode;
}

export default function AuthGuard({ children }: AuthGuardProps) {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const dispatch = useDispatch<AppDispatch>();

  useEffect(() => {
    const checkAuth = async () => {
      try {
        await dispatch(checkAuthState()).unwrap();
      } catch (error) {
        console.error("Auth check failed:", error);
        redirectToLogin();
      }
    };
    checkAuth();
  }, [dispatch]);

  useEffect(() => {
    if (!loading && !user) {
      redirectToLogin();
    }
  }, [user, loading, location]);

  const redirectToLogin = () => {
    // Get the full current path including URL parameters
    const currentPath = window.location.pathname + window.location.search;

    // Only store redirect for non-auth pages
    if (!currentPath.includes("/auth/")) {
      // Use encodeURIComponent to safely encode the path
      const redirectUrl = encodeURIComponent(currentPath);
      navigate(`/auth/login?redirect=${redirectUrl}`);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  return user ? <>{children}</> : null;
}
