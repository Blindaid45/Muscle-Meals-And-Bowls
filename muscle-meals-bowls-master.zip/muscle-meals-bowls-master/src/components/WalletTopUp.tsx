import { useState } from "react";
import { useWallet } from "../hooks/useWallet";

interface WalletTopUpProps {
  onSuccess?: () => void;
  initialAmount?: number;
  showTransactions?: boolean;
  showBalance?: boolean;
}

export default function WalletTopUp({
  onSuccess,
  initialAmount = 0,
  showTransactions = true,
  showBalance = true,
}: WalletTopUpProps) {
  const [amount, setAmount] = useState<number>(initialAmount);
  const [error, setError] = useState<string | null>(null);

  // Use our wallet hook
  const { walletDetails, loading, handleTopUp} = useWallet();

  // Handle form submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (amount <= 0) {
      setError("Please enter a valid amount");
      return;
    }

    setError(null);

    try {
      // Process wallet top-up
      const success = await handleTopUp({ amount });

      if (success) {
        // Call onSuccess callback if provided
        if (onSuccess) {
          onSuccess();
        }
      }
    } catch (err) {
      console.error("Top-up failed:", err);
      setError(err instanceof Error ? err.message : "Failed to process top-up");
    }
  };

  // Quick amount selection options
  const amountOptions = [100, 300, 500, 1000];

  return (
    <div className="max-w-md mx-auto p-4 bg-white rounded-lg">
      {!showBalance
        ? null
        : walletDetails && (
            <div className="mb-4 p-3 bg-gray-50 rounded">
              <p className="font-semibold">
                Current Balance:
                <span className="text-green-600 ml-2">
                  ₹{walletDetails.wallet.balance}
                </span>
              </p>
            </div>
          )}

      <form onSubmit={handleSubmit}>
        <div className="mb-4">
          <label
            htmlFor="amount"
            className="block text-sm font-medium text-gray-700 mb-1"
          >
            Amount (₹)
          </label>
          <input
            type="number"
            id="amount"
            value={amount}
            onChange={(e) => setAmount(Number(e.target.value))}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
            placeholder="Enter amount"
            min="1"
          />
        </div>

        {/* Quick amount selection */}
        <div className="flex flex-wrap gap-2 mb-4">
          {amountOptions.map((option) => (
            <button
              key={option}
              type="button"
              onClick={() => setAmount(option)}
              className={`px-3 py-1 rounded ${
                amount === option
                  ? "bg-indigo-100 text-indigo-700 border border-indigo-300"
                  : "bg-gray-100 text-gray-700 border border-gray-200 hover:bg-gray-200"
              }`}
            >
              ₹{option}
            </button>
          ))}
        </div>

        {error && (
          <div className="mb-4 p-2 bg-red-50 text-red-600 rounded">{error}</div>
        )}

        <button
          type="submit"
          disabled={loading || amount <= 0}
          className={`w-full py-2 px-4 rounded-md text-white font-medium 
            ${
              loading || amount <= 0
                ? "bg-gray-400 cursor-not-allowed"
                : "bg-indigo-600 hover:bg-indigo-700"
            }`}
        >
          {loading ? "Processing..." : "Top Up Wallet"}
        </button>
      </form>

      {showTransactions &&
        walletDetails &&
        walletDetails.transactions &&
        walletDetails.transactions.length > 0 && (
          <div className="mt-6">
            <h3 className="text-lg font-semibold mb-2">Recent Transactions</h3>
            <div className="max-h-60 overflow-y-auto">
              {walletDetails.transactions.map((tx: any) => (
                <div
                  key={tx.transactionId}
                  className="p-2 border-b border-gray-100"
                >
                  <div className="flex justify-between">
                    <span
                      className={
                        tx.type === "credit" ? "text-green-600" : "text-red-600"
                      }
                    >
                      {tx.type === "credit" ? "+" : "-"} ₹{tx.amount}
                    </span>
                    <span className="text-gray-500 text-sm">
                      {new Date(tx.createdAt.seconds * 1000).toLocaleString()}
                    </span>
                  </div>
                  <p className="text-sm text-gray-700">{tx.description}</p>
                </div>
              ))}
            </div>
          </div>
        )}
    </div>
  );
}
