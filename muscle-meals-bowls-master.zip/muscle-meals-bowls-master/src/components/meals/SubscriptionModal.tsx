import { useState, useEffect } from "react";
import Modal from "@/components/ui/Modal";
import Button from "@/components/ui/Button";
import { Meal } from "@/store/slices/mealSlice";
import { Spinner } from "@/components/ui/spinner";
import { Calendar, Check, CreditCard, Info, X } from "lucide-react";
import { toast } from "sonner";
import { calculatePriceWithDiscount } from "@/utils/priceUtils";
import { DayPicker } from "react-day-picker";
import { format, addDays, differenceInDays, isBefore } from "date-fns";
import "react-day-picker/dist/style.css";

// Define frequency options
const SUBSCRIPTION_FREQUENCIES = [
  { id: "weekly", label: "Weekly", days: 7 },
  { id: "biweekly", label: "Bi-weekly", days: 14 },
  { id: "monthly", label: "Monthly", days: 30 },
];

// Define quick duration options
const QUICK_DURATIONS = [
  { days: 7, label: "1 Week" },
  { days: 14, label: "2 Weeks" },
  { days: 30, label: "1 Month" },
  { days: 90, label: "3 Months" },
];

interface SubscriptionModalProps {
  isOpen: boolean;
  onClose: () => void;
  meal: Meal;
  quantity: number;
}

// CSS for DatePicker
const datePickerStyles = `
  .rdp {
    --rdp-cell-size: 40px;
    --rdp-accent-color: #4f46e5;
    --rdp-background-color: #e0e7ff;
    margin: 0;
  }
  .rdp-day_selected, .rdp-day_selected:focus-visible, .rdp-day_selected:hover {
    background-color: var(--rdp-accent-color);
    color: white;
  }
  .rdp-button:hover:not([disabled]):not(.rdp-day_selected) {
    background-color: var(--rdp-background-color);
  }
`;

const SubscriptionModal = ({
  isOpen,
  onClose,
  meal,
  quantity,
}: SubscriptionModalProps) => {
  // State for selected dates
  const [startDate, setStartDate] = useState<Date>(new Date());
  const [endDate, setEndDate] = useState<Date>(() => {
    const date = new Date();
    date.setDate(date.getDate() + 7); // Default 7 days
    return date;
  });

  // State for showing date pickers
  const [showStartDatePicker, setShowStartDatePicker] = useState(false);
  const [showEndDatePicker, setShowEndDatePicker] = useState(false);

  // State for selected frequency
  const [frequency, setFrequency] = useState("weekly");

  // State for calculated price
  const [totalPrice, setTotalPrice] = useState(0);
  const [discountedPrice, setDiscountedPrice] = useState(0);
  const [isProcessing, setIsProcessing] = useState(false);

  // Calculate days between two dates
  const getDaysBetween = (start: Date, end: Date) => {
    return differenceInDays(end, start) + 1; // +1 to include both start and end days
  };

  // Set quick duration
  const setQuickDuration = (days: number) => {
    const newEndDate = addDays(startDate, days - 1);
    setEndDate(newEndDate);
  };

  // Calculate total price when dates change
  useEffect(() => {
    if (!startDate || !endDate) return;

    const days = getDaysBetween(startDate, endDate);
    const dailyPrice = meal.price * (quantity / meal.baseQuantity);
    const subtotal = dailyPrice * days;

    // Apply discount for subscriptions longer than 7 days
    let discount = 0;
    if (days > 7 && days <= 14) {
      discount = 0.1; // 10% discount
    } else if (days > 14 && days <= 30) {
      discount = 0.15; // 15% discount
    } else if (days > 30) {
      discount = 0.2; // 20% discount
    }

    setTotalPrice(subtotal);
    setDiscountedPrice(subtotal * (1 - discount));
  }, [startDate, endDate, meal.price, quantity, meal.baseQuantity]);

  // Handle proceed to payment
  const handleProceedToPayment = async () => {
    try {
      setIsProcessing(true);

      // Here you'll connect to Razorpay
      // For now, just show a success message
      toast.success(
        "Subscription successful! Payment integration coming soon."
      );

      onClose();
    } catch (error) {
      console.error("Error processing subscription:", error);
      toast.error("Failed to process subscription");
    } finally {
      setIsProcessing(false);
    }
  };

  // Helper to check if a date should be disabled
  const isDateDisabled = (date: Date) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return isBefore(date, today);
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Subscribe to Meal"
      size="lg"
    >
      <style>{datePickerStyles}</style>
      <div className="space-y-6">
        <div className="bg-blue-50 p-4 rounded-lg flex items-start space-x-3">
          <Info className="h-5 w-5 text-blue-500 mt-0.5" />
          <div className="text-sm text-blue-700">
            <p className="font-medium mb-1">Subscription Benefits</p>
            <ul className="list-disc pl-5 space-y-1">
              <li>Regular deliveries without manual ordering</li>
              <li>Discounts on longer subscription periods</li>
              <li>Flexible payment options (weekly/monthly)</li>
              <li>Easy modification or cancellation anytime</li>
            </ul>
          </div>
        </div>

        {/* Quick duration selection */}
        <div>
          <h3 className="text-sm font-medium mb-3">Quick Selection</h3>
          <div className="flex flex-wrap gap-2">
            {QUICK_DURATIONS.map((option) => (
              <button
                key={option.days}
                onClick={() => setQuickDuration(option.days)}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors
                  ${
                    getDaysBetween(startDate, endDate) === option.days
                      ? "bg-primary text-white"
                      : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                  }`}
              >
                {option.label}
              </button>
            ))}
          </div>
        </div>

        {/* Date Selection */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h3 className="text-sm font-medium mb-3">Start Date</h3>
            <div className="bg-gray-50 p-4 rounded-lg border">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <Calendar className="h-5 w-5 text-gray-500 inline mr-2" />
                  {format(startDate, "PPP")}
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowStartDatePicker(!showStartDatePicker)}
                >
                  {showStartDatePicker ? "Hide" : "Change"}
                </Button>
              </div>
              {showStartDatePicker && (
                <div className="bg-white border rounded-lg p-2">
                  <DayPicker
                    mode="single"
                    selected={startDate}
                    onSelect={(date) => {
                      if (date) {
                        setStartDate(date);
                        // If start date is after end date, adjust end date
                        if (isBefore(endDate, date)) {
                          setEndDate(addDays(date, 7));
                        }
                      }
                    }}
                    disabled={isDateDisabled}
                    fromMonth={new Date()}
                    toYear={new Date().getFullYear() + 1}
                  />
                </div>
              )}
            </div>
          </div>
          <div>
            <h3 className="text-sm font-medium mb-3">End Date</h3>
            <div className="bg-gray-50 p-4 rounded-lg border">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <Calendar className="h-5 w-5 text-gray-500 inline mr-2" />
                  {format(endDate, "PPP")}
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowEndDatePicker(!showEndDatePicker)}
                >
                  {showEndDatePicker ? "Hide" : "Change"}
                </Button>
              </div>
              {showEndDatePicker && (
                <div className="bg-white border rounded-lg p-2">
                  <DayPicker
                    mode="single"
                    selected={endDate}
                    onSelect={(date) => date && setEndDate(date)}
                    disabled={(date) => isBefore(date, startDate)}
                    fromMonth={startDate}
                    toYear={new Date().getFullYear() + 1}
                  />
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Show selected period summary */}
        <div className="bg-gray-50 p-4 rounded-lg">
          <p className="text-sm text-gray-700">
            <span className="font-medium">Selected Period: </span>
            {getDaysBetween(startDate, endDate)} days (
            {format(startDate, "dd MMM yyyy")} to{" "}
            {format(endDate, "dd MMM yyyy")})
          </p>
        </div>

        {/* Billing frequency */}
        <div>
          <h3 className="text-sm font-medium mb-3">Billing Frequency</h3>
          <div className="flex flex-wrap gap-2">
            {SUBSCRIPTION_FREQUENCIES.map((option) => (
              <button
                key={option.id}
                onClick={() => setFrequency(option.id)}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors
                  ${
                    frequency === option.id
                      ? "bg-primary text-white"
                      : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                  }`}
              >
                {option.label}
              </button>
            ))}
          </div>
          <p className="text-xs text-gray-500 mt-1">
            How often you want to be billed for this subscription
          </p>
        </div>

        {/* Price calculation */}
        <div className="bg-neutral-light p-4 rounded-lg space-y-3">
          <h3 className="font-semibold">Price Summary</h3>
          <div className="flex justify-between text-sm">
            <span>Daily price ({quantity}g):</span>
            <span>
              ₹{(meal.price * (quantity / meal.baseQuantity)).toFixed(2)}
            </span>
          </div>
          <div className="flex justify-between text-sm">
            <span>Subscription period:</span>
            <span>{getDaysBetween(startDate, endDate)} days</span>
          </div>
          <div className="flex justify-between text-sm">
            <span>Subtotal:</span>
            <span>₹{totalPrice.toFixed(2)}</span>
          </div>
          {discountedPrice < totalPrice && (
            <>
              <div className="flex justify-between text-sm text-green-600">
                <span>Discount:</span>
                <span>
                  -₹{(totalPrice - discountedPrice).toFixed(2)} (
                  {Math.round((1 - discountedPrice / totalPrice) * 100)}% off)
                </span>
              </div>
              <div className="pt-2 border-t flex justify-between font-bold">
                <span>Total:</span>
                <span>₹{discountedPrice.toFixed(2)}</span>
              </div>
            </>
          )}
          {discountedPrice === totalPrice && (
            <div className="pt-2 border-t flex justify-between font-bold">
              <span>Total:</span>
              <span>₹{totalPrice.toFixed(2)}</span>
            </div>
          )}
        </div>

        {/* Actions */}
        <div className="flex justify-end gap-3 pt-2">
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button
            onClick={handleProceedToPayment}
            disabled={isProcessing}
            icon={
              isProcessing ? (
                <Spinner size="sm" />
              ) : (
                <CreditCard className="h-4 w-4" />
              )
            }
          >
            {isProcessing ? "Processing..." : "Proceed to Payment"}
          </Button>
        </div>
      </div>
    </Modal>
  );
};

export default SubscriptionModal;
