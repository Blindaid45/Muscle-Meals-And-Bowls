import { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Check, Loader2 } from "lucide-react";
import { toast } from "sonner";
import Modal from "@/components/ui/Modal";
import Button from "@/components/ui/Button";
import {
  MealPlanItem,
  addMealToMealPlan,
  fetchUserMealPlans,
} from "@/store/slices/mealPlanSlice";
import { RootState } from "@/store/store";
import { Meal } from "@/store/slices/mealSlice";
import { MEAL_TIMES } from "../mealPlan/constants";

interface MealPlanSelectionModalProps {
  isOpen: boolean;
  onClose: () => void;
  meal: Meal;
  quantity: number;
}

// Weekday options
const WEEKDAYS = [
  { id: 1, label: "M" },
  { id: 2, label: "T" },
  { id: 3, label: "W" },
  { id: 4, label: "T" },
  { id: 5, label: "F" },
  { id: 6, label: "S" },
  { id: 7, label: "S" },
];

const MealPlanSelectionModal = ({
  isOpen,
  onClose,
  meal,
  quantity,
}: MealPlanSelectionModalProps) => {
  const dispatch = useDispatch();
  const { mealPlans, loading } = useSelector(
    (state: RootState) => state.mealPlans
  );

  const [selectedPlans, setSelectedPlans] = useState<string[]>([]);
  const [savingPlans, setSavingPlans] = useState<string[]>([]);
  const [selectedMealTimes, setSelectedMealTimes] = useState<string[]>([
    "lunch",
  ]);
  const [selectedWeekdays, setSelectedWeekdays] = useState<number[]>([1]); // Monday by default
  const [notes, setNotes] = useState<string>("");

  // Fetch user's meal plans when modal opens
  useEffect(() => {
    if (isOpen && mealPlans.length === 0) {
      dispatch(fetchUserMealPlans() as any);
    }
  }, [dispatch, isOpen, mealPlans.length]);

  // Reset selected plans when modal closes
  useEffect(() => {
    if (!isOpen) {
      setSelectedPlans([]);
      setSavingPlans([]);
      setSelectedMealTimes(["lunch"]);
      setSelectedWeekdays([1]);
      setNotes("");
    }
  }, [isOpen]);

  const handlePlanToggle = (planId: string) => {
    setSelectedPlans((prev) =>
      prev.includes(planId)
        ? prev.filter((id) => id !== planId)
        : [...prev, planId]
    );
  };

  const handleMealTimeToggle = (mealTimeId: string) => {
    setSelectedMealTimes((prev) =>
      prev.includes(mealTimeId)
        ? prev.filter((id) => id !== mealTimeId)
        : [...prev, mealTimeId]
    );
  };

  const handleWeekdayToggle = (weekdayId: number) => {
    setSelectedWeekdays((prev) =>
      prev.includes(weekdayId)
        ? prev.filter((id) => id !== weekdayId)
        : [...prev, weekdayId]
    );
  };

  const handleSave = async () => {
    if (selectedPlans.length === 0) {
      toast.error("Please select at least one meal plan");
      return;
    }

    if (selectedMealTimes.length === 0) {
      toast.error("Please select at least one meal time");
      return;
    }

    if (selectedWeekdays.length === 0) {
      toast.error("Please select at least one day of the week");
      return;
    }

    let totalAdditions = 0;
    let failedAdditions = 0;

    // Add meal to each selected plan
    for (const planId of selectedPlans) {
      setSavingPlans((prev) => [...prev, planId]);

      try {
        // Create a single meal plan item with arrays for meal times and days
        const mealItem: MealPlanItem = {
          mealId: meal.id as string,
          quantity: quantity,
          mealTimes: selectedMealTimes, // Use array of selected meal times
          dayNumbers: selectedWeekdays, // Use array of selected weekdays
          // Only include notes if they exist and are not empty
          ...(notes.trim() ? { notes: notes.trim() } : {}),
        };

        await dispatch(addMealToMealPlan({ planId, mealItem }) as any).unwrap();
        totalAdditions++;
      } catch (error) {
        console.error(`Failed to add meal to plan ${planId}:`, error);
        failedAdditions++;
      } finally {
        setSavingPlans((prev) => prev.filter((id) => id !== planId));
      }
    }

    // Close modal after all operations
    onClose();

    // Show appropriate success/error message
    if (failedAdditions === 0) {
      toast.success(
        `Added ${meal.name} to ${selectedPlans.length} meal plan${
          selectedPlans.length > 1 ? "s" : ""
        }`
      );
    } else {
      toast.warning(
        `Added ${meal.name} to ${totalAdditions} meal plans, but failed to add to ${failedAdditions} plans. Please try again.`
      );
    }
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Add to Meal Plan" size="lg">
      <div className="space-y-6">
        {loading && mealPlans.length === 0 ? (
          <div className="flex justify-center items-center py-8">
            <Loader2 className="w-8 h-8 text-primary animate-spin" />
            <span className="ml-2">Loading your meal plans...</span>
          </div>
        ) : mealPlans.length === 0 ? (
          <div className="text-center py-6">
            <p className="mb-4">You don't have any meal plans yet.</p>
            <Button variant="outline" onClick={onClose}>
              Create a Meal Plan
            </Button>
          </div>
        ) : (
          <>
            <p className="text-sm text-gray-600">
              Select the meal plans you want to add{" "}
              <span className="font-medium">{meal.name}</span> to:
            </p>

            <div className="border rounded-lg divide-y max-h-60 overflow-y-auto">
              {mealPlans.map((plan) => (
                <div
                  key={plan.id}
                  className="flex items-center p-3 cursor-pointer hover:bg-gray-50"
                  onClick={() => handlePlanToggle(plan.id as string)}
                >
                  <div
                    className={`w-5 h-5 rounded border flex items-center justify-center mr-3 ${
                      selectedPlans.includes(plan.id as string)
                        ? "bg-primary border-primary"
                        : "border-gray-300"
                    }`}
                  >
                    {selectedPlans.includes(plan.id as string) && (
                      <Check className="w-3.5 h-3.5 text-white" />
                    )}
                  </div>
                  <div className="flex-1">
                    <h4 className="font-medium">{plan.name}</h4>
                    <p className="text-sm text-gray-500 line-clamp-1">
                      {plan.description}
                    </p>
                  </div>
                  {savingPlans.includes(plan.id as string) && (
                    <Loader2 className="w-4 h-4 text-primary animate-spin" />
                  )}
                </div>
              ))}
            </div>

            <div className="space-y-5 pt-2">
              {/* Meal time selection */}
              <div>
                <label className="block text-sm font-medium mb-2">
                  Meal times
                </label>
                <div className="flex flex-wrap gap-2">
                  {MEAL_TIMES.map((mealTime) => (
                    <button
                      key={mealTime.id}
                      type="button"
                      onClick={() => handleMealTimeToggle(mealTime.id)}
                      className={`
                        h-10 px-4 rounded-full text-sm font-medium transition-colors
                        ${
                          selectedMealTimes.includes(mealTime.id)
                            ? "bg-primary text-white"
                            : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                        }
                      `}
                    >
                      {mealTime.label}
                    </button>
                  ))}
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  Select multiple meal times if needed
                </p>
              </div>

              {/* Weekday selection */}
              <div>
                <label className="block text-sm font-medium mb-2">
                  Days of the week
                </label>
                <div className="flex flex-wrap gap-2">
                  {WEEKDAYS.map((day) => (
                    <button
                      key={day.id}
                      type="button"
                      onClick={() => handleWeekdayToggle(day.id)}
                      className={`
                        w-9 h-9 rounded-full text-sm font-medium flex items-center justify-center transition-colors
                        ${
                          selectedWeekdays.includes(day.id)
                            ? "bg-primary text-white"
                            : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                        }
                      `}
                    >
                      {day.label}
                    </button>
                  ))}
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  Select multiple days (M = Monday, S = Sunday)
                </p>
              </div>

              <div>
                <label className="block text-sm font-medium mb-1">
                  Notes (optional)
                </label>
                <textarea
                  className="border-2 border-gray-300 rounded-md w-full resize-none p-2 focus:outline-none  focus:border-primary"
                  rows={2}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Add any special instructions or notes"
                />
              </div>
            </div>

            <div className="flex justify-end gap-3 pt-2">
              <Button variant="outline" onClick={onClose}>
                Cancel
              </Button>
              <Button
                onClick={handleSave}
                disabled={
                  selectedPlans.length === 0 ||
                  selectedMealTimes.length === 0 ||
                  selectedWeekdays.length === 0 ||
                  savingPlans.length > 0
                }
              >
                {savingPlans.length > 0 ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Saving...
                  </>
                ) : (
                  "Add to Selected Plans"
                )}
              </Button>
            </div>
          </>
        )}
      </div>
    </Modal>
  );
};

export default MealPlanSelectionModal;
