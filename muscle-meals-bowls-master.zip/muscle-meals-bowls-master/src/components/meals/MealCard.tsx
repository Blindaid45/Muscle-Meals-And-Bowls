import { motion } from "framer-motion";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  HoverCard,
  HoverCardContent,
  HoverCardTrigger,
} from "@/components/ui/hover-card";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import NutritionBadge from "@/components/ui/NutritionBadge";
import ImageSlider from "@/components/ui/ImageSlider";
import { Meal } from "@/store/slices/mealSlice";
import { formatTagForDisplay } from "@/utils/tagUtils";
import { getMealImages } from "@/utils/imageUtils";
import { useNavigate } from "react-router-dom";

interface MealCardProps {
  meal: Meal;
}

const MealCard = ({ meal }: MealCardProps) => {
  const navigate = useNavigate();

  // Extract tag for category display, default to first tag if available
  const category = meal.tags && meal.tags.length > 0 ? meal.tags[0] : "";

  const handleCardClick = () => {
    if (meal.id) {
      navigate(`/meals/${meal.id}`);
    }
  };

  return (
    <Card className="h-full overflow-hidden">
      <div onClick={handleCardClick} className="cursor-pointer">
        <CardHeader className="p-0">
          <div className="relative">
            <ImageSlider
              images={getMealImages(meal)}
              aspectRatio="landscape"
              showArrows={true}
              showDots={true}
              autoplay={false}
            />
            <div className="absolute top-2 right-2 z-20">
              <span className="badge badge-primary">
                {formatTagForDisplay(category)}
              </span>
            </div>
          </div>
        </CardHeader>

        <CardContent className="p-4">
          <CardTitle className="font-montserrat text-lg mb-2">
            {meal.name}
          </CardTitle>
          <CardDescription className="line-clamp-2">
            {meal.description}
          </CardDescription>

          <div className="flex flex-wrap gap-2 my-4">
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger>
                  <NutritionBadge
                    label="Protein"
                    value={meal.protein.toFixed(1)}
                    color="red"
                  />
                </TooltipTrigger>
                <TooltipContent>
                  <p>
                    Protein content per {meal.baseQuantity}
                    {meal.unit} serving
                  </p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>

            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger>
                  <NutritionBadge
                    label="Carbs"
                    value={meal.carbs.toFixed(1)}
                    color="yellow"
                  />
                </TooltipTrigger>
                <TooltipContent>
                  <p>
                    Carbohydrate content per {meal.baseQuantity}
                    {meal.unit} serving
                  </p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>

            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger>
                  <NutritionBadge
                    label="Fat"
                    value={meal.fat.toFixed(1)}
                    color="green"
                  />
                </TooltipTrigger>
                <TooltipContent>
                  <p>
                    Fat content per {meal.baseQuantity}
                    {meal.unit} serving
                  </p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>

            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger>
                  <NutritionBadge
                    label="Fiber"
                    value={meal.fiber.toFixed(1)}
                    color="purple"
                  />
                </TooltipTrigger>
                <TooltipContent>
                  <p>
                    Fiber content per {meal.baseQuantity}
                    {meal.unit} serving
                  </p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>

            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger>
                  <NutritionBadge
                    label="Calories"
                    value={meal.calories.toFixed(1)}
                    unit="kcal"
                    color="blue"
                  />
                </TooltipTrigger>
                <TooltipContent>
                  <p>
                    Calorie content per {meal.baseQuantity}
                    {meal.unit} serving
                  </p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </div>
        </CardContent>

        <CardFooter className="p-4 pt-0">
          <div className="flex items-center justify-between w-full">
            <HoverCard>
              <HoverCardTrigger>
                <p className="font-montserrat font-bold text-xl text-primary">
                  ₹{meal.price}
                  <span className="text-xs text-gray-500 font-normal ml-1">
                    per {meal.baseQuantity}
                    <span className="text-xs text-gray-500 font-normal ml-1">
                      {meal.unit}
                    </span>
                  </span>
                </p>
              </HoverCardTrigger>
              <HoverCardContent>
                <div className="space-y-2">
                  <p className="text-sm font-medium">Price Breakdown</p>
                  <p className="text-sm">
                    ₹{(meal.price / meal.baseQuantity).toFixed(2)} per{" "}
                    {meal.unit}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    Includes preparation and packaging
                  </p>
                </div>
              </HoverCardContent>
            </HoverCard>

            <motion.div
              whileHover={{ scale: 1.05 }}
              className="text-white bg-secondary px-3 py-1 rounded-full text-sm"
            >
              View Details
            </motion.div>
          </div>
        </CardFooter>
      </div>
    </Card>
  );
};

export default MealCard;
