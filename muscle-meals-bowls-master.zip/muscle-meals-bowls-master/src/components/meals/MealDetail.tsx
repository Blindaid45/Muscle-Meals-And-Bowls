import { useState, useEffect } from "react";
import { Utensils, Clock, Calendar } from "lucide-react";
import { Meal } from "@/store/slices/mealSlice";
import Button from "@/components/ui/Button";
import QuantitySelector from "@/components/ui/QuantitySelector";
import NutritionBadge from "@/components/ui/NutritionBadge";
import ImageSlider from "@/components/ui/ImageSlider";
import MealPlanSelectionModal from "@/components/meals/MealPlanSelectionModal";
import { formatTagForDisplay } from "@/utils/tagUtils";
import { calculatePriceWithDiscount } from "@/utils/priceUtils";
import { getMealImages } from "@/utils/imageUtils";
import { useDispatch, useSelector } from "react-redux";
import { RootState } from "@/store/store";
import { fetchUserMealPlans } from "@/store/slices/mealPlanSlice";
import {
  Tooltip,
  TooltipContent,
  TooltipTrigger,
  TooltipProvider,
} from "@/components/ui/tooltip";

interface MealDetailProps {
  meal: Meal;
}

const MealDetail = ({ meal }: MealDetailProps) => {
  console.log(meal);
  const dispatch = useDispatch();
  const { mealPlans } = useSelector((state: RootState) => state.mealPlans);
  const [quantity, setQuantity] = useState<number>(meal.baseQuantity);

  const [isMealPlanModalOpen, setIsMealPlanModalOpen] = useState(false);
  const [mealPlanInfo, setMealPlanInfo] = useState<{
    totalPlans: number;
    mealTimes: string[];
    weekdays: number[];
  } | null>(null);

  // Update quantity when meal changes
  useEffect(() => {
    setQuantity(meal.baseQuantity);
  }, [meal.baseQuantity, meal.id]);

  // Fetch user's meal plans when component mounts
  useEffect(() => {
    if (mealPlans.length === 0) {
      dispatch(fetchUserMealPlans() as any);
    }
  }, [dispatch, mealPlans.length]);

  // Calculate meal plan information when mealPlans change
  useEffect(() => {
    if (mealPlans.length > 0 && meal.id) {
      const plansWithMeal = mealPlans.filter((plan) =>
        plan.items.some((item) => item.mealId === meal.id)
      );

      if (plansWithMeal.length > 0) {
        const mealTimes = new Set<string>();
        const weekdays = new Set<number>();

        plansWithMeal.forEach((plan) => {
          plan.items
            .filter((item) => item.mealId === meal.id)
            .forEach((item) => {
              // Handle both new and old format
              if (item.mealTimes && item.mealTimes.length > 0) {
                // New format with arrays
                item.mealTimes.forEach((time) => mealTimes.add(time));
              } else if ((item as any).mealTime) {
                // Old format with single value
                mealTimes.add((item as any).mealTime);
              }

              if (item.dayNumbers && item.dayNumbers.length > 0) {
                // New format with arrays
                item.dayNumbers.forEach((day) => weekdays.add(day));
              } else if ((item as any).dayNumber) {
                // Old format with single value
                weekdays.add((item as any).dayNumber);
              }
            });
        });

        setMealPlanInfo({
          totalPlans: plansWithMeal.length,
          mealTimes: Array.from(mealTimes),
          weekdays: Array.from(weekdays),
        });
      } else {
        setMealPlanInfo(null);
      }
    }
  }, [mealPlans, meal.id]);

  // Calculate price with discount based on quantity
  const { price: calculatedPrice, discountPercentage } =
    calculatePriceWithDiscount(meal.price, meal.baseQuantity, quantity);

  // Calculate raw price without discount for display
  const rawPrice = (meal.price / meal.baseQuantity) * quantity;

  // Calculate price per gram for both raw and discounted price
  const rawPricePerGram = rawPrice / quantity;
  const discountedPricePerGram = calculatedPrice / quantity;

  // Calculate scaled nutritional values
  const scaleFactor = quantity / meal.baseQuantity;
  const scaledProtein = Math.round(meal.protein * scaleFactor * 10) / 10;
  const scaledCarbs = Math.round(meal.carbs * scaleFactor * 10) / 10;
  const scaledFat = Math.round(meal.fat * scaleFactor * 10) / 10;
  const scaledFiber = Math.round(meal.fiber * scaleFactor * 10) / 10;
  const scaledCalories = Math.round(meal.calories * scaleFactor * 10) / 10;

  // Get category from tags
  const category = meal.tags && meal.tags.length > 0 ? meal.tags[0] : "";

  const handleQuantityChange = (value: number) => {
    setQuantity(value);
  };

  const openMealPlanModal = () => {
    setIsMealPlanModalOpen(true);
  };

  const closeMealPlanModal = () => {
    setIsMealPlanModalOpen(false);
  };

  // Helper function to format meal times for display
  const formatMealTimes = (times: string[]) => {
    if (!times || times.length === 0) return "N/A";
    return times
      .map((time) => (time ? time.charAt(0).toUpperCase() + time.slice(1) : ""))
      .filter((time) => time) // Filter out empty strings
      .join(", ");
  };

  // Helper function to format weekdays for display
  const formatWeekdays = (days: number[]) => {
    if (!days || days.length === 0) return "N/A";
    const dayMap = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
    return days
      .sort((a, b) => a - b)
      .map((day) => (day >= 1 && day <= 7 ? dayMap[day - 1] : ""))
      .filter((day) => day) // Filter out empty strings
      .join(", ");
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="bg-white rounded-xl shadow-lg overflow-hidden">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Image section */}
          <div className="relative">
            <ImageSlider
              images={getMealImages(meal)}
              aspectRatio="portrait"
              showArrows={true}
              showDots={true}
              autoplay={false}
            />
          </div>

          {/* Details section */}
          <div className="p-6 md:p-8">
            <div className="flex items-center gap-2 mb-3">
              <span className="badge badge-primary">
                {formatTagForDisplay(category)}
              </span>
              {mealPlanInfo && (
                <TooltipProvider>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <div className="badge badge-secondary flex items-center gap-1 cursor-help">
                        <Calendar className="h-3 w-3" />
                        <span>In Meal Plans</span>
                      </div>
                    </TooltipTrigger>
                    <TooltipContent>
                      <div className="p-2">
                        <p className="font-medium mb-1">
                          Added to {mealPlanInfo.totalPlans} meal plan(s)
                        </p>
                        <p className="text-sm">
                          Meal times: {formatMealTimes(mealPlanInfo.mealTimes)}
                        </p>
                        <p className="text-sm">
                          Days: {formatWeekdays(mealPlanInfo.weekdays)}
                        </p>
                      </div>
                    </TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              )}
            </div>
            <h1 className="text-3xl font-bold font-montserrat mb-3">
              {meal.name}
            </h1>

            <div className="flex items-center gap-3 mb-6">
              <div className="flex items-center text-gray-500">
                <Utensils className="h-4 w-4 mr-1" />
                <span className="text-sm">Premium Quality</span>
              </div>
              <div className="flex items-center text-gray-500">
                <Clock className="h-4 w-4 mr-1" />
                <span className="text-sm">Fresh Daily</span>
              </div>
            </div>

            <p className="text-gray-600 mb-6">{meal.description}</p>

            {/* Nutrition information */}
            <div className="bg-neutral-light p-4 rounded-lg mb-6">
              <h3 className="font-semibold text-lg mb-3">
                Nutrition Facts (per {quantity}
                {meal.unit || "g"})
              </h3>
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
                <NutritionBadge
                  label="Protein"
                  value={scaledProtein}
                  color="red"
                />
                <NutritionBadge
                  label="Carbs"
                  value={scaledCarbs}
                  color="yellow"
                />
                <NutritionBadge label="Fat" value={scaledFat} color="green" />
                <NutritionBadge
                  label="Fiber"
                  value={scaledFiber}
                  color="purple"
                />
                <NutritionBadge
                  label="Calories"
                  value={scaledCalories}
                  unit="kcal"
                  color="blue"
                />
              </div>
            </div>

            {/* Quantity selector */}
            <div className="mb-6">
              <h3 className="font-semibold mb-3">Select Portion Size</h3>
              <div className="flex flex-col">
                <QuantitySelector
                  key={meal.id}
                  initialValue={meal.baseQuantity}
                  min={meal.unit === "g" ? 50 : 1}
                  max={meal.unit === "g" ? 500 : 50}
                  step={meal.unit === "g" ? 50 : 1}
                  unit={meal.unit || "g"}
                  baseQuantity={meal.baseQuantity}
                  onChange={handleQuantityChange}
                />
                <p className="text-xs text-gray-500 mt-2">
                  <span className="font-medium">Minimum quantity: </span>
                  {meal.baseQuantity}
                  {meal.unit || "g"} (set by chef)
                </p>
              </div>
            </div>

            {/* Price and action */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-4">
              <div className="mb-4 sm:mb-0">
                <p className="text-sm text-gray-500">Price</p>
                {discountPercentage > 0 ? (
                  <div>
                    <p className="text-sm text-gray-500 line-through">
                      ₹{rawPrice.toFixed(2)}
                      <span className="ml-1 text-xs">
                        (₹{rawPricePerGram.toFixed(2)}/{meal.unit || "g"})
                      </span>
                    </p>
                    <p className="text-3xl font-bold text-primary flex items-center">
                      ₹{calculatedPrice.toFixed(2)}
                      <span className="ml-2 px-2 py-1 bg-green-100 text-green-700 text-xs rounded-full">
                        {discountPercentage}% OFF
                      </span>
                    </p>
                    <p className="text-xs text-gray-600">
                      ₹{discountedPricePerGram.toFixed(2)}/{meal.unit || "g"} ·
                      Best value!
                    </p>
                  </div>
                ) : (
                  <div>
                    <p className="text-3xl font-bold text-primary">
                      ₹{calculatedPrice.toFixed(2)}
                    </p>
                    <p className="text-xs text-gray-600">
                      ₹{rawPricePerGram.toFixed(2)}/{meal.unit || "g"}
                    </p>
                  </div>
                )}
              </div>

              <div className="flex flex-col sm:flex-row gap-3 w-full sm:w-auto">
                <Button
                  variant="outline"
                  icon={<Calendar className="h-5 w-5" />}
                  onClick={openMealPlanModal}
                  className="w-full sm:w-auto"
                >
                  {mealPlanInfo ? "Update in Meal Plans" : "Add to Meal Plan"}
                </Button>
              </div>
            </div>

            {/* Other promotions */}
            <div className="text-sm text-gray-500 border-t pt-4">
              <p>
                🔥 Create a meal plan and subscribe for regular deliveries to
                get 15% off!
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Meal Plan Modal */}
      <MealPlanSelectionModal
        isOpen={isMealPlanModalOpen}
        onClose={closeMealPlanModal}
        meal={meal}
        quantity={quantity}
      />
    </div>
  );
};

export default MealDetail;
