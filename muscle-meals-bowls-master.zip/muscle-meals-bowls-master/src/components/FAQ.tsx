import { useState } from "react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { FAQ_DATA } from "./mealPlan/constants";
import { motion, AnimatePresence } from "framer-motion";

// FAQ data

interface FAQProps {
  className?: string;
  hideTitle?: boolean;
}

export function FAQ({ className = "", hideTitle = false }: FAQProps) {
  const [hoveredItem, setHoveredItem] = useState<string | null>(null);
  const [openItem, setOpenItem] = useState<string | null>(null);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className={`w-full max-w-4xl mx-auto px-4 ${className}`}
    >
      {!hideTitle && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2, duration: 0.5 }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl font-bold text-primary-500 mb-3">
            Frequently Asked Questions
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Find answers to common questions about our meal subscription service
          </p>
        </motion.div>
      )}

      <Accordion
        type="single"
        collapsible
        className="w-full space-y-4"
        onValueChange={(value) => setOpenItem(value)}
      >
        {FAQ_DATA.map((faq, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 * index, duration: 0.3 }}
          >
            <AccordionItem
              value={`item-${index}`}
              className={`
                border border-primary-100 rounded-lg overflow-hidden 
                bg-white shadow-sm transition-all duration-300 
                ${
                  hoveredItem === `item-${index}`
                    ? "shadow-md scale-[1.01]"
                    : ""
                }
                ${
                  openItem === `item-${index}`
                    ? "shadow-md border-primary-200"
                    : ""
                }
              `}
              onMouseEnter={() => setHoveredItem(`item-${index}`)}
              onMouseLeave={() => setHoveredItem(null)}
            >
              <AccordionTrigger className="text-left font-medium px-6 py-5 text-primary-500 hover:text-primary-600 hover:bg-primary-50 transition-colors">
                <div className="flex items-start">
                  <div className="flex-grow text-[16px]">{faq.question}</div>
                </div>
              </AccordionTrigger>
              <AccordionContent className="px-6 py-5 text-gray-700 bg-neutral-50 overflow-hidden">
                <AnimatePresence>
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    exit={{ opacity: 0, height: 0 }}
                    transition={{ duration: 0.2 }}
                    className="whitespace-pre-line"
                  >
                    {faq.answer}
                  </motion.div>
                </AnimatePresence>
              </AccordionContent>
            </AccordionItem>
          </motion.div>
        ))}
      </Accordion>
    </motion.div>
  );
}

export default FAQ;
