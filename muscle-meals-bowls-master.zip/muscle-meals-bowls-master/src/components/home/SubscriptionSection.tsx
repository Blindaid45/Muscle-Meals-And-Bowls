import { motion } from 'framer-motion';
import { Check, X } from 'lucide-react';
import Button from '../ui/Button';

const plans = [
  {
    name: 'Basic',
    price: '1999',
    period: 'per month',
    description: 'Perfect for those just starting their fitness journey',
    features: [
      '2 deliveries per week',
      'Custom portioned meals',
      '24/7 customer support',
      'Basic nutritional tracking',
      'Limited meal variety'
    ],
    notIncluded: [
      'Free delivery',
      'Weekend deliveries',
      'Nutritionist consultation'
    ],
    recommended: false,
    buttonText: 'Get Started'
  },
  {
    name: 'Premium',
    price: '2999',
    period: 'per month',
    description: 'Our most popular plan for serious fitness enthusiasts',
    features: [
      '3 deliveries per week',
      'Custom portioned meals',
      'Free delivery',
      'Advanced nutritional tracking',
      'Wide meal variety',
      '24/7 customer support',
      'Weekend deliveries'
    ],
    notIncluded: [
      'Nutritionist consultation'
    ],
    recommended: true,
    buttonText: 'Try Premium'
  },
  {
    name: 'Ultimate',
    price: '4499',
    period: 'per month',
    description: 'The complete package for professional athletes and bodybuilders',
    features: [
      'Unlimited deliveries',
      'Custom portioned meals',
      'Free priority delivery',
      'Complete nutritional tracking',
      'Full meal variety',
      '24/7 priority customer support',
      'Weekend deliveries',
      'Monthly nutritionist consultation'
    ],
    notIncluded: [],
    recommended: false,
    buttonText: 'Go Ultimate'
  }
];

const SubscriptionSection = () => {
  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <motion.h2 
            className="text-3xl md:text-4xl font-bold text-primary mb-4"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            Subscription Plans
          </motion.h2>
          <motion.p 
            className="text-gray-600"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            Choose a plan that works for you. Start with our free delivery trial for the first week.
          </motion.p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {plans.map((plan, index) => (
            <motion.div 
              key={index}
              className={`rounded-xl overflow-hidden shadow-lg ${
                plan.recommended 
                  ? 'border-2 border-primary relative' 
                  : 'border border-gray-200'
              }`}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.1 * index }}
              whileHover={{ y: -10 }}
            >
              {plan.recommended && (
                <div className="bg-primary text-white py-1 text-center text-sm font-medium">
                  MOST POPULAR
                </div>
              )}
              
              <div className="p-6">
                <h3 className="text-2xl font-bold mb-2">{plan.name}</h3>
                <p className="text-gray-600 mb-4">{plan.description}</p>
                
                <div className="mb-6">
                  <span className="text-4xl font-bold">₹{plan.price}</span>
                  <span className="text-gray-500"> {plan.period}</span>
                </div>
                
                <div className="mb-6">
                  <h4 className="font-medium mb-2">Includes:</h4>
                  <ul className="space-y-2">
                    {plan.features.map((feature, idx) => (
                      <li key={idx} className="flex items-start">
                        <Check className="h-5 w-5 text-success mr-2 flex-shrink-0 mt-0.5" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                
                {plan.notIncluded.length > 0 && (
                  <div className="mb-6">
                    <h4 className="font-medium mb-2">Not included:</h4>
                    <ul className="space-y-2">
                      {plan.notIncluded.map((feature, idx) => (
                        <li key={idx} className="flex items-start text-gray-500">
                          <X className="h-5 w-5 text-error mr-2 flex-shrink-0 mt-0.5" />
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
                
                <Button 
                  variant={plan.recommended ? 'accent' : 'primary'} 
                  fullWidth
                >
                  {plan.buttonText}
                </Button>
              </div>
            </motion.div>
          ))}
        </div>
        
        <div className="mt-12 text-center">
          <p className="text-gray-500">
            All plans include a free delivery trial for the first week. <br />
            No commitment required, cancel anytime.
          </p>
        </div>
      </div>
    </section>
  );
};

export default SubscriptionSection;