import { motion } from "framer-motion";
import Button from "../ui/Button";
import { ArrowRight, UtensilsCrossed } from "lucide-react";
import { BackgroundBeams } from "../ui/BackgroundBeams";
import { TextGradient } from "../ui/TextGradient";
import { Meteors } from "../ui/Meteors";
import { useNavigate } from "react-router-dom";

const HeroSection = () => {
  const navigate = useNavigate();

  return (
    <div className="relative min-h-screen bg-neutral-light overflow-hidden">
      <BackgroundBeams />
      <Meteors />

      <div className="container mx-auto px-4 py-16 md:py-24 flex flex-col-reverse md:flex-row items-center relative z-10">
        {/* Text Content */}
        <motion.div
          className="md:w-1/2 mt-8 md:mt-0 md:pr-12"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 0.3 }}
            className="inline-flex items-center rounded-full bg-primary-100 px-4 py-1 text-primary mb-6"
          >
            <UtensilsCrossed className="h-4 w-4 mr-2" />
            <span className="text-sm font-medium">
              First Week Free Delivery!
            </span>
          </motion.div>

          <h1 className="font-montserrat font-bold text-4xl md:text-5xl text-primary leading-tight mb-4">
            <TextGradient>
              Precision Nutrition <br />
              For Your Fitness Goals
            </TextGradient>
          </h1>

          <p className="text-gray-700 text-lg mb-8 leading-relaxed">
            Custom-portioned meals with exact nutritional specifications
            delivered to your doorstep. Designed for fitness enthusiasts,
            bodybuilders, and gym-goers.
          </p>

          <div className="flex flex-wrap gap-4">
            <Button
              variant="accent"
              size="lg"
              icon={<ArrowRight className="h-5 w-5" />}
              onClick={() => navigate("/meals")}
            >
              Explore Meals
            </Button>

            <Button
              variant="secondary"
              size="lg"
              onClick={() => navigate("/subscriptions")}
            >
              View Subscription Plans
            </Button>
          </div>

          <div className="flex flex-wrap items-center mt-8 gap-4">
            <div className="flex -space-x-2">
              {[1, 2, 3, 4].map((i) => (
                <motion.img
                  key={i}
                  src={`https://randomuser.me/api/portraits/men/${i + 20}.jpg`}
                  alt="Customer"
                  className="w-10 h-10 rounded-full border-2 border-white"
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.3, delay: 0.2 + i * 0.1 }}
                />
              ))}
            </div>
            <div>
              <div className="flex items-center">
                {[1, 2, 3, 4, 5].map((i) => (
                  <svg
                    key={i}
                    className="w-5 h-5 text-yellow-400"
                    fill="currentColor"
                    viewBox="0 0 20 20"
                  >
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path>
                  </svg>
                ))}
              </div>
              <p className="text-sm text-gray-600">
                <span className="font-medium">4.9</span> from 2,000+ reviews
              </p>
            </div>
          </div>
        </motion.div>

        {/* Image */}
        <motion.div
          className="md:w-1/2 relative"
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8 }}
        >
          <div className="relative max-w-md mx-auto">
            <div
              className="absolute inset-0 -left-4 -right-4 -top-4 -bottom-4 bg-gradient-to-r from-primary to-secondary rounded-3xl opacity-10"
              style={{ filter: "blur(40px)" }}
            />
            <motion.div
              className="relative rounded-3xl shadow-xl z-10 overflow-hidden"
              whileHover={{ scale: 1.02 }}
              transition={{ duration: 0.3 }}
            >
              <img
                src="https://images.pexels.com/photos/1640773/pexels-photo-1640773.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2"
                alt="Protein rich meal"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
            </motion.div>
            <motion.div
              className="absolute -bottom-4 left-4 right-4 bg-white p-4 rounded-xl shadow-lg z-20"
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.5 }}
              whileHover={{ y: -5 }}
            >
              <div className="flex items-center">
                <div className="w-12 h-12 bg-primary-100 rounded-full flex items-center justify-center mr-4">
                  <span className="text-primary font-bold">24g</span>
                </div>
                <div>
                  <p className="font-medium text-gray-900">High Protein</p>
                  <p className="text-sm text-gray-500">
                    Perfect post-workout meal
                  </p>
                </div>
              </div>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default HeroSection;
