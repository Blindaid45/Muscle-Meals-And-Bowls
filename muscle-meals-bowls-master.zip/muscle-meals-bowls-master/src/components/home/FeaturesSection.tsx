import { motion } from 'framer-motion';
import { Dumbbell, UtensilsCrossed, Truck, Receipt, AlarmClock } from 'lucide-react';

const features = [
  {
    icon: <Dumbbell className="h-6 w-6 text-primary" />,
    title: 'Precise Meal Portions',
    description: 'Customized portions with exact nutritional specifications. Perfect for tracking your macros.'
  },
  {
    icon: <UtensilsCrossed className="h-6 w-6 text-primary" />,
    title: 'Premium Quality Ingredients',
    description: 'Locally sourced fresh ingredients prepared daily for maximum nutrition and taste.'
  },
  {
    icon: <Truck className="h-6 w-6 text-primary" />,
    title: 'Free First-Week Delivery',
    description: 'Enjoy free delivery for your first week of orders. Experience convenience at no extra cost.'
  },
  {
    icon: <Receipt className="h-6 w-6 text-primary" />,
    title: 'Detailed Nutritional Info',
    description: 'Complete breakdown of macros and micros for each meal. Know exactly what you\'re eating.'
  },
  {
    icon: <AlarmClock className="h-6 w-6 text-primary" />,
    title: 'Scheduled Deliveries',
    description: 'Flexible scheduling to fit your routine. Get meals delivered when you need them.'
  }
];

const FeaturesSection = () => {
  return (
    <section className="py-16 bg-neutral-light">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <motion.h2 
            className="text-3xl md:text-4xl font-bold text-primary mb-4"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            Why Choose Muscle Meals?
          </motion.h2>
          <motion.p 
            className="text-gray-600"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            We're not just another meal delivery service. We understand the specific needs of fitness enthusiasts and bodybuilders.
          </motion.p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <motion.div 
              key={index}
              className="bg-white rounded-xl p-6 shadow-md hover:shadow-lg transition-shadow"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.1 * index }}
              whileHover={{ y: -5 }}
            >
              <div className="w-12 h-12 rounded-full bg-primary-100 flex items-center justify-center mb-4">
                {feature.icon}
              </div>
              <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;