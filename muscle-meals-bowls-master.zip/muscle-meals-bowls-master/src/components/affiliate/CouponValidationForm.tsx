import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useAffiliate } from "../../hooks/useAffiliate";
import { ValidateCouponRequest } from "../../types/affiliate";
import { toast } from "sonner";

interface CouponValidationFormProps {
  subscriptionAmount: number;
  subscriptionType: "weekly" | "monthly";
  onValidationResult?: (result: {
    isValid: boolean;
    discountAmount: number;
    finalAmount: number;
    affiliateId?: string;
  }) => void;
}

export default function CouponValidationForm({
  subscriptionAmount,
  subscriptionType,
  onValidationResult,
}: CouponValidationFormProps) {
  const [couponCode, setCouponCode] = useState("");
  const [showForm, setShowForm] = useState(false);

  const {
    handleValidateCoupon,
    validationResult,
    isValidating,
    clearCouponValidation,
  } = useAffiliate();

  // Handle coupon validation
  const handleValidation = async () => {
    if (!couponCode.trim()) return;

    const request: ValidateCouponRequest = {
      couponCode: couponCode.trim(),
      subscriptionAmount,
      subscriptionType,
    };

    const result = await handleValidateCoupon(request);

    if (result.success && result.validation) {
      onValidationResult?.(result.validation);

      if (result.validation.isValid) {
        toast.success(
          `Coupon applied successfully! You saved ₹${result.validation.discountAmount}`
        );
        // Hide the form after successful application
        setShowForm(false);
      } else {
        toast.error(result.validation.error || "Invalid coupon code");
      }
    } else {
      toast.error(result.error || "Failed to validate coupon code");
    }
  };

  // Handle remove coupon
  const handleRemoveCoupon = () => {
    setCouponCode("");
    clearCouponValidation();
    setShowForm(false);
    onValidationResult?.({
      isValid: false,
      discountAmount: 0,
      finalAmount: subscriptionAmount,
    });
    toast.success("Coupon removed successfully");
  };

  // Handle input change
  const handleInputChange = (value: string) => {
    setCouponCode(value);
    // Clear previous validation when user types
    if (validationResult) {
      clearCouponValidation();
      onValidationResult?.({
        isValid: false,
        discountAmount: 0,
        finalAmount: subscriptionAmount,
      });
    }
  };

  // Clear validation when component unmounts
  useEffect(() => {
    return () => {
      clearCouponValidation();
    };
  }, [clearCouponValidation]);

  // If coupon is applied and valid, show applied state
  if (validationResult?.isValid) {
    return (
      <div className="bg-white border border-gray-200 rounded-lg p-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-green-50 border border-green-200 rounded-md p-4"
        >
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <p className="text-green-800 font-medium mb-1">
                🎉 Coupon Applied: {couponCode.toUpperCase()}
              </p>
              <p className="text-green-700 text-sm mb-3">
                You saved ₹{validationResult.discountAmount} (
                {validationResult.discountPercentage}% off)
              </p>

              <div className="space-y-2 pt-2 border-t border-green-200">
                <div className="flex justify-between text-sm">
                  <span className="text-green-700">
                    Base Amount (after bulk discount):
                  </span>
                  <span className="text-green-700">₹{subscriptionAmount}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-green-700">Affiliate Discount:</span>
                  <span className="text-green-700">
                    -₹{validationResult.discountAmount}
                  </span>
                </div>
                <div className="flex justify-between font-medium">
                  <span className="text-green-800">Final Amount:</span>
                  <span className="text-green-800">
                    ₹{validationResult.finalAmount}
                  </span>
                </div>
              </div>
            </div>

            <motion.button
              onClick={handleRemoveCoupon}
              whileTap={{ scale: 0.95 }}
              className="bg-red-500 text-white hover:bg-red-600 px-4 py-2 rounded-md font-medium transition-colors ml-4"
            >
              Remove
            </motion.button>
          </div>
        </motion.div>
      </div>
    );
  }

  // If no coupon applied, show the form
  return (
    <div className="bg-white border border-gray-200 rounded-lg p-4">
      <div className="flex items-center justify-between mb-3">
        <h3 className="font-medium text-gray-900">Have a Promo Code?</h3>
        {!showForm && (
          <motion.button
            onClick={() => setShowForm(true)}
            whileTap={{ scale: 0.95 }}
            className="text-indigo-600 text-sm font-medium hover:text-indigo-700"
          >
            Apply Code
          </motion.button>
        )}
      </div>

      <AnimatePresence>
        {showForm && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
            className="overflow-hidden"
          >
            <div className="space-y-3">
              <div className="flex space-x-2">
                <input
                  type="text"
                  value={couponCode}
                  onChange={(e) => handleInputChange(e.target.value)}
                  placeholder="Enter promo code"
                  className="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                  disabled={isValidating}
                  autoFocus
                />
                <motion.button
                  onClick={handleValidation}
                  disabled={!couponCode.trim() || isValidating}
                  whileTap={{ scale: 0.95 }}
                  className={`px-4 py-2 rounded-md font-medium transition-colors ${
                    !couponCode.trim() || isValidating
                      ? "bg-gray-300 text-gray-500 cursor-not-allowed"
                      : "bg-indigo-600 text-white hover:bg-indigo-700"
                  }`}
                >
                  {isValidating ? (
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  ) : (
                    "Apply"
                  )}
                </motion.button>
                <motion.button
                  onClick={() => {
                    setShowForm(false);
                    setCouponCode("");
                    if (validationResult) {
                      clearCouponValidation();
                      onValidationResult?.({
                        isValid: false,
                        discountAmount: 0,
                        finalAmount: subscriptionAmount,
                      });
                    }
                  }}
                  whileTap={{ scale: 0.95 }}
                  className="px-4 py-2 rounded-md font-medium text-gray-600 hover:text-gray-800 bg-gray-100 hover:bg-gray-200 transition-colors"
                >
                  Cancel
                </motion.button>
              </div>

              {/* Show error message if validation failed */}
              {validationResult && !validationResult.isValid && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-red-50 border border-red-200 rounded-md p-3"
                >
                  <p className="text-red-800 font-medium">
                    ❌ Invalid Coupon Code
                  </p>
                  <p className="text-red-700 text-sm">
                    {validationResult.error ||
                      "Please check your coupon code and try again."}
                  </p>
                </motion.div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
