import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useAffiliate } from "../../hooks/useAffiliate";
import { toast } from "sonner";
import {
  CreditCard,
  Tag,
  Loader2,
  CheckCircle,
  AlertCircle,
  Info,
  Gift,
  TrendingUp,
  Zap,
  BarChart3,
} from "lucide-react";

interface AffiliateRegistrationFormProps {
  onSuccess?: () => void;
}

export default function AffiliateRegistrationForm({
  onSuccess,
}: AffiliateRegistrationFormProps) {
  const [formData, setFormData] = useState({
    desiredCode: "",
    upiId: "",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});

  const { handleCreateAffiliate, loading, error, clearAffiliateError } =
    useAffiliate();

  // Validate form
  const validateForm = () => {
    const errors: Record<string, string> = {};

    // Validate desired code
    if (!formData.desiredCode.trim()) {
      errors.desiredCode = "Promo code is required";
    } else if (formData.desiredCode.trim().length < 3) {
      errors.desiredCode = "Promo code must be at least 3 characters";
    } else if (!/^[A-Za-z0-9]+$/.test(formData.desiredCode.trim())) {
      errors.desiredCode = "Promo code can only contain letters and numbers";
    }

    // Validate UPI ID
    if (!formData.upiId.trim()) {
      errors.upiId = "UPI ID is required";
    } else {
      const upiRegex = /^[a-zA-Z0-9.\-_]{2,256}@[a-zA-Z][a-zA-Z0-9.\-_]{2,64}$/;
      if (!upiRegex.test(formData.upiId.trim())) {
        errors.upiId = "Please enter a valid UPI ID (e.g., username@upi)";
      }
    }

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  // Handle input changes
  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));

    // Clear field-specific error when user starts typing
    if (formErrors[field]) {
      setFormErrors((prev) => ({ ...prev, [field]: "" }));
    }

    // Clear global error
    if (error) {
      clearAffiliateError();
    }
  };

  // Handle form submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) return;

    setIsSubmitting(true);

    try {
      const result = await handleCreateAffiliate({
        desiredCode: formData.desiredCode.trim(),
        upiId: formData.upiId.trim(),
      });

      if (result.success) {
        toast.success("Affiliate account created successfully!", {
          description: `Your coupon code is: ${result.affiliate?.couponCode}`,
          icon: <CheckCircle className="text-green-500" size={16} />,
        });

        // Reset form
        setFormData({ desiredCode: "", upiId: "" });
        setFormErrors({});

        // Call success callback
        onSuccess?.();
      } else {
        toast.error("Failed to create affiliate account", {
          description: result.error,
          icon: <AlertCircle className="text-red-500" size={16} />,
        });
      }
    } catch (err) {
      toast.error("An unexpected error occurred");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <motion.div
      className="bg-white shadow-xl rounded-2xl overflow-hidden border border-gray-100"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
    >
      {/* Header */}
      <div className="bg-gradient-to-r from-indigo-600 to-purple-600 px-8 py-6 text-white">
        <div className="flex items-center gap-3 mb-2">
          <TrendingUp size={28} />
          <h2 className="text-2xl font-bold">Become an Affiliate</h2>
        </div>
        <p className="text-indigo-100">
          Join our affiliate program and earn commissions on every successful
          referral.
        </p>
      </div>

      <div className="p-8">
        {/* Benefits Section */}
        <motion.div
          className="bg-gradient-to-r from-indigo-50 to-purple-50 rounded-xl p-6 mb-8 border border-indigo-100"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
        >
          <div className="flex items-center gap-2 mb-4">
            <Gift className="text-indigo-600" size={24} />
            <h3 className="font-semibold text-gray-900 text-lg">
              Affiliate Benefits
            </h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="flex items-start gap-3">
              <div className="bg-green-100 rounded-full p-2">
                <TrendingUp className="text-green-600" size={16} />
              </div>
              <div>
                <p className="font-medium text-gray-900">High Commissions</p>
                <p className="text-sm text-gray-600">
                  10% on monthly, 5% on weekly subscriptions
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="bg-blue-100 rounded-full p-2">
                <Gift className="text-blue-600" size={16} />
              </div>
              <div>
                <p className="font-medium text-gray-900">Customer Discounts</p>
                <p className="text-sm text-gray-600">
                  Your referrals save money too
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="bg-purple-100 rounded-full p-2">
                <Zap className="text-purple-600" size={16} />
              </div>
              <div>
                <p className="font-medium text-gray-900">Quick Payments</p>
                <p className="text-sm text-gray-600">
                  Direct UPI transfers within 24-48 hours
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="bg-orange-100 rounded-full p-2">
                <BarChart3 className="text-orange-600" size={16} />
              </div>
              <div>
                <p className="font-medium text-gray-900">Real-time Tracking</p>
                <p className="text-sm text-gray-600">
                  Monitor all your earnings and referrals
                </p>
              </div>
            </div>
          </div>
        </motion.div>

        {/* Global Error */}
        <AnimatePresence>
          {error && (
            <motion.div
              className="mb-6 p-4 bg-red-50 text-red-600 rounded-lg border border-red-200 flex items-start gap-3"
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.3 }}
            >
              <AlertCircle size={20} className="flex-shrink-0 mt-0.5" />
              <span>{error}</span>
            </motion.div>
          )}
        </AnimatePresence>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Desired Promo Code */}
          <div>
            <label
              htmlFor="desiredCode"
              className="block text-sm font-semibold text-gray-700 mb-2"
            >
              Your Promo Code
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Tag className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="text"
                id="desiredCode"
                value={formData.desiredCode}
                onChange={(e) =>
                  handleInputChange("desiredCode", e.target.value)
                }
                className={`w-full pl-10 pr-16 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all ${
                  formErrors.desiredCode
                    ? "border-red-300 focus:ring-red-500 focus:border-red-500"
                    : "border-gray-300"
                }`}
                placeholder="Enter your desired code"
                maxLength={20}
              />
              <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                <span className="text-sm font-semibold text-indigo-600 bg-indigo-50 px-2 py-1 rounded">
                  MMB
                </span>
              </div>
            </div>
            {formErrors.desiredCode && (
              <motion.p
                className="mt-2 text-sm text-red-600 flex items-center gap-1"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
              >
                <AlertCircle size={14} />
                {formErrors.desiredCode}
              </motion.p>
            )}
            <div className="mt-2 flex items-center gap-2 text-xs text-gray-500">
              <Info size={14} />
              <span>
                Your final coupon code will be:{" "}
                <strong className="text-indigo-600">
                  {formData.desiredCode.toUpperCase()}MMB
                </strong>
              </span>
            </div>
          </div>

          {/* UPI ID */}
          <div>
            <label
              htmlFor="upiId"
              className="block text-sm font-semibold text-gray-700 mb-2"
            >
              UPI ID
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <CreditCard className="h-5 w-5 text-gray-400" />
              </div>
              <input
                type="text"
                id="upiId"
                value={formData.upiId}
                onChange={(e) => handleInputChange("upiId", e.target.value)}
                className={`w-full pl-10 pr-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all ${
                  formErrors.upiId
                    ? "border-red-300 focus:ring-red-500 focus:border-red-500"
                    : "border-gray-300"
                }`}
                placeholder="yourname@paytm"
              />
            </div>
            {formErrors.upiId && (
              <motion.p
                className="mt-2 text-sm text-red-600 flex items-center gap-1"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
              >
                <AlertCircle size={14} />
                {formErrors.upiId}
              </motion.p>
            )}
            <div className="mt-2 flex items-center gap-2 text-xs text-gray-500">
              <Info size={14} />
              <span>
                Your affiliate commissions will be sent to this UPI ID
              </span>
            </div>
          </div>

          {/* Submit Button */}
          <motion.button
            type="submit"
            disabled={isSubmitting || loading}
            whileTap={{ scale: 0.98 }}
            className={`w-full py-4 px-6 rounded-lg text-white font-semibold transition-all duration-200 ${
              isSubmitting || loading
                ? "bg-gray-400 cursor-not-allowed"
                : "bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 shadow-lg hover:shadow-xl"
            }`}
          >
            {isSubmitting || loading ? (
              <div className="flex items-center justify-center gap-2">
                <Loader2 className="w-5 h-5 animate-spin" />
                Creating Account...
              </div>
            ) : (
              <div className="flex items-center justify-center gap-2">
                <TrendingUp size={20} />
                Create Affiliate Account
              </div>
            )}
          </motion.button>
        </form>

        {/* Terms */}
        <motion.div
          className="mt-8 text-xs text-gray-500 text-center border-t border-gray-100 pt-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
        >
          <div className="flex items-center justify-center gap-2 mb-2">
            <Info size={14} />
            <span className="font-medium">Terms & Conditions</span>
          </div>
          <p>
            By creating an affiliate account, you agree to our affiliate terms
            and conditions. Commissions are processed within 24-48 hours of
            successful subscription completion.
          </p>
        </motion.div>
      </div>
    </motion.div>
  );
}
