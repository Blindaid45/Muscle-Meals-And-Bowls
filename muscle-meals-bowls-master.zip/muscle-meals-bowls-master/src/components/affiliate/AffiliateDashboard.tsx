import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useAffiliate } from "../../hooks/useAffiliate";
import {
  BarChart3,
  TrendingUp,
  Users,
  Clock,
  Copy,
  RefreshCw,
  Calendar,
  DollarSign,
  CheckCircle,
  XCircle,
  AlertCircle,
  Gift,
  Zap,
  Wallet,
} from "lucide-react";
import Avvvatars from "avvvatars-react";
import { useSelector } from "react-redux";
import { RootState } from "../../store/store";
import { toast } from "sonner";
import {
  collection,
  addDoc,
  serverTimestamp,
  query,
  where,
  getDocs,
  orderBy,
} from "firebase/firestore";
import { db, auth } from "../../lib/firebase";

export default function AffiliateDashboard() {
  const [selectedTab, setSelectedTab] = useState<"overview" | "history">(
    "overview"
  );
  const [isRequestingPayout, setIsRequestingPayout] = useState(false);
  const [pendingPayoutRequest, setPendingPayoutRequest] = useState<{
    id: string;
    status: string;
    [key: string]: any;
  } | null>(null);
  const [isLoadingPayoutStatus, setIsLoadingPayoutStatus] = useState(true);

  const {
    currentAffiliate,
    affiliateStats,
    couponUsages,
    loading,
    refreshAffiliateData,
  } = useAffiliate();

  const user = useSelector((state: RootState) => state.auth.user);

  // Fallback: Use currentAffiliate data if affiliateStats is not available
  const effectiveStats = affiliateStats || {
    totalEarnings: currentAffiliate?.totalEarnings || 0,
    totalReferrals: currentAffiliate?.totalReferrals || 0,
    pendingCommissions: 0,
    thisMonthEarnings: 0,
    thisMonthReferrals: 0,
  };

  // Check if current date is between 5-10 of the month
  const isPayoutWindowOpen = () => {
    const today = new Date();
    const day = today.getDate();
    return day >= 5 && day <= 10;
  };

  // Fetch pending payout request status
  const fetchPayoutRequestStatus = async () => {
    if (!currentAffiliate) return;

    setIsLoadingPayoutStatus(true);
    try {
      const payoutRequestsRef = collection(db, "payoutRequests");
      const pendingRequestQuery = query(
        payoutRequestsRef,
        where("affiliateId", "==", currentAffiliate.affiliateId),
        where("status", "in", ["pending", "approved"]),
        orderBy("createdAt", "desc")
      );
      const pendingSnapshot = await getDocs(pendingRequestQuery);

      if (!pendingSnapshot.empty) {
        const docData = pendingSnapshot.docs[0].data();
        const latestRequest = {
          id: pendingSnapshot.docs[0].id,
          status: docData.status || "",
          ...docData,
        };
        setPendingPayoutRequest(latestRequest);
      } else {
        setPendingPayoutRequest(null);
      }
    } catch (error) {
      console.error("Error fetching payout request status:", error);
    } finally {
      setIsLoadingPayoutStatus(false);
    }
  };

  // Fetch payout status when affiliate data is available
  useEffect(() => {
    if (currentAffiliate) {
      fetchPayoutRequestStatus();
    }
  }, [currentAffiliate]);

  // Get button state and text
  const getPayoutButtonState = () => {
    if (isLoadingPayoutStatus) {
      return {
        disabled: true,
        text: "Loading...",
        className: "bg-gray-400 text-gray-200 cursor-not-allowed",
        icon: null,
      };
    }

    if (pendingPayoutRequest) {
      const statusMap: { [key: string]: string } = {
        pending: "Payout Pending",
        approved: "Payout Approved",
      };
      const statusText =
        statusMap[pendingPayoutRequest.status] || "Payout Processing";

      return {
        disabled: true,
        text: statusText,
        className: "bg-yellow-500 text-white cursor-not-allowed",
        icon: Clock,
      };
    }

    if (effectiveStats.totalEarnings <= 0) {
      return {
        disabled: true,
        text: "No Earnings",
        className: "bg-gray-400 text-gray-200 cursor-not-allowed",
        icon: DollarSign,
      };
    }

    if (!isPayoutWindowOpen()) {
      const today = new Date();
      const day = today.getDate();
      const daysUntilWindow = day > 10 ? 35 - day : 5 - day;

      return {
        disabled: true,
        text: `Available ${
          daysUntilWindow > 0 ? `in ${daysUntilWindow} days` : "5-10th"
        }`,
        className: "bg-gray-400 text-gray-200 cursor-not-allowed",
        icon: Calendar,
      };
    }

    return {
      disabled: false,
      text: "Request Payout",
      className: "bg-green-500 text-white hover:bg-green-600 shadow-lg",
      icon: Wallet,
    };
  };

  const buttonState = getPayoutButtonState();

  // Enhanced refresh function
  const handleManualRefresh = async () => {
    try {
      await refreshAffiliateData();
      await fetchPayoutRequestStatus();
      toast.success("Data refreshed successfully!", {
        icon: <RefreshCw className="text-green-500" size={16} />,
      });
    } catch (error) {
      toast.error("Failed to refresh data");
    }
  };

  // Copy coupon code to clipboard
  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast.success("Coupon code copied to clipboard!", {
        icon: <Copy className="text-green-500" size={16} />,
      });
    } catch (err) {
      console.error("Failed to copy:", err);
      toast.error("Failed to copy coupon code");
    }
  };

  // Format date
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("en-IN", {
      year: "numeric",
      month: "short",
      day: "numeric",
    });
  };

  // Format currency
  const formatCurrency = (amount: number) => {
    return `₹${amount.toLocaleString("en-IN")}`;
  };

  // Handle payout request
  const handleRequestPayout = async () => {
    if (!currentAffiliate || !user) {
      toast.error("Please log in to request payout");
      return;
    }

    if (effectiveStats.totalEarnings <= 0) {
      toast.error("No earnings available for payout");
      return;
    }

    setIsRequestingPayout(true);

    try {
      // Check if user has a wallet
      const walletsRef = collection(db, "wallets");
      const walletQuery = query(walletsRef, where("userId", "==", user.uid));
      const walletSnapshot = await getDocs(walletQuery);

      if (walletSnapshot.empty) {
        toast.error("Wallet not found. Please contact support.");
        setIsRequestingPayout(false);
        return;
      }

      const walletBalance = walletSnapshot.docs[0].data().balance || 0;

      if (walletBalance < effectiveStats.totalEarnings) {
        toast.error("Insufficient wallet balance for payout request");
        setIsRequestingPayout(false);
        return;
      }

      // Check for existing pending payout requests
      const payoutRequestsRef = collection(db, "payoutRequests");
      const existingRequestQuery = query(
        payoutRequestsRef,
        where("affiliateId", "==", currentAffiliate.affiliateId),
        where("status", "==", "pending")
      );
      const existingRequests = await getDocs(existingRequestQuery);

      if (!existingRequests.empty) {
        toast.error("You already have a pending payout request");
        setIsRequestingPayout(false);
        return;
      }

      // Create payout request
      const payoutRequest = {
        affiliateId: currentAffiliate.affiliateId,
        userId: user.uid,
        requestedAmount: effectiveStats.totalEarnings,
        upiId: currentAffiliate.upiId,
        couponCode: currentAffiliate.couponCode,
        status: "pending",
        createdAt: serverTimestamp(),
        requestedAt: serverTimestamp(),
      };

      await addDoc(payoutRequestsRef, payoutRequest);

      // Create wallet transaction for scheduled amount
      const walletTransactionsRef = collection(db, "walletTransactions");
      const walletTransaction = {
        userId: user.uid,
        affiliateId: currentAffiliate.affiliateId,
        type: "debit",
        amount: effectiveStats.totalEarnings,
        status: "scheduled",
        description: `Payout request for ₹${effectiveStats.totalEarnings}`,
        payoutRequestId: null, // Will be updated when admin approves
        createdAt: serverTimestamp(),
      };

      await addDoc(walletTransactionsRef, walletTransaction);

      toast.success("Payout request submitted successfully!");
      await refreshAffiliateData();
    } catch (error) {
      console.error("Error requesting payout:", error);
      toast.error("Failed to submit payout request");
    } finally {
      setIsRequestingPayout(false);
    }
  };

  if (loading) {
    return (
      <div className="bg-white shadow-xl rounded-2xl p-8 border border-gray-100">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded mb-4"></div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="h-24 bg-gray-200 rounded-lg"></div>
            ))}
          </div>
          <div className="h-48 bg-gray-200 rounded-lg"></div>
        </div>
      </div>
    );
  }

  if (!currentAffiliate) {
    return null;
  }

  const tabs = [
    { id: "overview", label: "Overview", icon: BarChart3 },
    { id: "history", label: "Redemption History", icon: Clock },
  ];

  const stats = [
    {
      label: "Total Earnings",
      value: formatCurrency(effectiveStats.totalEarnings),
      icon: DollarSign,
      color: "text-green-600",
      bgColor: "bg-green-50",
      borderColor: "border-green-200",
    },
    {
      label: "Total Referrals",
      value: effectiveStats.totalReferrals,
      icon: Users,
      color: "text-blue-600",
      bgColor: "bg-blue-50",
      borderColor: "border-blue-200",
    },
    {
      label: "Pending Commissions",
      value: formatCurrency(effectiveStats.pendingCommissions),
      icon: Clock,
      color: "text-orange-600",
      bgColor: "bg-orange-50",
      borderColor: "border-orange-200",
    },
  ];

  const thisMonthStats = [
    {
      label: "This Month Earnings",
      value: formatCurrency(effectiveStats.thisMonthEarnings),
      change: "+12%",
      positive: true,
      icon: TrendingUp,
    },
    {
      label: "This Month Redemptions",
      value: effectiveStats.thisMonthReferrals,
      change: "+8%",
      positive: true,
      icon: Users,
    },
  ];

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "processed":
        return <CheckCircle className="text-green-500" size={16} />;
      case "pending":
        return <Clock className="text-orange-500" size={16} />;
      case "failed":
        return <XCircle className="text-red-500" size={16} />;
      default:
        return <AlertCircle className="text-gray-500" size={16} />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "processed":
        return "bg-green-100 text-green-800 border-green-200";
      case "pending":
        return "bg-orange-100 text-orange-800 border-orange-200";
      case "failed":
        return "bg-red-100 text-red-800 border-red-200";
      default:
        return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  return (
    <motion.div
      className="bg-white shadow-xl rounded-2xl overflow-hidden border border-gray-100"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
    >
      {/* Header */}
      <div className="bg-gradient-to-r from-indigo-600 to-purple-600 px-8 py-6 text-white">
        <div className="flex justify-between items-start">
          <div className="flex items-center gap-4">
            {user && (
              <Avvvatars
                value={user.email || user.uid}
                size={56}
                style="shape"
                shadow
              />
            )}
            <div>
              <h2 className="text-2xl font-bold flex items-center gap-2">
                <BarChart3 size={28} />
                Affiliate Dashboard
              </h2>
              <p className="text-indigo-100 mt-1">
                Track your earnings and referrals
              </p>
            </div>
          </div>
          <div className="flex gap-3">
            <motion.button
              onClick={handleRequestPayout}
              disabled={isRequestingPayout || buttonState.disabled}
              whileTap={{ scale: 0.95 }}
              className={`px-6 py-3 rounded-lg text-sm font-medium flex items-center gap-2 transition-colors ${buttonState.className}`}
            >
              {isRequestingPayout ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  Requesting...
                </>
              ) : (
                <>
                  {buttonState.icon && <buttonState.icon size={16} />}
                  {buttonState.text}
                </>
              )}
            </motion.button>
            <motion.button
              onClick={handleManualRefresh}
              whileTap={{ scale: 0.95 }}
              className="px-4 py-2 bg-white bg-opacity-20 rounded-lg text-sm font-medium hover:bg-opacity-30 transition-colors flex items-center gap-2 backdrop-blur-sm"
            >
              <RefreshCw size={16} />
              Refresh
            </motion.button>
          </div>
        </div>
      </div>

      <div className="p-8">
        {/* Coupon Code Section */}
        <div className="mb-8 bg-gradient-to-r from-indigo-50 to-purple-50 rounded-xl p-6 border border-indigo-100">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="bg-indigo-100 rounded-full p-3">
                <Gift className="text-indigo-600" size={24} />
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 text-lg">
                  Your Coupon Code
                </h3>
                <p className="text-sm text-gray-600">
                  Share this code to earn commissions
                </p>
              </div>
            </div>
            <motion.button
              onClick={() => copyToClipboard(currentAffiliate.couponCode)}
              whileTap={{ scale: 0.95 }}
              className="flex items-center space-x-3 px-6 py-3 bg-white hover:bg-gray-50 rounded-lg transition-colors shadow-sm border border-gray-200"
            >
              <span className="font-mono font-bold text-xl text-indigo-600">
                {currentAffiliate.couponCode}
              </span>
              <Copy className="text-gray-500" size={20} />
            </motion.button>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {stats.map((stat, index) => (
            <motion.div
              key={stat.label}
              className={`${stat.bgColor} ${stat.borderColor} border rounded-xl p-6 shadow-sm`}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ scale: 1.02 }}
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 mb-1">
                    {stat.label}
                  </p>
                  <p className={`text-2xl font-bold ${stat.color}`}>
                    {stat.value}
                  </p>
                </div>
                <div className={`${stat.bgColor} p-3 rounded-full`}>
                  <stat.icon className={stat.color} size={24} />
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* This Month Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          {thisMonthStats.map((stat, index) => (
            <motion.div
              key={stat.label}
              className="bg-gray-50 border border-gray-200 rounded-xl p-6 shadow-sm"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 + index * 0.1 }}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="bg-white rounded-full p-2 shadow-sm">
                    <stat.icon className="text-gray-600" size={20} />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-600">
                      {stat.label}
                    </p>
                    <p className="text-xl font-bold text-gray-900">
                      {stat.value}
                    </p>
                  </div>
                </div>
                <span
                  className={`text-sm font-medium px-3 py-1 rounded-full ${
                    stat.positive
                      ? "text-green-600 bg-green-100"
                      : "text-red-600 bg-red-100"
                  }`}
                >
                  {stat.change}
                </span>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Tabs */}
        <div className="border-b border-gray-200 mb-6">
          <nav className="flex space-x-8">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setSelectedTab(tab.id as any)}
                className={`py-3 px-1 border-b-2 font-medium text-sm transition-colors flex items-center gap-2 ${
                  selectedTab === tab.id
                    ? "border-indigo-500 text-indigo-600"
                    : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                }`}
              >
                <tab.icon size={18} />
                {tab.label}
              </button>
            ))}
          </nav>
        </div>

        {/* Tab Content */}
        <AnimatePresence mode="wait">
          {selectedTab === "overview" && (
            <motion.div
              key="overview"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
            >
              <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl p-8 border border-blue-100">
                <div className="flex items-center gap-3 mb-6">
                  <Zap className="text-indigo-600" size={28} />
                  <h3 className="font-semibold text-gray-900 text-xl">
                    How It Works
                  </h3>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-sm text-gray-700">
                  <div className="bg-white rounded-lg p-6 shadow-sm">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="bg-green-100 rounded-full p-2">
                        <TrendingUp className="text-green-600" size={20} />
                      </div>
                      <h4 className="font-semibold text-gray-900">
                        Monthly Subscriptions
                      </h4>
                    </div>
                    <ul className="space-y-2">
                      <li className="flex items-center gap-2">
                        <CheckCircle className="text-green-500" size={16} />
                        Your referral gets 10% discount
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle className="text-green-500" size={16} />
                        You earn 10% commission
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle className="text-green-500" size={16} />
                        Commission paid within 24-48 hours
                      </li>
                    </ul>
                  </div>
                  <div className="bg-white rounded-lg p-6 shadow-sm">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="bg-blue-100 rounded-full p-2">
                        <Calendar className="text-blue-600" size={20} />
                      </div>
                      <h4 className="font-semibold text-gray-900">
                        Weekly Subscriptions
                      </h4>
                    </div>
                    <ul className="space-y-2">
                      <li className="flex items-center gap-2">
                        <CheckCircle className="text-blue-500" size={16} />
                        Your referral gets 5% discount
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle className="text-blue-500" size={16} />
                        You earn 5% commission
                      </li>
                      <li className="flex items-center gap-2">
                        <CheckCircle className="text-blue-500" size={16} />
                        Commission paid within 24-48 hours
                      </li>
                    </ul>
                  </div>
                </div>
                <div className="mt-6 p-4 bg-white rounded-lg shadow-sm border border-gray-200">
                  <div className="flex items-center gap-2 mb-2">
                    <DollarSign className="text-indigo-600" size={20} />
                    <p className="font-semibold text-gray-900">
                      UPI ID: {currentAffiliate.upiId}
                    </p>
                  </div>
                  <p className="text-xs text-gray-500">
                    All commissions will be sent to this UPI ID
                  </p>
                </div>
              </div>
            </motion.div>
          )}

          {selectedTab === "history" && (
            <motion.div
              key="history"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
            >
              {couponUsages.length > 0 ? (
                <div className="space-y-4">
                  {couponUsages.map((usage, index) => (
                    <motion.div
                      key={usage.usageId}
                      className="border border-gray-200 rounded-xl p-6 bg-white shadow-sm hover:shadow-md transition-shadow"
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.05 }}
                    >
                      <div className="flex justify-between items-start mb-4">
                        <div className="flex items-center gap-3">
                          <div className="bg-indigo-100 rounded-full p-2">
                            <Gift className="text-indigo-600" size={20} />
                          </div>
                          <div>
                            <h4 className="font-semibold text-gray-900">
                              {usage.subscriptionType.charAt(0).toUpperCase() +
                                usage.subscriptionType.slice(1)}{" "}
                              Subscription
                            </h4>
                            <p className="text-sm text-gray-600 flex items-center gap-1">
                              <Calendar size={14} />
                              {formatDate(usage.createdAt)}
                            </p>
                          </div>
                        </div>
                        <div
                          className={`px-3 py-1 rounded-full text-xs font-medium border flex items-center gap-1 ${getStatusColor(
                            usage.status
                          )}`}
                        >
                          {getStatusIcon(usage.status)}
                          {usage.status.charAt(0).toUpperCase() +
                            usage.status.slice(1)}
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div className="bg-green-50 rounded-lg p-3">
                          <span className="text-gray-500 text-xs">
                            Customer Discount
                          </span>
                          <p className="font-semibold text-green-600">
                            -{formatCurrency(usage.discountAmount)}
                          </p>
                        </div>
                        <div className="bg-purple-50 rounded-lg p-3">
                          <span className="text-gray-500 text-xs">
                            Your Commission
                          </span>
                          <p className="font-semibold text-purple-600">
                            +{formatCurrency(usage.commissionAmount)}
                          </p>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <div className="bg-gray-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                    <BarChart3 className="text-gray-400" size={32} />
                  </div>
                  <h3 className="text-lg font-medium text-gray-900 mb-2">
                    No referrals yet
                  </h3>
                  <p className="text-gray-600 max-w-sm mx-auto">
                    Start sharing your coupon code to see your referral history
                    here.
                  </p>
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}
