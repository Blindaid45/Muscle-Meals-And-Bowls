export { default as AffiliateRegistrationForm } from './AffiliateRegistrationForm';
export { default as AffiliateDashboard } from './AffiliateDashboard';
export { default as CouponValidationForm } from './CouponValidationForm'; 