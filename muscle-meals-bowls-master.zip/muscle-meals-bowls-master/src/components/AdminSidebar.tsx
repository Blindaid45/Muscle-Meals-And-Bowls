import { Link, useLocation } from "react-router-dom";
import {
  LayoutDashboard,
  Users,
  UtensilsCrossed,
  Calendar,
  ClipboardList,
  LogOut,
  Settings,
  ChefHat,
  UserCheck,
} from "lucide-react";
import { useAdmin } from "@/hooks/useAdmin";
import { TextGradient } from "./ui/TextGradient";

interface SidebarLink {
  to: string;
  label: string;
  icon: React.ElementType;
}

export default function AdminSidebar() {
  const location = useLocation();
  const { isAdmin } = useAdmin();

  const links: SidebarLink[] = [
    {
      to: "/admin",
      label: "Dashboard",
      icon: LayoutDashboard,
    },
    {
      to: "/admin/meals",
      label: "Meals",
      icon: UtensilsCrossed,
    },
    {
      to: "/admin/meal-plans",
      label: "Meal Plans",
      icon: Calendar,
    },
    {
      to: "/admin/users",
      label: "Users",
      icon: Users,
    },
    {
      to: "/admin/orders",
      label: "Orders",
      icon: ClipboardList,
    },
    {
      to: "/admin/affiliate-management",
      label: "Affiliate Management",
      icon: UserCheck,
    },
    {
      to: "/admin/chef-guide",
      label: "Chef Guide",
      icon: ChefHat,
    },
    {
      to: "/admin/settings",
      label: "Settings",
      icon: Settings,
    },
  ];

  // Check if the current route is active
  const isActiveRoute = (path: string) => {
    if (path === "/admin") {
      return location.pathname === path;
    }
    return location.pathname.startsWith(path);
  };

  return (
    <div className="bg-white h-full shadow-md border-r border-gray-100 w-64 fixed left-0 top-0 z-10">
      <div className="p-4 border-b border-gray-100">
        <Link to="/admin">
          <div className="flex items-center space-x-2">
            <div className="h-8 w-8 bg-primary rounded-md flex items-center justify-center">
              <span className="text-white text-sm font-bold">A</span>
            </div>
            <h1 className="text-xl font-bold">
              <TextGradient>Admin Panel</TextGradient>
            </h1>
          </div>
        </Link>
      </div>

      <nav className="p-4 space-y-1">
        {links.map((link) => (
          <Link
            key={link.to}
            to={link.to}
            className={`flex items-center space-x-2 p-3 rounded-md transition-colors group ${
              isActiveRoute(link.to)
                ? "bg-primary text-white"
                : "text-gray-700 hover:bg-gray-50"
            }`}
          >
            <link.icon
              className={`h-5 w-5 ${
                isActiveRoute(link.to) ? "text-white" : "text-gray-500"
              } group-hover:text-primary ${
                isActiveRoute(link.to) ? "group-hover:text-white" : ""
              }`}
            />
            <span
              className={`${
                isActiveRoute(link.to)
                  ? "text-white"
                  : "group-hover:text-primary"
              }`}
            >
              {link.label}
            </span>
          </Link>
        ))}
      </nav>

      <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-gray-100">
        <Link
          to="/auth/login"
          className="flex items-center space-x-2 p-3 rounded-md text-gray-700 hover:bg-red-50 hover:text-red-500 transition-colors"
        >
          <LogOut className="h-5 w-5 text-red-500" />
          <span>Logout</span>
        </Link>
      </div>
    </div>
  );
}
