import { Link } from "react-router-dom";
import { Dumbbell, Instagram, Facebook, Twitter } from "lucide-react";

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-primary text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Logo and description */}
          <div className="col-span-1 md:col-span-2">
            <Link to="/" className="flex items-center space-x-2">
              <Dumbbell className="h-7 w-7" />
              <span className="font-montserrat font-bold text-xl">
                Muscle Meals
              </span>
            </Link>
            <p className="mt-4 text-primary-100">
              Precision nutrition for fitness enthusiasts. Custom portioned
              meals with exact nutritional specifications delivered to your
              doorstep.
            </p>
            <div className="mt-6 flex space-x-4">
              <a
                href="#"
                className="text-primary-100 hover:text-white transition-colors"
              >
                <Instagram className="h-6 w-6" />
              </a>
              <a
                href="#"
                className="text-primary-100 hover:text-white transition-colors"
              >
                <Facebook className="h-6 w-6" />
              </a>
              <a
                href="#"
                className="text-primary-100 hover:text-white transition-colors"
              >
                <Twitter className="h-6 w-6" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-montserrat font-semibold text-lg mb-4">
              Quick Links
            </h3>
            <ul className="space-y-2">
              <li>
                <Link
                  to="/meals"
                  className="text-primary-100 hover:text-white transition-colors"
                >
                  Meal Catalog
                </Link>
              </li>
              <li>
                <Link
                  to="/subscriptions"
                  className="text-primary-100 hover:text-white transition-colors"
                >
                  Subscription Plans
                </Link>
              </li>
              <li>
                <Link
                  to="/profile"
                  className="text-primary-100 hover:text-white transition-colors"
                >
                  My Account
                </Link>
              </li>
              {/* <li>
                <Link
                  to="/cart"
                  className="text-primary-100 hover:text-white transition-colors"
                >
                  Cart
                </Link>
              </li> */}
            </ul>
          </div>

          {/* Support */}
          <div>
            <h3 className="font-montserrat font-semibold text-lg mb-4">
              Support
            </h3>
            <ul className="space-y-2">
              <li>
                <Link
                  to="/faq"
                  className="text-primary-100 hover:text-white transition-colors"
                >
                  FAQ
                </Link>
              </li>
              {/* <li>
                <a
                  href="#"
                  className="text-primary-100 hover:text-white transition-colors"
                >
                  Delivery Information
                </a>
              </li> */}
              <li>
                <Link
                  to="/privacy-policy"
                  className="text-primary-100 hover:text-white transition-colors"
                >
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link
                  to="/terms"
                  className="text-primary-100 hover:text-white transition-colors"
                >
                  Terms & Conditions
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-6 border-t border-primary-400">
          <p className="text-center text-primary-100">
            &copy; {currentYear} Muscle Meals and Bowls. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
