import { User, MapPin, ShoppingBag, LogOut, Upload } from "lucide-react";
import { useState, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../hooks/useAuth";
import { useProfile } from "../../hooks/useProfile";
import { uploadFile } from "../../lib/storageService";
import { toast } from "sonner";

interface ProfileSidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  displayName: string;
  email: string | null;
  photoURL?: string | null;
}

const ProfileSidebar = ({
  activeTab,
  setActiveTab,
  displayName,
  email,
  photoURL,
}: ProfileSidebarProps) => {
  const navigate = useNavigate();
  const { logout } = useAuth();
  const { updateProfile } = useProfile();
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleLogout = async () => {
    try {
      await logout();
      toast.success("You've been successfully signed out");
      navigate("/");
    } catch (error) {
      console.error("Logout error:", error);
      toast.error("There was a problem signing you out. Please try again.");
    }
  };

  const handlePhotoClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Check if file is an image
    if (!file.type.startsWith("image/")) {
      toast.error("Please select an image file (JPEG, PNG, etc.)");
      return;
    }

    // Check file size (limit to 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast.error("Image size should be less than 5MB");
      return;
    }

    try {
      setUploading(true);
      // Generate a unique filename
      const fileExtension = file.name.split(".").pop();
      const fileName = `profile_${Date.now()}.${fileExtension}`;

      // Upload file to Firebase Storage
      const result = await uploadFile({
        folder: "profile_photos",
        fileName,
        file,
      });

      // Update user profile with the new photo URL
      await updateProfile({ photoURL: result.url });

      toast.success("Profile picture updated successfully");
    } catch (error) {
      console.error("Error uploading profile picture:", error);
      toast.error(
        "We couldn't update your profile picture. Please try again later."
      );
    } finally {
      setUploading(false);
      // Reset the file input
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
    }
  };

  return (
    <div className="md:w-1/4">
      <div className="bg-white rounded-xl shadow-md overflow-hidden sticky top-24">
        <div className="p-6 border-b">
          <div className="flex items-center">
            <div className="relative">
              <div
                className="w-16 h-16 rounded-full bg-neutral-light flex items-center justify-center overflow-hidden cursor-pointer"
                onClick={handlePhotoClick}
              >
                {photoURL ? (
                  <img
                    src={photoURL}
                    alt={displayName}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <User className="h-8 w-8 text-gray-400" />
                )}

                <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                  <Upload className="h-5 w-5 text-white" />
                </div>
              </div>
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileChange}
                accept="image/*"
                className="hidden"
                disabled={uploading}
              />
              {uploading && (
                <div className="absolute inset-0 flex items-center justify-center bg-white bg-opacity-70 rounded-full">
                  <div className="w-5 h-5 border-2 border-primary border-t-transparent rounded-full animate-spin"></div>
                </div>
              )}
            </div>
            <div className="ml-4">
              <h2 className="font-bold text-lg">
                {displayName || "Guest User"}
              </h2>
              <p className="text-sm text-gray-500">{email}</p>
            </div>
          </div>
        </div>

        <div className="p-2">
          <button
            className={`w-full text-left px-4 py-3 rounded-lg transition-colors ${
              activeTab === "account"
                ? "bg-primary-100 text-primary font-medium"
                : "hover:bg-gray-100"
            }`}
            onClick={() => setActiveTab("account")}
          >
            <div className="flex items-center">
              <User className="h-5 w-5 mr-3" />
              <span>Account Information</span>
            </div>
          </button>

          <button
            className={`w-full text-left px-4 py-3 rounded-lg transition-colors ${
              activeTab === "addresses"
                ? "bg-primary-100 text-primary font-medium"
                : "hover:bg-gray-100"
            }`}
            onClick={() => setActiveTab("addresses")}
          >
            <div className="flex items-center">
              <MapPin className="h-5 w-5 mr-3" />
              <span>Delivery Addresses</span>
            </div>
          </button>

          <button
            className={`w-full text-left px-4 py-3 rounded-lg transition-colors ${
              activeTab === "orders"
                ? "bg-primary-100 text-primary font-medium"
                : "hover:bg-gray-100"
            }`}
            onClick={() => setActiveTab("orders")}
          >
            <div className="flex items-center">
              <ShoppingBag className="h-5 w-5 mr-3" />
              <span>Order History</span>
            </div>
          </button>

          <hr className="my-2" />

          <button
            className="w-full text-left px-4 py-3 rounded-lg transition-colors text-red-600 hover:bg-red-50"
            onClick={handleLogout}
          >
            <div className="flex items-center">
              <LogOut className="h-5 w-5 mr-3" />
              <span>Logout</span>
            </div>
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProfileSidebar;
