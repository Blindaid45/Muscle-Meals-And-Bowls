import { useState, useRef, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import {
  // ShoppingCart,
  Menu,
  X,
  User,
  Wallet,
  Coffee,
  ChevronDown,
  Handshake,
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useAuth } from "../../hooks/useAuth";
import { cn } from "@/lib/utils";

const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [showProfileDropdown, setShowProfileDropdown] = useState(false);
  const profileRef = useRef<HTMLDivElement>(null);
  const location = useLocation();
  const { user } = useAuth();

  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);

  // Close dropdown when clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (
        profileRef.current &&
        !profileRef.current.contains(event.target as Node)
      ) {
        setShowProfileDropdown(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const profileMenuItems = [
    { title: "Profile", href: "/profile", icon: User },
    { title: "Wallet", href: "/user/wallet", icon: Wallet },
    { title: "My Meal Plans", href: "/user/meal-plans", icon: Coffee },
    { title: "Affiliate Dashboard", href: "/user/affiliate", icon: Handshake },
  ];

  const navItems = [
    { title: "Meal Catalog", href: "/meals" },
    { title: "Subscription Plans", href: "/subscriptions" },
  ];

  return (
    <header className="sticky top-0 z-50 bg-white shadow-sm">
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-2">
            <img
              src="/muscle-meals-logo.svg"
              alt="MMB"
              className="h-10 w-10 rounded-full p-1"
            />
            <span className="font-montserrat font-bold text-xl text-primary">
              MMB
            </span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-6">
            {navItems.map((item) => (
              <Link
                key={item.title}
                to={item.href}
                className={cn(
                  "text-sm font-medium transition-colors hover:text-primary",
                  location.pathname === item.href
                    ? "text-primary"
                    : "text-neutral"
                )}
              >
                {item.title}
              </Link>
            ))}
          </div>

          {/* Actions */}
          <div className="flex items-center space-x-4">
            {/* {user && (
              <Link to="/cart" className="relative">
                <ShoppingCart className="h-6 w-6 text-neutral hover:text-primary transition-colors" />
                <span className="absolute -top-1 -right-1 bg-secondary text-white text-xs rounded-full h-4 w-4 flex items-center justify-center">
                  0
                </span>
              </Link>
            )} */}

            {user ? (
              <div
                ref={profileRef}
                className="relative"
                onMouseEnter={() => setShowProfileDropdown(true)}
                onMouseLeave={() => setShowProfileDropdown(false)}
              >
                <button
                  className="flex items-center space-x-1 text-neutral hover:text-primary transition-colors"
                  onClick={() => setShowProfileDropdown(!showProfileDropdown)}
                >
                  <User className="h-6 w-6" />
                  <span className="hidden md:inline font-medium">Profile</span>
                  <ChevronDown className="h-4 w-4" />
                </button>

                {/* Profile Dropdown */}
                <AnimatePresence>
                  {showProfileDropdown && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 10 }}
                      transition={{ duration: 0.2 }}
                      className="absolute right-0 mt-2 w-48 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 py-1 z-50"
                    >
                      {profileMenuItems.map((item) => {
                        const Icon = item.icon;
                        return (
                          <Link
                            key={item.title}
                            to={item.href}
                            className="flex items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 hover:text-primary"
                            onClick={() => setShowProfileDropdown(false)}
                          >
                            <Icon className="mr-2 h-4 w-4" />
                            {item.title}
                          </Link>
                        );
                      })}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            ) : (
              <>
                {/* Desktop Login */}
                <Link
                  to="/auth/login"
                  className="hidden md:flex items-center space-x-1 text-neutral hover:text-primary transition-colors"
                >
                  <User className="h-5 w-5" />
                  <span className="font-medium">Login</span>
                </Link>

                {/* Mobile Login Button */}
                <Link
                  to="/auth/login"
                  className="md:hidden text-neutral hover:text-primary transition-colors"
                  aria-label="Login"
                >
                  <User className="h-6 w-6" />
                </Link>
              </>
            )}

            {/* Mobile menu button */}
            <button
              className="md:hidden text-neutral focus:outline-none"
              onClick={toggleMenu}
              aria-label="Toggle menu"
            >
              {isMenuOpen ? (
                <X className="h-6 w-6" />
              ) : (
                <Menu className="h-6 w-6" />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Navigation Menu */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="md:hidden overflow-hidden bg-white border-t"
          >
            <div className="container mx-auto px-4 py-3 space-y-4">
              {navItems.map((item) => (
                <Link
                  key={item.title}
                  to={item.href}
                  className={cn(
                    "block py-2 font-medium",
                    location.pathname === item.href
                      ? "text-primary"
                      : "text-neutral hover:text-primary"
                  )}
                  onClick={() => setIsMenuOpen(false)}
                >
                  {item.title}
                </Link>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
};

export default Navbar;
