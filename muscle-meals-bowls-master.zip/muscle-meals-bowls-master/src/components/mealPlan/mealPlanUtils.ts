// Helper function to format meal time
export const formatMealTime = (time: string): string => {
  return time.charAt(0).toUpperCase() + time.slice(1);
};

// Helper function to format multiple meal times
export const formatMealTimes = (times: string[]): string => {
  if (!times || times.length === 0) return "";
  return times.map((time) => formatMealTime(time)).join(", ");
};

// Helper function to format weekday
export const formatWeekday = (day: number): string => {
  const days = [
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday",
    "Sunday",
  ];
  return days[day - 1];
};

// Helper function to format multiple weekdays
export const formatWeekdays = (days: number[]): string => {
  if (!days || days.length === 0) return "";
  return days.map((day) => formatWeekday(day)).join(", ");
};

// Process a tag string: trim, lowercase, replace spaces with hyphens
export const processTag = (tag: string): string => {
  return tag.trim().toLowerCase().replace(/\s+/g, "-");
};
