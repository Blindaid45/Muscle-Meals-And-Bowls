import { Info } from "lucide-react";

const SubscriptionBenefitsInfo = () => {
  return (
    <div className="bg-blue-50 p-4 rounded-lg flex items-start space-x-3">
      <Info className="h-5 w-5 text-blue-500 mt-0.5" />
      <div className="text-sm text-blue-700">
        <p className="font-medium mb-1">Subscription Benefits</p>
        <ul className="list-disc pl-5 space-y-1">
          <li>Regular deliveries without manual ordering</li>
          <li>Discounts on longer subscription periods</li>
          <li>Flexible payment options (weekly/monthly)</li>
          <li>Easy modification or cancellation anytime</li>
        </ul>
      </div>
    </div>
  );
};

export default SubscriptionBenefitsInfo;
