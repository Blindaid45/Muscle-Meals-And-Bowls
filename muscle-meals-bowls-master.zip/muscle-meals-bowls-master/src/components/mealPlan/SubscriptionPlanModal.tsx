import { useState, useEffect } from "react";
import Modal from "@/components/ui/Modal";
import { MealPlan } from "@/store/slices/mealPlanSlice";
import { AdminMealPlan } from "@/store/slices/adminMealPlanSlice";
import { addDays, isBefore } from "date-fns";
import { toast } from "sonner";
import { handleSubscription } from "@/lib/razorpay";
import "react-day-picker/dist/style.css";
import { useAppSelector, useAppDispatch } from "@/store/hooks";
import { calculateFirstTimeUserDiscount } from "@/utils/priceUtils";
import { updateUserProfile } from "@/store/slices/userSlice";

// Import constants
import { datePickerStyles, USE_MOCK_MODE } from "./constants";

// Import our components
import SubscriptionBenefitsInfo from "./SubscriptionBenefitsInfo";
import QuickDurationSection from "./QuickDurationSection";
import DateSelectionSection from "./DateSelectionSection";
import SelectedPeriodSummary from "./SelectedPeriodSummary";

import MealPlanSummary from "./MealPlanSummary";
import PriceSummary from "./PriceSummary";

import ActionButtons from "./ActionButtons";

// Import Coupon Validation Component
import { CouponValidationForm } from "../affiliate";

// Type that can be either MealPlan or AdminMealPlan
type MealPlanType = MealPlan | AdminMealPlan;

interface SubscriptionPlanModalProps {
  isOpen: boolean;
  onClose: () => void;
  mealPlan: MealPlanType;
}

const SubscriptionPlanModal = ({
  isOpen,
  onClose,
  mealPlan,
}: SubscriptionPlanModalProps) => {
  const dispatch = useAppDispatch();
  const { profile } = useAppSelector((state) => state.user);
  const isFirstTimeUser = profile?.isFirstTimeUser ?? false;

  // State for selected dates
  const [startDate, setStartDate] = useState<Date>(new Date());
  const [isEligible, setIsEligible] = useState(false);
  const [endDate, setEndDate] = useState<Date>(() => {
    const date = new Date();
    date.setDate(date.getDate() + 7); // Default 7 days
    return date;
  });

  // State for calculated price
  const [totalPrice, setTotalPrice] = useState(0);
  const [discountedPrice, setDiscountedPrice] = useState(0);
  const [isProcessing, setIsProcessing] = useState(false);

  // State for coupon validation
  const [couponValidation, setCouponValidation] = useState<{
    isValid: boolean;
    discountAmount: number;
    finalAmount: number;
    affiliateId?: string;
    couponCode?: string;
  } | null>(null);

  // Set quick duration
  const setQuickDuration = (days: number) => {
    const newEndDate = addDays(startDate, days - 1);
    setEndDate(newEndDate);
  };

  // Calculate days between two dates
  const getDaysBetween = (start: Date, end: Date) => {
    return Math.max(
      1,
      Math.floor((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24)) + 1
    );
  };

  // Calculate total price when dates change
  useEffect(() => {
    if (!startDate || !endDate || !mealPlan) return;

    const days = getDaysBetween(startDate, endDate);
    const dailyPrice = mealPlan.totalPrice;
    const subtotal = dailyPrice * days;

    // Apply bulk discount for subscriptions longer than 7 days
    let bulkDiscount = 0;
    if (days > 7 && days <= 14) {
      bulkDiscount = 0.1; // 10% discount
    } else if (days > 14 && days <= 30) {
      bulkDiscount = 0.15; // 15% discount
    } else if (days > 30) {
      bulkDiscount = 0.2; // 20% discount
    }

    const afterBulkDiscountPrice = subtotal * (1 - bulkDiscount);

    // Apply first-time user discount
    const firstTimeUserDiscount = calculateFirstTimeUserDiscount(
      afterBulkDiscountPrice,
      isFirstTimeUser
    );
    const afterFirstTimeDiscountPrice = firstTimeUserDiscount.finalAmount;

    // Set the total price (before any discounts) and discounted price (after bulk + first-time discount)
    setTotalPrice(subtotal);

    // Apply affiliate coupon discount on the first-time discounted price
    if (couponValidation?.isValid) {
      // Affiliate discount is applied on the first-time discounted price
      setDiscountedPrice(couponValidation.finalAmount);
    } else {
      // No coupon, just the first-time discounted price
      setDiscountedPrice(afterFirstTimeDiscountPrice);
    }

    // Set eligibility based on whether the final amount is more than 200
    const finalAmount = couponValidation?.isValid
      ? couponValidation.finalAmount
      : afterFirstTimeDiscountPrice;
    setIsEligible(finalAmount > 200);
  }, [startDate, endDate, mealPlan, couponValidation, isFirstTimeUser]);

  // Handle coupon validation result
  const handleCouponValidation = (result: {
    isValid: boolean;
    discountAmount: number;
    finalAmount: number;
    affiliateId?: string;
    couponCode?: string;
  }) => {
    console.log("Coupon validation result:", result);
    setCouponValidation(result);
  };

  // Handle proceed to payment
  const handleProceedToPayment = async () => {
    try {
      setIsProcessing(true);

      if (!mealPlan || !mealPlan.id) {
        throw new Error("Meal plan information is missing");
      }

      // Ensure start date is at least tomorrow
      const today = new Date();
      const tomorrow = new Date(today);
      tomorrow.setDate(tomorrow.getDate() + 1);
      tomorrow.setHours(0, 0, 0, 0); // Start of day

      // Use tomorrow as start date if today is selected
      const subscriptionStartDate = isBefore(startDate, tomorrow)
        ? tomorrow
        : startDate;

      // Calculate bulk discount amount for reference
      const days = getDaysBetween(subscriptionStartDate, endDate);
      const bulkDiscountRate =
        days > 30 ? 0.2 : days > 14 ? 0.15 : days > 7 ? 0.1 : 0;
      const bulkDiscountedAmount = totalPrice * (1 - bulkDiscountRate);

      // Prepare subscription data
      const subscriptionData = {
        mealPlanId: mealPlan.id,
        startDate: subscriptionStartDate,
        endDate: endDate,
        amount: discountedPrice, // Final amount after all discounts
        currency: "INR",
        quantity: 1,
        frequency:
          getDaysBetween(subscriptionStartDate, endDate) <= 14
            ? "weekly"
            : "monthly",
        // Include coupon data if valid
        ...(couponValidation?.isValid && {
          couponCode: couponValidation.couponCode,
          originalAmount: bulkDiscountedAmount, // Base amount for affiliate discount (after bulk discount)
          discountAmount: couponValidation.discountAmount, // Affiliate discount amount
          affiliateId: couponValidation.affiliateId,
          subscriptionType:
            getDaysBetween(subscriptionStartDate, endDate) <= 14
              ? "weekly"
              : "monthly",
          // Store the truly original amount for commission calculation
          retailAmount: totalPrice, // Original retail price before any discounts
        }),
      };

      // Use the real Razorpay integration with immediate full payment
      await handleSubscription(subscriptionData as any);
      toast.success("Subscription purchased successfully!");

      
      if (isFirstTimeUser) {
        console.log("Updating user profile to not first-time user");
        dispatch(updateUserProfile({ isFirstTimeUser: false }));
      }

      // Show wallet credit notification if coupon was used
      if (couponValidation?.isValid) {
        toast.success(
          `₹${couponValidation.discountAmount} credited to your wallet!`,
          {
            description:
              "Your discount amount has been added to your wallet balance",
          }
        );
      }

      toast.info(
        "Your payment has been processed for the full subscription period"
      );
      onClose();
      setIsProcessing(false);
    } catch (error) {
      console.error("Error processing subscription:", error);
      toast.error("Failed to process subscription");
      setIsProcessing(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={`Subscribe to ${mealPlan?.name || "Meal Plan"}`}
      size="lg"
    >
      <style>{datePickerStyles}</style>
      <div className="space-y-6">
        {/* Benefits Info */}
        <SubscriptionBenefitsInfo />

        {/* Information about upfront payment */}
        <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
          <h3 className="font-semibold text-blue-800">Upfront Payment</h3>
          <p className="text-sm text-blue-700">
            You will be charged the full amount for the entire subscription
            period upfront. This ensures uninterrupted service for your entire
            selected period.
          </p>
        </div>

        {/* Quick Duration Selection */}
        <QuickDurationSection
          startDate={startDate}
          endDate={endDate}
          setQuickDuration={setQuickDuration}
        />

        {/* Date Selection */}
        <DateSelectionSection
          startDate={startDate}
          endDate={endDate}
          setStartDate={setStartDate}
          setEndDate={setEndDate}
        />

        {/* Show selected period summary */}
        <SelectedPeriodSummary startDate={startDate} endDate={endDate} />

        {/* Plan details summary */}
        <MealPlanSummary mealPlan={mealPlan} />

        {/* COUPON VALIDATION INTEGRATION - Add this before price summary */}
        <CouponValidationForm
          subscriptionAmount={(() => {
            const bulkDiscountedAmount =
              totalPrice *
              (1 -
                (getDaysBetween(startDate, endDate) > 30
                  ? 0.2
                  : getDaysBetween(startDate, endDate) > 14
                  ? 0.15
                  : getDaysBetween(startDate, endDate) > 7
                  ? 0.1
                  : 0));

            const firstTimeDiscount = calculateFirstTimeUserDiscount(
              bulkDiscountedAmount,
              isFirstTimeUser
            );

            return firstTimeDiscount.finalAmount;
          })()}
          subscriptionType={
            getDaysBetween(startDate, endDate) <= 14 ? "weekly" : "monthly"
          }
          onValidationResult={handleCouponValidation}
        />

        {/* Price calculation */}
        <PriceSummary
          mealPlan={mealPlan}
          startDate={startDate}
          endDate={endDate}
          totalPrice={totalPrice}
          discountedPrice={discountedPrice}
          couponDiscount={
            couponValidation?.isValid ? couponValidation.discountAmount : 0
          }
          isFirstTimeUser={isFirstTimeUser}
        />

        {/* Actions */}
        <ActionButtons
          onClose={onClose}
          onProceedToPayment={handleProceedToPayment}
          isProcessing={isProcessing}
          useMockMode={USE_MOCK_MODE}
          paymentText="Pay Now"
          isEligible={isEligible}
        />
      </div>
    </Modal>
  );
};

export default SubscriptionPlanModal;
