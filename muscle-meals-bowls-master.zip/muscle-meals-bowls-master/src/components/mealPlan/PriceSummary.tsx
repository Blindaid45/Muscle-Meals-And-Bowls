import { MealPlan } from "@/store/slices/mealPlanSlice";
import { AdminMealPlan } from "@/store/slices/adminMealPlanSlice";
import { differenceInDays } from "date-fns";
import { calculateFirstTimeUserDiscount } from "@/utils/priceUtils";

// Type that can be either MealPlan or AdminMealPlan
type MealPlanType = MealPlan | AdminMealPlan;

interface PriceSummaryProps {
  mealPlan: MealPlanType;
  startDate: Date;
  endDate: Date;
  totalPrice: number;
  discountedPrice: number;
  couponDiscount?: number; // Affiliate coupon discount amount
  isFirstTimeUser?: boolean; // Whether user is first-time user
}

const PriceSummary = ({
  mealPlan,
  startDate,
  endDate,
  totalPrice,
  discountedPrice,
  couponDiscount = 0,
  isFirstTimeUser = false,
}: PriceSummaryProps) => {
  // Calculate days between two dates
  const getDaysBetween = (start: Date, end: Date) => {
    return differenceInDays(end, start) + 1; // +1 to include both start and end days
  };

  // Calculate bulk discount
  const days = getDaysBetween(startDate, endDate);
  const bulkDiscountRate =
    days > 30 ? 0.2 : days > 14 ? 0.15 : days > 7 ? 0.1 : 0;
  const bulkDiscountAmount = totalPrice * bulkDiscountRate;
  const afterBulkDiscountPrice = totalPrice - bulkDiscountAmount;

  // Calculate first-time user discount
  const firstTimeUserDiscount = calculateFirstTimeUserDiscount(
    afterBulkDiscountPrice,
    isFirstTimeUser
  );
  const afterFirstTimeDiscountPrice = firstTimeUserDiscount.finalAmount;

  // Final price after all discounts including coupon
  const finalPrice = afterFirstTimeDiscountPrice - couponDiscount;

  return (
    <div className="bg-neutral-light p-4 rounded-lg space-y-3">
      <h3 className="font-semibold">Price Summary</h3>
      <div className="flex justify-between text-sm">
        <span>Daily meal plan price:</span>
        <span>₹{mealPlan?.totalPrice.toFixed(2) || "0.00"}</span>
      </div>
      <div className="flex justify-between text-sm">
        <span>Subscription period:</span>
        <span>{getDaysBetween(startDate, endDate)} days</span>
      </div>
      <div className="flex justify-between text-sm">
        <span>Subtotal:</span>
        <span>₹{totalPrice.toFixed(2)}</span>
      </div>

      {/* Show bulk discount if applicable */}
      {bulkDiscountAmount > 0 && (
        <div className="flex justify-between text-sm text-blue-600">
          <span>
            Bulk discount ({Math.round(bulkDiscountRate * 100)}% off):
          </span>
          <span>-₹{bulkDiscountAmount.toFixed(2)}</span>
        </div>
      )}

      {/* Show price after bulk discount */}
      {bulkDiscountAmount > 0 && (
        <div className="flex justify-between text-sm">
          <span>After bulk discount:</span>
          <span>₹{afterBulkDiscountPrice.toFixed(2)}</span>
        </div>
      )}

      {/* Show first-time user discount if applicable */}
      {firstTimeUserDiscount.isEligible && (
        <>
          <div className="flex justify-between text-sm text-purple-600">
            <span>First-time user discount (₹50 off orders &gt; ₹300):</span>
            <span>-₹{firstTimeUserDiscount.discountAmount.toFixed(2)}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span>After first-time discount:</span>
            <span>₹{afterFirstTimeDiscountPrice.toFixed(2)}</span>
          </div>
        </>
      )}

      {/* Show affiliate coupon discount if applicable */}
      {couponDiscount > 0 && (
        <div className="flex justify-between text-sm text-green-600">
          <span>Affiliate coupon discount:</span>
          <span>-₹{couponDiscount.toFixed(2)}</span>
        </div>
      )}

      {/* Final total */}
      <div className="pt-2 border-t flex justify-between font-bold">
        <span>Total:</span>
        <span>₹{finalPrice.toFixed(2)}</span>
      </div>
    </div>
  );
};

export default PriceSummary;
