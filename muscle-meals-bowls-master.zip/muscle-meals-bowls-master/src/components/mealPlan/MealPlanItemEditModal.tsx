import { useState, useEffect } from "react";
import { useAppDispatch } from "@/store/hooks";
import {
  updateMealPlanItem,
  fetchMealPlanById,
  MealPlanItem,
} from "@/store/slices/mealPlanSlice";
import { Meal } from "@/store/slices/mealSlice";
import { Loader2 } from "lucide-react";
import Button from "@/components/ui/Button";
import Modal from "@/components/ui/Modal";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";
import { MEAL_TIMES, WEEKDAYS } from "./constants";
import { useMealPlanWallet } from "@/hooks/useMealPlanWallet";
import { calculatePriceChange } from "./mealPlanPriceCalculator";

interface MealPlanItemEditModalProps {
  isOpen: boolean;
  onClose: () => void;
  planId: string | null | undefined;
  itemId: string;
  items: MealPlanItem[];
  getMealDetails: (mealId: string) => Meal | undefined;
}

const MealPlanItemEditModal = ({
  isOpen,
  onClose,
  planId,
  itemId,
  items,
  getMealDetails,
}: MealPlanItemEditModalProps) => {
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const [isProcessing, setIsProcessing] = useState(false);
  const [editFormState, setEditFormState] = useState<{
    quantity: number;
    mealTimes: string[];
    dayNumbers: number[];
    notes?: string;
  }>({
    quantity: 0,
    mealTimes: [],
    dayNumbers: [],
    notes: "",
  });
  const [originalItemState, setOriginalItemState] = useState<{
    quantity: number;
    mealTimes: string[];
    dayNumbers: number[];
  } | null>(null);

  // Price calculation state
  const [priceChange, setPriceChange] = useState<number | null>(null);
  const [priceChangeFactors, setPriceChangeFactors] = useState<{
    quantity: number;
    mealTimes: number;
    days: number;
  } | null>(null);

  // Get wallet functionality
  const {
    wallet,
    useWalletForPayment,
    setUseWalletForPayment,
    processWalletPayment,
  } = useMealPlanWallet();

  // Find current item
  const currentItem = items.find((i) => i.id === itemId);

  // Initialize form state when item changes
  useEffect(() => {
    const item = items.find((i) => i.id === itemId);
    if (item) {
      // Handle both newer array format and legacy single value format
      const mealTimes = item.mealTimes
        ? [...item.mealTimes]
        : [(item as any).mealTime];
      const dayNumbers = item.dayNumbers
        ? [...item.dayNumbers]
        : [(item as any).dayNumber];

      // Store original state to calculate price difference later
      setOriginalItemState({
        quantity: item.quantity,
        mealTimes: mealTimes,
        dayNumbers: dayNumbers,
      });

      setEditFormState({
        quantity: item.quantity,
        mealTimes: mealTimes,
        dayNumbers: dayNumbers,
        notes: item.notes,
      });
      setPriceChange(null);
    }
  }, [itemId, items]);

  // Recalculate price when form state changes
  useEffect(() => {
    if (originalItemState && itemId) {
      calculateItemPriceChange();
    }
  }, [
    editFormState.quantity,
    editFormState.mealTimes,
    editFormState.dayNumbers,
  ]);

  const handleEditInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value, type } = e.target;
    setEditFormState({
      ...editFormState,
      [name]: type === "number" ? parseInt(value, 10) : value,
    });
  };

  const handleMealTimeToggle = (mealTimeId: string) => {
    setEditFormState((prev) => {
      const newState = {
        ...prev,
        mealTimes: prev.mealTimes.includes(mealTimeId)
          ? prev.mealTimes.filter((id) => id !== mealTimeId)
          : [...prev.mealTimes, mealTimeId],
      };

      return newState;
    });
  };

  const handleWeekdayToggle = (weekdayId: number) => {
    setEditFormState((prev) => {
      const newState = {
        ...prev,
        dayNumbers: prev.dayNumbers.includes(weekdayId)
          ? prev.dayNumbers.filter((id) => id !== weekdayId)
          : [...prev.dayNumbers, weekdayId],
      };

      return newState;
    });
  };

  // Calculate price change based on quantity, meal times, and days
  const calculateItemPriceChange = () => {
    if (!itemId || !originalItemState) return;

    const currentItem = items.find((item) => item.id === itemId);
    if (!currentItem) return;

    const meal = getMealDetails(currentItem.mealId);

    // Use utility function to calculate price change
    const priceChangeResult = calculatePriceChange(
      meal,
      originalItemState,
      editFormState
    );

    setPriceChange(priceChangeResult.totalPriceDifference);
    setPriceChangeFactors(priceChangeResult.priceChangeFactors);
  };

  const handleSaveEdit = async () => {
    if (!planId || !itemId) return;

    // Validate at least one meal time and one day is selected
    if (editFormState.mealTimes.length === 0) {
      toast.error("Please select at least one meal time");
      return;
    }

    if (editFormState.dayNumbers.length === 0) {
      toast.error("Please select at least one day of the week");
      return;
    }

    // Check if there's a price increase that needs payment
    if (priceChange && priceChange > 0) {
      // Get the meal details for the transaction description
      const currentItem = items.find((item) => item.id === itemId);
      const meal = currentItem ? getMealDetails(currentItem.mealId) : null;
      const mealName = meal ? meal.name : "meal item";

      // Create a descriptive message for the transaction
      const description = `Updated ${mealName} in meal plan (${planId})`;

      // Process the payment
      const paymentSuccess = await processWalletPayment(
        priceChange,
        description,
        itemId
      );

      if (!paymentSuccess) {
        return;
      }
    }

    setIsProcessing(true);

    try {
      // Create an update object without undefined values
      const updateData: Partial<MealPlanItem> = {
        quantity: editFormState.quantity,
        mealTimes: editFormState.mealTimes,
        dayNumbers: editFormState.dayNumbers,
      };

      // Only include notes if it's defined and not null
      if (editFormState.notes !== undefined && editFormState.notes !== null) {
        updateData.notes = editFormState.notes;
      }

      // Now we update the item with the arrays
      await dispatch(
        updateMealPlanItem({
          planId,
          itemId,
          updatedItem: updateData,
        })
      ).unwrap();

      // Refresh the meal plan data
      await dispatch(fetchMealPlanById(planId)).unwrap();

      toast.success("Meal item updated successfully!");
      onClose();
      setUseWalletForPayment(false);
    } catch (error) {
      console.error("Failed to update meal item:", error);
      toast.error("Failed to update meal item");
    } finally {
      setIsProcessing(false);
    }
  };

  // Navigate to wallet top-up
  const handleNavigateToWalletTopUp = () => {
    onClose();
    navigate("/user/wallet");
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Edit Meal Item" size="md">
      <div className="space-y-6">
        <div>
          <label htmlFor="quantity" className="block text-sm font-medium mb-2">
            Quantity (
            {getMealDetails(currentItem?.mealId || "")?.unit || "grams"})
          </label>
          <input
            type="number"
            id="quantity"
            name="quantity"
            value={editFormState.quantity}
            onChange={handleEditInputChange}
            min="1"
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-primary focus:border-primary"
          />
        </div>

        {/* Meal time selection */}
        <div>
          <label className="block text-sm font-medium mb-2">Meal times</label>
          <div className="flex flex-wrap gap-2">
            {MEAL_TIMES.map((mealTime) => (
              <button
                key={mealTime.id}
                type="button"
                onClick={() => handleMealTimeToggle(mealTime.id)}
                className={`
                  h-10 px-4 rounded-full text-sm font-medium transition-colors
                  ${
                    editFormState.mealTimes.includes(mealTime.id)
                      ? "bg-primary text-white"
                      : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                  }
                `}
              >
                {mealTime.label}
              </button>
            ))}
          </div>
          <p className="text-xs text-gray-500 mt-1">
            Select multiple meal times if needed
          </p>
        </div>

        {/* Weekday selection */}
        <div>
          <label className="block text-sm font-medium mb-2">
            Days of the week
          </label>
          <div className="flex flex-wrap gap-2">
            {WEEKDAYS.map((day) => (
              <button
                key={day.id}
                type="button"
                onClick={() => handleWeekdayToggle(day.id)}
                className={`
                  w-9 h-9 rounded-full text-sm font-medium flex items-center justify-center transition-colors
                  ${
                    editFormState.dayNumbers.includes(day.id)
                      ? "bg-primary text-white"
                      : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                  }
                `}
              >
                {day.label}
              </button>
            ))}
          </div>
          <p className="text-xs text-gray-500 mt-1">
            Select multiple days (M = Monday, S = Sunday)
          </p>
        </div>

        <div>
          <label htmlFor="notes" className="block text-sm font-medium mb-2">
            Notes (Optional)
          </label>
          <textarea
            id="notes"
            name="notes"
            value={editFormState.notes || ""}
            onChange={handleEditInputChange}
            rows={3}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-primary focus:border-primary"
            placeholder="Add any special instructions..."
          />
        </div>

        {priceChange !== null && (
          <div className="p-3 rounded bg-gray-50">
            <h4 className="text-sm font-medium mb-2">Price Impact</h4>

            <div className="space-y-1">
              <div className="flex justify-between">
                <span className="text-sm font-medium">Total:</span>
                <span
                  className={`text-sm font-medium ${
                    priceChange > 0
                      ? "text-red-600"
                      : priceChange < 0
                      ? "text-green-600"
                      : "text-gray-600"
                  }`}
                >
                  {priceChange > 0 ? "+" : ""}
                  {priceChange.toFixed(2)}
                </span>
              </div>

              {priceChangeFactors && (
                <div className="border-t pt-1 mt-1">
                  {priceChangeFactors.quantity !== 0 && (
                    <div className="flex justify-between text-xs items-center py-0.5">
                      <div>
                        <span className="font-medium">Quantity:</span>
                        <span className="text-gray-500 ml-1">
                          {originalItemState?.quantity}
                          {getMealDetails(currentItem?.mealId || "")?.unit ||
                            "g"}{" "}
                          → {editFormState.quantity}
                          {getMealDetails(currentItem?.mealId || "")?.unit ||
                            "g"}
                        </span>
                      </div>
                      <span
                        className={
                          priceChangeFactors.quantity > 0
                            ? "text-red-500"
                            : priceChangeFactors.quantity < 0
                            ? "text-green-500"
                            : "text-gray-500"
                        }
                      >
                        {priceChangeFactors.quantity > 0 ? "+" : ""}
                        {priceChangeFactors.quantity.toFixed(2)}
                      </span>
                    </div>
                  )}

                  {priceChangeFactors.mealTimes !== 0 && (
                    <div className="flex justify-between text-xs items-center py-0.5">
                      <div>
                        <span className="font-medium">Meal Times:</span>
                        <span className="text-gray-500 ml-1">
                          {originalItemState?.mealTimes.length} →{" "}
                          {editFormState.mealTimes.length}
                        </span>
                      </div>
                      <span
                        className={
                          priceChangeFactors.mealTimes > 0
                            ? "text-red-500"
                            : priceChangeFactors.mealTimes < 0
                            ? "text-green-500"
                            : "text-gray-500"
                        }
                      >
                        {priceChangeFactors.mealTimes > 0 ? "+" : ""}
                        {priceChangeFactors.mealTimes.toFixed(2)}
                      </span>
                    </div>
                  )}

                  {priceChangeFactors.days !== 0 && (
                    <div className="flex justify-between text-xs items-center py-0.5">
                      <div>
                        <span className="font-medium">Days:</span>
                        <span className="text-gray-500 ml-1">
                          {originalItemState?.dayNumbers.length} →{" "}
                          {editFormState.dayNumbers.length}
                        </span>
                      </div>
                      <span
                        className={
                          priceChangeFactors.days > 0
                            ? "text-red-500"
                            : priceChangeFactors.days < 0
                            ? "text-green-500"
                            : "text-gray-500"
                        }
                      >
                        {priceChangeFactors.days > 0 ? "+" : ""}
                        {priceChangeFactors.days.toFixed(2)}
                      </span>
                    </div>
                  )}
                </div>
              )}

              {/* Wallet payment option - show only if there's a price increase */}
              {priceChange && priceChange > 0 && (
                <div className="border-t pt-2 mt-2">
                  <div className="flex items-center mb-2">
                    <input
                      type="checkbox"
                      id="useWallet"
                      checked={useWalletForPayment}
                      onChange={() =>
                        setUseWalletForPayment(!useWalletForPayment)
                      }
                      className="h-4 w-4 text-primary focus:ring-primary border-gray-300 rounded"
                    />
                    <label
                      htmlFor="useWallet"
                      className="ml-2 block text-sm text-gray-700"
                    >
                      Pay from wallet
                    </label>
                  </div>

                  {useWalletForPayment && wallet && (
                    <div className="bg-gray-100 p-2 rounded text-sm">
                      <p className="flex justify-between">
                        <span>Current balance:</span>
                        <span className="font-medium">
                          {wallet.balance.toFixed(2)}
                        </span>
                      </p>

                      {wallet.balance < priceChange && (
                        <div className="mt-2">
                          <p className="text-red-500 mb-1">
                            Insufficient balance
                          </p>
                          <button
                            onClick={handleNavigateToWalletTopUp}
                            className="w-full text-xs py-1 bg-primary text-white rounded hover:bg-primary-dark transition"
                          >
                            Top up wallet
                          </button>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        )}

        <div className="flex justify-end space-x-3 pt-4 border-t">
          <Button
            variant="outline"
            type="button"
            onClick={onClose}
            disabled={isProcessing}
          >
            Cancel
          </Button>
          <Button
            variant="accent"
            type="button"
            onClick={handleSaveEdit}
            disabled={
              isProcessing ||
              editFormState.mealTimes.length === 0 ||
              editFormState.dayNumbers.length === 0 ||
              Boolean(
                priceChange !== null &&
                  priceChange > 0 &&
                  useWalletForPayment &&
                  wallet &&
                  wallet.balance < priceChange
              )
            }
          >
            {isProcessing ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Saving...
              </>
            ) : (
              "Save Changes"
            )}
          </Button>
        </div>
      </div>
    </Modal>
  );
};

export default MealPlanItemEditModal;
