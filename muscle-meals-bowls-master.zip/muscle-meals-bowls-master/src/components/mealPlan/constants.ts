// Define frequency options
export const SUBSCRIPTION_FREQUENCIES = [
  { id: "weekly", label: "Weekly", days: 7 },
  { id: "monthly", label: "Monthly", days: 30 },
];

// Define quick duration options
export const QUICK_DURATIONS = [
  { days: 7, label: "1 Week" },

  { days: 30, label: "1 Month" },
];

// Define meal times
export const MEAL_TIMES = [
  { id: "breakfast", label: "Breakfast" },
  { id: "lunch", label: "Lunch" },
  // { id: "dinner", label: "Dinner" },
  // { id: "snack", label: "Snack" },
];

// Define weekdays
export const WEEKDAYS = [
  { id: 0, label: "S", fullName: "Sunday" },
  { id: 1, label: "M", fullName: "Monday" },
  { id: 2, label: "T", fullName: "Tuesday" },
  { id: 3, label: "W", fullName: "Wednesday" },
  { id: 4, label: "T", fullName: "Thursday" },
  { id: 5, label: "F", fullName: "Friday" },
  { id: 6, label: "S", fullName: "Saturday" },
];

// CSS for DatePicker
export const datePickerStyles = `
  .rdp {
    --rdp-cell-size: 40px;
    --rdp-accent-color: #4f46e5;
    --rdp-background-color: #e0e7ff;
    margin: 0;
  }
  .rdp-day_selected, .rdp-day_selected:focus-visible, .rdp-day_selected:hover {
    background-color: var(--rdp-accent-color);
    color: white;
  }
  .rdp-button:hover:not([disabled]):not(.rdp-day_selected) {
    background-color: var(--rdp-background-color);
  }
`;

// Set to true if Firebase Functions are not yet deployed
// This will run in mock mode for testing UI
export const USE_MOCK_MODE = false;

export const BENEFITS = [
  {
    title: "Consistent Nutrition",
    description:
      "Never miss a meal with regular deliveries that fit your schedule.",
  },
  {
    title: "Exclusive Recipes",
    description: "Access premium meals only available to subscribers.",
  },
  {
    title: "Save Time",
    description:
      "No more meal prep or cooking - focus on your training instead.",
  },
  {
    title: "Always Fresh",
    description:
      "Meals prepared fresh on the day of delivery for maximum nutrition.",
  },
];

export const TESTIMONIALS = [
  {
    name: "Rahul S.",
    role: "Fitness Enthusiast",
    image: "https://randomuser.me/api/portraits/men/32.jpg",
    quote:
      "The subscription saves me so much time! Getting perfectly portioned meals delivered regularly has transformed my training.",
  },
  {
    name: "Priya M.",
    role: "Bodybuilding Competitor",
    image: "https://randomuser.me/api/portraits/women/44.jpg",
    quote:
      "As a competitive bodybuilder, consistency is key. This subscription ensures I never miss a meal and always hit my macros.",
  },
];

export const FAQ_DATA = [
  {
    question: "What is included in the meal subscription?",
    answer:
      "Our subscription includes two high-protein non-veg meals per day, freshly prepared with a focus on quality and nutrition. We also offer a few veg options, like high-protein overnight oats for variety.",
  },
  {
    question: "How many meals do I get per week or month?",
    answer:
      "We provide:\n- Weekly plan: 12 meals (2 meals/day for 6 days)\n- Monthly plan: 48 meals (2 meals/day for 24 days)",
  },
  {
    question: "Can I customize my meals?",
    answer:
      "Yes! While our core offerings are non-vegetarian, we do accommodate certain preferences and offer limited veg choices like overnight oats. Just let us know your dietary needs or allergies.",
  },
  {
    question: "What are the delivery timings?",
    answer:
      "We deliver twice daily at the following times:\n- Morning: 6:30 AM to 8:30 AM\n- Afternoon: 12:00 PM to 2:00 PM\nPlease ensure someone is available to receive the delivery during these slots.",
  },
  {
    question: "What areas do you deliver to?",
    answer: "We currently serve Marathahalli and Whitefield in Bangalore.",
  },
  {
    question: "Is there a trial plan available?",
    answer:
      "Yes! We offer a 1-day trial pack so you can experience our meal quality before subscribing to a full plan.",
  },
  {
    question: "How do I pause or reschedule my subscription?",
    answer:
      "Just contact us at least 24 hours in advance, and we'll help you pause or shift your meals accordingly.",
  },
  {
    question: "Are your meals freshly made?",
    answer:
      "Yes! All meals are cooked fresh every day using high-quality ingredients, and delivered promptly within our delivery windows.",
  },
  {
    question: "Do you provide GST invoices?",
    answer:
      "We do not provide GST invoices at this time, as we are not yet GST-registered.",
  },
  {
    question: "What is your refund or cancellation policy?",
    answer:
      "You can cancel or reschedule your subscription with at least 48 hours' notice. Refunds will be issued as per our policy upon cancellation.",
  },
];
