import { useState } from "react";
import { Plus, Tag, X } from "lucide-react";
import { processTag } from "./mealPlanUtils";

interface MealPlanBasicInfoFormProps {
  formState: {
    name: string;
    description: string;
    duration: number;
    isPublic: boolean;
    tags: string[];
  };
  errors: Record<string, string>;
  updateFormState: (
    update: Partial<MealPlanBasicInfoFormProps["formState"]>
  ) => void;
}

const MealPlanBasicInfoForm = ({
  formState,
  errors,
  updateFormState,
}: MealPlanBasicInfoFormProps) => {
  const [tagInput, setTagInput] = useState("");

  const handleInputChange = (
    e: React.ChangeEvent<
      HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement
    >
  ) => {
    const { name, value, type } = e.target;
    updateFormState({
      [name]:
        type === "checkbox"
          ? (e.target as HTMLInputElement).checked
          : type === "number"
          ? parseInt(value, 10)
          : value,
    });
  };

  // Add multiple tags from comma-separated input
  const handleAddTags = () => {
    if (!tagInput.trim()) return;

    // Split by comma and process each tag
    const newTags = tagInput
      .split(",")
      .map(processTag)
      .filter((tag) => tag.length > 0);

    // Add only unique tags
    const uniqueNewTags = newTags.filter(
      (tag) => !formState.tags.includes(tag)
    );

    if (uniqueNewTags.length > 0) {
      updateFormState({
        tags: [...formState.tags, ...uniqueNewTags],
      });
    }

    setTagInput("");
  };

  const handleRemoveTag = (tagToRemove: string) => {
    updateFormState({
      tags: formState.tags.filter((tag) => tag !== tagToRemove),
    });
  };

  return (
    <>
      {/* Name field */}
      <div>
        <label
          htmlFor="name"
          className="block text-sm font-medium text-gray-700 mb-1"
        >
          Plan Name*
        </label>
        <input
          type="text"
          id="name"
          name="name"
          value={formState.name}
          onChange={handleInputChange}
          className={`w-full px-4 py-2 border rounded-lg focus:ring-primary focus:border-primary ${
            errors.name ? "border-red-500" : "border-gray-300"
          }`}
          placeholder="e.g., Week 1 Muscle Building Plan"
        />
        {errors.name && (
          <p className="mt-1 text-sm text-red-500">{errors.name}</p>
        )}
      </div>

      {/* Description field */}
      <div>
        <label
          htmlFor="description"
          className="block text-sm font-medium text-gray-700 mb-1"
        >
          Description*
        </label>
        <textarea
          id="description"
          name="description"
          value={formState.description}
          onChange={handleInputChange}
          rows={3}
          className={`w-full px-4 py-2 border rounded-lg focus:ring-primary focus:border-primary ${
            errors.description ? "border-red-500" : "border-gray-300"
          }`}
          placeholder="Describe your meal plan..."
        />
        {errors.description && (
          <p className="mt-1 text-sm text-red-500">{errors.description}</p>
        )}
      </div>

      {/* Duration field */}
      <div>
        <label
          htmlFor="duration"
          className="block text-sm font-medium text-gray-700 mb-1"
        >
          Duration (days)*
        </label>
        <input
          type="number"
          id="duration"
          name="duration"
          value={formState.duration}
          onChange={handleInputChange}
          min="1"
          max="30"
          className={`w-full px-4 py-2 border rounded-lg focus:ring-primary focus:border-primary ${
            errors.duration ? "border-red-500" : "border-gray-300"
          }`}
        />
        {errors.duration && (
          <p className="mt-1 text-sm text-red-500">{errors.duration}</p>
        )}
      </div>

      {/* Public/Private toggle */}
      <div className="flex items-center">
        <input
          type="checkbox"
          id="isPublic"
          name="isPublic"
          checked={formState.isPublic}
          onChange={handleInputChange}
          className="h-4 w-4 text-primary focus:ring-primary border-gray-300 rounded"
        />
        <label htmlFor="isPublic" className="ml-2 block text-sm text-gray-700">
          Make this plan public
        </label>
      </div>

      {/* Tags */}
      <div>
        <label
          htmlFor="tags"
          className="block text-sm font-medium text-gray-700 mb-1"
        >
          Tags
        </label>
        <div className="flex">
          <input
            type="text"
            id="tags"
            value={tagInput}
            onChange={(e) => setTagInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                e.preventDefault();
                handleAddTags();
              }
            }}
            className="flex-1 px-4 py-2 border border-gray-300 rounded-l-lg focus:ring-primary focus:border-primary"
            placeholder="Add tags..."
          />
          <button
            type="button"
            onClick={handleAddTags}
            className="px-4 py-2 bg-primary text-white rounded-r-lg hover:bg-primary-dark"
          >
            <Plus className="h-5 w-5" />
          </button>
        </div>
        <div className="flex flex-wrap gap-2 mt-2">
          {formState.tags.map((tag) => (
            <div
              key={tag}
              className="bg-primary-50 text-primary px-3 py-1 rounded-full text-sm font-medium flex items-center"
            >
              <Tag className="h-3 w-3 mr-1" />
              {tag}
              <button
                type="button"
                onClick={() => handleRemoveTag(tag)}
                className="ml-1 text-primary-700 hover:text-primary-900"
              >
                <X className="h-3 w-3" />
              </button>
            </div>
          ))}
          {formState.tags.length === 0 && (
            <p className="text-sm text-gray-500 italic">No tags added yet</p>
          )}
        </div>
      </div>
    </>
  );
};

export default MealPlanBasicInfoForm;
