import { Info } from "lucide-react";

interface MockModeWarningProps {
  useMockMode: boolean;
}

const MockModeWarning = ({ useMockMode }: MockModeWarningProps) => {
  if (!useMockMode) return null;

  return (
    <div className="bg-yellow-50 p-3 rounded-lg text-sm text-yellow-700 flex items-start space-x-2">
      <Info className="h-4 w-4 text-yellow-500 mt-0.5 flex-shrink-0" />
      <p>
        <span className="font-medium">Mock Mode Active:</span> Firebase
        Functions are not yet deployed. This is a simulation for testing
        purposes.
      </p>
    </div>
  );
};

export default MockModeWarning;
