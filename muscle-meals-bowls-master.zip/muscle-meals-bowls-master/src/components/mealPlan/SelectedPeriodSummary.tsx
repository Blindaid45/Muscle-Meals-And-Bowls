import { differenceInDays, format } from "date-fns";

interface SelectedPeriodSummaryProps {
  startDate: Date;
  endDate: Date;
}

const SelectedPeriodSummary = ({
  startDate,
  endDate,
}: SelectedPeriodSummaryProps) => {
  // Calculate days between two dates
  const getDaysBetween = (start: Date, end: Date) => {
    return differenceInDays(end, start) + 1; // +1 to include both start and end days
  };

  return (
    <div className="bg-gray-50 p-4 rounded-lg">
      <p className="text-sm text-gray-700">
        <span className="font-medium">Selected Period: </span>
        {getDaysBetween(startDate, endDate)} days (
        {format(startDate, "dd MMM yyyy")} to {format(endDate, "dd MMM yyyy")})
      </p>
    </div>
  );
};

export default SelectedPeriodSummary; 