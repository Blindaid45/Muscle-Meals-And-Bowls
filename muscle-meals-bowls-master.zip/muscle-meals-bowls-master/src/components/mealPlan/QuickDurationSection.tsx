import { differenceInDays } from "date-fns";
import { QUICK_DURATIONS } from "./constants";

interface QuickDurationSectionProps {
  startDate: Date;
  endDate: Date;
  setQuickDuration: (days: number) => void;
}

const QuickDurationSection = ({
  startDate,
  endDate,
  setQuickDuration,
}: QuickDurationSectionProps) => {
  // Calculate days between two dates
  const getDaysBetween = (start: Date, end: Date) => {
    return differenceInDays(end, start) + 1; // +1 to include both start and end days
  };

  return (
    <div>
      <h3 className="text-sm font-medium mb-3">Select Your Duration</h3>
      <div className="flex flex-wrap gap-2">
        {QUICK_DURATIONS.map((option) => (
          <button
            key={option.days}
            onClick={() => setQuickDuration(option.days)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors
              ${
                getDaysBetween(startDate, endDate) === option.days
                  ? "bg-primary text-white"
                  : "bg-gray-100 text-gray-700 hover:bg-gray-200"
              }`}
          >
            {option.label}
          </button>
        ))}
      </div>
    </div>
  );
};

export default QuickDurationSection;
