import { MealPlanItem } from "@/store/slices/mealPlanSlice";
import { Spinner } from "@/components/ui/spinner";
import {
  formatMealTimes,
  formatWeekdays,
} from "@/components/mealPlan/mealPlanUtils";

interface MealPlanItemsListProps {
  items: MealPlanItem[];
  getMealDetails: (mealId: string) => any;
  isMealLoading: (mealId: string) => boolean;
}

const MealPlanItemsList = ({
  items,
  getMealDetails,
  isMealLoading,
}: MealPlanItemsListProps) => {
  if (items.length === 0) {
    return (
      <p className="text-sm text-gray-500 text-center py-2">
        No meals added yet
      </p>
    );
  }

  return (
    <div className="mt-4 space-y-3">
      {items.map((item) => {
        const meal = getMealDetails(item.mealId);
        const isLoading = isMealLoading(item.mealId);

        // Handle both new and old format
        const displayMealTimes = item.mealTimes
          ? formatMealTimes(item.mealTimes)
          : formatMealTimes([(item as any).mealTime || ""]);

        const displayDayNumbers = item.dayNumbers
          ? formatWeekdays(item.dayNumbers)
          : formatWeekdays([(item as any).dayNumber || 0]);

        return (
          <div
            key={item.id}
            className="flex items-start space-x-3 p-3 bg-gray-50 rounded-lg"
          >
            {isLoading ? (
              <div className="w-16 h-16 rounded-lg bg-gray-200 flex items-center justify-center">
                <Spinner size="sm" />
              </div>
            ) : meal?.image ? (
              <img
                src={meal.image}
                alt={meal.name}
                className="w-16 h-16 object-cover rounded-lg"
              />
            ) : (
              <div className="w-16 h-16 rounded-lg bg-gray-200 flex items-center justify-center text-gray-400">
                No Image
              </div>
            )}
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <div>
                  {isLoading ? (
                    <div className="h-5 w-24 bg-gray-200 rounded animate-pulse"></div>
                  ) : (
                    <h4 className="font-medium text-sm">
                      {meal?.name || item.mealId}
                    </h4>
                  )}
                  {!isLoading && meal?.tags && meal.tags.length > 0 && (
                    <span className="text-xs text-gray-500">
                      {meal.tags[0]}
                    </span>
                  )}
                </div>
              </div>
              <div className="mt-1 text-xs text-gray-600">
                <p>
                  Quantity: {item.quantity}
                  {meal?.unit || "g"}
                </p>
                <p>Meal Times: {displayMealTimes}</p>
                <p>Days: {displayDayNumbers}</p>
                {item.notes && <p>Notes: {item.notes}</p>}
                {!isLoading && meal && (
                  <div className="mt-2 grid grid-cols-5 gap-2 text-xs">
                    <div className="bg-red-50 p-1 rounded text-center">
                      <span className="block font-semibold text-red-600">
                        {meal.protein.toFixed(1)}g
                      </span>
                      <span className="text-gray-500">Protein</span>
                    </div>
                    <div className="bg-yellow-50 p-1 rounded text-center">
                      <span className="block font-semibold text-yellow-600">
                        {meal.carbs.toFixed(1)}g
                      </span>
                      <span className="text-gray-500">Carbs</span>
                    </div>
                    <div className="bg-green-50 p-1 rounded text-center">
                      <span className="block font-semibold text-green-600">
                        {meal.fat.toFixed(1)}g
                      </span>
                      <span className="text-gray-500">Fat</span>
                    </div>
                    <div className="bg-purple-50 p-1 rounded text-center">
                      <span className="block font-semibold text-purple-600">
                        {meal.fiber.toFixed(1)}g
                      </span>
                      <span className="text-gray-500">Fiber</span>
                    </div>
                    <div className="bg-blue-50 p-1 rounded text-center">
                      <span className="block font-semibold text-blue-600">
                        {meal.calories.toFixed(1)}
                      </span>
                      <span className="text-gray-500">Kcal</span>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
};

export default MealPlanItemsList;
