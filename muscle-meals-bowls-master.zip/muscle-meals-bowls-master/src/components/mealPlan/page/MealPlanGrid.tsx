import { MealPlan } from "@/store/slices/mealPlanSlice";
import MealPlanCard from "./MealPlanCard";

interface MealPlanGridProps {
  mealPlans: MealPlan[];
  getMealDetails: (mealId: string) => any;
  isMealLoading: (mealId: string) => boolean;
  onEdit: (planId: string) => void;
  onDelete: (planId: string) => void;
  onSubscribe: (plan: MealPlan) => void;
}

const MealPlanGrid = ({
  mealPlans,
  getMealDetails,
  isMealLoading,
  onEdit,
  onDelete,
  onSubscribe,
}: MealPlanGridProps) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {mealPlans.map((plan) => (
        <MealPlanCard
          key={plan.id}
          plan={plan}
          getMealDetails={getMealDetails}
          isMealLoading={isMealLoading}
          onEdit={onEdit}
          onDelete={onDelete}
          onSubscribe={onSubscribe}
        />
      ))}
    </div>
  );
};

export default MealPlanGrid;
