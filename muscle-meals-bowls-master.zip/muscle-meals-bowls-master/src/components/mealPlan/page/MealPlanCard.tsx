import { useState, useRef, useEffect } from "react";
import {
  CheckCircle,
  MoreVertical,
  Edit,
  Trash2,
  Calendar,
} from "lucide-react";
import { format } from "date-fns";
import Button from "@/components/ui/Button";
import { MealPlan } from "@/store/slices/mealPlanSlice";
import MealPlanNutrition from "./MealPlanNutrition";
import MealPlanItemsList from "./MealPlanItemsList";

interface MealPlanCardProps {
  plan: MealPlan;
  getMealDetails: (mealId: string) => any;
  isMealLoading: (mealId: string) => boolean;
  onEdit: (planId: string) => void;
  onDelete: (planId: string) => void;
  onSubscribe: (plan: MealPlan) => void;
}

const MealPlanCard = ({
  plan,
  getMealDetails,
  isMealLoading,
  onEdit,
  onDelete,
  onSubscribe,
}: MealPlanCardProps) => {
  const [expandedItems, setExpandedItems] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  // Close menu when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setMenuOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const toggleExpand = () => {
    setExpandedItems(!expandedItems);
  };

  const toggleMenu = () => {
    setMenuOpen(!menuOpen);
  };

  return (
    <div className="bg-white rounded-xl shadow-md overflow-hidden relative">
      {/* Subscription badge */}
      {plan.isSubscribed && (
        <div className="absolute top-0 left-0 bg-green-500 text-white px-4 py-1 rounded-br-lg flex items-center">
          <CheckCircle className="h-4 w-4 mr-1" />
          <span className="text-xs font-medium">Subscribed</span>
        </div>
      )}

      <div className="p-6">
        {/* Card header with title, description, and actions */}
        <div className="flex justify-between items-start mb-4">
          <div>
            <h3 className="text-xl font-semibold mb-2">{plan.name}</h3>
            <p className="text-gray-600 text-sm line-clamp-2">
              {plan.description}
            </p>
          </div>

          {/* Actions menu */}
          <div className="flex gap-2 relative">
            <button
              onClick={toggleMenu}
              className="text-gray-500 hover:text-gray-700 p-1 rounded-full hover:bg-gray-100"
            >
              <MoreVertical className="h-5 w-5" />
            </button>

            {/* Dropdown Menu */}
            {menuOpen && (
              <div
                ref={menuRef}
                className="absolute right-0 top-8 bg-white shadow-lg rounded-lg py-2 z-10 w-36"
              >
                <button
                  onClick={() => {
                    onEdit(plan.id as string);
                    setMenuOpen(false);
                  }}
                  className="w-full text-left px-4 py-2 hover:bg-gray-100 flex items-center text-sm"
                >
                  <Edit className="h-4 w-4 mr-2 text-blue-500" />
                  Edit Plan
                </button>
                <button
                  onClick={() => {
                    onDelete(plan.id as string);
                    setMenuOpen(false);
                  }}
                  className="w-full text-left px-4 py-2 hover:bg-gray-100 flex items-center text-sm text-red-600"
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete Plan
                </button>
              </div>
            )}

            {!plan.isSubscribed && (
              <Button
                variant="secondary"
                size="sm"
                icon={<Calendar className="h-4 w-4" />}
                onClick={() => onSubscribe(plan)}
              >
                Subscribe
              </Button>
            )}
          </div>
        </div>

        {/* Nutrition grid */}
        <MealPlanNutrition
          protein={plan.totalProtein}
          carbs={plan.totalCarbs}
          fat={plan.totalFat}
          fiber={plan.totalFiber}
          calories={plan.totalCalories}
        />

        {/* Price and created date */}
        <div className="flex justify-between items-center text-xs text-gray-500 mb-4">
          <div>₹{plan.totalPrice.toFixed(2)}</div>
          <div>
            {plan.createdAt &&
              `Created ${format(new Date(plan.createdAt), "MMM d, yyyy")}`}
          </div>
        </div>

        {/* Meal Items Section */}
        <div className="border-t pt-4">
          <button
            onClick={toggleExpand}
            className="w-full text-left text-sm font-medium text-primary hover:text-primary-dark flex items-center justify-between"
          >
            <span>View Meal Items ({plan.items.length})</span>
            <span className="transform transition-transform duration-200">
              {expandedItems ? "▲" : "▼"}
            </span>
          </button>

          {expandedItems && (
            <MealPlanItemsList
              items={plan.items}
              getMealDetails={getMealDetails}
              isMealLoading={isMealLoading}
            />
          )}
        </div>
      </div>
    </div>
  );
};

export default MealPlanCard;
