interface MealPlanNutritionProps {
  protein: number;
  carbs: number;
  fat: number;
  fiber: number;
  calories: number;
}

const MealPlanNutrition = ({
  protein,
  carbs,
  fat,
  fiber,
  calories,
}: MealPlanNutritionProps) => {
  return (
    <div className="grid grid-cols-5 gap-2 mb-4 text-xs">
      <div className="bg-red-50 p-2 rounded text-center">
        <span className="block font-semibold text-red-600">
          {protein.toFixed(1)}g
        </span>
        <span className="text-gray-500">Protein</span>
      </div>
      <div className="bg-yellow-50 p-2 rounded text-center">
        <span className="block font-semibold text-yellow-600">
          {carbs.toFixed(1)}g
        </span>
        <span className="text-gray-500">Carbs</span>
      </div>
      <div className="bg-green-50 p-2 rounded text-center">
        <span className="block font-semibold text-green-600">
          {fat.toFixed(1)}g
        </span>
        <span className="text-gray-500">Fat</span>
      </div>
      <div className="bg-purple-50 p-2 rounded text-center">
        <span className="block font-semibold text-purple-600">
          {fiber?.toFixed(1)}g
        </span>
        <span className="text-gray-500">Fiber</span>
      </div>
      <div className="bg-blue-50 p-2 rounded text-center">
        <span className="block font-semibold text-blue-600">
          {calories.toFixed(1)}
        </span>
        <span className="text-gray-500">Kcal</span>
      </div>
    </div>
  );
};

export default MealPlanNutrition;
