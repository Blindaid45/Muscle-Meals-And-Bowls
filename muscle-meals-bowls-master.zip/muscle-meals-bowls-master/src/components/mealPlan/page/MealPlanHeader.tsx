import { Plus } from "lucide-react";
import Button from "@/components/ui/Button";

interface MealPlanHeaderProps {
  onCreatePlan: () => void;
}

const MealPlanHeader = ({ onCreatePlan }: MealPlanHeaderProps) => {
  return (
    <div className="flex justify-between items-center mb-8">
      <h1 className="text-3xl font-bold text-primary">My Meal Plans</h1>
      <Button
        variant="accent"
        onClick={onCreatePlan}
        icon={<Plus className="h-5 w-5" />}
      >
        Create New Plan
      </Button>
    </div>
  );
};

export default MealPlanHeader;
