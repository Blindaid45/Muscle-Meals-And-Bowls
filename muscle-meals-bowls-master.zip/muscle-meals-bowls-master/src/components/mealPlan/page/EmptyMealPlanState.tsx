import { Plus } from "lucide-react";
import Button from "@/components/ui/Button";

interface EmptyMealPlanStateProps {
  onCreatePlan: () => void;
}

const EmptyMealPlanState = ({ onCreatePlan }: EmptyMealPlanStateProps) => {
  return (
    <div className="text-center py-12">
      <h2 className="text-2xl font-semibold text-gray-700 mb-4">
        No Meal Plans Yet
      </h2>
      <p className="text-gray-500 mb-6">
        Create your first meal plan to start organizing your meals.
      </p>
      <Button
        variant="accent"
        onClick={onCreatePlan}
        icon={<Plus className="h-5 w-5" />}
      >
        Create Your First Plan
      </Button>
    </div>
  );
};

export default EmptyMealPlanState;
