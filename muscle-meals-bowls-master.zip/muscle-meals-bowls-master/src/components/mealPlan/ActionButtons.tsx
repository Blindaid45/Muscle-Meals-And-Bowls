import Button from "@/components/ui/Button";
import { CreditCard } from "lucide-react";
import { Spinner } from "@/components/ui/spinner";

interface ActionButtonsProps {
  onClose: () => void;
  onProceedToPayment: () => void;
  isProcessing: boolean;
  useMockMode: boolean;
  paymentText?: string;
  isEligible: boolean;
}

const ActionButtons = ({
  onClose,
  onProceedToPayment,
  isProcessing,
  useMockMode,
  paymentText = "Proceed to Payment",
  isEligible = false,
}: ActionButtonsProps) => {
  return (
    <div className="flex justify-end gap-3 pt-2">
      <Button
        variant="outline"
        disabled={isProcessing}
        className="disabled:opacity-50 disabled:cursor-not-allowed"
        onClick={onClose}
      >
        Cancel
      </Button>
      <Button
        onClick={onProceedToPayment}
        disabled={isProcessing || !isEligible}
        icon={
          isProcessing ? (
            <Spinner size="sm" />
          ) : (
            <CreditCard className="h-4 w-4" />
          )
        }
      >
        {isProcessing
          ? "Processing..."
          : useMockMode
          ? `${paymentText} (Mock)`
          : paymentText}
      </Button>
    </div>
  );
};

export default ActionButtons;
