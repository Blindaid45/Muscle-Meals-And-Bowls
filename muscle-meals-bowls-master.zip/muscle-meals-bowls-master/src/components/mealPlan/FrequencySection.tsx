import { SUBSCRIPTION_FREQUENCIES } from "./constants";

interface FrequencySectionProps {
  frequency: string;
  setFrequency: (frequency: string) => void;
}

const FrequencySection = ({
  frequency,
  setFrequency,
}: FrequencySectionProps) => {
  return (
    <div>
      <h3 className="text-sm font-medium mb-3">Billing Frequency</h3>
      <div className="flex flex-wrap gap-2">
        {SUBSCRIPTION_FREQUENCIES.map((option) => (
          <button
            key={option.id}
            onClick={() => setFrequency(option.id)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors
              ${
                frequency === option.id
                  ? "bg-primary text-white"
                  : "bg-gray-100 text-gray-700 hover:bg-gray-200"
              }`}
          >
            {option.label}
          </button>
        ))}
      </div>
      <p className="text-xs text-gray-500 mt-1">
        How often you want to be billed for this subscription
      </p>
    </div>
  );
};

export default FrequencySection;
