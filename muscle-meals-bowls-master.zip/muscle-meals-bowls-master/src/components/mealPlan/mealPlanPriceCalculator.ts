import { Meal } from "@/store/slices/mealSlice";

interface MealTimeState {
  quantity: number;
  mealTimes: string[];
  dayNumbers: number[];
}

interface PriceChangeFactors {
  quantity: number;
  mealTimes: number;
  days: number;
}

export function calculatePriceChange(
  meal: Meal | undefined,
  originalState: MealTimeState,
  newState: MealTimeState
): {
  totalPriceDifference: number;
  priceChangeFactors: PriceChangeFactors | null;
} {
  if (!meal || !meal.price) {
    return { totalPriceDifference: 0, priceChangeFactors: null };
  }

  // Calculate price per gram using the base price and base quantity
  const pricePerGram = meal.price / meal.baseQuantity;

  // Calculate BEFORE state (original price)
  const originalPrice =
    pricePerGram *
    originalState.quantity *
    originalState.mealTimes.length *
    originalState.dayNumbers.length;

  // Calculate AFTER state (new price)
  const newPrice =
    pricePerGram *
    newState.quantity *
    newState.mealTimes.length *
    newState.dayNumbers.length;

  // Calculate the total price difference
  const totalPriceDifference = newPrice - originalPrice;

  // Calculate detailed breakdowns for UI display:

  // 1. Quantity change impact (keeping meal times and days constant)
  const quantityChangeImpact =
    pricePerGram *
    (newState.quantity - originalState.quantity) *
    originalState.mealTimes.length *
    originalState.dayNumbers.length;

  // 2. Meal time changes impact
  // Calculate the difference in meal times
  const addedMealTimes = newState.mealTimes.filter(
    (mt) => !originalState.mealTimes.includes(mt)
  );
  const removedMealTimes = originalState.mealTimes.filter(
    (mt) => !newState.mealTimes.includes(mt)
  );

  // Cost of added meal times
  const addedMealTimesCost =
    addedMealTimes.length *
    pricePerGram *
    newState.quantity *
    newState.dayNumbers.length;

  // Cost of removed meal times
  const removedMealTimesCost =
    removedMealTimes.length *
    pricePerGram *
    originalState.quantity *
    originalState.dayNumbers.length;

  // Net impact of meal time changes
  const mealTimesChangeImpact = addedMealTimesCost - removedMealTimesCost;

  // 3. Day changes impact
  // Calculate the difference in days
  const addedDays = newState.dayNumbers.filter(
    (day) => !originalState.dayNumbers.includes(day)
  );
  const removedDays = originalState.dayNumbers.filter(
    (day) => !newState.dayNumbers.includes(day)
  );

  // Cost of added days
  const addedDaysCost =
    addedDays.length *
    pricePerGram *
    newState.quantity *
    newState.mealTimes.length;

  // Cost of removed days
  const removedDaysCost =
    removedDays.length *
    pricePerGram *
    originalState.quantity *
    originalState.mealTimes.length;

  // Net impact of day changes
  const daysChangeImpact = addedDaysCost - removedDaysCost;

  return {
    totalPriceDifference,
    priceChangeFactors: {
      quantity: quantityChangeImpact,
      mealTimes: mealTimesChangeImpact,
      days: daysChangeImpact,
    },
  };
}
