import { useState, useEffect } from "react";
import { useAppDispatch, useAppSelector } from "@/store/hooks";
import {
  createMealPlan,
  fetchMealPlanById,
  updateMealPlan,
  MealPlan,
} from "@/store/slices/mealPlanSlice";

import { XCircle, Save } from "lucide-react";
import Button from "@/components/ui/Button";
import { Spinner } from "@/components/ui/spinner";
import Modal from "@/components/ui/Modal";

import MealPlanBasicInfoForm from "./MealPlanBasicInfoForm";
import MealPlanItemsList from "./MealPlanItemsList";
import MealPlanItemEditModal from "./MealPlanItemEditModal";
import { useMealPlanItems } from "@/hooks/useMealPlanItems";

interface MealPlanModalProps {
  isOpen: boolean;
  onClose: () => void;
  planId?: string | null;
}

// Initial values for a new meal plan
const initialFormState: Omit<
  MealPlan,
  | "id"
  | "userId"
  | "createdAt"
  | "updatedAt"
  | "totalCalories"
  | "totalProtein"
  | "totalCarbs"
  | "totalFat"
  | "totalFiber"
  | "totalPrice"
> = {
  name: "",
  description: "",
  duration: 7,
  isPublic: false,
  tags: [],
  items: [],
};

const MealPlanModal = ({ isOpen, onClose, planId }: MealPlanModalProps) => {
  const dispatch = useAppDispatch();

  const { currentMealPlan, loading } = useAppSelector(
    (state) => state.mealPlans
  );

  const [formState, setFormState] = useState(initialFormState);

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [activeTab, setActiveTab] = useState<"basic" | "meals">("basic");
  const [editModalOpen, setEditModalOpen] = useState(false);
  const [editItemId, setEditItemId] = useState<string | null>(null);

  const { fetchMealDetails, isMealLoading, getMealDetails } = useMealPlanItems(
    formState.items
  );

  // Load existing meal plan data if editing
  useEffect(() => {
    if (planId) {
      dispatch(fetchMealPlanById(planId));
    } else {
      setFormState(initialFormState);
    }
  }, [dispatch, planId]);

  // Update form when current meal plan changes
  useEffect(() => {
    if (currentMealPlan && planId) {
      setFormState({
        name: currentMealPlan.name,
        description: currentMealPlan.description,
        duration: currentMealPlan.duration,
        isPublic: currentMealPlan.isPublic,
        tags: currentMealPlan.tags,
        items: currentMealPlan.items,
      });
    }
  }, [currentMealPlan, planId]);

  // Fetch meal details for all meal items when items change
  useEffect(() => {
    if (formState.items.length > 0) {
      fetchMealDetails();
    }
  }, [formState.items, fetchMealDetails]);

  const handleEditModalClose = () => {
    setEditModalOpen(false);
    setEditItemId(null);
  };

  const openEditModal = (itemId: string) => {
    setEditItemId(itemId);
    setEditModalOpen(true);
  };

  // Handle form updates from the basic info form
  const updateFormState = (newState: Partial<typeof formState>) => {
    setFormState((prev) => ({ ...prev, ...newState }));
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formState.name.trim()) {
      newErrors.name = "Name is required";
    }

    if (!formState.description.trim()) {
      newErrors.description = "Description is required";
    }

    if (!formState.duration || formState.duration < 1) {
      newErrors.duration = "Duration must be at least 1 day";
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    // Create empty placeholders for required numeric fields
    // These will be calculated by the backend based on items
    const mealPlanData = {
      ...formState,
      totalCalories: 0,
      totalProtein: 0,
      totalCarbs: 0,
      totalFat: 0,
      totalFiber: 0,
      totalPrice: 0,
    };

    try {
      if (planId) {
        await dispatch(
          updateMealPlan({ id: planId, ...mealPlanData })
        ).unwrap();
      } else {
        await dispatch(createMealPlan(mealPlanData)).unwrap();
      }
      onClose();
    } catch (error) {
      console.error("Error saving meal plan:", error);
    }
  };

  return (
    <>
      <Modal
        isOpen={isOpen}
        onClose={onClose}
        title={planId ? "Edit Meal Plan" : "Create Meal Plan"}
        size="lg"
      >
        <div className="mb-4 border-b">
          <div className="flex space-x-4">
            <button
              className={`pb-2 px-1 ${
                activeTab === "basic"
                  ? "border-b-2 border-primary text-primary"
                  : "text-gray-500 hover:text-gray-700"
              }`}
              onClick={() => setActiveTab("basic")}
            >
              Basic Information
            </button>
            {planId && (
              <button
                className={`pb-2 px-1 ${
                  activeTab === "meals"
                    ? "border-b-2 border-primary text-primary"
                    : "text-gray-500 hover:text-gray-700"
                }`}
                onClick={() => setActiveTab("meals")}
              >
                Meal Options
              </button>
            )}
          </div>
        </div>

        {activeTab === "basic" ? (
          <form onSubmit={handleSubmit} className="space-y-6">
            <MealPlanBasicInfoForm
              formState={formState}
              errors={errors}
              updateFormState={updateFormState}
            />

            {/* Form actions */}
            <div className="flex items-center justify-end space-x-3 pt-4 border-t">
              <Button
                variant="outline"
                type="button"
                onClick={onClose}
                icon={<XCircle className="h-5 w-5" />}
              >
                Cancel
              </Button>
              <Button
                variant="accent"
                type="submit"
                disabled={loading}
                icon={
                  loading ? <Spinner size="sm" /> : <Save className="h-5 w-5" />
                }
              >
                {planId ? "Update Plan" : "Create Plan"}
              </Button>
            </div>
          </form>
        ) : (
          <MealPlanItemsList
            items={formState.items}
            planId={planId}
            getMealDetails={getMealDetails}
            isMealLoading={isMealLoading}
            onEditItem={openEditModal}
            onItemsChange={(newItems) => updateFormState({ items: newItems })}
          />
        )}
      </Modal>

      {editItemId && (
        <MealPlanItemEditModal
          isOpen={editModalOpen}
          onClose={handleEditModalClose}
          planId={planId}
          itemId={editItemId}
          items={formState.items}
          getMealDetails={getMealDetails}
        />
      )}
    </>
  );
};

export default MealPlanModal;
