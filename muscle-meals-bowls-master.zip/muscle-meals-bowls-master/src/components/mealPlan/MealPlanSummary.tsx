import { MealPlan } from "@/store/slices/mealPlanSlice";
import { AdminMealPlan } from "@/store/slices/adminMealPlanSlice";

// Type that can be either MealPlan or AdminMealPlan
type MealPlanType = MealPlan | AdminMealPlan;

interface MealPlanSummaryProps {
  mealPlan: MealPlanType;
}

const MealPlanSummary = ({ mealPlan }: MealPlanSummaryProps) => {
  return (
    <div className="bg-neutral-light p-4 rounded-lg">
      <h3 className="font-semibold mb-2">Meal Plan Summary</h3>
      <div className="text-sm space-y-1">
        <div className="flex justify-between">
          <span>Plan:</span>
          <span>{mealPlan?.name || "N/A"}</span>
        </div>
        <div className="flex justify-between">
          <span>Total Protein:</span>
          <span>{mealPlan?.totalProtein?.toFixed(1) || 0}g</span>
        </div>
        <div className="flex justify-between">
          <span>Total Carbs:</span>
          <span>{mealPlan?.totalCarbs?.toFixed(1) || 0}g</span>
        </div>
        <div className="flex justify-between">
          <span>Total Fat:</span>
          <span>{mealPlan?.totalFat?.toFixed(1) || 0}g</span>
        </div>
        <div className="flex justify-between">
          <span>Total Fiber:</span>
          <span>{mealPlan?.totalFiber?.toFixed(1) || 0}g</span>
        </div>
        <div className="flex justify-between">
          <span>Total Calories:</span>
          <span>{mealPlan?.totalCalories?.toFixed(1) || 0}</span>
        </div>
        <div className="flex justify-between">
          <span>Meals:</span>
          <span>{mealPlan?.items.length || 0}</span>
        </div>
      </div>
    </div>
  );
};

export default MealPlanSummary;
