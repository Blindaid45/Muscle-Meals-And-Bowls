import { useState } from "react";
import { Calendar } from "lucide-react";
import { format, isBefore, addDays } from "date-fns";
import { DayPicker } from "react-day-picker";
import Button from "@/components/ui/Button";

interface DateSelectionSectionProps {
  startDate: Date;
  endDate: Date;
  setStartDate: (date: Date) => void;
  setEndDate: (date: Date) => void;
}

const DateSelectionSection = ({
  startDate,
  endDate,
  setStartDate,
  setEndDate,
}: DateSelectionSectionProps) => {
  const [showStartDatePicker, setShowStartDatePicker] = useState(false);
  const [showEndDatePicker, setShowEndDatePicker] = useState(false);

  // Helper to check if a date should be disabled
  const isDateDisabled = (date: Date) => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return isBefore(date, today);
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <div>
        <h3 className="text-sm font-medium mb-3">Start Date</h3>
        <div className="bg-gray-50 p-4 rounded-lg border">
          <div className="flex items-center justify-between mb-3">
            <div>
              <Calendar className="h-5 w-5 text-gray-500 inline mr-2" />
              {format(startDate, "PPP")}
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowStartDatePicker(!showStartDatePicker)}
            >
              {showStartDatePicker ? "Hide" : "Change"}
            </Button>
          </div>
          {showStartDatePicker && (
            <div className="bg-white border rounded-lg p-2">
              <DayPicker
                mode="single"
                selected={startDate}
                onSelect={(date) => {
                  if (date) {
                    setStartDate(date);
                    // If start date is after end date, adjust end date
                    if (isBefore(endDate, date)) {
                      setEndDate(addDays(date, 7));
                    }
                  }
                }}
                disabled={isDateDisabled}
                fromMonth={new Date()}
                toYear={new Date().getFullYear() + 1}
              />
            </div>
          )}
        </div>
      </div>
      <div>
        <h3 className="text-sm font-medium mb-3">End Date</h3>
        <div className="bg-gray-50 p-4 rounded-lg border">
          <div className="flex items-center justify-between mb-3">
            <div>
              <Calendar className="h-5 w-5 text-gray-500 inline mr-2" />
              {format(endDate, "PPP")}
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowEndDatePicker(!showEndDatePicker)}
            >
              {showEndDatePicker ? "Hide" : "Change"}
            </Button>
          </div>
          {showEndDatePicker && (
            <div className="bg-white border rounded-lg p-2">
              <DayPicker
                mode="single"
                selected={endDate}
                onSelect={(date) => date && setEndDate(date)}
                disabled={(date) => isBefore(date, startDate)}
                fromMonth={startDate}
                toYear={new Date().getFullYear() + 1}
              />
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default DateSelectionSection;
