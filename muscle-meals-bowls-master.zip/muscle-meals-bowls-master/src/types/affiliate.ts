export interface Affiliate {
  affiliateId: string;
  userId: string;
  couponCode: string;
  upiId: string;
  isActive: boolean;
  totalEarnings: number;
  totalReferrals: number;
  createdAt: string;
  updatedAt: string;
}

export interface CouponUsage {
  usageId: string;
  couponCode: string;
  affiliateId: string;
  userId: string; // User who used the coupon
  orderId: string;
  subscriptionId: string;
  discountAmount: number;
  commissionAmount: number;
  subscriptionType: "weekly" | "monthly";
  originalAmount: number;
  finalAmount: number;
  status: "pending" | "processed" | "failed";
  createdAt: string;
  processedAt?: string;
}

export interface AffiliateStats {
  totalEarnings: number;
  totalReferrals: number;
  pendingCommissions: number;
  thisMonthEarnings: number;
  thisMonthReferrals: number;
}

export interface CreateAffiliateRequest {
  desiredCode: string;
  upiId: string;
}

export interface ValidateCouponRequest {
  couponCode: string;
  subscriptionAmount: number;
  subscriptionType: "weekly" | "monthly";
}

export interface ValidateCouponResponse {
  isValid: boolean;
  discountAmount: number;
  discountPercentage: number;
  finalAmount: number;
  affiliateId?: string;
  error?: string;
}
