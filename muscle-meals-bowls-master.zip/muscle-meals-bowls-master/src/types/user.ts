export interface User {
  uid: string;
  email: string | null;
  displayName: string | null;
  photoURL?: string | null;
}

export interface UserProfile {
  displayName?: string;
  phoneNumber?: string;
  weight?: number | null;
  height?: number | null;
  fitnessGoal?: string;
  photoURL?: string | null;
  isFirstTimeUser?: boolean;
}
