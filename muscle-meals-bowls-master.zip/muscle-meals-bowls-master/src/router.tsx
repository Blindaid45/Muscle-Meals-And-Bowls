import { createBrowserRouter, Navigate, Outlet } from "react-router-dom";
import { Suspense, lazy } from "react";
import { Toaster } from "sonner";

// Layouts
import Layout from "@/components/layout/Layout";
import AdminLayout from "@/components/admin/AdminLayout";

// Guards
import AuthGuard from "@/components/auth/AuthGuard";
import AdminGuard from "@/components/auth/AdminGuard";

// Regular pages - Eagerly loaded
import HomePage from "@/pages/HomePage";
import NotFoundPage from "@/pages/NotFoundPage";
import WalletPage from "./pages/WalletPage";

// Lazy loaded pages with error handling
const MealCatalogPage = lazy(() => import("@/pages/MealCatalogPage"));
const MealDetailPage = lazy(() => import("@/pages/MealDetailPage"));
const SubscriptionPage = lazy(() => import("@/pages/SubscriptionPage"));
const CartPage = lazy(() => import("@/pages/CartPage"));
const MealPlanPage = lazy(() => import("@/pages/MealPlanPage"));
const ProfilePage = lazy(() => import("@/pages/ProfilePage"));
const AffiliatePage = lazy(() => import("@/pages/AffiliatePage"));
const LoginPage = lazy(() => import("@/pages/LoginPage"));
const RegisterPage = lazy(() => import("@/pages/RegisterPage"));
const ForgotPasswordPage = lazy(() => import("@/pages/ForgotPasswordPage"));
const FAQPage = lazy(() => import("@/pages/FAQPage"));
const PrivacyPolicyPage = lazy(() => import("@/pages/PrivacyPolicyPage"));
const TermsPage = lazy(() => import("@/pages/TermsPage"));

// Admin pages
const AdminLoginPage = lazy(() => import("@/pages/admin/AdminLoginPage"));
const AdminRegisterPage = lazy(() => import("@/pages/admin/AdminRegisterPage"));
const AdminDashboardPage = lazy(
  () => import("@/pages/admin/AdminDashboardPage")
);
const AdminMealsPage = lazy(() => import("@/pages/admin/AdminMealsPage"));
const AdminMealPlansPage = lazy(
  () => import("@/pages/admin/AdminMealPlansPage")
);
const AdminUsersPage = lazy(() => import("@/pages/admin/AdminUsersPage"));
const AdminOrdersPage = lazy(() => import("@/pages/admin/AdminOrdersPage"));
const AdminAffiliateManagementPage = lazy(
  () => import("@/pages/admin/AdminAffiliateManagementPage")
);
const AdminSettingsPage = lazy(() => import("@/pages/admin/AdminSettingsPage"));

// Loading component for suspense
const PageLoader = () => (
  <div className="min-h-screen flex items-center justify-center">
    <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"></div>
  </div>
);

// Error fallback component
const ErrorFallback = () => (
  <div className="min-h-screen flex flex-col items-center justify-center p-4">
    <h2 className="text-2xl font-bold text-red-600 mb-4">
      Something went wrong
    </h2>
    <p className="text-gray-600 mb-6">
      Sorry, an unexpected error has occurred.
    </p>
    <button
      onClick={() => (window.location.href = "/")}
      className="px-4 py-2 bg-primary text-white rounded-md"
    >
      Go Home
    </button>
  </div>
);

// Root layout with Toaster
const RootLayout = () => {
  return (
    <>
      <Toaster
        theme="light"
        position="bottom-right"
        className="rounded-md border border-primary-50"
        closeButton
        richColors
      />
      <Outlet />
    </>
  );
};

// Protected route wrapper
const ProtectedRoute = ({ children }: { children: React.ReactNode }) => {
  return <AuthGuard>{children}</AuthGuard>;
};

// Admin route wrapper
const AdminRoute = ({ children }: { children: React.ReactNode }) => {
  return <AdminGuard>{children}</AdminGuard>;
};

// Wrapper for lazy-loaded components with error boundary
const LazyComponentWithFallback = ({
  component: Component,
}: {
  component: React.ComponentType;
}) => {
  return (
    <Suspense fallback={<PageLoader />}>
      <Component />
    </Suspense>
  );
};

export const router = createBrowserRouter([
  {
    element: <RootLayout />,
    errorElement: <ErrorFallback />,
    children: [
      {
        path: "/",
        element: <Layout />,
        children: [
          { index: true, element: <HomePage /> },
          {
            path: "meals",
            element: <LazyComponentWithFallback component={MealCatalogPage} />,
          },
          {
            path: "meals/:id",
            element: <LazyComponentWithFallback component={MealDetailPage} />,
          },
          {
            path: "subscriptions",
            element: <LazyComponentWithFallback component={SubscriptionPage} />,
          },
          {
            path: "faq",
            element: <LazyComponentWithFallback component={FAQPage} />,
          },
          {
            path: "privacy-policy",
            element: (
              <LazyComponentWithFallback component={PrivacyPolicyPage} />
            ),
          },
          {
            path: "terms",
            element: <LazyComponentWithFallback component={TermsPage} />,
          },

          // Legacy route redirects
          { path: "cart", element: <Navigate to="/user/cart" replace /> },
          {
            path: "meal-plans",
            element: <Navigate to="/user/meal-plans" replace />,
          },
          { path: "profile", element: <Navigate to="/user/profile" replace /> },
        ],
      },

      // Protected User Routes
      {
        path: "/user",
        element: <Layout />,
        children: [
          {
            path: "cart",
            element: (
              <ProtectedRoute>
                <LazyComponentWithFallback component={CartPage} />
              </ProtectedRoute>
            ),
          },
          {
            path: "meal-plans",
            element: (
              <ProtectedRoute>
                <LazyComponentWithFallback component={MealPlanPage} />
              </ProtectedRoute>
            ),
          },
          {
            path: "profile",
            element: (
              <ProtectedRoute>
                <LazyComponentWithFallback component={ProfilePage} />
              </ProtectedRoute>
            ),
          },
          {
            path: "wallet",
            element: (
              <ProtectedRoute>
                <LazyComponentWithFallback component={WalletPage} />
              </ProtectedRoute>
            ),
          },
          {
            path: "affiliate",
            element: (
              <ProtectedRoute>
                <LazyComponentWithFallback component={AffiliatePage} />
              </ProtectedRoute>
            ),
          },
        ],
      },

      // Auth Routes
      {
        path: "/auth",
        children: [
          {
            path: "login",
            element: <LazyComponentWithFallback component={LoginPage} />,
          },
          {
            path: "register",
            element: <LazyComponentWithFallback component={RegisterPage} />,
          },
          {
            path: "forgot-password",
            element: (
              <LazyComponentWithFallback component={ForgotPasswordPage} />
            ),
          },
          {
            path: "admin",
            children: [
              {
                index: true,
                element: (
                  <LazyComponentWithFallback component={AdminLoginPage} />
                ),
              },
              {
                path: "register",
                element: (
                  <LazyComponentWithFallback component={AdminRegisterPage} />
                ),
              },
            ],
          },
        ],
      },

      // Admin Routes
      {
        path: "/admin",
        element: (
          <AdminRoute>
            <AdminLayout />
          </AdminRoute>
        ),
        children: [
          {
            index: true,
            element: (
              <LazyComponentWithFallback component={AdminDashboardPage} />
            ),
          },
          {
            path: "meals",
            element: <LazyComponentWithFallback component={AdminMealsPage} />,
          },
          {
            path: "meal-plans",
            element: (
              <LazyComponentWithFallback component={AdminMealPlansPage} />
            ),
          },
          {
            path: "users",
            element: <LazyComponentWithFallback component={AdminUsersPage} />,
          },
          {
            path: "orders",
            element: <LazyComponentWithFallback component={AdminOrdersPage} />,
          },
          {
            path: "affiliate-management",
            element: (
              <LazyComponentWithFallback
                component={AdminAffiliateManagementPage}
              />
            ),
          },
          {
            path: "settings",
            element: (
              <LazyComponentWithFallback component={AdminSettingsPage} />
            ),
          },
        ],
      },

      // Catch-all route for 404
      {
        path: "*",
        element: <NotFoundPage />,
      },
    ],
  },
]);

export default router;
