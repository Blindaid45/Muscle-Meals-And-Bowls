export interface UnitOption {
  value: string;
  label: string;
  description: string;
}

export const MEAL_UNITS: UnitOption[] = [
  {
    value: "g",
    label: "Grams (g)",
    description: "Weight-based measurement for most meals",
  },
  {
    value: "pieces",
    label: "Pieces",
    description: "Count-based measurement for items like cookies, rolls, etc.",
  },
  {
    value: "bowls",
    label: "Bowls",
    description: "Portion-based measurement for soups, salads, etc.",
  },
  {
    value: "cups",
    label: "Cups",
    description: "Volume-based measurement for beverages and liquids",
  },
  {
    value: "servings",
    label: "Servings",
    description: "Standard portion-based measurement",
  },
  {
    value: "ml",
    label: "Milliliters (ml)",
    description: "Volume-based measurement for liquids",
  },
];

export const DEFAULT_UNIT = "g";

// Helper function to get unit label by value
export const getUnitLabel = (value: string): string => {
  const unit = MEAL_UNITS.find((u) => u.value === value);
  return unit ? unit.label : value;
};

// Helper function to get unit description by value
export const getUnitDescription = (value: string): string => {
  const unit = MEAL_UNITS.find((u) => u.value === value);
  return unit ? unit.description : "";
};
