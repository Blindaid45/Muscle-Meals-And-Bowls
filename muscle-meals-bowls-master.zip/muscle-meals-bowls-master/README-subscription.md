# Meal Plan Subscription Implementation

## Overview

This implementation moves the subscription functionality from individual meal details to the meal plans page, allowing users to subscribe to entire meal plans rather than single meals.

## Key Components

### 1. SubscriptionPlanModal

- Located at `src/components/mealPlan/SubscriptionPlanModal.tsx`
- Allows users to select:
  - Subscription duration (1 week, 2 weeks, 1 month, 3 months)
  - Start and end dates with date picker
  - Billing frequency (weekly, bi-weekly, monthly)
- Calculates price with tiered discounts based on subscription length
- Displays meal plan nutritional summary
- Integrates with Razorpay for payment processing

### 2. MealPlanPage Updates

- Added subscription button to each meal plan card
- Implemented state management for subscription modal
- Connected subscription button to open the modal with the selected plan

### 3. Razorpay Integration

- Updated to handle both meal and meal plan subscriptions
- Created separate interfaces for meal and meal plan subscription requests
- Included subscription type in the payment request

### 4. MealDetail Updates

- Removed subscription button and functionality
- Updated promotional text to direct users to meal plans for subscriptions

### 5. Firebase Cloud Functions

Located in the `functions/` directory, these handle the secure backend operations:

- **createRazorpayOrder**: Creates a new order in Razorpay and stores subscription data in Firestore
- **verifyRazorpayPayment**: Verifies payment signatures and updates subscription status
- **razorpayWebhook**: Handles webhook events from Razorpay for automated status updates

## How It Works

1. Users create meal plans with multiple meals for different days/times
2. From the Meal Plans page, users can click "Subscribe" on any plan
3. The subscription modal opens, showing plan details and allowing subscription configuration
4. Upon proceeding to payment:
   - The client calls the `createRazorpayOrder` Cloud Function
   - The function creates a Razorpay order and stores subscription details in Firestore
   - The Razorpay payment flow is initiated in the browser
5. After payment completion:
   - The client calls the `verifyRazorpayPayment` Cloud Function
   - The function verifies the payment signature and updates subscription status
   - The subscription is added to the user's active subscriptions
6. Razorpay also sends webhook events to the `razorpayWebhook` function to handle automated status updates

## Deployment Steps

1. Install dependencies in the functions directory:

   ```
   cd functions
   npm install
   ```

2. Configure Razorpay API keys:

   ```
   firebase functions:config:set razorpay.key_id="YOUR_RAZORPAY_KEY_ID" razorpay.key_secret="YOUR_RAZORPAY_KEY_SECRET" razorpay.webhook_secret="YOUR_WEBHOOK_SECRET"
   ```

3. Deploy the functions:

   ```
   npm run deploy
   ```

4. Configure the webhook in the Razorpay dashboard pointing to:
   ```
   https://<your-region>-<your-project-id>.cloudfunctions.net/razorpayWebhook
   ```

## Future Improvements

- Add subscription management interface for users to view/modify active subscriptions
- Implement subscription renewal notifications
- Add ability to pause/resume subscriptions
- Implement detailed analytics for subscription usage

## Technical Notes

- The implementation uses React with TypeScript
- State management is handled through Redux
- Razorpay is used for payment processing
- Firebase Cloud Functions handle secure backend operations
- Firestore stores subscription data and user's active subscriptions
