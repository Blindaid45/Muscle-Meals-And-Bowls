# Admin Orders Management System

This document describes the implementation of the admin orders page, where administrators can view and manage all customer orders (subscriptions).

## Implementation Details

### Data Model

The admin orders page displays subscription data with related meal plan information. Each subscription contains:

- Basic subscription details: ID, amount, currency, start/end dates, status, etc.
- Related meal plan information: name, description, nutritional information, etc.

### Components Created

1. **Subscription Slice (`src/store/slices/subscriptionSlice.ts`)**:

   - Manages subscription data in Redux store
   - Provides actions for fetching subscriptions (all or by user)
   - Handles loading states and errors

2. **Admin Orders Page (`src/pages/admin/AdminOrdersPage.tsx`)**:
   - Displays a table of all orders/subscriptions
   - Provides filtering by status and search functionality
   - Includes detailed view of each subscription in a modal dialog
   - Shows related meal plan information

### Routes

Added a new route to the admin section:

- `/admin/orders` - Lists all customer orders

### Navigation

The AdminSidebar already included an "Orders" navigation item with the ShoppingBag icon.

## Features

- **View All Orders**: Administrators can see all customer orders in a tabular format
- **Filter Orders**: Filter by status (active, pending, cancelled) or search by ID, user ID, plan name
- **Detailed View**: Click on an order to see detailed information including:
  - Subscription details (payment ID, frequency, amount, dates)
  - Related meal plan information (name, description, nutrition, tags)
- **Status Indication**: Visual status indicators (color-coded chips) for order status

## Data Flow

1. When the admin orders page loads, it dispatches `fetchAllSubscriptions()` action
2. The subscription slice fetches subscription data from Firebase
3. For each subscription, the related meal plan is also fetched to provide complete information
4. The component displays the loaded data in a table with filtering options
5. Clicking on an order opens a detailed modal view

## Future Enhancements

Possible future enhancements could include:

- Order status management (ability to change status)
- Customer communication features
- Order history and analytics
- Payment tracking and management
