import * as functions from "firebase-functions";
import * as admin from "firebase-admin";
import Razorpay from "razorpay";
import * as crypto from "crypto";
import corsLib from "cors";

// Initialize Firebase
admin.initializeApp();

// Initialize Cors middleware
const corsHandler = corsLib({ origin: true });

const razorpayInstance = new Razorpay({
  key_id: functions.config().razorpay?.key_id,
  key_secret: functions.config().razorpay?.key_secret,
});

/**
 * Create a Razorpay subscription plan
 */
export const createRazorpayPlan = functions.https.onCall(
  async (data, context) => {
    // Check if user is authenticated
    if (!context.auth) {
      throw new functions.https.HttpsError(
        "unauthenticated",
        "User must be authenticated to create a plan."
      );
    }

    try {
      console.log("Creating Razorpay plan with data:", data);

      // Validate required fields
      if (!data.amount || data.amount <= 0) {
        throw new functions.https.HttpsError(
          "invalid-argument",
          "Amount must be greater than 0"
        );
      }

      if (!data.frequency) {
        throw new functions.https.HttpsError(
          "invalid-argument",
          "Frequency is required"
        );
      }

      // Map frequency to Razorpay period and interval
      let period: "weekly" | "monthly" | "daily" | "yearly";
      let interval: number;
      switch (data.frequency) {
        case "weekly":
          period = "weekly";
          interval = 1;
          break;
        case "biweekly":
          period = "weekly";
          interval = 2;
          break;
        case "monthly":
          period = "monthly";
          interval = 1;
          break;
        default:
          throw new functions.https.HttpsError(
            "invalid-argument",
            "Invalid frequency. Must be weekly, biweekly, or monthly"
          );
      }

      // Create plan options
      const planName = data.mealPlanId
        ? `Meal Plan Subscription - ${data.mealPlanId.substring(0, 8)}`
        : `Meal Subscription - ${Date.now()}`;

      const planOptions = {
        period: period,
        interval: interval,
        item: {
          name: planName,
          amount: Math.round(data.amount * 100), // Convert to paise
          currency: data.currency || "INR",
          description: `${period} subscription for ${data.type || "meal plan"}`,
        },
        notes: {
          userId: context.auth.uid,
          type: data.type || "mealPlan",
          itemId: data.mealPlanId || data.mealId || "",
        },
      };

      // Create Razorpay plan
      const planResult = await razorpayInstance.plans.create(planOptions);
      console.log("Razorpay plan created:", planResult);

      // Extract plan details
      const plan = planResult as unknown as {
        id: string;
        // Add other properties as needed
      };

      return { planId: plan.id, plan: planResult };
    } catch (error) {
      console.error("Error creating Razorpay plan:", error);
      throw new functions.https.HttpsError(
        "internal",
        "Failed to create plan",
        error
      );
    }
  }
);

/**
 * Create a Razorpay subscription
 */
export const createRazorpaySubscription = functions.https.onCall(
  async (data, context) => {
    // Check if user is authenticated
    if (!context.auth) {
      throw new functions.https.HttpsError(
        "unauthenticated",
        "User must be authenticated to create a subscription."
      );
    }

    try {
      console.log("Creating Razorpay subscription with data:", data);

      // Validate required fields
      if (!data.planId) {
        throw new functions.https.HttpsError(
          "invalid-argument",
          "Plan ID is required"
        );
      }

      // Calculate total count (number of billing cycles)
      // If endDate and startDate are provided, calculate billing cycles
      let totalCount = data.totalCount || 12; // Default to 12 cycles (about a year)

      if (data.startDate && data.endDate) {
        const startDate = new Date(data.startDate);
        const endDate = new Date(data.endDate);

        // Calculate difference in months (approximate billing cycles)
        const diffTime = Math.abs(endDate.getTime() - startDate.getTime());
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

        // Convert days to billing cycles based on frequency
        switch (data.frequency) {
          case "weekly":
            totalCount = Math.ceil(diffDays / 7);
            break;
          case "biweekly":
            totalCount = Math.ceil(diffDays / 14);
            break;
          case "monthly":
            totalCount = Math.ceil(diffDays / 30);
            break;
          default:
            totalCount = Math.ceil(diffDays / 30); // Default to monthly
        }

        // Ensure at least 1 billing cycle
        totalCount = Math.max(1, totalCount);
      }

      // Create subscription options
      const subscriptionOptions = {
        plan_id: data.planId,
        total_count: totalCount,
        quantity: data.quantity || 1,
        start_at: Math.floor((new Date().getTime() + 7 * 60 * 1000) / 1000), // Start 7 minutes from now to avoid timing issues
        expire_by: data.endDate
          ? Math.floor(new Date(data.endDate).getTime() / 1000)
          : undefined,
        customer_notify: true, // Notify customer about subscription charges
        // Enable immediate first charge at the time of subscription creation
        addons: [
          {
            item: {
              name: "Immediate setup fee",
              amount: Math.round(data.amount * 100), // Full amount charged upfront
              currency: data.currency || "INR",
            },
          },
        ],
        notes: {
          userId: context.auth.uid,
          type: data.type || "mealPlan",
          itemId: data.mealPlanId || data.mealId || "",
          frequency: data.frequency || "monthly",
          immediateCharge: "true", // Flag to indicate immediate charge is expected
        },
      };

      // Create Razorpay subscription
      const subscriptionResult = await razorpayInstance.subscriptions.create(
        subscriptionOptions
      );
      console.log("Razorpay subscription created:", subscriptionResult);

      // Extract subscription details
      const subscription = subscriptionResult as unknown as {
        id: string;
        status: string;
        // Add other properties as needed
      };

      // Save subscription data to Firestore
      const subscriptionData = {
        userId: context.auth.uid,
        subscriptionId: subscription.id,
        planId: data.planId,
        status: subscription.status,
        type: data.type || "mealPlan",
        itemId: data.mealPlanId || data.mealId || "",
        quantity: data.quantity || 1,
        startDate: data.startDate || new Date().toISOString(),
        endDate: data.endDate,
        frequency: data.frequency || "monthly",
        totalCount: totalCount,
        amount: data.amount,
        currency: data.currency || "INR",
        immediateChargeExpected: true, // Flag to indicate immediate charge is expected
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
        updatedAt: admin.firestore.FieldValue.serverTimestamp(),
      };

      await admin
        .firestore()
        .collection("subscriptions")
        .doc(subscription.id)
        .set(subscriptionData);

      return {
        subscriptionId: subscription.id,
        subscription: subscriptionResult,
      };
    } catch (error) {
      console.error("Error creating Razorpay subscription:", error);
      throw new functions.https.HttpsError(
        "internal",
        "Failed to create subscription",
        error
      );
    }
  }
);

/**
 * Create a Razorpay order for subscriptions
 */
export const createRazorpayOrder = functions.https.onCall(
  async (data, context) => {
    // Check if user is authenticated
    if (!context.auth) {
      throw new functions.https.HttpsError(
        "unauthenticated",
        "User must be authenticated to create an order."
      );
    }

    try {
      const userId = context.auth.uid;
      console.log("Creating order with data:", JSON.stringify(data, null, 2));

      // Validate required fields
      if (!data.amount || data.amount <= 0) {
        throw new functions.https.HttpsError(
          "invalid-argument",
          "Amount must be greater than 0"
        );
      }

      // Create order options
      const orderOptions = {
        amount: Math.round(data.amount * 100), // Razorpay expects amount in paise (multiply by 100)
        currency: data.currency || "INR",
        receipt: `order_${Date.now()}_${userId.substring(0, 5)}`,
        notes: {
          userId: userId,
          type: data.type || "meal", // 'meal' or 'mealPlan'
          itemId: data.mealId || data.mealPlanId || "",
          // Add coupon information to notes
          ...(data.couponCode && {
            couponCode: data.couponCode,
            discountAmount: data.discountAmount?.toString() || "0",
            originalAmount:
              data.originalAmount?.toString() || data.amount.toString(),
          }),
        },
        payment_capture: 1, // Auto-capture payment
      };

      // Create Razorpay order
      const order = await razorpayInstance.orders.create(orderOptions);

      // Prepare subscription data to save
      const subscriptionData = {
        userId,
        orderId: order.id,
        amount: data.amount,
        currency: data.currency || "INR",
        status: "created",
        type: data.type || "meal",
        itemId: data.mealId || data.mealPlanId || "",
        startDate: data.startDate,
        endDate: data.endDate,
        frequency: data.frequency,
        quantity: data.quantity ?? 1, // Ensure quantity has a default value if undefined

        // Store coupon information if provided
        ...(data.couponCode && {
          couponCode: data.couponCode,
          discountAmount: data.discountAmount || 0,
          originalAmount: data.originalAmount || data.amount, // Amount after bulk discount
          finalAmount: data.amount, // This should be the discounted amount
          affiliateId: data.affiliateId,
          subscriptionType:
            data.subscriptionType || data.frequency || "monthly",
          retailAmount: data.retailAmount || data.originalAmount || data.amount, // For commission calculation
        }),

        createdAt: admin.firestore.FieldValue.serverTimestamp(),
        updatedAt: admin.firestore.FieldValue.serverTimestamp(),
      };

      console.log(
        "Saving subscription data:",
        JSON.stringify(subscriptionData, null, 2)
      );

      // Save subscription data to Firestore
      await admin
        .firestore()
        .collection("subscriptions")
        .doc(order.id)
        .set(subscriptionData);

      // Return order ID to client
      return { orderId: order.id };
    } catch (error) {
      console.error("Error creating Razorpay order:", error);
      throw new functions.https.HttpsError(
        "internal",
        "Failed to create order",
        error
      );
    }
  }
);

/**
 * Verify Razorpay payment
 */
export const verifyRazorpayPayment = functions.https.onCall(
  async (data, context) => {
    // Check if user is authenticated
    if (!context.auth) {
      throw new functions.https.HttpsError(
        "unauthenticated",
        "User must be authenticated to verify payment."
      );
    }

    try {
      // Verify signature
      const { razorpay_order_id, razorpay_payment_id, razorpay_signature } =
        data;

      // Validate required fields
      if (!razorpay_order_id || !razorpay_payment_id || !razorpay_signature) {
        throw new functions.https.HttpsError(
          "invalid-argument",
          "Missing required payment verification parameters"
        );
      }

      // Generate expected signature
      const text = `${razorpay_order_id}|${razorpay_payment_id}`;
      const secret = functions.config().razorpay?.key_secret;
      const generatedSignature = crypto
        .createHmac("sha256", secret)
        .update(text)
        .digest("hex");

      // Compare signatures
      if (generatedSignature !== razorpay_signature) {
        throw new functions.https.HttpsError(
          "permission-denied",
          "Invalid payment signature"
        );
      }

      // Update subscription status in Firestore
      await admin
        .firestore()
        .collection("subscriptions")
        .doc(razorpay_order_id)
        .update({
          status: "paid",
          paymentId: razorpay_payment_id,
          updatedAt: admin.firestore.FieldValue.serverTimestamp(),
        });

      // Get subscription data
      const subscriptionDoc = await admin
        .firestore()
        .collection("subscriptions")
        .doc(razorpay_order_id)
        .get();

      if (!subscriptionDoc.exists) {
        throw new functions.https.HttpsError(
          "not-found",
          "Subscription not found"
        );
      }

      const subscription = subscriptionDoc.data();

      // Add subscription to user's active subscriptions
      await admin
        .firestore()
        .collection("users")
        .doc(context.auth.uid)
        .collection("activeSubscriptions")
        .doc(razorpay_order_id)
        .set({
          ...subscription,
          paymentId: razorpay_payment_id,
          status: "active",
          updatedAt: admin.firestore.FieldValue.serverTimestamp(),
        });

      // UPDATE THE MEAL PLAN'S SUBSCRIPTION STATUS
      if (
        subscription &&
        subscription.type === "mealPlan" &&
        subscription.itemId
      ) {
        console.log(
          `Attempting to update meal plan ${subscription.itemId} subscription status...`
        );

        await admin
          .firestore()
          .collection("mealPlans")
          .doc(subscription.itemId)
          .update({
            isSubscribed: true,
            updatedAt: admin.firestore.FieldValue.serverTimestamp(),
          });

        console.log(
          `✅ Updated meal plan ${subscription.itemId} subscription status to true via payment verification`
        );
      } else {
        console.log(
          `❌ Meal plan subscription status NOT updated. Subscription data:`,
          {
            hasSubscription: !!subscription,
            type: subscription?.type,
            itemId: subscription?.itemId,
            reason: !subscription
              ? "No subscription data"
              : subscription.type !== "mealPlan"
              ? `Wrong type: ${subscription.type}`
              : !subscription.itemId
              ? "No itemId"
              : "Unknown",
          }
        );
      }

      // PROCESS COUPON WALLET CREDITS IMMEDIATELY (NO WEBHOOK NEEDED)
      if (
        subscription &&
        subscription.couponCode &&
        subscription.discountAmount
      ) {
        console.log(
          `🎯 IMMEDIATE PROCESSING: Coupon ${subscription.couponCode} detected, processing affiliate commission...`
        );

        try {
          // Calculate commission amount based on subscription type
          const commissionRate =
            subscription.subscriptionType === "monthly" ? 0.1 : 0.05;
          const commissionBaseAmount =
            subscription.retailAmount || subscription.originalAmount;
          const commissionAmount =
            Math.round(commissionBaseAmount * commissionRate * 100) / 100;

          console.log(`💰 Commission Details:`, {
            couponCode: subscription.couponCode,
            subscriptionType: subscription.subscriptionType,
            commissionRate: `${commissionRate * 100}%`,
            commissionBaseAmount: commissionBaseAmount,
            commissionAmount: commissionAmount,
            discountAmount: subscription.discountAmount,
          });

          // Process affiliate wallet credits immediately
          await processCouponWalletCreditsInternal({
            userId: subscription.userId,
            couponCode: subscription.couponCode,
            discountAmount: subscription.discountAmount,
            commissionAmount: commissionAmount,
            subscriptionId: razorpay_order_id,
            orderId: razorpay_order_id,
            originalAmount: subscription.originalAmount || subscription.amount,
            finalAmount:
              subscription.finalAmount ||
              subscription.amount - subscription.discountAmount,
            subscriptionType: subscription.subscriptionType || "monthly",
          });

          console.log(
            `✅ SUCCESS: Affiliate commission ₹${commissionAmount} credited immediately for coupon ${subscription.couponCode}`
          );
        } catch (error) {
          console.error(
            `❌ ERROR: Failed to process affiliate commission for coupon ${subscription.couponCode}:`,
            error
          );
          // Don't throw error to avoid breaking the main payment verification
        }
      } else {
        console.log(
          `ℹ️  No coupon detected in subscription. Skipping affiliate processing.`,
          {
            hasCouponCode: !!subscription?.couponCode,
            hasDiscountAmount: !!subscription?.discountAmount,
            couponCode: subscription?.couponCode || "none",
          }
        );
      }

      return { success: true, message: "Payment verified successfully" };
    } catch (error) {
      console.error("Error verifying payment:", error);
      throw new functions.https.HttpsError(
        "internal",
        "Failed to verify payment",
        error
      );
    }
  }
);

/**
 * Verify Razorpay subscription payment
 */
export const verifyRazorpaySubscription = functions.https.onCall(
  async (data, context) => {
    // Check if user is authenticated
    if (!context.auth) {
      throw new functions.https.HttpsError(
        "unauthenticated",
        "User must be authenticated to verify subscription."
      );
    }

    try {
      // Verify signature for subscription
      const {
        razorpay_payment_id,
        razorpay_subscription_id,
        razorpay_signature,
      } = data;

      // Validate required fields
      if (
        !razorpay_subscription_id ||
        !razorpay_payment_id ||
        !razorpay_signature
      ) {
        throw new functions.https.HttpsError(
          "invalid-argument",
          "Missing required subscription verification parameters"
        );
      }

      // Generate expected signature
      const text = `${razorpay_payment_id}|${razorpay_subscription_id}`;
      const secret = functions.config().razorpay?.key_secret;
      const generatedSignature = crypto
        .createHmac("sha256", secret)
        .update(text)
        .digest("hex");

      // Compare signatures
      if (generatedSignature !== razorpay_signature) {
        throw new functions.https.HttpsError(
          "permission-denied",
          "Invalid subscription signature"
        );
      }

      // Update subscription status in Firestore
      await admin
        .firestore()
        .collection("subscriptions")
        .doc(razorpay_subscription_id)
        .update({
          status: "active",
          paymentId: razorpay_payment_id,
          updatedAt: admin.firestore.FieldValue.serverTimestamp(),
        });

      // Get subscription data
      const subscriptionDoc = await admin
        .firestore()
        .collection("subscriptions")
        .doc(razorpay_subscription_id)
        .get();

      if (!subscriptionDoc.exists) {
        throw new functions.https.HttpsError(
          "not-found",
          "Subscription not found"
        );
      }

      const subscription = subscriptionDoc.data();

      // Add subscription to user's active subscriptions
      await admin
        .firestore()
        .collection("users")
        .doc(context.auth.uid)
        .collection("activeSubscriptions")
        .doc(razorpay_subscription_id)
        .set({
          ...subscription,
          paymentId: razorpay_payment_id,
          status: "active",
          updatedAt: admin.firestore.FieldValue.serverTimestamp(),
        });

      // Update the meal plan's isSubscribed status if this is a meal plan subscription
      if (
        subscription &&
        subscription.type === "mealPlan" &&
        subscription.itemId
      ) {
        // Update the meal plan document
        await admin
          .firestore()
          .collection("mealPlans")
          .doc(subscription.itemId)
          .update({
            isSubscribed: true,
            updatedAt: admin.firestore.FieldValue.serverTimestamp(),
          });

        console.log(
          `Updated meal plan ${subscription.itemId} subscription status to true`
        );
      }

      return { success: true, message: "Subscription verified successfully" };
    } catch (error) {
      console.error("Error verifying subscription:", error);
      throw new functions.https.HttpsError(
        "internal",
        "Failed to verify subscription",
        error
      );
    }
  }
);

/**
 * Webhook handler for Razorpay events
 * Note: Configure this webhook URL in Razorpay dashboard
 */
export const razorpayWebhook = functions.https.onRequest(
  (request, response) => {
    corsHandler(request, response, async () => {
      try {
        // Verify webhook signature
        const webhookSignature = request.headers[
          "x-razorpay-signature"
        ] as string;
        if (!webhookSignature) {
          return response
            .status(400)
            .send({ error: "Missing webhook signature" });
        }

        const webhookSecret =
          functions.config().razorpay?.webhook_secret || "your_webhook_secret";
        const shasum = crypto.createHmac("sha256", webhookSecret);
        shasum.update(JSON.stringify(request.body));
        const digest = shasum.digest("hex");

        if (digest !== webhookSignature) {
          return response
            .status(400)
            .send({ error: "Invalid webhook signature" });
        }

        // Process webhook event
        const event = request.body;
        console.log("Received Razorpay webhook event:", event.event);

        // Handle different event types
        switch (event.event) {
          case "payment.authorized":
            // Payment authorized, update subscription status
            await handlePaymentAuthorized(event.payload.payment.entity);
            break;

          case "payment.failed":
            // Payment failed, update subscription status
            await handlePaymentFailed(event.payload.payment.entity);
            break;

          case "subscription.created":
            // Subscription was created - immediately charge the customer
            await handleSubscriptionCreated(event.payload.subscription.entity);
            break;

          case "subscription.charged":
            // Subscription was charged successfully
            await handleSubscriptionCharged(
              event.payload.subscription.entity,
              event.payload.payment.entity
            );
            break;

          case "subscription.authentication_failed":
            // Subscription authentication failed
            await handleSubscriptionAuthFailed(
              event.payload.subscription.entity
            );
            break;

          // Add more event handlers as needed
        }

        return response.status(200).send({ received: true });
      } catch (error) {
        console.error("Error processing webhook:", error);
        return response
          .status(500)
          .send({ error: "Failed to process webhook" });
      }
    });
  }
);

/**
 * Handle payment authorized event
 */
async function handlePaymentAuthorized(payment: any) {
  try {
    const orderId = payment.order_id;

    // Update subscription status
    await admin.firestore().collection("subscriptions").doc(orderId).update({
      status: "active",
      paymentId: payment.id,
      updatedAt: admin.firestore.FieldValue.serverTimestamp(),
    });

    // Get user ID from subscription
    const subscriptionDoc = await admin
      .firestore()
      .collection("subscriptions")
      .doc(orderId)
      .get();

    if (!subscriptionDoc.exists) {
      throw new Error("Subscription not found");
    }

    const subscription = subscriptionDoc.data();
    if (!subscription) return;

    // Update user's active subscriptions
    await admin
      .firestore()
      .collection("users")
      .doc(subscription.userId)
      .collection("activeSubscriptions")
      .doc(orderId)
      .set({
        ...subscription,
        paymentId: payment.id,
        status: "active",
        updatedAt: admin.firestore.FieldValue.serverTimestamp(),
      });

    // Update the meal plan's isSubscribed status if this is a meal plan payment
    if (subscription.type === "mealPlan" && subscription.itemId) {
      // Update the meal plan document
      await admin
        .firestore()
        .collection("mealPlans")
        .doc(subscription.itemId)
        .update({
          isSubscribed: true,
          updatedAt: admin.firestore.FieldValue.serverTimestamp(),
        });

      console.log(
        `Updated meal plan ${subscription.itemId} subscription status to true via payment`
      );
    }

    // CHECK FOR COUPON USAGE AND PROCESS WALLET CREDITS
    if (subscription.couponCode && subscription.discountAmount) {
      console.log(`Coupon detected in order: ${subscription.couponCode}`);

      try {
        // Calculate commission amount based on subscription type
        // Commission should be calculated on the retail amount (before bulk discounts)
        const commissionRate =
          subscription.subscriptionType === "monthly" ? 0.1 : 0.05;
        const commissionBaseAmount =
          subscription.retailAmount || subscription.originalAmount;
        const commissionAmount =
          Math.round(commissionBaseAmount * commissionRate * 100) / 100;

        // Process wallet credits for both user and affiliate
        await processCouponWalletCreditsInternal({
          userId: subscription.userId,
          couponCode: subscription.couponCode,
          discountAmount: subscription.discountAmount,
          commissionAmount: commissionAmount,
          subscriptionId: orderId,
          orderId: orderId,
          originalAmount: subscription.originalAmount || subscription.amount,
          finalAmount:
            subscription.finalAmount ||
            subscription.amount - subscription.discountAmount,
          subscriptionType: subscription.subscriptionType || "monthly",
        });

        console.log(
          `Successfully processed coupon wallet credits for ${subscription.couponCode}`
        );
      } catch (error) {
        console.error("Error processing coupon wallet credits:", error);
        // Don't throw error to avoid breaking the main payment flow
      }
    }
  } catch (error) {
    console.error("Error handling payment authorized event:", error);
  }
}

/**
 * Handle payment failed event
 */
async function handlePaymentFailed(payment: any) {
  try {
    const orderId = payment.order_id;

    // Update subscription status
    await admin
      .firestore()
      .collection("subscriptions")
      .doc(orderId)
      .update({
        status: "failed",
        paymentId: payment.id,
        failureReason: payment.error_description || payment.error_code,
        updatedAt: admin.firestore.FieldValue.serverTimestamp(),
      });
  } catch (error) {
    console.error("Error handling payment failed event:", error);
  }
}

/**
 * Handle subscription charged event
 */
async function handleSubscriptionCharged(subscription: any, payment: any) {
  try {
    const subscriptionId = subscription.id;

    // Update subscription status in Firestore
    await admin
      .firestore()
      .collection("subscriptions")
      .doc(subscriptionId)
      .update({
        status: "active",
        lastPaymentId: payment.id,
        lastPaymentDate: new Date().toISOString(),
        updatedAt: admin.firestore.FieldValue.serverTimestamp(),
      });

    // Log subscription payment
    await admin
      .firestore()
      .collection("subscriptions")
      .doc(subscriptionId)
      .collection("payments")
      .doc(payment.id)
      .set({
        paymentId: payment.id,
        amount: payment.amount / 100, // Convert from paise to rupees
        status: payment.status,
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
      });

    // Get user ID from subscription
    const subscriptionDoc = await admin
      .firestore()
      .collection("subscriptions")
      .doc(subscriptionId)
      .get();

    if (!subscriptionDoc.exists) {
      throw new Error("Subscription not found");
    }

    const subscriptionData = subscriptionDoc.data();
    if (!subscriptionData) return;

    // Update user's active subscriptions
    await admin
      .firestore()
      .collection("users")
      .doc(subscriptionData.userId)
      .collection("activeSubscriptions")
      .doc(subscriptionId)
      .update({
        status: "active",
        lastPaymentId: payment.id,
        lastPaymentDate: new Date().toISOString(),
        updatedAt: admin.firestore.FieldValue.serverTimestamp(),
      });

    // Update the meal plan's isSubscribed status if this is a meal plan subscription
    if (subscriptionData.type === "mealPlan" && subscriptionData.itemId) {
      // Update the meal plan document
      await admin
        .firestore()
        .collection("mealPlans")
        .doc(subscriptionData.itemId)
        .update({
          isSubscribed: true,
          updatedAt: admin.firestore.FieldValue.serverTimestamp(),
        });

      console.log(
        `Updated meal plan ${subscriptionData.itemId} subscription status to true via webhook`
      );
    }

    // CHECK FOR COUPON USAGE AND PROCESS WALLET CREDITS
    if (subscriptionData.couponCode && subscriptionData.discountAmount) {
      console.log(
        `Coupon detected in subscription: ${subscriptionData.couponCode}`
      );

      try {
        const commissionRate =
          subscriptionData.subscriptionType === "monthly" ? 0.1 : 0.05;
        const commissionBaseAmount =
          subscriptionData.retailAmount || subscriptionData.originalAmount;
        const commissionAmount =
          Math.round(commissionBaseAmount * commissionRate * 100) / 100;

        // Process wallet credits for both user and affiliate
        await processCouponWalletCreditsInternal({
          userId: subscriptionData.userId,
          couponCode: subscriptionData.couponCode,
          discountAmount: subscriptionData.discountAmount,
          commissionAmount: commissionAmount,
          subscriptionId: subscriptionId,
          orderId: payment.order_id || "",
          originalAmount:
            subscriptionData.originalAmount || subscriptionData.amount,
          finalAmount:
            subscriptionData.finalAmount ||
            subscriptionData.amount - subscriptionData.discountAmount,
          subscriptionType: subscriptionData.subscriptionType || "monthly",
        });

        console.log(
          `Successfully processed coupon wallet credits for ${subscriptionData.couponCode}`
        );
      } catch (error) {
        console.error("Error processing coupon wallet credits:", error);
        // Don't throw error to avoid breaking the main subscription flow
      }
    }
  } catch (error) {
    console.error("Error handling subscription charged event:", error);
  }
}

/**
 * Internal function to process coupon wallet credits (for immediate processing)
 */
async function processCouponWalletCreditsInternal(data: {
  userId: string;
  couponCode: string;
  discountAmount: number;
  commissionAmount: number;
  subscriptionId: string;
  orderId: string;
  originalAmount: number;
  finalAmount: number;
  subscriptionType: string;
}) {
  const {
    userId,
    couponCode,
    discountAmount,
    commissionAmount,
    subscriptionId,
    orderId,
    originalAmount,
    finalAmount,
    subscriptionType,
  } = data;

  console.log(`🔍 Processing affiliate commission for coupon: ${couponCode}`);
  console.log(`📊 Processing details:`, {
    userId,
    couponCode,
    commissionAmount,
    subscriptionId,
    subscriptionType,
  });

  // Find affiliate by coupon code
  const affiliatesRef = admin.firestore().collection("affiliates");
  const affiliateSnapshot = await affiliatesRef
    .where("couponCode", "==", couponCode.toUpperCase())
    .where("isActive", "==", true)
    .get();

  if (affiliateSnapshot.empty) {
    throw new Error(`❌ Affiliate not found for coupon code: ${couponCode}`);
  }

  const affiliateDoc = affiliateSnapshot.docs[0];
  const affiliateData = affiliateDoc.data();
  const affiliateId = affiliateDoc.id;

  console.log(
    `👤 Found affiliate: ${affiliateData.name || affiliateId} (${
      affiliateData.userId
    })`
  );

  // Use Firestore transaction to ensure consistency
  await admin.firestore().runTransaction(async (transaction) => {
    // Credit commission to affiliate's wallet
    const affiliateWalletRef = admin
      .firestore()
      .collection("wallets")
      .doc(affiliateData.userId);
    const affiliateWalletDoc = await transaction.get(affiliateWalletRef);

    let affiliatePreviousBalance = 0;
    if (!affiliateWalletDoc.exists) {
      console.log(
        `💳 Creating new wallet for affiliate: ${affiliateData.userId}`
      );
      // Create new wallet for affiliate
      transaction.set(affiliateWalletRef, {
        userId: affiliateData.userId,
        balance: commissionAmount,
        currency: "INR",
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
        updatedAt: admin.firestore.FieldValue.serverTimestamp(),
      });
    } else {
      // Update existing wallet
      const currentData = affiliateWalletDoc.data();
      affiliatePreviousBalance = currentData?.balance || 0;
      console.log(
        `💳 Updating existing wallet. Previous balance: ₹${affiliatePreviousBalance}, Adding: ₹${commissionAmount}`
      );
      transaction.update(affiliateWalletRef, {
        balance: admin.firestore.FieldValue.increment(commissionAmount),
        updatedAt: admin.firestore.FieldValue.serverTimestamp(),
      });
    }

    // Create wallet transaction for affiliate (commission credit)
    const affiliateTransactionRef = admin
      .firestore()
      .collection("walletTransactions")
      .doc();
    transaction.set(affiliateTransactionRef, {
      transactionId: affiliateTransactionRef.id,
      userId: affiliateData.userId,
      type: "credit",
      amount: commissionAmount,
      currency: "INR",
      source: "affiliate-commission",
      description: `Commission from referral using coupon ${couponCode}`,
      orderId: orderId,
      subscriptionId: subscriptionId,
      referenceId: userId, // Reference to the user who used the coupon
      status: "completed",
      previousBalance: affiliatePreviousBalance,
      newBalance: affiliatePreviousBalance + commissionAmount,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
    });

    console.log(
      `📝 Created wallet transaction: ₹${commissionAmount} commission`
    );

    // Create coupon usage record
    const couponUsageRef = admin.firestore().collection("couponUsages").doc();
    transaction.set(couponUsageRef, {
      usageId: couponUsageRef.id,
      couponCode: couponCode,
      affiliateId: affiliateId,
      userId: userId,
      orderId: orderId,
      subscriptionId: subscriptionId,
      discountAmount: discountAmount,
      commissionAmount: commissionAmount,
      subscriptionType: subscriptionType,
      originalAmount: originalAmount,
      finalAmount: finalAmount,
      status: "processed", // Mark as processed since we're crediting wallets immediately
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
      processedAt: admin.firestore.FieldValue.serverTimestamp(),
    });

    console.log(`📋 Created coupon usage record: ${couponUsageRef.id}`);

    // Update affiliate stats
    transaction.update(
      admin.firestore().collection("affiliates").doc(affiliateId),
      {
        totalEarnings: admin.firestore.FieldValue.increment(commissionAmount),
        totalReferrals: admin.firestore.FieldValue.increment(1),
        updatedAt: admin.firestore.FieldValue.serverTimestamp(),
      }
    );

    console.log(
      `📈 Updated affiliate stats: +₹${commissionAmount} earnings, +1 referral`
    );
  });

  console.log(
    `✅ COMPLETED: Successfully processed affiliate commission ₹${commissionAmount} for coupon: ${couponCode}`
  );
}

/**
 * Handle subscription authentication failed event
 */
async function handleSubscriptionAuthFailed(subscription: any) {
  try {
    const subscriptionId = subscription.id;

    // Update subscription status
    await admin
      .firestore()
      .collection("subscriptions")
      .doc(subscriptionId)
      .update({
        status: "authentication_failed",
        failureReason: "Authentication failed for subscription",
        updatedAt: admin.firestore.FieldValue.serverTimestamp(),
      });

    // Get user ID from subscription
    const subscriptionDoc = await admin
      .firestore()
      .collection("subscriptions")
      .doc(subscriptionId)
      .get();

    if (!subscriptionDoc.exists) {
      throw new Error("Subscription not found");
    }

    const subscriptionData = subscriptionDoc.data();
    if (!subscriptionData) return;

    // Update user's active subscriptions
    await admin
      .firestore()
      .collection("users")
      .doc(subscriptionData.userId)
      .collection("activeSubscriptions")
      .doc(subscriptionId)
      .update({
        status: "authentication_failed",
        updatedAt: admin.firestore.FieldValue.serverTimestamp(),
      });
  } catch (error) {
    console.error(
      "Error handling subscription authentication failed event:",
      error
    );
  }
}

/**
 * Handle subscription created event - charge customer immediately
 */
async function handleSubscriptionCreated(subscription: any) {
  try {
    const subscriptionId = subscription.id;
    console.log(
      `Subscription created: ${subscriptionId}, charging immediately`
    );

    // Get the subscription details from Firestore
    const subscriptionDoc = await admin
      .firestore()
      .collection("subscriptions")
      .doc(subscriptionId)
      .get();

    if (!subscriptionDoc.exists) {
      throw new Error("Subscription not found in Firestore");
    }

    const subscriptionData = subscriptionDoc.data();
    if (!subscriptionData) return;

    // Create an order for the full amount
    const orderOptions = {
      amount: Math.round(subscriptionData.amount * 100), // Razorpay expects amount in paise
      currency: subscriptionData.currency || "INR",
      receipt: `initial_subscription_${subscriptionId}`,
      notes: {
        userId: subscriptionData.userId,
        subscriptionId: subscriptionId,
        type: "initialSubscriptionCharge",
      },
      payment_capture: 1, // Auto-capture payment
    };

    // Create a Razorpay order for the initial payment
    const order = await razorpayInstance.orders.create(orderOptions);
    console.log("Initial payment order created:", order);

    // Update subscription status
    await admin
      .firestore()
      .collection("subscriptions")
      .doc(subscriptionId)
      .update({
        initialChargeRequested: true,
        initialOrderId: order.id,
        updatedAt: admin.firestore.FieldValue.serverTimestamp(),
      });
  } catch (error) {
    console.error("Error handling subscription created event:", error);
  }
}

/**
 * Create a Razorpay order for wallet top-up (callable version)
 */
export const createWalletTopUpOrder = functions.https.onCall(
  async (data, context) => {
    // Check if user is authenticated
    if (!context.auth) {
      throw new functions.https.HttpsError(
        "unauthenticated",
        "User must be authenticated to create a wallet top-up order."
      );
    }

    try {
      const userId = context.auth.uid;

      // Validate required fields
      if (!data.amount || data.amount <= 0) {
        throw new functions.https.HttpsError(
          "invalid-argument",
          "Amount must be greater than 0"
        );
      }

      const currency = data.currency || "INR";

      // Create order options for wallet top-up
      const orderOptions = {
        amount: Math.round(data.amount * 100), // Razorpay expects amount in paise
        currency: currency,
        receipt: `wallet_topup_${Date.now()}_${userId.substring(0, 5)}`,
        notes: {
          userId: userId,
          type: "walletTopUp",
          amount: data.amount.toString(),
        },
        payment_capture: 1, // Auto-capture payment
      };

      // Create Razorpay order
      const order = await razorpayInstance.orders.create(orderOptions);

      // Return order details to client
      return {
        orderId: order.id,
        amount: data.amount,
        currency,
        key_id: functions.config().razorpay?.key_id,
      };
    } catch (error) {
      console.error("Error creating wallet top-up order:", error);
      throw new functions.https.HttpsError(
        "internal",
        "Failed to create wallet top-up order",
        error
      );
    }
  }
);

/**
 * Verify and process wallet top-up payment (callable version)
 */
export const verifyWalletTopUp = functions.https.onCall(
  async (data, context) => {
    // Check if user is authenticated
    if (!context.auth) {
      throw new functions.https.HttpsError(
        "unauthenticated",
        "User must be authenticated to verify wallet top-up."
      );
    }

    try {
      // Extract request data
      const { razorpay_order_id, razorpay_payment_id, razorpay_signature } =
        data;

      // Validate required fields
      if (!razorpay_order_id || !razorpay_payment_id || !razorpay_signature) {
        throw new functions.https.HttpsError(
          "invalid-argument",
          "Missing required payment verification parameters"
        );
      }

      // Generate expected signature
      const text = `${razorpay_order_id}|${razorpay_payment_id}`;
      const secret = functions.config().razorpay?.key_secret;
      const generatedSignature = crypto
        .createHmac("sha256", secret)
        .update(text)
        .digest("hex");

      // Compare signatures
      if (generatedSignature !== razorpay_signature) {
        throw new functions.https.HttpsError(
          "permission-denied",
          "Invalid payment signature"
        );
      }

      // Get order details from Razorpay to confirm amount and user
      const order = await razorpayInstance.orders.fetch(razorpay_order_id);

      if (
        !order ||
        !order.notes ||
        !order.notes.userId ||
        !order.notes.amount
      ) {
        throw new functions.https.HttpsError(
          "not-found",
          "Invalid order data. Cannot retrieve user or amount information."
        );
      }

      const userId = order.notes.userId;
      const amount = parseFloat(order.notes.amount.toString());
      const currency = order.currency || "INR";

      // Verify the authenticated user matches the order's user
      if (context.auth.uid !== userId) {
        throw new functions.https.HttpsError(
          "permission-denied",
          "User does not match the order's user"
        );
      }

      // Reference to the user's wallet document - there is only ONE document per user
      const walletRef = admin.firestore().collection("wallets").doc(userId);

      // Use a transaction to safely update the wallet balance
      await admin.firestore().runTransaction(async (transaction) => {
        // Get the current wallet document
        const walletDoc = await transaction.get(walletRef);

        // Get current balance or initialize to 0 if wallet doesn't exist yet
        let currentBalance = 0;
        if (walletDoc.exists) {
          const walletData = walletDoc.data();
          currentBalance = walletData?.balance || 0;
        }

        // Calculate new balance
        const newBalance = currentBalance + amount;

        // Update the existing wallet document or create it if it doesn't exist yet
        // Using { merge: true } ensures we don't overwrite any other fields
        transaction.set(
          walletRef,
          {
            userId: userId,
            balance: newBalance, // Update the balance with the new total
            currency: currency,
            updatedAt: admin.firestore.FieldValue.serverTimestamp(),
            // Only add createdAt when creating a new wallet document
            ...(walletDoc.exists
              ? {}
              : { createdAt: admin.firestore.FieldValue.serverTimestamp() }),
          },
          { merge: true }
        );

        // Create transaction record for audit purposes (this is a separate collection)
        const transactionRef = admin
          .firestore()
          .collection("walletTransactions")
          .doc();

        transaction.set(transactionRef, {
          transactionId: transactionRef.id,
          userId: userId,
          type: "credit",
          amount: amount,
          currency: currency,
          source: "top-up",
          orderId: razorpay_order_id,
          paymentId: razorpay_payment_id,
          description: "Wallet top-up",
          previousBalance: currentBalance,
          newBalance: newBalance,
          createdAt: admin.firestore.FieldValue.serverTimestamp(),
        });
      });

      return {
        success: true,
        message: "Wallet top-up successful",
      };
    } catch (error) {
      console.error("Error verifying wallet top-up:", error);
      throw new functions.https.HttpsError(
        "internal",
        error instanceof functions.https.HttpsError
          ? error.message
          : "Failed to verify wallet top-up",
        error
      );
    }
  }
);

/**
 * Update an existing Razorpay subscription
 */
export const updateSubscription = functions.https.onCall(
  async (data, context) => {
    // Check if user is authenticated
    if (!context.auth) {
      throw new functions.https.HttpsError(
        "unauthenticated",
        "User must be authenticated to update a subscription."
      );
    }

    try {
      // Validate required parameters
      if (!data.subscriptionId) {
        throw new functions.https.HttpsError(
          "invalid-argument",
          "Subscription ID is required"
        );
      }

      const userId = context.auth.uid;

      // Get current subscription data
      const subscriptionDoc = await admin
        .firestore()
        .collection("subscriptions")
        .doc(data.subscriptionId)
        .get();

      if (!subscriptionDoc.exists) {
        throw new functions.https.HttpsError(
          "not-found",
          "Subscription not found"
        );
      }

      const subscription = subscriptionDoc.data();

      // Verify the authenticated user is the owner of the subscription
      if (subscription?.userId !== userId) {
        throw new functions.https.HttpsError(
          "permission-denied",
          "User is not authorized to update this subscription"
        );
      }

      // Check if subscription is active
      if (subscription?.status !== "active") {
        throw new functions.https.HttpsError(
          "failed-precondition",
          "Only active subscriptions can be updated"
        );
      }

      let updateFields = {};
      let razorpayUpdateRequired = false;
      const razorpayUpdateData: Record<string, any> = {};

      // Check what fields need to be updated
      if (data.quantity && data.quantity !== subscription.quantity) {
        updateFields = { ...updateFields, quantity: data.quantity };
        razorpayUpdateData.quantity = data.quantity;
        razorpayUpdateRequired = true;
      }

      // Check if meal item selection changed
      if (data.itemId && data.itemId !== subscription.itemId) {
        updateFields = { ...updateFields, itemId: data.itemId };
        // Note: Changing the item requires notes to be updated in Razorpay
        razorpayUpdateData.notes = {
          ...subscription.notes,
          itemId: data.itemId,
        };
        razorpayUpdateRequired = true;
      }

      // Check if frequency changed (breakfast, lunch, dinner, snack)
      if (data.mealTime && data.mealTime !== subscription.mealTime) {
        updateFields = { ...updateFields, mealTime: data.mealTime };
        // Update notes in Razorpay
        razorpayUpdateData.notes = {
          ...(razorpayUpdateData.notes || subscription.notes || {}),
          mealTime: data.mealTime,
        };
        razorpayUpdateRequired = true;
      }

      // If no updates needed, return early
      if (!razorpayUpdateRequired) {
        return {
          success: false,
          message: "No changes to update",
        };
      }

      // Update subscription in Razorpay
      await razorpayInstance.subscriptions.update(
        data.subscriptionId,
        razorpayUpdateData
      );

      // Log the update operation
      updateFields = {
        ...updateFields,
        updatedAt: admin.firestore.FieldValue.serverTimestamp(),
        lastUpdateType: "user_update",
        lastUpdateDetails: data,
      };

      // Update subscription in Firestore
      await admin
        .firestore()
        .collection("subscriptions")
        .doc(data.subscriptionId)
        .update(updateFields);

      // Update active subscription in user collection
      await admin
        .firestore()
        .collection("users")
        .doc(userId)
        .collection("activeSubscriptions")
        .doc(data.subscriptionId)
        .update(updateFields);

      return {
        success: true,
        message: "Subscription updated successfully",
      };
    } catch (error) {
      console.error("Error updating subscription:", error);
      throw new functions.https.HttpsError(
        "internal",
        "Failed to update subscription",
        error
      );
    }
  }
);

/**
 * Cancel a Razorpay subscription
 */
export const cancelSubscription = functions.https.onCall(
  async (data, context) => {
    // Check if user is authenticated
    if (!context.auth) {
      throw new functions.https.HttpsError(
        "unauthenticated",
        "User must be authenticated to cancel a subscription."
      );
    }

    try {
      // Validate required parameters
      if (!data.subscriptionId) {
        throw new functions.https.HttpsError(
          "invalid-argument",
          "Subscription ID is required"
        );
      }

      const userId = context.auth.uid;

      // Get current subscription data
      const subscriptionDoc = await admin
        .firestore()
        .collection("subscriptions")
        .doc(data.subscriptionId)
        .get();

      if (!subscriptionDoc.exists) {
        throw new functions.https.HttpsError(
          "not-found",
          "Subscription not found"
        );
      }

      const subscription = subscriptionDoc.data();

      // Verify the authenticated user is the owner of the subscription
      if (subscription?.userId !== userId) {
        throw new functions.https.HttpsError(
          "permission-denied",
          "User is not authorized to cancel this subscription"
        );
      }

      // Check if subscription is cancellable
      if (
        subscription?.status !== "active" &&
        subscription?.status !== "created"
      ) {
        throw new functions.https.HttpsError(
          "failed-precondition",
          "Subscription cannot be cancelled in its current state"
        );
      }

      // Cancel the subscription in Razorpay
      const cancelAtCycleEnd = data.cancelAtCycleEnd || false;

      await razorpayInstance.subscriptions.cancel(
        data.subscriptionId,
        cancelAtCycleEnd
      );

      // Update status in Firestore
      const updateFields = {
        status: cancelAtCycleEnd ? "scheduled_for_cancellation" : "cancelled",
        cancelledAt: admin.firestore.FieldValue.serverTimestamp(),
        cancelReason: data.reason || "User cancelled subscription",
        cancelAtCycleEnd: cancelAtCycleEnd,
        updatedAt: admin.firestore.FieldValue.serverTimestamp(),
      };

      // Update subscription in Firestore
      await admin
        .firestore()
        .collection("subscriptions")
        .doc(data.subscriptionId)
        .update(updateFields);

      // Update active subscription in user collection
      await admin
        .firestore()
        .collection("users")
        .doc(userId)
        .collection("activeSubscriptions")
        .doc(data.subscriptionId)
        .update(updateFields);

      return {
        success: true,
        message: cancelAtCycleEnd
          ? "Subscription scheduled for cancellation at the end of the billing cycle"
          : "Subscription cancelled successfully",
      };
    } catch (error) {
      console.error("Error cancelling subscription:", error);
      throw new functions.https.HttpsError(
        "internal",
        "Failed to cancel subscription",
        error
      );
    }
  }
);

/**
 * Process coupon-based wallet credits for both user and affiliate
 */
export const processCouponWalletCredits = functions.https.onCall(
  async (data, context) => {
    // Check if user is authenticated
    if (!context.auth) {
      throw new functions.https.HttpsError(
        "unauthenticated",
        "User must be authenticated."
      );
    }

    try {
      const {
        userId,
        couponCode,
        discountAmount,
        commissionAmount,
        subscriptionId,
        orderId,
        originalAmount,
        finalAmount,
        subscriptionType,
      } = data;

      // Validate required fields
      if (!userId || !couponCode || !discountAmount || !commissionAmount) {
        throw new functions.https.HttpsError(
          "invalid-argument",
          "Missing required fields for wallet credit processing"
        );
      }

      console.log(`Processing wallet credits for coupon: ${couponCode}`);

      // Find affiliate by coupon code
      const affiliatesRef = admin.firestore().collection("affiliates");
      const affiliateSnapshot = await affiliatesRef
        .where("couponCode", "==", couponCode.toUpperCase())
        .where("isActive", "==", true)
        .get();

      if (affiliateSnapshot.empty) {
        throw new functions.https.HttpsError(
          "not-found",
          "Affiliate not found for coupon code"
        );
      }

      const affiliateDoc = affiliateSnapshot.docs[0];
      const affiliateData = affiliateDoc.data();
      const affiliateId = affiliateDoc.id;

      // Use Firestore transaction to ensure consistency
      await admin.firestore().runTransaction(async (transaction) => {
        // 1. Credit discount amount to user's wallet
        const userWalletRef = admin
          .firestore()
          .collection("wallets")
          .doc(userId);
        const userWalletDoc = await transaction.get(userWalletRef);

        if (!userWalletDoc.exists) {
          // Create new wallet for user
          transaction.set(userWalletRef, {
            userId: userId,
            balance: discountAmount,
            currency: "INR",
            createdAt: admin.firestore.FieldValue.serverTimestamp(),
            updatedAt: admin.firestore.FieldValue.serverTimestamp(),
          });
        } else {
          // Update existing wallet
          transaction.update(userWalletRef, {
            balance: admin.firestore.FieldValue.increment(discountAmount),
            updatedAt: admin.firestore.FieldValue.serverTimestamp(),
          });
        }

        // 2. Credit commission to affiliate's wallet
        const affiliateWalletRef = admin
          .firestore()
          .collection("wallets")
          .doc(affiliateData.userId);
        const affiliateWalletDoc = await transaction.get(affiliateWalletRef);

        if (!affiliateWalletDoc.exists) {
          // Create new wallet for affiliate
          transaction.set(affiliateWalletRef, {
            userId: affiliateData.userId,
            balance: commissionAmount,
            currency: "INR",
            createdAt: admin.firestore.FieldValue.serverTimestamp(),
            updatedAt: admin.firestore.FieldValue.serverTimestamp(),
          });
        } else {
          // Update existing wallet
          transaction.update(affiliateWalletRef, {
            balance: admin.firestore.FieldValue.increment(commissionAmount),
            updatedAt: admin.firestore.FieldValue.serverTimestamp(),
          });
        }

        // 3. Create wallet transaction for user (discount credit)
        const userTransactionRef = admin
          .firestore()
          .collection("walletTransactions")
          .doc();
        transaction.set(userTransactionRef, {
          transactionId: userTransactionRef.id,
          userId: userId,
          type: "credit",
          amount: discountAmount,
          currency: "INR",
          source: "coupon-discount",
          description: `Discount from coupon ${couponCode}`,
          orderId: orderId || "",
          subscriptionId: subscriptionId || "",
          referenceId: affiliateId,
          status: "completed",
          createdAt: admin.firestore.FieldValue.serverTimestamp(),
        });

        // 4. Create wallet transaction for affiliate (commission credit)
        const affiliateTransactionRef = admin
          .firestore()
          .collection("walletTransactions")
          .doc();
        transaction.set(affiliateTransactionRef, {
          transactionId: affiliateTransactionRef.id,
          userId: affiliateData.userId,
          type: "credit",
          amount: commissionAmount,
          currency: "INR",
          source: "affiliate-commission",
          description: `Commission from referral using coupon ${couponCode}`,
          orderId: orderId || "",
          subscriptionId: subscriptionId || "",
          referenceId: userId, // Reference to the user who used the coupon
          status: "completed",
          createdAt: admin.firestore.FieldValue.serverTimestamp(),
        });

        // 5. Create/Update coupon usage record
        const couponUsageRef = admin
          .firestore()
          .collection("couponUsages")
          .doc();
        transaction.set(couponUsageRef, {
          usageId: couponUsageRef.id,
          couponCode: couponCode,
          affiliateId: affiliateId,
          userId: userId,
          orderId: orderId || "",
          subscriptionId: subscriptionId || "",
          discountAmount: discountAmount,
          commissionAmount: commissionAmount,
          subscriptionType: subscriptionType || "monthly",
          originalAmount: originalAmount,
          finalAmount: finalAmount,
          status: "processed", // Mark as processed since we're crediting wallets immediately
          createdAt: admin.firestore.FieldValue.serverTimestamp(),
          processedAt: admin.firestore.FieldValue.serverTimestamp(),
        });

        // 6. Update affiliate stats
        transaction.update(
          admin.firestore().collection("affiliates").doc(affiliateId),
          {
            totalEarnings:
              admin.firestore.FieldValue.increment(commissionAmount),
            totalReferrals: admin.firestore.FieldValue.increment(1),
            updatedAt: admin.firestore.FieldValue.serverTimestamp(),
          }
        );
      });

      console.log(
        `Successfully processed wallet credits for coupon: ${couponCode}`
      );

      return {
        success: true,
        message: "Wallet credits processed successfully",
        userCreditAmount: discountAmount,
        affiliateCreditAmount: commissionAmount,
      };
    } catch (error: any) {
      console.error("Error processing wallet credits:", error);
      throw new functions.https.HttpsError(
        "internal",
        "Failed to process wallet credits",
        error
      );
    }
  }
);

/**
 * Enhanced webhook to handle subscription payment success and trigger coupon wallet credits
 */
