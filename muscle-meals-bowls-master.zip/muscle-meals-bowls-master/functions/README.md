# Firebase Functions for Razorpay Integration

This directory contains Firebase Cloud Functions to handle Razorpay payment processing for meal plan subscriptions.

## Functions Overview

1. **createRazorpayOrder** - Creates a new order in Razorpay and stores subscription data in Firestore
2. **verifyRazorpayPayment** - Verifies payment signatures and updates subscription status
3. **razorpayWebhook** - Handles webhook events from Razorpay for automated status updates

## Installation and Setup

### 1. Install Dependencies

```bash
cd functions
npm install
```

### 2. Set Razorpay API Keys

```bash
firebase functions:config:set razorpay.key_id="YOUR_RAZORPAY_KEY_ID" razorpay.key_secret="YOUR_RAZORPAY_KEY_SECRET" razorpay.webhook_secret="YOUR_WEBHOOK_SECRET"
```

### 3. Local Testing

```bash
npm run serve
```

### 4. Deployment

```bash
npm run deploy
```

## Firestore Structure

The functions create and manage the following collections:

- **subscriptions**: Stores all subscription orders
- **users/{userId}/activeSubscriptions**: Stores active subscriptions for each user

## Webhook Configuration

After deploying the functions, you need to configure the webhook in your Razorpay dashboard:

1. Go to the Razorpay Dashboard > Settings > Webhooks
2. Add a new webhook with the URL: `https://<your-region>-<your-project-id>.cloudfunctions.net/razorpayWebhook`
3. Set the webhook secret (same as used in the configuration)
4. Select events to listen for: `payment.authorized`, `payment.failed`

## Security Considerations

- Never hardcode API keys in your code - use Firebase Config instead
- Always verify webhook signatures to prevent fraudulent requests
- Implement proper error handling as shown in the functions
- Use environment variables for different deployment environments (dev/prod)

## Testing

To test the integration locally:

1. Use the Firebase Emulator Suite: `npm run serve`
2. Use a tool like ngrok to expose your local server for webhook testing
3. Set up a test account in Razorpay's dashboard for sandbox testing
