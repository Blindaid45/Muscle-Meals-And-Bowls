# Meal Plan Subscription Feature Deployment Guide

This guide provides step-by-step instructions for deploying the meal plan subscription feature, including both the frontend components and the backend Firebase Cloud Functions.

## Pre-requisites

- Node.js 14+ installed
- Firebase CLI installed (`npm install -g firebase-tools`)
- Firebase project already set up
- Razorpay account with API keys

## Deployment Steps

### 1. Setup Firebase Functions

1. Navigate to the functions directory:
   ```bash
   cd functions
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Set your Razorpay API keys in Firebase config:
   ```bash
   firebase functions:config:set razorpay.key_id="YOUR_RAZORPAY_KEY_ID" razorpay.key_secret="YOUR_RAZORPAY_KEY_SECRET" razorpay.webhook_secret="YOUR_WEBHOOK_SECRET"
   ```

4. Build and deploy the functions:
   ```bash
   npm run build
   firebase deploy --only functions
   ```

### 2. Frontend Configuration

1. Update the Razorpay configuration in `src/lib/razorpay.ts`:
   - Set `USE_MOCK_MODE` to `false`
   - Update the `RAZORPAY_KEY_ID` with your actual Razorpay key

2. Update the SubscriptionPlanModal component in `src/components/mealPlan/SubscriptionPlanModal.tsx`:
   - Set `USE_MOCK_MODE` to `false`

3. Build and deploy the frontend:
   ```bash
   npm run build
   firebase deploy --only hosting
   ```

### 3. Razorpay Dashboard Configuration

1. Log in to your Razorpay dashboard

2. Set up a webhook in Settings > Webhooks:
   - URL: `https://<your-region>-<your-project-id>.cloudfunctions.net/razorpayWebhook`
   - Secret: Same as what you used in Firebase config
   - Events to subscribe: `payment.authorized`, `payment.failed`

3. Save and activate the webhook

### 4. Testing the Integration

1. Create a meal plan in the app
2. Click the "Subscribe" button on a meal plan
3. Configure your subscription (duration, billing frequency, etc.)
4. Click "Proceed to Payment"
5. Complete the payment flow using Razorpay test cards:
   - Card Number: 4111 1111 1111 1111
   - Expiry: Any future date
   - CVV: Any 3 digits
   - Name: Any name
   - 3D Secure Password: 1234

6. Verify that the subscription is created in the Firestore database:
   - Check the `subscriptions` collection
   - Check the user's `activeSubscriptions` subcollection

### 5. Monitoring and Troubleshooting

1. Monitor function logs:
   ```bash
   firebase functions:log
   ```

2. Check Razorpay webhook logs in the Razorpay dashboard

3. Common issues:
   - CORS errors: Ensure proper CORS configuration
   - Function timeouts: Check function execution time
   - Invalid signatures: Verify API keys and secrets

### 6. Production Considerations

1. Set up Firebase Functions scaling configuration if needed

2. Enable logging and error tracking

3. Consider setting up monitoring alerts for function failures

4. Implement a periodic backup strategy for subscription data

5. Consider implementing a subscription management UI for users

## Switching Between Mock Mode and Live Mode

For development or testing purposes, you can switch between mock mode and live mode:

1. In `src/lib/razorpay.ts` and `src/components/mealPlan/SubscriptionPlanModal.tsx`:
   - Set `USE_MOCK_MODE = true` for development/testing
   - Set `USE_MOCK_MODE = false` for production

2. When in mock mode:
   - No Firebase Functions are called
   - No real Razorpay transactions are made
   - The UI shows a "Mock Mode" indicator

## Firestore Data Structure

The following collections are used for the subscription feature:

1. `subscriptions`: Stores all subscription orders
   - Document ID: Razorpay Order ID
   - Fields: userId, amount, currency, status, etc.

2. `users/{userId}/activeSubscriptions`: 
   - Document ID: Subscription ID (same as Razorpay Order ID)
   - Fields: Full subscription details including start/end dates, frequency, etc. 