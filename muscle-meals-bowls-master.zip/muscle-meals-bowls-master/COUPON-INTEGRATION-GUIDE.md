# Coupon System Integration Guide

## Overview

This guide shows you exactly where and how to integrate the affiliate coupon validation system into your subscription flows.

## 💡 **NEW: Stacked Discount System**

**🎯 Affiliate coupons now apply AFTER bulk discounts, not on original price!**

### 📊 How Discounts Stack

```
📋 Example Pricing Flow:
1. Original Price: ₹1,000 (30-day subscription)
2. Bulk Discount (15%): ₹1,000 - ₹150 = ₹850
3. Affiliate Coupon (10%): ₹850 - ₹85 = ₹765
4. Final Price: ₹765

💰 Commission Calculation:
- Commission Base: ₹1,000 (original retail price)
- Commission Rate: 10% (monthly subscription)
- Commission Amount: ₹100 (paid to affiliate)

💳 Wallet Credits:
- User gets: ₹85 (affiliate discount amount)
- Affiliate gets: ₹100 (commission on retail price)
```

### 🔄 Technical Implementation

**Frontend Changes:**

- ✅ CouponValidationForm receives bulk-discounted amount as base
- ✅ PriceSummary shows both discounts separately
- ✅ Commission calculated on original retail price
- ✅ Clear terminology: "Base Amount (after bulk discount)"

**Backend Changes:**

- ✅ `retailAmount` field stores original price for commission
- ✅ `originalAmount` stores bulk-discounted amount for affiliate discount
- ✅ Commission calculation uses `retailAmount`
- ✅ Wallet credits use affiliate discount amount

### 💻 Code Implementation

**In SubscriptionPlanModal:**

```typescript
// Calculate bulk discount
const bulkDiscountRate =
  days > 30 ? 0.2 : days > 14 ? 0.15 : days > 7 ? 0.1 : 0;
const bulkDiscountedAmount = totalPrice * (1 - bulkDiscountRate);

// Pass bulk-discounted amount to coupon validation
<CouponValidationForm
  subscriptionAmount={bulkDiscountedAmount} // Not totalPrice!
  subscriptionType="monthly"
  onValidationResult={handleCouponValidation}
/>;

// In payment data
const subscriptionData = {
  amount: discountedPrice, // Final amount after all discounts
  ...(couponValidation?.isValid && {
    originalAmount: bulkDiscountedAmount, // Base for affiliate discount
    retailAmount: totalPrice, // Original price for commission
    discountAmount: couponValidation.discountAmount,
  }),
};
```

**In Cloud Function:**

```typescript
// Calculate commission on retail amount
const commissionBaseAmount =
  subscriptionData.retailAmount || subscriptionData.originalAmount;
const commissionAmount =
  Math.round(commissionBaseAmount * commissionRate * 100) / 100;
```

## 🔄 Complete Affiliate Wallet Flow (UPDATED!)

**🎉 FULLY IMPLEMENTED: Real-time Wallet Credits**

The affiliate system now includes automatic wallet credits for both users and affiliates:

### 📋 Complete Flow

1. **User applies coupon** → Gets discount in subscription
2. **Payment successful** → Razorpay webhook triggers
3. **Cloud function detects coupon** → Processes wallet credits automatically
4. **Real-time wallet updates** → Both users see immediate balance updates

### 💰 Wallet Credit Details

**For Users (Discount Recipients):**

- ✅ Discount amount credited to wallet immediately
- ✅ Can be used for future purchases
- ✅ Transaction record created with description: "Discount from coupon CODECODENAMEMMB"

**For Affiliates (Commission Earners):**

- ✅ Commission credited to wallet immediately
- ✅ 10% for monthly subscriptions, 5% for weekly
- ✅ Transaction record created with description: "Commission from referral using coupon CODECODENAMEMMB"

### 🏗️ Technical Implementation

**Cloud Functions Added:**

- `processCouponWalletCredits` - Manual processing if needed
- `processCouponWalletCreditsInternal` - Automatic webhook processing
- Enhanced `handleSubscriptionCharged` - Detects coupon usage

**Frontend Integration:**

- Modified `SubscriptionPlanModal.tsx` to pass coupon data
- Updated `razorpay.ts` to include coupon information in orders
- Enhanced notification system to show wallet credits

**Automatic Processing:**

```typescript
// When subscription payment succeeds, webhook automatically:
if (subscriptionData.couponCode && subscriptionData.discountAmount) {
  // 1. Calculate commission (10% monthly, 5% weekly)
  const commissionRate =
    subscriptionData.subscriptionType === "monthly" ? 0.1 : 0.05;

  // 2. Credit both wallets in single transaction
  await processCouponWalletCreditsInternal({
    userId: subscriptionData.userId,
    couponCode: subscriptionData.couponCode,
    discountAmount: subscriptionData.discountAmount,
    commissionAmount: commissionAmount,
    // ... other data
  });
}
```

### 🔒 Data Consistency Features

- **Firestore Transactions**: All wallet operations use transactions for consistency
- **Atomic Operations**: User wallet, affiliate wallet, and usage records updated together
- **Error Handling**: Wallet credit failures don't break main subscription flow
- **Audit Trail**: Complete transaction history for both users

## 🎯 Integration Points

### 1. Subscription Modal Integration ✅ (Already Implemented)

**Location**: `src/components/mealPlan/SubscriptionPlanModal.tsx`

The coupon validation form has been integrated into the subscription modal. Here's what was added:

```typescript
// Import the component
import { CouponValidationForm } from "../affiliate";

// State for coupon validation
const [couponValidation, setCouponValidation] = useState<{
  isValid: boolean;
  discountAmount: number;
  finalAmount: number;
  affiliateId?: string;
} | null>(null);

// Handle coupon validation results
const handleCouponValidation = (result) => {
  setCouponValidation(result);
};

// Update price calculation to include coupon discount
useEffect(() => {
  // ... existing price calculation ...

  // Apply coupon discount if valid
  if (couponValidation?.isValid) {
    setDiscountedPrice(couponValidation.finalAmount);
  } else {
    setDiscountedPrice(finalDiscountedPrice);
  }
}, [startDate, endDate, mealPlan, couponValidation]);

// Include coupon data in subscription
const subscriptionData = {
  // ... existing data ...

  // Include coupon data if valid
  ...(couponValidation?.isValid && {
    couponCode: couponValidation.couponCode,
    originalAmount: totalPrice,
    discountAmount: couponValidation.discountAmount,
    affiliateId: couponValidation.affiliateId,
  }),
};
```

**In the JSX**:

```typescript
{
  /* COUPON VALIDATION INTEGRATION - Add this before price summary */
}
<CouponValidationForm
  subscriptionAmount={totalPrice}
  subscriptionType={
    getDaysBetween(startDate, endDate) <= 14 ? "weekly" : "monthly"
  }
  onValidationResult={handleCouponValidation}
/>;
```

### 2. Other Integration Points

You can integrate the coupon system in any subscription flow by following this pattern:

#### A. Cart Page Integration

**Location**: `src/pages/CartPage.tsx`

```typescript
import { CouponValidationForm } from "@/components/affiliate";

// Add to your cart component before checkout
<CouponValidationForm
  subscriptionAmount={cartTotal}
  subscriptionType="monthly" // or "weekly" based on cart contents
  onValidationResult={handleCouponValidation}
/>;
```

#### B. Direct Meal Subscription

**Location**: `src/components/meals/SubscriptionModal.tsx`

```typescript
import { CouponValidationForm } from "@/components/affiliate";

// Add before payment section
<CouponValidationForm
  subscriptionAmount={subscriptionAmount}
  subscriptionType={selectedPlan} // weekly or monthly
  onValidationResult={handleCouponValidation}
/>;
```

#### C. Subscription Plan Cards

**Location**: `src/components/subscription/SubscriptionPlanCard.tsx`

```typescript
// Add coupon validation in the subscription flow
<CouponValidationForm
  subscriptionAmount={plan.price}
  subscriptionType={plan.frequency}
  onValidationResult={handleCouponValidation}
/>
```

## 🔧 Implementation Steps

### Step 1: Import the Component

```typescript
import { CouponValidationForm } from "@/components/affiliate";
```

### Step 2: Add State Management

```typescript
const [couponValidation, setCouponValidation] = useState(null);

const handleCouponValidation = (result) => {
  setCouponValidation(result);
  // Update your pricing calculations here
};
```

### Step 3: Update Price Calculations

```typescript
// Apply coupon discount to your existing price calculation
const finalAmount = couponValidation?.isValid
  ? couponValidation.finalAmount
  : originalAmount;
```

### Step 4: Add to JSX

```typescript
<CouponValidationForm
  subscriptionAmount={originalAmount}
  subscriptionType="monthly" // or "weekly"
  onValidationResult={handleCouponValidation}
/>
```

### Step 5: Include in Payment Data

```typescript
const paymentData = {
  // ... your existing payment data ...

  // Include coupon information if valid
  ...(couponValidation?.isValid && {
    couponCode: couponValidation.couponCode,
    originalAmount: originalAmount,
    discountAmount: couponValidation.discountAmount,
    affiliateId: couponValidation.affiliateId,
  }),
};
```

### Step 6: Process After Payment

After successful payment, call the coupon processing service:

```typescript
import { processCouponUsage } from "@/services/affiliateService";

// After successful payment
if (couponValidation?.isValid) {
  await processCouponUsage({
    couponCode: couponValidation.couponCode,
    subscriptionId: subscription.id,
    orderId: order.id,
    originalAmount: originalAmount,
    discountAmount: couponValidation.discountAmount,
    finalAmount: couponValidation.finalAmount,
    subscriptionType: subscriptionType,
    affiliateId: couponValidation.affiliateId,
  });
}
```

## 📱 Modern UI Features

The affiliate system now includes:

### ✨ Modern Design Elements

- **Avvvatars**: Unique user avatars based on email/ID
- **Lucide Icons**: Modern, consistent iconography
- **Framer Motion**: Smooth animations and transitions
- **Gradient Backgrounds**: Beautiful visual design
- **Glass Morphism**: Modern backdrop blur effects

### 🎨 Color Theme Integration

The components use the existing Tailwind color scheme:

- **Primary**: Indigo/Purple gradients
- **Success**: Green tones
- **Warning**: Orange tones
- **Error**: Red tones

### 📱 Responsive Design

All components are fully responsive with:

- Mobile-first approach
- Tablet breakpoints
- Desktop optimizations

## 🔒 Security Features

- **Self-referral prevention**: Users cannot use their own codes
- **Real-time validation**: Instant feedback on coupon validity
- **UPI validation**: Proper format checking
- **Error boundaries**: Graceful error handling

## 📊 Analytics & Tracking

The system automatically tracks:

- Coupon usage statistics
- Affiliate earnings
- Commission processing
- Referral history

## 🛠 Troubleshooting

### Common Issues

1. **Loading Issues**: Fixed with timeout handling (3-second max)
2. **State Management**: Proper Redux integration with timestamp conversion
3. **UI Responsiveness**: Mobile-optimized layouts

### Where to Find Components

- **Affiliate Page**: `/user/affiliate`
- **Registration Form**: `src/components/affiliate/AffiliateRegistrationForm.tsx`
- **Dashboard**: `src/components/affiliate/AffiliateDashboard.tsx`
- **Coupon Validation**: `src/components/affiliate/CouponValidationForm.tsx`

## 🚀 Getting Started

1. **Become an Affiliate**: Go to `/user/affiliate` and register
2. **Get Your Code**: Receive your unique `YOURCODENAMEMMB` coupon
3. **Share & Earn**: Share with friends and start earning commissions
4. **Track Earnings**: Monitor your dashboard for real-time statistics

## 💡 Best Practices

1. **Place coupon validation before payment**: Users should see discounts before paying
2. **Show clear pricing breakdown**: Display original, discount, and final amounts
3. **Provide immediate feedback**: Real-time validation with clear success/error states
4. **Handle edge cases**: Network errors, invalid codes, expired coupons
5. **Test thoroughly**: Verify the complete flow from validation to commission payment

---

**Need Help?** Check the complete implementation in `SubscriptionPlanModal.tsx` for a working example!
