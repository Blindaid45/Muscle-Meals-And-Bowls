# 🎯 Stacked Discount System - Complete Example

## 📋 Real-World Example

### **Scenario**: 30-day meal plan subscription with affiliate coupon

---

## 💰 **Step-by-Step Pricing Breakdown**

### **Step 1: Base Pricing**

```
📊 Daily meal plan price: ₹50
📅 Subscription period: 30 days
💵 Subtotal: ₹50 × 30 = ₹1,500
```

### **Step 2: Bulk Discount Applied**

```
🛒 Bulk discount (30+ days): 20% off
💰 Bulk discount amount: ₹1,500 × 20% = ₹300
📉 After bulk discount: ₹1,500 - ₹300 = ₹1,200
```

### **Step 3: Affiliate Coupon Applied**

```
🎟️ Coupon code: JOHNDOEMMB
📱 Affiliate discount (monthly): 10% off bulk-discounted price
💳 Affiliate discount amount: ₹1,200 × 10% = ₹120
🎯 Final price: ₹1,200 - ₹120 = ₹1,080
```

### **Step 4: Commission Calculation**

```
💼 Commission base: ₹1,500 (original retail price)
📈 Commission rate: 10% (monthly subscription)
💰 Commission amount: ₹1,500 × 10% = ₹150
```

---

## 💳 **Wallet Credits Processed**

### **For the Customer:**

- **Amount Credited**: ₹120 (affiliate discount amount)
- **Source**: `coupon-discount`
- **Description**: "Discount from coupon JOHNDOEMMB"
- **Can be used for**: Future purchases

### **For the Affiliate (John Doe):**

- **Amount Credited**: ₹150 (commission on retail price)
- **Source**: `affiliate-commission`
- **Description**: "Commission from referral using coupon JOHNDOEMMB"
- **Can be used for**: Withdrawal to UPI

---

## 📊 **UI Display Breakdown**

### **Price Summary Component Shows:**

```
Daily meal plan price:           ₹50.00
Subscription period:             30 days
Subtotal:                        ₹1,500.00

Bulk discount (20% off):         -₹300.00
After bulk discount:             ₹1,200.00

Affiliate coupon discount:       -₹120.00

--------------------------------
Total:                           ₹1,080.00

You save ₹420.00 (28% total savings)
```

### **Coupon Validation Form Shows:**

```
🎉 Coupon Applied Successfully!
You saved ₹120 (10% off)

Base Amount (after bulk discount): ₹1,200
Affiliate Discount:                -₹120
Final Amount:                       ₹1,080
```

---

## 🔧 **Database Records Created**

### **1. Subscription Record**

```json
{
  "subscriptionId": "sub_abc123",
  "userId": "user_customer123",
  "amount": 1080,
  "couponCode": "JOHNDOEMMB",
  "originalAmount": 1200,
  "discountAmount": 120,
  "finalAmount": 1080,
  "retailAmount": 1500,
  "affiliateId": "affiliate_johndoe456",
  "subscriptionType": "monthly"
}
```

### **2. User Wallet Transaction**

```json
{
  "transactionId": "txn_user789",
  "userId": "user_customer123",
  "type": "credit",
  "amount": 120,
  "source": "coupon-discount",
  "description": "Discount from coupon JOHNDOEMMB",
  "previousBalance": 0,
  "newBalance": 120,
  "status": "completed"
}
```

### **3. Affiliate Wallet Transaction**

```json
{
  "transactionId": "txn_aff890",
  "userId": "user_johndoe456",
  "type": "credit",
  "amount": 150,
  "source": "affiliate-commission",
  "description": "Commission from referral using coupon JOHNDOEMMB",
  "previousBalance": 500,
  "newBalance": 650,
  "status": "completed"
}
```

### **4. Coupon Usage Record**

```json
{
  "usageId": "usage_xyz999",
  "couponCode": "JOHNDOEMMB",
  "affiliateId": "affiliate_johndoe456",
  "userId": "user_customer123",
  "subscriptionId": "sub_abc123",
  "discountAmount": 120,
  "commissionAmount": 150,
  "subscriptionType": "monthly",
  "originalAmount": 1200,
  "finalAmount": 1080,
  "status": "processed"
}
```

---

## ✅ **Benefits of This System**

### **For Customers:**

- 💰 **Double Savings**: Get both bulk and affiliate discounts
- 🔄 **Wallet Credit**: ₹120 credited for future use
- 💯 **Fair Pricing**: Discounts stack logically

### **For Affiliates:**

- 💸 **Higher Commissions**: Based on full retail price (₹150 vs ₹120)
- 📈 **Better Incentive**: Earn more when referring high-value customers
- ⚡ **Instant Payment**: Commission credited immediately

### **For Business:**

- 🎯 **Logical Stacking**: Bulk discounts first, then affiliate discounts
- 📊 **Clear Tracking**: Separate tracking of each discount type
- 🔒 **Consistent Rules**: Same commission structure regardless of bulk discounts

---

## 🚀 **Key Advantages**

1. **Customer gets the maximum possible discount** (both bulk + affiliate)
2. **Affiliate gets fair commission** on the retail value they helped sell
3. **Business maintains clear discount hierarchy** (bulk first, then affiliate)
4. **All parties benefit** from the stacked discount approach

This system ensures that affiliate discounts enhance the customer experience rather than compete with existing bulk discounts! 🎉
